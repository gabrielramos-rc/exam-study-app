# Question 023

**Source:** https://www.examtopics.com/discussions/google/view/83973-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** DLP, Sensitive Data Protection, PII, redaction, image redaction

---

## Question

When working with agents in the support center via online chat, your organization's customers often share pictures of their documents with personally identifiable information (PII). Your leadership team is concerned that this PII is being stored as part of the regular chat logs, which are reviewed by internal or external analysts for customer service trends. You want to resolve this concern while still maintaining data utility. What should you do?
## Choices

- **A.** Use Cloud Key Management Service to encrypt PII shared by customers before storing it for analysis.
- **B.** Use Object Lifecycle Management to make sure that all chat records containing PII are discarded and not saved for analysis.
- **C.** Use the image inspection and redaction actions of the DLP API to redact PII from the images before storing them for analysis. Most Voted
- **D.** Use the generalization and bucketing actions of the DLP API solution to redact PII from the texts before storing them for analysis.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (5 total)


**Top Comments:**

- (5 upvotes) Agree with C

- (4 upvotes) Answer is C

- (2 upvotes) C the q refers to imaging

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

The DLP API (now called Sensitive Data Protection) provides **image inspection and redaction** capabilities specifically designed for this use case. The service can:

1. **Inspect images** by accepting base64-encoded images and detecting PII using configurable infoType detectors
2. **Redact sensitive findings** by covering detected PII with opaque rectangles in the images
3. **Return modified images** in the original format, preserving data utility for trend analysis while removing PII

The `image.redact` API method scans submitted images for sensitive data matching your detection criteria, then returns a redacted version where all PII is masked with opaque boxes (with customizable colors). This maintains the utility of the chat logs for customer service trend analysis - analysts can still review conversations and understand context - while ensuring PII from customer-uploaded images is not stored in plaintext.

This approach directly addresses the requirement to "resolve this concern while still maintaining data utility" - the redacted images remain analyzable but without exposing PII.

### Why Other Options Are Wrong

- **A:** Cloud KMS encryption only protects data at rest or in transit. Encrypted PII is still PII - analysts with decryption access would still see the sensitive data. This doesn't solve the concern about analysts viewing PII, it only encrypts it in storage.

- **B:** Object Lifecycle Management discarding all records containing PII would eliminate data utility entirely. The organization specifically needs to maintain chat logs for customer service trend analysis, so discarding conversations with images would create significant data gaps and defeat the business purpose.

- **D:** Generalization and bucketing are de-identification techniques for **text data** (e.g., replacing "age 34" with "age 30-40"). These techniques don't work on images. Since customers are sharing "pictures of their documents," you need image-specific redaction, not text transformation methods.

### References

- [Image inspection and redaction | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/concepts-image-redaction)
- [De-identifying sensitive data | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/deidentify-sensitive-data)
- [De-identification and re-identification of PII in large-scale datasets](https://docs.cloud.google.com/architecture/de-identification-re-identification-pii-using-cloud-dlp)
