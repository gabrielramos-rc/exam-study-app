# Question 197

**Source:** https://www.examtopics.com/discussions/google/view/117176-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Binary Authorization, Cloud Run, container security, organization policy, trusted images

---

## Question

You run applications on Cloud Run. You already enabled container analysis for vulnerability scanning. However, you are concerned about the lack of control on the applications that are deployed. You must ensure that only trusted container images are deployed on Cloud Run. What should you do? (Choose two.)
## Choices

- **A.** Enable Binary Authorization on the existing Cloud Run service. Most Voted
- **B.** Set the organization policy constraint constraints/run.allowedBinaryAuthorizationPolicies to the list or allowed Binary Authorization policy names. Most Voted
- **C.** Enable Binary Authorization on the existing Kubernetes cluster.
- **D.** Use Cloud Run breakglass to deploy an image that meets the Binary Authorization policy by default.
- **E.** Set the organization policy constraint constraints/compute.trustedImageProjects to the list of projects that contain the trusted container images.

---

## Community

**Most Voted:** AB


**Votes:** AB: 86% | AE: 14% (14 total)


**Top Comments:**

- (5 upvotes) AB. C: No. The question doesn't have "the existing Kubernetes cluster". D: No. Why breakglass if we already took opt A? E: No. "compute.trustedImageProjects" is for Compute Engine. See the link below:

- (2 upvotes) To ensure that only trusted container images are deployed on Cloud Run, you should take the following actions: Option A: Enable Binary Authorization on the existing Cloud Run service. Binary Authoriza

- (2 upvotes) A speaks about authorization and E talks about using trusted images so AE are correct

---

## Answer

**Correct:** A, B

**Confidence:** high

### Explanation

To ensure only trusted container images are deployed on Cloud Run, you need to implement Binary Authorization, which requires two key actions:

**Option A - Enable Binary Authorization on the Cloud Run service** is essential because Binary Authorization must be explicitly enabled at the service level. This can be done via:
- Console: Security tab → "Verify container deployment with Binary Authorization" checkbox
- CLI: `gcloud run deploy SERVICE_NAME --binary-authorization=default`
- YAML: Add annotation `run.googleapis.com/binary-authorization: default`

Once enabled, Cloud Run will enforce signature validation and policy checks before deploying container images.

**Option B - Set the organization policy constraint constraints/run.allowedBinaryAuthorizationPolicies** is critical for governance and control. According to Google's documentation, "Binary Authorization can be disabled by Cloud Run developers if the policy is not configured." This constraint:
- Defines which Binary Authorization policy names may be specified on Cloud Run resources
- Prevents developers from bypassing Binary Authorization enforcement
- Can specify the default policy using the value "default" or custom platform policies using their resource IDs
- Ensures consistent security controls across all Cloud Run deployments in the organization

Together, these two controls provide both technical enforcement (A) and organizational governance (B) to ensure only trusted images are deployed.

### Why Other Options Are Wrong

- **C:** This option enables Binary Authorization on a Kubernetes cluster, but the question specifically asks about Cloud Run services, not GKE/Kubernetes. Binary Authorization for Cloud Run and GKE use different enablement mechanisms.

- **D:** Breakglass is an emergency mechanism that allows bypassing Binary Authorization policies in exceptional circumstances. Using it "by default" contradicts the security goal of ensuring only trusted images are deployed. Breakglass should be used sparingly for emergency situations, not as a standard deployment method.

- **E:** The constraint `constraints/compute.trustedImageProjects` is for Compute Engine VM instances, not Cloud Run. This constraint restricts which projects can provide boot disk images for VMs and is not applicable to container deployments on Cloud Run.

### References

- [Use Binary Authorization for Cloud Run](https://docs.cloud.google.com/run/docs/securing/binary-authorization)
- [Enable Binary Authorization for Cloud Run](https://docs.cloud.google.com/binary-authorization/docs/run/enabling-binauthz-cloud-run)
- [Organization Policy Constraints](https://docs.cloud.google.com/resource-manager/docs/organization-policy/org-policy-constraints)
