# Question 031

**Source:** https://www.examtopics.com/discussions/google/view/17841-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** disaster recovery, backup, Cloud Storage, data transfer, on-premises migration

---

## Question

An organization is starting to move its infrastructure from its on-premises environment to Google Cloud Platform (GCP). The first step the organization wants to take is to migrate its current data backup and disaster recovery solutions to GCP for later analysis. The organization's production environment will remain on- premises for an indefinite time. The organization wants a scalable and cost-efficient solution. Which GCP solution should the organization use?
## Choices

- **A.** BigQuery using a data pipeline job with continuous updates
- **B.** Cloud Storage using a scheduled task and gsutil Most Voted
- **C.** Compute Engine Virtual Machines using Persistent Disk
- **D.** Cloud Datastore using regularly scheduled batch upload jobs

---

## Community

**Most Voted:** B


**Votes:** A: 20% | B: 80% (5 total)


**Top Comments:**

- (24 upvotes) B is correct. It is about data backup, DR, not the database backup to GCP. BQ is not cost efficient compare to GCS

- (4 upvotes) B is the answer.

- (3 upvotes) It is B

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud Storage with scheduled tasks using gsutil (or gcloud storage) is the optimal solution for migrating backup and disaster recovery data from on-premises to GCP. This approach provides:

**Scalability**: Cloud Storage automatically scales to accommodate any amount of backup data without manual infrastructure provisioning. You can store petabytes of data without managing capacity.

**Cost-efficiency**: Cloud Storage offers multiple storage classes (Standard, Nearline, Coldline, Archive) optimized for different access patterns. For backup/DR data accessed infrequently, you can use Nearline or Coldline storage classes at significantly lower costs. You only pay for actual storage consumed.

**Simplicity**: The solution uses a straightforward architecture - install gcloud CLI on an on-premises machine, create a scheduled task (using crontab on Linux or Task Scheduler on Windows), and run gsutil commands to transfer backup files to a Cloud Storage bucket. The gcloud storage rsync command is particularly efficient for incremental backups, copying only changed data between backup sessions.

**No ongoing infrastructure management**: Unlike Compute Engine VMs, Cloud Storage is a fully managed service requiring no OS patching, capacity planning, or VM maintenance.

The documentation explicitly recommends this pattern: "One option for backing up data is to create a scheduled task that runs a script or application to transfer the data to Cloud Storage."

### Why Other Options Are Wrong

- **A (BigQuery with continuous data pipeline):** BigQuery is a data warehouse optimized for analytics queries, not a backup/DR storage solution. It's designed for structured data analysis, not storing raw backup files. Using continuous data pipelines for backup would be unnecessarily complex and expensive compared to simple file storage. BigQuery also charges for storage and queries, making it cost-inefficient for backup data that's rarely accessed.

- **C (Compute Engine VMs with Persistent Disk):** This requires managing virtual machine infrastructure (OS patching, security updates, capacity planning, availability) which contradicts the requirement for a cost-efficient solution. You'd pay for compute resources even when not actively transferring data. Persistent Disks also have size limits and require manual scaling. This adds operational overhead without providing benefits over object storage for backup purposes.

- **D (Cloud Datastore with batch uploads):** Cloud Datastore is a NoSQL document database designed for application data storage with fast queries and transactions. It's not appropriate for storing large backup files or unstructured backup data. The pricing model (based on operations and storage) would be expensive for large backup datasets. Like BigQuery, it's optimized for a completely different use case than backup/DR storage.

### References

- [Disaster recovery scenarios for data](https://docs.cloud.google.com/architecture/dr-scenarios-for-data)
- [gsutil tool documentation](https://docs.cloud.google.com/storage/docs/gsutil)
- [Transition from gsutil to gcloud storage](https://docs.cloud.google.com/storage/docs/gsutil-transition-to-gcloud)
