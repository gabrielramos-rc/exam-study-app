# Question 265

**Source:** https://www.examtopics.com/discussions/google/view/147059-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Determining regulatory requirements for the cloud
**Tags:** PCI DSS, compliance monitoring, Security Command Center, infrastructure compliance

---

## Question

Your organization must follow the Payment Card Industry Data Security Standard (PCI DSS). To prepare for an audit, you must detect deviations on an infrastructure-as-a-service level in your Google Cloud landing zone. What should you do?
## Choices

- **A.** Create a data profile covering all payment relevant data types. Configure Data Discovery and a risk analysis job in Google Cloud Sensitive Data Protection to analyze findings.
- **B.** Use the Google Cloud Compliance Reports Manager to download the latest version of the PCI DSS report Analyze the report to detect deviations.
- **C.** Create an Assured Workloads folder in your Google Cloud organization. Migrate existing projects into the folder and monitor for deviations in the PCI DSS.
- **D.** Activate Security Command Center Premium. Use the Compliance Monitoring product to filter findings that may not be PCI DSS compliant. Most Voted

---

## Community

**Most Voted:** D


**Votes:** A: 9% | D: 91% (11 total)


**Top Comments:**

- (5 upvotes) D. is the most direct and effective solution for detecting active deviations. Security Command Center Premium's Compliance Monitoring feature is specifically designed for this purpose. It automaticall

- (2 upvotes) https://cloud.google.com/security-command-center/docs/compliance-management

- (1 upvotes) D. A: No. This option only covers the data protection. PCI-DSS has other requirements, e.g. IAM, EKM, etc. B: No. This only download the checklist of PCI-DSS items. Not reflect to the snapshot of curr

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Security Command Center Premium with Compliance Manager (Compliance Monitoring product) is specifically designed to detect infrastructure-level deviations from compliance frameworks like PCI DSS in Google Cloud environments. The platform provides:

- **Pre-built PCI DSS Templates**: Predefined posture templates for PCI DSS v3.2.1 and v4.0 that include policy sets with Security Health Analytics detectors tailored for PCI DSS compliance
- **Infrastructure-Level Monitoring**: Evaluates Google Cloud resources against PCI DSS controls at the IaaS level, checking for misconfigurations, publicly exposed resources, and policy violations
- **Compliance Dashboards**: Displays compliance status as a percentage of controls passing, with detailed framework dashboards showing which controls are failing and how to remediate violations
- **Continuous Deviation Detection**: Monitors environment continuously and surfaces findings that violate PCI DSS controls, enabling teams to detect and address posture drift
- **Audit-Ready Reporting**: Provides downloadable CSV reports with control mapping, shared responsibility status, and compliance trends over time

This directly addresses the requirement to "detect deviations on an infrastructure-as-a-service level in your Google Cloud landing zone" for PCI DSS audit preparation.

### Why Other Options Are Wrong

- **A:** Sensitive Data Protection (DLP) focuses on discovering and protecting sensitive data at the data layer (PAN numbers, cardholder data), not detecting infrastructure-level compliance deviations. While useful for PCI DSS data protection requirements, it doesn't monitor IaaS configurations and security controls.

- **B:** Compliance Reports Manager provides Google's third-party audit reports and certifications showing that Google's infrastructure meets various compliance standards. These reports document Google's compliance, not your organization's use of Google Cloud resources. They don't detect deviations in your landing zone configuration.

- **C:** Assured Workloads helps establish compliant environments by enforcing controls at the folder level and provides monitoring for specific regulatory requirements. However, it's primarily designed for government and highly regulated workloads (FedRAMP, IL4, ITAR, etc.), and while it can support compliance, it's not the primary tool for PCI DSS infrastructure deviation detection across existing landing zones.

### References

- [Monitor your frameworks for compliance | Security Command Center](https://docs.cloud.google.com/security-command-center/docs/compliance-manager-monitor-framework)
- [Predefined posture template for PCI DSS v3.2.1 and v1.0](https://docs.cloud.google.com/security-command-center/docs/security-posture-pci-dss-template)
- [PCI Data Security Standard compliance | Cloud Architecture Center](https://docs.cloud.google.com/architecture/pci-dss-compliance-in-gcp)
