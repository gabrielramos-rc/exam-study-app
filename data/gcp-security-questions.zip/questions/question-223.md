# Question 223

**Source:** https://www.examtopics.com/discussions/google/view/117328-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Managing authentication
**Tags:** session management, gcloud CLI, reauthentication frequency, Google Cloud Session Control

---

## Question

After completing a security vulnerability assessment, you learned that cloud administrators leave Google Cloud CLI sessions open for days. You need to reduce the risk of attackers who might exploit these open sessions by setting these sessions to the minimum duration. What should you do?
## Choices

- **A.** Set the session duration for the Google session control to one hour.
- **B.** Set the reauthentication frequency for the Google Cloud Session Control to one hour. Most Voted
- **C.** Set the organization policy constraint constraints/iam.allowServiceAccountCredentialLifetimeExtension to one hour.
- **D.** Set the organization policy constraint constraints/iam.serviceAccountKeyExpiryHours to one hour and inheritFromParent to false.

---

## Community

**Most Voted:** B


**Votes:** A: 27% | B: 68% | D: 5% (22 total)


**Top Comments:**

- (3 upvotes) The best option would be B. Set the reauthentication frequency for the Google Cloud Session Control to one hour. This is because Google Cloud Session Control allows you to set a reauthentication frequ

- (3 upvotes) https://cloud.google.com/blog/products/identity-security/improve-security-posture-with-time-bound-session-length

- (3 upvotes) A and B both satisfies the question but the effective and easy to do will be A, BTW B does the same job

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Google Cloud Session Control allows administrators to enforce reauthentication for users accessing Google Cloud console and gcloud CLI. The reauthentication frequency setting specifically controls how often users must re-authenticate during active sessions, which directly addresses the security vulnerability of long-running CLI sessions.

Key technical points:
- **Reauthentication frequency** is the correct control for gcloud CLI sessions, with a minimum allowed value of 1 hour and maximum of 24 hours
- When reauthentication is required, gcloud CLI users must execute `gcloud auth login` to renew the session, which brings up a browser window for credential verification
- This setting applies to both Google Cloud console and Cloud SDK (gcloud) sessions
- Application Default Credentials (ADC) files also respect the session expiration and must be refreshed using `gcloud auth application-default login`
- This control ensures that even if administrators leave sessions "open," the refresh tokens expire at the end of the defined duration, limiting the window of opportunity for attackers to exploit compromised tokens

The reauthentication frequency is specifically designed to reduce the risk of session hijacking and credential theft by forcing periodic verification of user identity.

### Why Other Options Are Wrong

- **A:** "Session duration" is less precise terminology. While session duration exists as a concept, the specific control for gcloud CLI is called "reauthentication frequency" in Google Cloud Session Control. Session duration typically refers to the total session lifetime, whereas reauthentication frequency enforces periodic re-authentication during an active session.

- **C:** The constraint `constraints/iam.allowServiceAccountCredentialLifetimeExtension` is unrelated to user authentication sessions. This organization policy constraint controls whether service account credentials can have extended lifetimes beyond default limits, not human user CLI sessions.

- **D:** The constraint `constraints/iam.serviceAccountKeyExpiryHours` controls the maximum lifetime of service account keys (not user sessions). This is for service account key management and has no effect on gcloud CLI sessions used by human administrators. Additionally, this constraint accepts values in hours but is designed for longer-term key management (days/weeks), not hourly session controls.

### References

- [Set session length for Google Cloud services - Cloud Identity Help](https://support.google.com/cloudidentity/answer/9368756)
- [Configure session controls for re-authentication - Chrome Enterprise Premium](https://docs.cloud.google.com/chrome-enterprise-premium/docs/session-controls-for-reauthentication)
- [Best practices for mitigating compromised OAuth tokens for Google Cloud CLI](https://docs.cloud.google.com/architecture/bps-for-mitigating-gcloud-oauth-tokens)
