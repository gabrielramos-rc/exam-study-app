# Question 114

**Source:** https://www.examtopics.com/discussions/google/view/75714-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** firewall rules, Firewall Insights, Network Intelligence Center, shadowed rules

---

## Question

You recently joined the networking team supporting your company's Google Cloud implementation. You are tasked with familiarizing yourself with the firewall rules configuration and providing recommendations based on your networking and Google Cloud experience. What product should you recommend to detect firewall rules that are overlapped by attributes from other firewall rules with higher or equal priority?
## Choices

- **A.** Security Command Center
- **B.** Firewall Rules Logging
- **C.** VPC Flow Logs
- **D.** Firewall Insights Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (18 total)


**Top Comments:**

- (6 upvotes) Agreed

- (6 upvotes) To detect firewall rules that are overlapped by attributes from other firewall rules with higher or equal priority, you can use Firewall Insights. Firewall Insights is a feature of Google Cloud that p

- (3 upvotes) definitely D - https://cloud.google.com/network-intelligence-center/docs/firewall-insights/concepts/overview

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

**Firewall Insights** is the correct product for detecting shadowed firewall rules - rules that are overlapped by attributes from other firewall rules with higher or equal priority. Firewall Insights is part of Network Intelligence Center and provides specialized analysis of firewall rule configurations.

Specifically, Firewall Insights:
- **Detects shadowed rules**: Identifies firewall rules that share attributes (such as IP address ranges, ports, protocols) with other rules of higher or equal priority
- **Analyzes rule priority conflicts**: The shadowing rules (higher or equal priority) will be processed before the shadowed rules, making the shadowed rules ineffective
- **Provides configuration-based insights**: Analyzes your VPC firewall rules and firewall policies to detect these shadowed rules without requiring traffic data
- **Refreshes automatically**: Shadowed rule analysis evaluates existing firewall rule configuration every 24 hours

Example scenarios detected by Firewall Insights:
- **Overlapping IP ranges**: Rule A allows 10.10.0.0/16 while Rule B allows 10.10.0.0/24 with same priority - Rule B is shadowed by Rule A
- **Multiple shadowing rules**: Rule C allows HTTP/HTTPS (priority 1000) but is shadowed by Rules D and E which deny HTTP and HTTPS respectively (priority 900)

This analysis helps identify firewall misconfigurations where IP address filters are too broad or restrictive rules are rendered ineffective by higher-priority rules.

### Why Other Options Are Wrong

- **A. Security Command Center:** SCC focuses on security posture management, vulnerability detection, and threat detection across Google Cloud resources. While it can identify security findings and misconfigurations, it does not provide specialized firewall rule overlap analysis that detects shadowed rules based on priority and attribute overlap. This is a specific capability of Firewall Insights.

- **B. Firewall Rules Logging:** Firewall Rules Logging records information about connections matched by firewall rules, showing which rules are being hit by actual traffic. However, it does not analyze the firewall rule configuration itself to detect overlapping attributes or identify rules shadowed by higher-priority rules. It's a traffic-based logging tool, not a configuration analysis tool.

- **C. VPC Flow Logs:** VPC Flow Logs capture network flow information for monitoring and forensics, recording samples of network flows sent from and received by VM instances. Like Firewall Rules Logging, it provides traffic-level visibility but does not perform configuration analysis to detect overlapping firewall rule attributes or identify shadowed rules.

### References

- [Firewall Insights overview | Network Intelligence Center](https://docs.cloud.google.com/network-intelligence-center/docs/firewall-insights/concepts/overview)
- [Firewall Insights categories and states](https://docs.cloud.google.com/network-intelligence-center/docs/firewall-insights/concepts/insights-categories-states)
- [Review and optimize firewall rules](https://docs.cloud.google.com/network-intelligence-center/docs/firewall-insights/how-to/review-optimize)
