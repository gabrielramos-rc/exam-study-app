# Question 293

**Source:** https://www.examtopics.com/discussions/google/view/147087-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** workforce identity federation, external IdP, partner access, federated identity

---

## Question

Your organization has hired a small, temporary partner team for 18 months. The temporary team will work alongside your DevOps team to develop your organization's application that is hosted on Google Cloud. You must give the temporary partner team access to your application's resources on Google Cloud and ensure that partner employees lose access. If they are removed from their employer's organization. What should you do?
## Choices

- **A.** Create a temporary username and password for the temporary partner team members. Auto-clean the usernames and passwords after the work engagement has ended.
- **B.** Create a workforce identity pool and federate the identity pool with the identity provider (IdP) of the temporary partner team. Most Voted
- **C.** Implement just-in-time privileged access to Google Cloud for the temporary partner team.
- **D.** Add the identities of the temporary partner team members to your identity provider (IdP).

---

## Community

**Most Voted:** B


**Votes:** B: 100% (3 total)


**Top Comments:**

- (1 upvotes) b: https://cloud.google.com/iam/docs/workforce-identity-federation https://cloud.google.com/iam/docs/temporary-elevated-access One way to protect sensitive resources is to limit access to them. Howeve

- (1 upvotes) Answer is B

- (1 upvotes) I think it's B.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Workforce Identity Federation is specifically designed for this scenario - granting external partners and contractors access to Google Cloud resources through their employer's identity provider. This approach provides automatic access lifecycle management:

**Key benefits:**
- **Federated authentication**: Partner employees authenticate through their own employer's IdP using SSO, eliminating the need to create separate Google Cloud accounts
- **Automatic access revocation**: Since authentication depends on real-time validation against the partner's IdP (rather than stored credentials), when a user is removed from their employer's IdP, they immediately lose the ability to obtain new access tokens
- **No synchronization overhead**: Workforce Identity Federation doesn't store user accounts in Google Cloud - it federates identities directly from the external IdP, so access control is managed at the source
- **Time-bounded access**: Session durations can be configured from 15 minutes to 12 hours, providing additional security controls
- **Granular IAM controls**: You can use attribute conditions to restrict access to specific subsets of partner employees (e.g., only certain teams or roles)

The system follows OAuth 2.0 Token Exchange (RFC 8693), where partner employees provide credentials from their IdP to Google's Security Token Service, which verifies the identity and returns short-lived access tokens.

### Why Other Options Are Wrong

- **A:** Creating temporary usernames and passwords violates security best practices. Manual credential management is error-prone, doesn't provide automatic revocation when employees leave the partner organization, and requires building custom "auto-clean" mechanisms. This approach also doesn't leverage existing identity infrastructure.

- **C:** Just-in-time (JIT) privileged access is designed for temporary elevation of privileges for administrative tasks, not for ongoing development work over 18 months. JIT access typically involves approval workflows and very short access windows (hours), which is impractical for a sustained development engagement.

- **D:** Adding partner employees to your own organization's IdP creates operational overhead, security risks, and doesn't provide automatic cleanup when they leave the partner company. You would need to manually track and remove accounts when partner employees depart, creating a significant security gap.

### References

- [Workforce Identity Federation Overview](https://docs.cloud.google.com/iam/docs/workforce-identity-federation)
- [Configuring Workforce Identity Federation](https://docs.cloud.google.com/iam/docs/configuring-workforce-identity-federation)
- [Configure IAP with Workforce Identity Federation](https://docs.cloud.google.com/iap/docs/use-workforce-identity-federation)
