# Question 132

**Source:** https://www.examtopics.com/discussions/google/view/75964-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** log sink, aggregated sink, external SIEM, Audit Logs, Pub/Sub

---

## Question

You are tasked with exporting and auditing security logs for login activity events for Google Cloud console and API calls that modify configurations to Google Cloud resources. Your export must meet the following requirements: ✑ Export related logs for all projects in the Google Cloud organization. ✑ Export logs in near real-time to an external SIEM. What should you do? (Choose two.)
## Choices

- **A.** Create a Log Sink at the organization level with a Pub/Sub destination.
- **B.** Create a Log Sink at the organization level with the includeChildren parameter, and set the destination to a Pub/Sub topic. Most Voted
- **C.** Enable Data Access audit logs at the organization level to apply to all projects. Most Voted
- **D.** Enable Google Workspace audit logs to be shared with Google Cloud in the Admin Console.
- **E.** Ensure that the SIEM processes the AuthenticationInfo field in the audit log entry to gather identity information.

---

## Community

**Most Voted:** BC


**Votes:** AE: 3% | BC: 47% | BD: 39% | BE: 11% (38 total)


**Top Comments:**

- (13 upvotes) Google cloud logs is different from Google Workspace logs. D is definitely incorrect.

- (12 upvotes) There is no mention about 'data access logs' in question

- (5 upvotes) The other options are not relevant or necessary for meeting the specified requirements: D. "Enable Google Workspace audit logs to be shared with Google Cloud in the Admin Console" is not directly rela

---

## Answer

**Correct:** B, C

**Confidence:** high

### Explanation

This question requires exporting two types of audit logs: login activity events and API calls that modify configurations. The correct solution involves both proper log export infrastructure and enabling the necessary audit logs.

**Option B** is essential because it creates an aggregated log sink at the organization level with the `includeChildren` parameter. This parameter is critical - when set to true, the sink exports logs not only from the organization itself but from all child projects, folders, and billing accounts. The Pub/Sub destination enables near real-time streaming to external SIEM systems, which is a standard integration pattern for third-party security tools like Splunk, Datadog, or QRadar.

**Option C** is necessary because login activity events are captured by Data Access audit logs. While API calls that modify configurations are recorded in Admin Activity audit logs (which are always enabled by default), login events specifically require Data Access audit logs to be enabled. According to Google Cloud documentation, "Login Audit logs track user sign-ins to your domain" and "Login Audit writes Data Access audit logs only." Without enabling Data Access audit logs at the organization level, login activity events would not be captured.

The combination of B and C provides a complete solution: the aggregated sink with includeChildren exports logs from all projects to Pub/Sub in near real-time, while enabling Data Access audit logs ensures that both login events and configuration changes are captured.

### Why Other Options Are Wrong

- **A:** This option is incomplete. Without the `includeChildren` parameter, the sink would only export logs from the organization resource itself, not from the individual projects where most activities occur. The default value of `includeChildren` is false, so it must be explicitly set to true to aggregate logs from all child resources.

- **D:** Google Workspace audit logs are only relevant if you need to track login activity to Google Workspace services (Gmail, Drive, etc.) or admin console operations. The question specifically asks about "Google Cloud console and API calls," which are captured by Google Cloud Audit Logs, not Google Workspace logs. This option introduces unnecessary complexity for a different use case.

- **E:** The AuthenticationInfo field is indeed useful for gathering identity information, but processing this field in the SIEM is not a configuration requirement for the export itself. This is an optional downstream processing step, not a requirement to meet the stated objectives. The question asks what you should do to export the logs, not how to process them after export.

### References

- [Aggregated sinks overview](https://docs.cloud.google.com/logging/docs/export/aggregated_sinks_overview)
- [Collate and route organization-level logs](https://docs.cloud.google.com/logging/docs/export/aggregated_sinks)
- [Cloud Audit Logs overview](https://docs.cloud.google.com/logging/docs/audit)
- [Enable Data Access audit logs](https://docs.cloud.google.com/logging/docs/audit/configure-data-access)
- [View logs routed to Pub/Sub](https://docs.cloud.google.com/logging/docs/export/pubsub)
