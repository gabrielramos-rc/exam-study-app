# Question 012

**Source:** https://www.examtopics.com/discussions/google/view/74817-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Web Security Scanner, vulnerability scanning, OWASP, App Engine, application security

---

## Question

A customer deploys an application to App Engine and needs to check for Open Web Application Security Project (OWASP) vulnerabilities. Which service should be used to accomplish this?
## Choices

- **A.** Cloud Armor
- **B.** Google Cloud Audit Logs
- **C.** Web Security Scanner Most Voted
- **D.** Anomaly Detection

---

## Community

**Most Voted:** C


**Votes:** C: 100% (4 total)


**Top Comments:**

- (10 upvotes) The correct answer is C

- (3 upvotes) This is called DAST (Dynamic Application Security Testing) through tools such as BurpSuite,ZAP in normal non-cloud deployments but the same has been done through web security scanner in GCP hence my a

- (1 upvotes) The correct answer is C

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Web Security Scanner is the correct service for checking OWASP vulnerabilities in App Engine applications. It is specifically designed to identify security vulnerabilities and misconfigurations in web applications by:

- **Supporting App Engine**: Works with both App Engine standard and flexible environments, as well as GKE and Compute Engine
- **OWASP Coverage**: Explicitly supports categories from the OWASP Top Ten framework, detecting vulnerabilities including XSS (cross-site scripting), SQL injection, insecure deserialization, and outdated libraries
- **Automated Scanning**: Crawls the application following all links within the scope of starting URLs, exercising user inputs and event handlers to identify 24+ vulnerability types
- **Integration**: Available as both managed scans (automatic weekly scans) and custom scans for more granular findings

The scanner is part of Security Command Center and is designed specifically for application vulnerability scanning in compliance with OWASP standards.

### Why Other Options Are Wrong

- **A. Cloud Armor**: A web application firewall (WAF) and DDoS protection service that protects against attacks in real-time, but does not scan or identify OWASP vulnerabilities in your application code. It prevents exploitation but doesn't detect vulnerabilities.

- **B. Google Cloud Audit Logs**: A logging service that records administrative activities and data access within Google Cloud resources. It tracks "who did what, where, and when" but does not perform vulnerability scanning or security testing of applications.

- **D. Anomaly Detection**: Not a standalone Google Cloud service. While some services like Security Command Center include anomaly detection capabilities, there is no service called "Anomaly Detection" that performs OWASP vulnerability scanning for App Engine applications.

### References

- [Overview of Web Security Scanner](https://docs.cloud.google.com/security-command-center/docs/concepts-web-security-scanner-overview)
- [OWASP Top 10 2021 mitigation options on Google Cloud](https://cloud.google.com/architecture/security/owasp-top-ten-mitigation)
