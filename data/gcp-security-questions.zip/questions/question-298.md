# Question 298

**Source:** https://www.examtopics.com/discussions/google/view/148653-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Audit Logs, IAM monitoring, service account activity, SIEM, log export

---

## Question

A security audit uncovered several inconsistencies in your project's Identity and Access Management (IAM) configuration. Some service accounts have overly permissive roles, and a few external collaborators have more access than necessary. You need to gain detailed visibility into changes to IAM policies, user activity, service account behavior, and access to sensitive projects. What should you do?
## Choices

- **A.** Configure Google Cloud Functions to be triggered by changes to IAM policies. Analyze changes by using the policy simulator, send alerts upon risky modifications, and store event details.
- **B.** Enable the metrics explorer in Cloud Monitoring to follow the service account authentication events and build alerts linked on it.
- **C.** Use Cloud Audit Logs. Create log export sinks to send these logs to a security information and event management (SIEM) solution for correlation with other event sources. Most Voted
- **D.** Deploy the OS Config Management agent to your VMs. Use OS Config Management to create patch management jobs and monitor system modifications.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (3 total)


**Top Comments:**

- (1 upvotes) This approach allows you to monitor and analyze IAM changes comprehensively, ensuring that you can detect and respond to any security issues effectively https://cloud.google.com/iam/docs/audit-logging

- (1 upvotes) It's C

- (1 upvotes) C - Comprehensive Logging: Cloud Audit Logs capture a wide range of activities, including IAM policy changes, user logins, API calls, and resource access. This provides a comprehensive view of your or

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Cloud Audit Logs is the native GCP service designed to provide comprehensive visibility into IAM policy changes, user activity, and service account behavior. The service automatically captures four types of audit logs:

1. **Admin Activity Logs** - Always enabled by default, these capture IAM policy changes (SetIamPolicy method calls), service account creation/modification, and all administrative actions that modify resource configuration
2. **Data Access Logs** - When enabled, record API calls that access or modify user data, providing visibility into who accessed sensitive projects
3. **System Event Logs** - Capture system-driven configuration changes
4. **Policy Denied Logs** - Record denied access attempts due to security policy violations

For the security audit scenario, Cloud Audit Logs provides exactly what's needed:
- **IAM policy changes**: Tracked via SetIamPolicy method in Admin Activity logs
- **User activity**: Captured with caller identity, IP addresses, and timestamps
- **Service account behavior**: Includes service account impersonation details via serviceAccountDelegationInfo section

The recommended approach of exporting logs to a SIEM via log export sinks allows for:
- Correlation with other security event sources
- Long-term retention beyond Cloud Logging's default retention
- Advanced analysis and alerting capabilities
- Centralized security monitoring across multiple projects using aggregated sinks

This is the standard, best-practice approach for security visibility in GCP environments.

### Why Other Options Are Wrong

- **A:** Building custom Cloud Functions for IAM monitoring is unnecessary overhead when Cloud Audit Logs provides this natively. The Policy Simulator is a planning tool for evaluating policy changes before applying them, not a monitoring solution. This approach would require significant custom development to replicate what Audit Logs provides out-of-the-box.

- **B:** Cloud Monitoring metrics explorer can track authentication events, but it doesn't provide the detailed audit trail needed for security investigations. Metrics are aggregated time-series data, not detailed logs showing who made what changes, when, and from where. This lacks the granular visibility required for the security audit scenario.

- **D:** OS Config Management is for VM-level patch management and OS configuration, not for monitoring IAM policies, user activity, or service account behavior at the GCP platform level. This tool is completely inappropriate for the stated requirements of monitoring IAM configurations and access patterns.

### References

- [Cloud Audit Logs overview](https://docs.cloud.google.com/logging/docs/audit)
- [Identity and Access Management audit logging](https://docs.cloud.google.com/iam/docs/audit-logging)
- [Review IAM allow policy history](https://docs.cloud.google.com/iam/docs/review-iam-policy-history)
- [Service Account Credentials audit logging](https://docs.cloud.google.com/iam/docs/audit-logging/audit-logging-iamcreds)
