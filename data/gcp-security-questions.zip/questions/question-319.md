# Question 319

**Source:** https://www.examtopics.com/discussions/google/view/150191-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Binary Authorization, Cloud Run security, organization policy, enforcement

---

## Question

The InfoSec team has mandated that all new Cloud Run jobs and services in production must have Binary Authorization enabled. You need to enforce this requirement. What should you do?
## Choices

- **A.** Configure an organization policy to require Binary Authorization enforcement on images deployed to Cloud Run. Most Voted
- **B.** Configure a Security Health Analytics (SHA) custom rule that prevents the execution of Cloud Run jobs and services without Binary Authorization.
- **C.** Ensure the Cloud Run admin role is not assigned to developers.
- **D.** Configure a Binary Authorization custom policy that is not editable by developers and auto-attaches to all Cloud Run jobs and services.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (3 total)


**Top Comments:**

- (1 upvotes) Answer A

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Google Cloud explicitly recommends using an organization policy to require Binary Authorization for Cloud Run. According to the official documentation:

"We recommend that you require Binary Authorization for Cloud Run by configuring an organization policy to do so. Binary Authorization can be disabled by Cloud Run developers if the policy is not configured."

This approach provides centralized, programmatic enforcement at the organization, folder, or project level. Once configured, the organization policy:
- Prevents developers from deploying Cloud Run services or jobs without Binary Authorization enabled
- Cannot be circumvented by individual developers
- Applies automatically to all Cloud Run deployments in scope
- Enforces policy checks during deployment (for services) and execution (for jobs)

The documentation notes that when an organization policy is set to require Binary Authorization for Cloud Run, the Binary Authorization checkbox in the UI will be disabled, preventing users from turning it off.

### Why Other Options Are Wrong

- **B:** Security Health Analytics (SHA) is a vulnerability detection and compliance monitoring service. It generates findings about misconfigurations but does not actively prevent or block deployments. SHA custom modules detect security issues after they occur rather than enforcing preventive controls.

- **C:** Restricting the Cloud Run admin role does not enforce Binary Authorization. Developers with different roles (like Cloud Run Developer) can still deploy services, and this approach doesn't mandate Binary Authorization usage. This is a role-based access control mechanism, not a policy enforcement mechanism.

- **D:** Binary Authorization policies do not "auto-attach" to Cloud Run services and jobs. Policies must be explicitly enabled on each service/job, and developers can disable Binary Authorization if no organization policy is in place. Additionally, there is no concept of a policy that is "not editable" by developers in this context - the enforcement comes from organization policy, not policy editability settings.

### References

- [Enable Binary Authorization for Cloud Run](https://docs.cloud.google.com/binary-authorization/docs/run/enabling-binauthz-cloud-run)
- [Set up overview for Cloud Run](https://docs.cloud.google.com/binary-authorization/docs/run/overview)
- [Use custom organization policies](https://docs.cloud.google.com/binary-authorization/docs/binary-authorization-custom-constraints)
