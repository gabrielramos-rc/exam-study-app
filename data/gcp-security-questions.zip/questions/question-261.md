# Question 261

**Source:** https://www.examtopics.com/discussions/google/view/147055-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** hierarchical firewall, FQDN, VPC, Cloud Run, folder-level policy

---

## Question

Your organization utilizes Cloud Run services within multiple projects underneath the non-production folder which requires primarily internal communication. Some services need external access to approved fully qualified domain names (FQDN) while other external traffic must be blocked. Internal applications must not be exposed. You must achieve this granular control with allowlists overriding broader restrictions only for designated VPCs. What should you do?
## Choices

- **A.** Implement a global-level allowlist rule for the necessary FQDNs within a hierarchical firewall policy. Apply this policy across all VPCs in the organization and configure Cloud NAT without any additional filtering.
- **B.** Create a folder-level deny-all rule for outbound traffic within a hierarchical firewall policy. Define FQDN allowlist rules in separate policies and associate them with the necessary VPCs. Configure Cloud NAT for these VPCs. Most Voted
- **C.** Create a project-level deny-all rule within a hierarchical structure and apply it broadly. Override this rule with separate FQDN allowlists defined in VPC-level firewall policies associated with the relevant VPCs.
- **D.** Configure Cloud NAT with IP-based filtering to permit outbound traffic only to the allowlist d FQDNs' IP ranges. Apply Cloud NAT uniformly to all VPCs within the organization's folder structure.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (5 total)


**Top Comments:**

- (1 upvotes) Cloud Public NAT support not only the VM instances but also Cloud Run https://cloud.google.com/nat/docs/overview#supported-resources

- (1 upvotes) This approach allows you to: Enforce a deny-all rule at the folder level, ensuring that no outbound traffic is allowed by default. Create specific allowlist rules for the approved FQDNs and apply thes

- (1 upvotes) Only answer that makes sense to me.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B correctly implements the hierarchical firewall policy architecture required for this scenario. By creating a folder-level deny-all rule within a hierarchical firewall policy, you establish a broad default-deny posture for all projects under the non-production folder. Hierarchical firewall policies are evaluated from organization level down through folder levels before reaching VPC-level rules. The key architectural principle is that you can define FQDN allowlist rules in the same hierarchical policy but target them to specific VPCs using target network specifications. This allows allowlist rules to apply only to designated VPCs while the deny-all rule applies broadly to all VPCs in the folder.

When hierarchical firewall policy rules are evaluated, Cloud NGFW first evaluates rules from the organization level, then folder levels from top to bottom. Within each policy, rules are evaluated from highest to lowest priority. By placing both the deny-all and the FQDN allowlists in the hierarchical policy structure (with proper prioritization), the FQDN allowlist rules (higher priority) will match first for designated VPCs, while the deny-all rule (lower priority) catches all other traffic. Cloud NAT provides the outbound connectivity required for Cloud Run services to access external FQDNs.

The critical architectural element is that hierarchical firewall policies support FQDN objects as destinations for egress rules, allowing granular control over which domain names can be accessed. Target networks in hierarchical policies enable the allowlist rules to apply only to specific VPCs, achieving the requirement that "allowlists override broader restrictions only for designated VPCs."

### Why Other Options Are Wrong

- **A:** Implementing a global-level (organization-level) allowlist would apply the FQDN allowlist to ALL VPCs in the entire organization, not just designated VPCs in the non-production folder. This violates the requirement for granular control where allowlists should only override restrictions for specific designated VPCs. Without a default deny-all rule, this approach also lacks the broad restrictive baseline.

- **C:** This option contains a fundamental architectural error. Hierarchical firewall policies cannot be created at the "project-level" - they can only be applied at organization and folder levels, not at the project or VPC level. Additionally, the concept of "overriding" hierarchical rules with VPC-level firewall policies is incorrect - lower-level rules cannot override rules from higher places in the resource hierarchy. VPC firewall rules are evaluated after hierarchical policies and cannot override them.

- **D:** Cloud NAT does not support IP-based filtering or FQDN-based filtering. Cloud NAT is designed to provide outbound internet connectivity by translating private IP addresses to public IP addresses, but it does not perform traffic filtering based on destination IPs or FQDNs. Traffic filtering must be implemented using firewall policies (hierarchical or VPC-level), not through Cloud NAT. This approach fundamentally misunderstands the purpose and capabilities of Cloud NAT.

### References

- [Hierarchical firewall policies | Cloud Next Generation Firewall](https://docs.cloud.google.com/firewall/docs/firewall-policies)
- [Use hierarchical firewall policies and rules](https://docs.cloud.google.com/firewall/docs/using-firewall-policies)
- [Configure FQDN egress in firewall policies](https://docs.cloud.google.com/firewall/docs/quickstarts/configure-nwfwpolicy-fqdn-egress)
- [Firewall policy rules details](https://docs.cloud.google.com/firewall/docs/firewall-policies-rule-details)
