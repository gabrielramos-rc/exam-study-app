# Question 164

**Source:** https://www.examtopics.com/discussions/google/view/80492-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, constraints, compute.skipDefaultNetworkCreation, VPC network, project creation

---

## Question

You are creating a new infrastructure CI/CD pipeline to deploy hundreds of ephemeral projects in your Google Cloud organization to enable your users to interact with Google Cloud. You want to restrict the use of the default networks in your organization while following Google-recommended best practices. What should you do?
## Choices

- **A.** Enable the constraints/compute.skipDefaultNetworkCreation organization policy constraint at the organization level. Most Voted
- **B.** Create a cron job to trigger a daily Cloud Function to automatically delete all default networks for each project.
- **C.** Grant your users the IAM Owner role at the organization level. Create a VPC Service Controls perimeter around the project that restricts the compute.googleapis.com API.
- **D.** Only allow your users to use your CI/CD pipeline with a predefined set of infrastructure templates they can deploy to skip the creation of the default networks.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (13 total)


**Top Comments:**

- (5 upvotes) Agreed

- (4 upvotes) A. https://cloud.google.com/resource-manager/docs/organization-policy/org-policy-constraints "This boolean constraint skips the creation of the default network and related resources during Google Clou

- (2 upvotes) A-Org Policy

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The `constraints/compute.skipDefaultNetworkCreation` organization policy is the Google-recommended best practice for preventing the automatic creation of default networks when new projects are created. This boolean constraint, when enabled at the organization level, skips the creation of the default network and related resources during project creation for all projects under the organization.

This approach is ideal for the scenario because:
- **Centralized control**: Applied once at the organization level, it automatically affects all current and future projects
- **Preventive security**: Stops default networks from being created in the first place, rather than trying to remove them after creation
- **Scalable**: Works seamlessly with hundreds of ephemeral projects without additional automation
- **Zero maintenance**: Unlike reactive approaches, it requires no ongoing management or monitoring
- **Native Google solution**: Uses the built-in Organization Policy Service, which is the recommended way to enforce organizational governance

The constraint applies at project creation time, ensuring that users must explicitly design and create custom VPC networks that meet your organization's security requirements.

### Why Other Options Are Wrong

- **B:** Creating a cron job to delete default networks is a reactive, error-prone approach that creates a window of vulnerability between project creation and network deletion. It adds unnecessary operational complexity and doesn't follow Google's best practices. Default networks could be used or have resources deployed before deletion occurs.

- **C:** Granting IAM Owner roles at the organization level violates the principle of least privilege and creates significant security risks. VPC Service Controls are designed for protecting sensitive data in specific services, not for preventing network creation. This approach is overly permissive and doesn't actually prevent default network creation.

- **D:** Restricting users to predefined infrastructure templates is a process-based control that relies on user compliance rather than technical enforcement. It doesn't prevent default network creation at the platform level and can be bypassed if users have sufficient permissions to create projects outside the pipeline. This is less reliable than enforcing the constraint through organization policy.

### References

- [Organization Policy Constraints - Google Cloud](https://docs.cloud.google.com/resource-manager/docs/organization-policy/org-policy-constraints)
- [Batch Networking Overview - Default Network](https://docs.cloud.google.com/batch/docs/networking-overview)
