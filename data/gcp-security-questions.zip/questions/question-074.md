# Question 074

**Source:** https://www.examtopics.com/discussions/google/view/74820-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Implementing data protection and encryption
**Tags:** envelope encryption, Cloud KMS, DEK, KEK, encryption

---

## Question

What are the steps to encrypt data using envelope encryption?

## Choices

- **A.** Generate a data encryption key (DEK) locally. ✑ Use a key encryption key (KEK) to wrap the DEK. ✑ Encrypt data with the KEK. ✑ Store the encrypted data and the wrapped KEK.
- **B.** Generate a key encryption key (KEK) locally. ✑ Use the KEK to generate a data encryption key (DEK). ✑ Encrypt data with the DEK. ✑ Store the encrypted data and the wrapped DEK.
- **C.** Generate a data encryption key (DEK) locally. ✑ Encrypt data with the DEK. ✑ Use a key encryption key (KEK) to wrap the DEK. ✑ Store the encrypted data and the wrapped DEK.
- **D.** Generate a key encryption key (KEK) locally. ✑ Generate a data encryption key (DEK) locally. ✑ Encrypt data with the KEK. Store the encrypted data and the wrapped DEK.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

According to Google Cloud's official documentation on envelope encryption, the correct sequence is:

1. **Generate a DEK locally** - Create a data encryption key using an open-source library like OpenSSL, specifying a cipher type (recommended: 256-bit AES-GCM)
2. **Encrypt data with the DEK** - Use the locally-generated DEK to encrypt your actual data
3. **Wrap the DEK with a KEK** - Use Cloud KMS to encrypt (wrap) the DEK with a key encryption key stored in Cloud KMS
4. **Store encrypted data and wrapped DEK** - Save both the encrypted data and the wrapped DEK (never store a plaintext DEK)

The key principle is that **the KEK never leaves Cloud KMS**, ensuring your encryption key remains protected in the central key management service. The DEK is used locally for fast symmetric encryption of data, while the KEK (managed by Cloud KMS) provides secure protection of the DEK itself. This model permits individual data objects to each have their own DEK without massively increasing the volume of keys stored in the key management service.

### Why Other Options Are Wrong

- **A:** Incorrect sequence - it wraps the DEK before encrypting the data, and then incorrectly states you encrypt data with the KEK (you encrypt data with the DEK). Also incorrectly stores the wrapped KEK instead of the wrapped DEK.

- **B:** Incorrect flow - the KEK doesn't generate the DEK. The DEK is generated locally by the client, not derived from the KEK. Also, the KEK should not be generated locally; it's stored and managed in Cloud KMS.

- **D:** Incorrect on multiple points - suggests generating the KEK locally (KEKs are managed in Cloud KMS, not generated locally), encrypts data with the KEK instead of the DEK (which would be inefficient and defeat the purpose of envelope encryption), and doesn't wrap the DEK before storage.

### References

- [Envelope encryption | Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/envelope-encryption)
- [Client-side encryption with Tink and Cloud KMS](https://docs.cloud.google.com/kms/docs/client-side-encryption)
