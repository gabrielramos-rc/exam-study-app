# Question 343

**Source:** https://www.examtopics.com/discussions/google/view/311183-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** log export, BigQuery, external table, log analysis, auditor access

---

## Question

You manage the security logs within your cloud environment. You have configured a continuous export of security logs to Cloud Storage buckets for long-term retention. You need to provide auditors the ability to analyze the logs that were exported to Cloud Storage. Your solution must be cost-effective and quickly implemented. What should you do?
## Choices

- **A.** Use a VM instance to download the data from Cloud Storage. Provide the auditors access to the VM and allow them to install their preferred analytics toolset.
- **B.** Use the data in the Cloud Storage bucket as an external table in BigQuery. Provide the auditors access to the BigQuery dataset. Most Voted
- **C.** Use Dataflow to import the data from Cloud Storage into Elasticsearch. Provide the auditors with access to Elasticsearch.
- **D.** Use a Cloud Run job to import the log data from Cloud Storage to Cloud Logging. Provide the auditors access through Log Analytics.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (1 total)

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

BigQuery external tables are the optimal solution for this scenario because they allow direct querying of log data stored in Cloud Storage without moving or importing the data. This approach is:

**Cost-effective:** BigQuery does not charge for external table storage since the data remains in Cloud Storage. You only pay for query costs when auditors run analyses. There are no additional data import or processing costs.

**Quick to implement:** Creating an external table is straightforward using SQL DDL, the console, or bq CLI. You simply point the table definition to the Cloud Storage bucket location containing the logs. No ETL pipelines or data migration is required.

**Powerful for analysis:** Auditors can use standard SQL queries to analyze the logs directly through BigQuery's interface. BigQuery provides excellent performance for analytical queries and supports various log formats (JSON, CSV, Avro, Parquet).

**Secure access control:** You can grant auditors specific IAM permissions on the BigQuery dataset without providing direct Cloud Storage access. With BigLake tables, access delegation ensures auditors only need permissions on the table, not the underlying storage.

The external table approach maintains the data in its original Cloud Storage location for long-term retention while enabling immediate SQL-based analysis capabilities.

### Why Other Options Are Wrong

- **A:** Using a VM instance is neither cost-effective nor quickly implemented. It requires provisioning and maintaining infrastructure, downloading potentially large amounts of log data, managing VM access, and allowing auditors to install tools which introduces security and operational overhead. This is the most expensive and complex option.

- **C:** Dataflow to Elasticsearch requires setting up a data pipeline, running Dataflow jobs (compute costs), deploying and managing an Elasticsearch cluster (significant infrastructure costs), and implementing data import processes. This is expensive, complex to implement, and requires ongoing operational management. It violates both the cost-effective and quickly implemented requirements.

- **D:** Re-importing logs from Cloud Storage back to Cloud Logging defeats the purpose of exporting them for long-term retention. Cloud Logging has retention limits and is designed for operational logging, not long-term audit analysis. Creating a Cloud Run job to repeatedly import data would be complex, inefficient, and could hit Cloud Logging quotas and retention policies.

### References

- [Create Cloud Storage external tables | BigQuery](https://docs.cloud.google.com/bigquery/docs/external-data-cloud-storage)
- [Introduction to external data sources | BigQuery](https://docs.cloud.google.com/bigquery/docs/external-data-sources)
