# Question 341

**Source:** https://www.examtopics.com/discussions/google/view/311186-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Cloud Armor, WAF, Identity-Aware Proxy, IAP, perimeter security

---

## Question

Your organization is deploying a new web application on Compute Engine and needs robust perimeter security. You need to protect the application from common web attacks, including SQL injection and cross-site scripting (XSS), while also controlling network traffic based on the source IP address and user identity. What should you do?
## Choices

- **A.** Implement Cloud Load Balancing and Cloud DNS. Set up Cloud CDN to cache content and mitigate some DDoS attacks. Configure Cloud Armor to provide layer 7 protection.
- **B.** Deploy Cloud Armor with its default WAF rules enabled. Configure network firewall rules on the Compute Engine instances to control all traffic based on source IP addresses. Use Cloud IAM to manage which users have roles granting access to the web application.
- **C.** Use Google Cloud Armor with pre-configured WAF rules to filter malicious traffic. Implement VPC Service Controls to create a secure perimeter around the application's resources. Manage users with Cloud IAM.
- **D.** Deploy Cloud Armor, and configure Cloud Firewall rules to control traffic based on source IP addresses. Integrate with Identity-Aware Proxy to control access based on user identity. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (1 total)

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D provides the complete solution that addresses all three requirements:

1. **Protection from SQL injection and XSS attacks**: Cloud Armor provides preconfigured WAF rules based on OWASP Core Rule Set 3.3.2 that include complex signatures for detecting and blocking SQL injection (sqli-v33-stable) and cross-site scripting (xss-v33-stable) attacks. These WAF rules filter malicious traffic at Google's edge infrastructure before it reaches your application backends.

2. **Network traffic control by source IP address**: Cloud Firewall rules (VPC firewall rules) enable you to control network traffic based on source IP addresses, implementing network-level access controls. These rules can be configured to allow or deny traffic from specific IP ranges.

3. **Access control based on user identity**: Identity-Aware Proxy (IAP) provides application-level access control based on user identity rather than network location. When a web application is protected by IAP, users must authenticate (via OAuth 2.0) and be granted the "IAP-secured Web App User" IAM role to access the application. This enables group-based access control where resource availability depends on verified user identity.

This combination creates defense-in-depth: Cloud Armor protects at Layer 7 from web attacks, VPC firewall rules control network access at Layer 3/4, and IAP enforces identity-based authentication and authorization.

### Why Other Options Are Wrong

- **A:** While Cloud Load Balancing and Cloud Armor provide good Layer 7 protection against web attacks and DDoS, this option completely lacks user identity-based access control. Cloud CDN and Cloud DNS don't provide authentication or authorization capabilities for controlling access based on user identity.

- **B:** Cloud IAM roles control access to Google Cloud resources (APIs, management operations), not access to the web application itself. IAM cannot enforce user-based access control for end users accessing a web application - that requires IAP or an equivalent application-level authentication mechanism. Additionally, network firewall rules alone don't provide application-layer WAF protection.

- **C:** VPC Service Controls create security perimeters around Google Cloud APIs and services to prevent data exfiltration, but they are designed to protect API access (like Compute Engine API, Cloud Storage API) rather than end-user web application traffic. VPC Service Controls don't provide user identity-based access control for web applications - that's the role of IAP. Cloud IAM similarly manages GCP resource access, not web application end-user authentication.

### References

- [Cloud Armor preconfigured WAF rules overview](https://docs.cloud.google.com/armor/docs/waf-rules)
- [Cloud Armor product overview](https://docs.cloud.google.com/armor/docs/cloud-armor-overview)
- [Identity-Aware Proxy overview](https://docs.cloud.google.com/iap/docs/concepts-overview)
- [Managing access to IAP-secured resources](https://docs.cloud.google.com/iap/docs/managing-access)
