# Question 081

**Source:** https://www.examtopics.com/discussions/google/view/30371-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Private Google Access, network isolation, external IP, Cloud Storage, Compute Engine

---

## Question

A customer is running an analytics workload on Google Cloud Platform (GCP) where Compute Engine instances are accessing data stored on Cloud Storage. Your team wants to make sure that this workload will not be able to access, or be accessed from, the internet. Which two strategies should your team use to meet these requirements? (Choose two.)
## Choices

- **A.** Configure Private Google Access on the Compute Engine subnet Most Voted
- **B.** Avoid assigning public IP addresses to the Compute Engine cluster. Most Voted
- **C.** Make sure that the Compute Engine cluster is running on a separate subnet.
- **D.** Turn off IP forwarding on the Compute Engine instances in the cluster.
- **E.** Configure a Cloud NAT gateway.

---

## Community

**Most Voted:** AB


**Votes:** AB: 75% | AE: 12% | BE: 12% (8 total)


**Top Comments:**

- (20 upvotes) Ans : AB

- (7 upvotes) AE A. Configuring Private Google Access on the Compute Engine subnet: This feature enables instances without public IP addresses to connect to Google APIs and services over internal IP addresses, ensu

- (4 upvotes) AB is the correct answer.

---

## Answer

**Correct:** A, B

**Confidence:** high

### Explanation

To ensure that Compute Engine instances cannot access or be accessed from the internet while still being able to access Cloud Storage, you need to implement two complementary strategies:

**Option A - Configure Private Google Access on the subnet:** Private Google Access enables VMs without external IP addresses to reach Google APIs and services (including Cloud Storage) using internal IP addresses only. According to Google Cloud documentation, "Private Google Access enables Compute Engine VMs without external IP addresses to connect to Google APIs and services." This allows the analytics workload to access Cloud Storage data while keeping all traffic within Google's private network, never traversing the public internet.

**Option B - Avoid assigning public IP addresses to the Compute Engine instances:** Without external IP addresses, VMs cannot receive inbound connections from the internet or initiate outbound connections to external services. The documentation states that "when a VM does not have an external IP address assigned, it cannot make direct connections to external services." This directly satisfies the requirement that the workload "will not be able to access, or be accessed from, the internet." Combined with Private Google Access, the VMs can still reach Cloud Storage internally.

Together, these two strategies create a secure, internet-isolated environment where VMs can access Cloud Storage through Google's private network infrastructure.

### Why Other Options Are Wrong

- **C:** Running the cluster on a separate subnet does not inherently prevent internet access. VMs on any subnet can have external IPs and access the internet unless explicitly prevented. Subnet separation alone provides no security benefit for this requirement.

- **D:** IP forwarding controls whether a VM instance can forward packets between network interfaces, which is relevant for routing scenarios (like using a VM as a NAT gateway). Disabling IP forwarding does not prevent a VM with an external IP from accessing or being accessed from the internet.

- **E:** Cloud NAT is specifically designed to provide outbound internet access to VMs without external IPs. Configuring Cloud NAT would violate the requirement that the workload "will not be able to access...the internet." Cloud NAT enables internet connectivity, which is the opposite of what's needed here.

### References

- [Configure Private Google Access](https://docs.cloud.google.com/vpc/docs/configure-private-google-access)
- [Private access options for services](https://docs.cloud.google.com/vpc/docs/private-access-options)
- [IP addresses - Compute Engine](https://docs.cloud.google.com/compute/docs/ip-addresses)
