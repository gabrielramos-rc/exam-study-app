# Question 310

**Source:** https://www.examtopics.com/discussions/google/view/150182-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** Assured Workloads, compliance, regulatory, data residency, personnel access controls

---

## Question

You work for a financial organization in a highly regulated industry that is subject to active regulatory compliance. To meet compliance requirements, you need to continuously maintain a specific set of configurations, data residency, organizational policies, and personnel data access controls. What should you do?
## Choices

- **A.** Apply an organizational policy constraint at the organization level to limit the location of new resource creation.
- **B.** Create an Assured Workloads folder for your required compliance program to apply defined controls and requirements. Most Voted
- **C.** Go to the Compliance page in Security Command Center. View the report for your status against the required compliance standard. Triage violations to maintain compliance on a regular basis.
- **D.** Create a posture.yaml file with the required security compliance posture. Apply the posture with the gcloud scc postures create POSTURE_NAME --posture-from-file=posture.yaml command in Security Command Center Premium.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (5 total)


**Top Comments:**

- (1 upvotes) https://cloud.google.com/assured-workloads/docs/overview#when_to_use_assured_workloads

- (1 upvotes) https://cloud.google.com/assured-workloads/docs/key-concepts

- (1 upvotes) https://cloud.google.com/assured-workloads/docs/key-concepts#:~:text=Assured%20Workloads%20provides%20Google%20Cloud,information%20about%20its%20key%20components.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Assured Workloads is specifically designed for organizations in highly regulated industries that need to maintain comprehensive compliance requirements. When you create an Assured Workloads folder, it provides a complete solution that addresses all four requirements mentioned in the question:

1. **Data residency controls**: Regional data boundary packages restrict where resources can be stored geographically (e.g., EU-only regions)
2. **Organizational policies**: Control packages define guardrails for all projects and resources within the folder, enforced using organization policy constraints
3. **Personnel data access controls**: Google support personnel must adhere to geographical and personnel-based attribute requirements based on the selected control package
4. **Continuous compliance maintenance**: Built-in workload updates feature evaluates whether deployed configurations match the most recent available version, with violation monitoring and audit logging to track compliance status

Assured Workloads enables organizations to configure a sovereign data and access boundary with predefined control packages tailored to specific compliance frameworks (HIPAA, PCI DSS, FedRAMP, GDPR, ISO 27001, etc.), making it the purpose-built solution for this scenario.

### Why Other Options Are Wrong

- **A:** While organizational policy constraints can help with data residency by limiting resource creation locations, this only addresses one aspect of the requirements. It doesn't provide personnel access controls, continuous compliance monitoring, or the comprehensive control packages needed for regulatory compliance in financial services.

- **C:** Security Command Center's Compliance page provides visibility and reporting on compliance status, but it's a monitoring and detection tool rather than a preventive control mechanism. It can help you triage violations but doesn't enforce the configurations, data residency restrictions, or personnel access controls required by the question. You would still need to implement the actual controls separately.

- **D:** Security Command Center Premium's security postures are useful for defining and detecting security configurations, but they primarily focus on security posture management and drift detection. They don't provide the comprehensive regulatory compliance framework with data residency enforcement, personnel access controls, and compliance-specific control packages that Assured Workloads offers for regulated industries.

### References

- [Overview of Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/overview)
- [Control packages | Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/control-packages)
- [Data residency | Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/data-residency)
