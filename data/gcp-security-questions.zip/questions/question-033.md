# Question 033

**Source:** https://www.examtopics.com/discussions/google/view/75050-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** CMEK, Cloud KMS, key lifecycle, boot disk encryption, MIG

---

## Question

A customer wants to move their sensitive workloads to a Compute Engine-based cluster using Managed Instance Groups (MIGs). The jobs are bursty and must be completed quickly. They have a requirement to be able to control the key lifecycle. Which boot disk encryption solution should you use on the cluster to meet this customer's requirements?
## Choices

- **A.** Customer-supplied encryption keys (CSEK)
- **B.** Customer-managed encryption keys (CMEK) using Cloud Key Management Service (KMS) Most Voted
- **C.** Encryption by default
- **D.** Pre-encrypting files before transferring to Google Cloud Platform (GCP) for analysis

---

## Community

**Most Voted:** B


**Votes:** B: 100% (13 total)


**Top Comments:**

- (7 upvotes) Correct Answer: B Explanation/Reference: Reference https://cloud.google.com/kubernetes-engine/docs/how-to/dynamic-provisioning-cmek

- (5 upvotes) "Control over the key lifecycle" is the key. The KMS is the most appropriate solution.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Customer-managed encryption keys (CMEK) using Cloud KMS is the correct solution for boot disk encryption with Managed Instance Groups when key lifecycle control is required. Here's why:

**Key Lifecycle Control:** CMEK provides comprehensive control over encryption key lifecycle through Cloud KMS, including:
- Key rotation (automatic or manual)
- Key revocation (disable or delete keys)
- Key versioning and management
- Audit logging of key usage
- Geographic key residency control

**MIG Compatibility:** CMEK integrates seamlessly with Managed Instance Groups and instance templates. When you create an instance template with CMEK-protected boot disks, Cloud KMS automatically encrypts new instances created by the MIG using the specified key. The key reference is stored in the instance template, enabling automatic encryption for all scaled instances.

**Operational Requirements:** For bursty workloads requiring rapid scaling:
- CMEK supports automatic encryption without manual intervention
- New instances in the MIG are automatically encrypted with the specified Cloud KMS key
- No additional steps required when scaling up or down
- The Compute Engine Service Agent is granted necessary permissions to use the encryption key

### Why Other Options Are Wrong

- **A (CSEK):** Customer-supplied encryption keys are fundamentally incompatible with Managed Instance Groups. According to Google Cloud documentation, "Compute Engine does not store encryption keys with instance templates, so you need to store your own keys in KMS to encrypt disks in a managed instance group." CSEK requires you to manually provide the encryption key with each request, which cannot be automated in MIG scaling scenarios.

- **C (Encryption by default):** While encryption by default (using Google-managed keys) provides automatic encryption, it does NOT give the customer control over the key lifecycle. The customer cannot rotate, revoke, or manage these keys, failing to meet the stated requirement of controlling the key lifecycle.

- **D (Pre-encrypting files):** Pre-encrypting files before transfer only protects data in transit and at the file level, not the boot disks themselves. This approach does not provide boot disk encryption for Compute Engine instances and does not integrate with MIG automation. Additionally, it adds operational complexity and does not provide comprehensive key lifecycle management for the entire disk.

### References

- [Encrypt disks with customer-supplied encryption keys | Compute Engine Documentation](https://docs.cloud.google.com/compute/docs/disks/customer-supplied-encryption)
- [Protect resources by using Cloud KMS keys | Compute Engine Documentation](https://docs.cloud.google.com/compute/docs/disks/customer-managed-encryption)
- [Customer-managed encryption keys (CMEK) | Cloud KMS Documentation](https://docs.cloud.google.com/kms/docs/cmek)
