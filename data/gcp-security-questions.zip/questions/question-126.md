# Question 126

**Source:** https://www.examtopics.com/discussions/google/view/74834-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** load balancer, network tier, client IP preservation, passthrough Network Load Balancer

---

## Question

Which type of load balancer should you use to maintain client IP by default while using the standard network tier?
## Choices

- **A.** SSL Proxy
- **B.** TCP Proxy
- **C.** Internal TCP/UDP
- **D.** TCP/UDP Network Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (20 total)


**Top Comments:**

- (5 upvotes) Answer is D: https://cloud.google.com/network-tiers/docs/overview#:~:text=Premium%20Tier%20enables%20global%20load,Standard%20Tier%20regional%20IP%20address. Order of elimination : TCP and SSL proxy i

- (4 upvotes) D is the answer. https://cloud.google.com/load-balancing/docs/load-balancing-overview#choosing_a_load_balancer

- (4 upvotes) Definitely D https://cloud.google.com/load-balancing/docs/load-balancing-overview#backend_region_and_network

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The **TCP/UDP Network Load Balancer** (external passthrough Network Load Balancer) is the correct choice because it preserves client IP addresses by default and supports the Standard Network Tier. This load balancer operates as a passthrough load balancer, meaning packets are received by backend VMs with the source and destination IP addresses, protocol, and ports completely unchanged. The architecture uses direct server return (DSR), where responses from backend VMs go directly to clients without passing back through the load balancer, eliminating any proxy layer that would obscure the original client source IP.

The external passthrough Network Load Balancer explicitly supports both Premium and Standard Network Tiers for regional external IPv4 addresses, making it the only option that satisfies both requirements in the question.

### Why Other Options Are Wrong

- **A (SSL Proxy):** SSL Proxy is a proxy-based load balancer that terminates client connections and establishes new connections to backends. Proxy load balancers do not preserve client IP addresses by default - the backend sees the load balancer's IP as the source. Additionally, SSL Proxy is a global load balancer that only operates in Premium Tier.

- **B (TCP Proxy):** TCP Proxy is also a proxy-based load balancer that terminates connections, obscuring the original client IP address. Like SSL Proxy, it operates as a global load balancer and only supports Premium Tier, not Standard Tier.

- **C (Internal TCP/UDP):** The internal passthrough Network Load Balancer does preserve client IP addresses, but it can only be configured in Premium Tier, not Standard Tier. Additionally, it's designed for internal load balancing within a VPC, not for external traffic scenarios typically associated with network tier selection.

### References

- [Passthrough Network Load Balancer overview](https://docs.cloud.google.com/load-balancing/docs/passthrough-network-load-balancer)
- [Network Service Tiers overview](https://docs.cloud.google.com/network-tiers/docs/overview)
- [Cloud Load Balancing overview](https://docs.cloud.google.com/load-balancing/docs/load-balancing-overview)
