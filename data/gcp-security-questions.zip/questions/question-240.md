# Question 240

**Source:** https://www.examtopics.com/discussions/google/view/126780-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Certificate Authority Service, subordinate CA, on-premises PKI, load balancer certificates, TLS

---

## Question

Your customer has an on-premises Public Key Infrastructure (PKI) with a certificate authority (CA). You need to issue certificates for many HTTP load balancer frontends. The on-premises PKI should be minimally affected due to many manual processes, and the solution needs to scale. What should you do?
## Choices

- **A.** Use Certificate Manager to issue Google managed public certificates and configure it at HTTP the load balancers in your infrastructure as code (IaC).
- **B.** Use a subordinate CA in the Google Certificate Authority Service from the on-premises PKI system to issue certificates for the load balancers. Most Voted
- **C.** Use Certificate Manager to import certificates issued from on-premises PKI and for the frontends. Leverage the gcloud tool for importing.
- **D.** Use the web applications with PKCS12 certificates issued from subordinate CA based on OpenSSL on-premises. Use the gcloud tool for importing. Use the External TCP/UDP Network load balancer instead of an external HTTP Load Balancer.

---

## Community

**Most Voted:** B


**Votes:** B: 83% | C: 17% (12 total)


**Top Comments:**

- (7 upvotes) !!!!B. Use a subordinate CA in the Google Certificate Authority Service from the on-premises PKI system to issue certificates for the load balancers

- (2 upvotes) Use Certificate Manager to import certificates issued from on-premises PKI and for the frontends. Leverage the gcloud tool for importing

- (1 upvotes) Use a subordinate CA in the Google Certificate Authority Service from the on-premises PKI system to issue certificates for the load balancers.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B is the correct solution because it directly addresses all requirements: minimal impact on on-premises PKI, scalability, and integration with HTTP load balancers.

Certificate Authority Service allows you to create a subordinate CA in Google Cloud that chains to your external on-premises root CA through a three-step process:

1. **Generate CSR**: CA Service creates a Certificate Signing Request for the subordinate CA
2. **External Signing**: Submit the CSR to your on-premises root CA for signing (one-time manual process)
3. **Activation**: Upload the signed certificate chain back to CA Service to activate the subordinate CA

Once activated, the subordinate CA operates independently in Google Cloud and can issue certificates at scale without requiring runtime communication with the on-premises PKI. As the documentation states, the subordinate CA can "issue certificates without needing to reach back to the external root CA at run time."

This architecture provides:
- **Minimal on-premises impact**: The on-premises CA only needs to sign the subordinate CA certificate once (single manual process)
- **Scalability**: The cloud-based subordinate CA can automatically issue thousands of certificates for load balancers
- **Trust preservation**: Any workload trusting your on-premises root CA automatically trusts the subordinate CA
- **Operational efficiency**: Certificate issuance is fully automated in the cloud

### Why Other Options Are Wrong

- **A:** Google-managed public certificates don't integrate with your existing on-premises PKI. This breaks the trust chain and doesn't leverage your existing private CA infrastructure. Organizations with established PKI systems need to maintain their own certificate hierarchy.

- **C:** Importing certificates manually from the on-premises PKI does not scale. Every certificate would require a manual request to the on-premises CA, processing, and import - exactly the manual burden the question asks to minimize. This defeats the scalability requirement.

- **D:** This option is overly complex and inappropriate. It suggests using OpenSSL-based subordinate CA on-premises (which doesn't reduce manual processes), PKCS12 format (unnecessary complexity), and switching to TCP/UDP load balancer instead of HTTP load balancer (which contradicts the question's requirement for HTTP load balancers). External Network Load Balancers also don't support the same certificate management features as HTTP(S) load balancers.

### References

- [Create a subordinate CA from an external CA](https://docs.cloud.google.com/certificate-authority-service/docs/create-sub-ca-from-external-ca)
- [Certificate Authority Service overview](https://cloud.google.com/certificate-authority-service/docs/ca-service-overview)
- [Create a subordinate certificate authority](https://docs.cloud.google.com/certificate-authority-service/docs/create-subordinate-ca)
