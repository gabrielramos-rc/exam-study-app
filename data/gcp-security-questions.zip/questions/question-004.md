# Question 004

**Source:** https://www.examtopics.com/discussions/google/view/17785-exam-professional-cloud-security-engineer-topic-1-question-4/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Directory Sync, GCDS, Active Directory, IAM permissions, group-based access

---

## Question

Your team wants to centrally manage GCP IAM permissions from their on-premises Active Directory Service. Your team wants to manage permissions by AD group membership. What should your team do to meet these requirements?
## Choices

- **A.** Set up Cloud Directory Sync to sync groups, and set IAM permissions on the groups. Most Voted
- **B.** Set up SAML 2.0 Single Sign-On (SSO), and assign IAM permissions to the groups.
- **C.** Use the Cloud Identity and Access Management API to create groups and IAM permissions from Active Directory.
- **D.** Use the Admin SDK to create groups and assign IAM permissions from Active Directory.

---

## Community

**Most Voted:** A


**Votes:** A: 87% | B: 13% (15 total)


**Top Comments:**

- (30 upvotes) Correct Answer is A as explained here https://www.udemy.com/course/google-security-engineer-certification/?referralCode=E90E3FF49D9DE15E2855 "In order to be able to keep using the existing identity ma

- (10 upvotes) Explanation: Cloud Directory Sync (CDS) is the crucial first step. It's the mechanism that synchronizes your on-premises Active Directory groups with your Google Cloud environment. This allows GCP to 

- (3 upvotes) Correct answer is A.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Cloud Directory Sync (GCDS) is the correct solution for centrally managing GCP IAM permissions from on-premises Active Directory by synchronizing AD groups to Cloud Identity or Google Workspace. The process works in two phases:

1. **User and Group Provisioning**: GCDS periodically synchronizes relevant users and security groups from Active Directory to Cloud Identity/Google Workspace. This keeps Active Directory as the authoritative source while ensuring Google Cloud stays synchronized.

2. **IAM Permission Assignment**: Once groups are synced to Cloud Identity, you can assign IAM roles to these groups in GCP. Group membership changes in Active Directory automatically propagate through GCDS, allowing you to control access to Google Cloud resources by managing AD group membership.

The documentation emphasizes that to maintain Active Directory as the central system for identity and access management, you should "synchronize security groups from Active Directory instead of managing them in Cloud Identity or Google Workspace. With this approach, you can set up IAM so that you can use group memberships in Active Directory to control who has access to certain resources in Google Cloud."

This enables efficient access control at scale - rather than assigning individual users to IAM roles in each project, you define groups that model common roles in your organization and assign those groups to IAM roles.

### Why Other Options Are Wrong

- **B:** SAML 2.0 SSO handles authentication (verifying user identity), not authorization (permission assignment). While SAML SSO is part of the federation solution, it doesn't provision groups to Cloud Identity or enable IAM permission assignment. SAML SSO is used after GCDS provisions identities to allow users to authenticate using their AD credentials.

- **C:** The Cloud IAM API doesn't have built-in functionality to automatically synchronize with Active Directory. You would need to build custom integration code to continuously sync groups and memberships, which is exactly what GCDS already provides as a purpose-built tool.

- **D:** The Admin SDK is a programmatic interface for managing Cloud Identity/Google Workspace, but like option C, it doesn't provide automatic synchronization with Active Directory. You would need to build and maintain custom synchronization logic rather than using the purpose-built GCDS tool.

### References

- [Federate Google Cloud with Active Directory](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-introduction)
- [Active Directory Single Sign-On](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-configuring-single-sign-on)
