# Question 064

**Source:** https://www.examtopics.com/discussions/google/view/30350-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** FIPS 140-2, encryption, BoringCrypto, BoringSSL, Local SSD

---

## Question

In an effort for your company messaging app to comply with FIPS 140-2, a decision was made to use GCP compute and network services. The messaging app architecture includes a Managed Instance Group (MIG) that controls a cluster of Compute Engine instances. The instances use Local SSDs for data caching and UDP for instance-to-instance communications. The app development team is willing to make any changes necessary to comply with the standard Which options should you recommend to meet the requirements?
## Choices

- **A.** Encrypt all cache storage and VM-to-VM communication using the BoringCrypto module. Most Voted
- **B.** Set Disk Encryption on the Instance Template used by the MIG to customer-managed key and use BoringSSL for all data transit between instances.
- **C.** Change the app instance-to-instance communications from UDP to TCP and enable BoringSSL on clients' TLS connections.
- **D.** Set Disk Encryption on the Instance Template used by the MIG to Google-managed Key and use BoringSSL library on all instance-to-instance communications.

---

## Community

**Most Voted:** A


**Votes:** A: 56% | B: 25% | C: 19% (16 total)


**Top Comments:**

- (16 upvotes) Disk Encryption with customer-managed keys: FIPS 140-2 compliance often requires encryption, and using customer-managed encryption keys (CMEK) ensures that you have control over the encryption keys, w

- (4 upvotes) YES, as in your link: you need to encrypt SSD using your own solution, and BoringSSL is a library to use

- (4 upvotes) A. Encrypt all cache storage and VM-to-VM communication using the BoringCrypto module. This option ensures both storage (Local SSDs) and inter-instance communications are encrypted using a FIPS 140-2 

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D is correct because it aligns with Google Cloud's FIPS 140-2 compliance capabilities and the constraints of Local SSDs:

**Local SSD Encryption (Google-managed keys only):** Local SSDs cannot use customer-managed encryption keys (CMEK) or customer-supplied encryption keys (CSEK). They are automatically encrypted using Google-managed encryption keys that are deleted when the VM terminates. Google Cloud uses a FIPS 140-2 validated encryption module (BoringCrypto, certificate 4407) for all default encryption operations, including Local SSDs. This means using Google-managed keys on Local SSDs automatically provides FIPS 140-2 compliant encryption at rest.

**BoringSSL for Instance-to-Instance Communication:** BoringSSL is Google's TLS implementation that incorporates the BoringCrypto module, which is validated to FIPS 140-3 level 1 (backward compatible with FIPS 140-2). Using the BoringSSL library for instance-to-instance communications provides FIPS-compliant encryption in transit. BoringSSL supports both TCP and UDP protocols, so there's no need to change the application's UDP-based communication.

**No Protocol Change Required:** Google's encryption technologies (PSP - PSP Security Protocol) support non-TCP protocols like UDP and use unique encryption keys for each connection. The application can continue using UDP while still achieving FIPS compliance through BoringSSL.

### Why Other Options Are Wrong

- **A:** While BoringCrypto is the correct FIPS-validated module, you cannot directly "encrypt cache storage" with BoringCrypto on Local SSDs—encryption is automatic with Google-managed keys. This option is vague about implementation and doesn't specify using BoringSSL for the VM-to-VM communication layer.

- **B:** This option is technically impossible. Local SSDs do not support customer-managed encryption keys (CMEK). The documentation explicitly states: "You can't use your own keys with Local SSD disks because Local SSD disks use Google-owned and Google-managed encryption keys." Attempting to set disk encryption to a customer-managed key on Local SSDs will fail.

- **C:** Changing from UDP to TCP is unnecessary for FIPS compliance. BoringSSL and Google's encryption protocols support UDP traffic. This would require application changes that aren't needed and could impact the application's performance characteristics. Additionally, it only addresses client TLS connections, not the instance-to-instance communication requirement.

### References

- [Encryption in transit for Google Cloud](https://docs.cloud.google.com/docs/security/encryption-in-transit)
- [Default encryption at rest](https://docs.cloud.google.com/docs/security/encryption/default-encryption)
- [FIPS 140-2 Validated - Google Cloud Compliance](https://cloud.google.com/security/compliance/fips-140-2-validated)
- [Protect resources by using Cloud KMS keys](https://cloud.google.com/compute/docs/disks/customer-managed-encryption)
