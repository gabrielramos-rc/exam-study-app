# Question 128

**Source:** https://www.examtopics.com/discussions/google/view/75981-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Firewall Rules Logging, firewall troubleshooting, VPC Flow Logs, network logging

---

## Question

Users are reporting an outage on your public-facing application that is hosted on Compute Engine. You suspect that a recent change to your firewall rules is responsible. You need to test whether your firewall rules are working properly. What should you do?
## Choices

- **A.** Enable Firewall Rules Logging on the latest rules that were changed. Use Logs Explorer to analyze whether the rules are working correctly. Most Voted
- **B.** Connect to a bastion host in your VPC. Use a network traffic analyzer to determine at which point your requests are being blocked.
- **C.** In a pre-production environment, disable all firewall rules individually to determine which one is blocking user traffic.
- **D.** Enable VPC Flow Logs in your VPC. Use Logs Explorer to analyze whether the rules are working correctly.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (12 total)


**Top Comments:**

- (8 upvotes) Ans:A https://cloud.google.com/vpc/docs/firewall-rules-logging

- (6 upvotes) To test whether your firewall rules are working properly, you can enable Firewall Rules Logging on the latest rules that were changed and use Logs Explorer to analyze whether the rules are working cor

- (4 upvotes) A is right

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Firewall Rules Logging is specifically designed to audit, verify, and analyze the effects of firewall rules in production environments. When you suspect a recent firewall rule change is causing an outage, enabling Firewall Rules Logging on the recently changed rules provides immediate visibility into:

- Whether the rules are being applied as intended
- Which specific rules are allowing or denying traffic
- Whether higher-priority rules are overriding expected behavior
- The actual connections being affected by each rule

You can enable Firewall Rules Logging on specific rules without impacting production traffic, then use Logs Explorer to filter by resource type (VM instance, subnet) and view "firewall" logs. The logs show which rule matched each connection attempt, allowing you to quickly identify if a deny rule is incorrectly blocking legitimate traffic or if rule priorities are not configured as expected.

This approach provides targeted troubleshooting directly in production without requiring changes to the environment or disabling traffic.

### Why Other Options Are Wrong

- **B:** Using a bastion host with a network traffic analyzer requires manual traffic generation and packet analysis. This is time-consuming, doesn't provide visibility into which specific firewall rules are matching, and may not replicate the exact traffic patterns causing the user outage. It's also reactive rather than using GCP's native troubleshooting capabilities.

- **C:** Testing in a pre-production environment won't help troubleshoot a production outage that's happening right now. Additionally, pre-production may not have the same traffic patterns, source IPs, or network topology as production, making it difficult to reproduce the exact issue. This approach also delays resolution while users continue experiencing the outage.

- **D:** VPC Flow Logs capture general network traffic flows (source/destination IPs, ports, protocols, bytes transferred) but do not show which specific firewall rules matched or denied traffic. Flow logs are useful for understanding traffic patterns and volume but are not designed for firewall rule troubleshooting. Firewall Rules Logging is the purpose-built tool for validating firewall rule behavior.

### References

- [Firewall Rules Logging Overview](https://docs.cloud.google.com/firewall/docs/firewall-rules-logging)
- [Using Firewall Rules Logging](https://docs.cloud.google.com/firewall/docs/using-firewall-rules-logging)
- [Troubleshooting Policy and Access Problems](https://docs.cloud.google.com/vpc/docs/troubleshooting-policy-and-access-problems)
