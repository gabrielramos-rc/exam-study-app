# Question 272

**Source:** https://www.examtopics.com/discussions/google/view/147066-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Supporting compliance requirements
**Tags:** organization policy, resource location, compliance, gcp.resourceLocations

---

## Question

You work for a global company. Due to compliance requirements, certain Compute Engine instances that reside within specific projects must be located exclusively in cloud regions within the European Union (EU). You need to ensure that existing non-compliant workloads are remediated and prevent future Compute Engine instances from being launched in restricted regions. What should you do?
## Choices

- **A.** Use a third-party configuration management tool to monitor the location of Compute Engine instances. Automatically delete or migrate non-compliant instances, including existing deployments.
- **B.** Deploy a Security Command Center source to detect Compute Engine instances created outside the EU. Use a custom remediation function to automatically relocate the instances, run the function once a day.
- **C.** Use organization policy constraints in Resource Manager to enforce allowed regions for Compute Engine instance creation within specific projects.
- **D.** Set an organization policy that denies the creation of Compute Engine instances outside the EU. Apply the policy to the appropriate projects. Identify existing non-compliant instances and migrate the instances to compliant EU regions. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (7 total)


**Top Comments:**

- (3 upvotes) https://cloud.google.com/resource-manager/docs/organization-policy/defining-locations-supported-services

- (1 upvotes) https://cloud.google.com/resource-manager/docs/organization-policy/defining-locations-supported-services#compute-engine For example, an instance template is a global resource, but you might specify re

- (1 upvotes) https://cloud.google.com/resource-manager/docs/organization-policy/defining-locations-supported-services

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D is the complete and correct solution because it addresses both requirements stated in the question: preventing future non-compliant deployments AND remediating existing violations.

The solution uses the **`gcp.resourceLocations`** organization policy constraint, which can be set at the project level to restrict where Compute Engine instances can be created. You would configure this constraint to allow only EU regions (using values like `in:eu-locations` or `in:europe-locations`). However, as documented: "After you define resource locations, this limitation will apply only to newly-created resources. Resources you created before setting the resource locations constraint will continue to exist and perform their function."

This means organization policies are preventive controls for future resources but do NOT automatically remediate existing non-compliant instances. Therefore, the complete solution requires:
1. Setting the organization policy constraint (prevents future violations)
2. Manually identifying existing non-compliant instances
3. Migrating those instances to EU regions (remediates current violations)

Option D explicitly includes all three steps, making it the only complete answer.

### Why Other Options Are Wrong

- **A:** Using third-party tools is unnecessarily complex when Google Cloud provides native organization policy constraints. Additionally, automatically deleting instances could cause service disruptions, and automatic migration is technically infeasible (you cannot relocate running instances; they must be recreated).

- **B:** Security Command Center can detect compliance violations, but Compute Engine instances cannot be "automatically relocated" - they must be recreated in the target region. This option suggests an impossible automation and doesn't mention using organization policies to prevent future violations.

- **C:** While organization policy constraints are the correct preventive mechanism, this option is incomplete. It only addresses preventing future instances but completely ignores the requirement to remediate existing non-compliant workloads. The question explicitly states you need to "ensure that existing non-compliant workloads are remediated."

### References

- [Restricting Resource Locations | Resource Manager Documentation](https://docs.cloud.google.com/resource-manager/docs/organization-policy/defining-locations)
- [Resource locations supported services | Resource Manager Documentation](https://docs.cloud.google.com/resource-manager/docs/organization-policy/defining-locations-supported-services)
