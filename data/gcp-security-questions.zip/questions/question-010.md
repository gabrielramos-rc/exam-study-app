# Question 010

**Source:** https://www.examtopics.com/discussions/google/view/16103-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Logging, aggregated sink, log export, SIEM, folder-level logging

---

## Question

Your team needs to obtain a unified log view of all development cloud projects in your SIEM. The development projects are under the NONPROD organization folder with the test and pre-production projects. The development projects share the ABC-BILLING billing account with the rest of the organization. Which logging export strategy should you use to meet the requirements?
## Choices

- **A.** 1. Export logs to a Cloud Pub/Sub topic with folders/NONPROD parent and includeChildren property set to True in a dedicated SIEM project. 2. Subscribe SIEM to the topic. Most Voted
- **B.** 1. Create a Cloud Storage sink with billingAccounts/ABC-BILLING parent and includeChildren property set to False in a dedicated SIEM project. 2. Process Cloud Storage objects in SIEM.
- **C.** 1. Export logs in each dev project to a Cloud Pub/Sub topic in a dedicated SIEM project. 2. Subscribe SIEM to the topic.
- **D.** 1. Create a Cloud Storage sink with a publicly shared Cloud Storage bucket in each project. 2. Process Cloud Storage objects in SIEM.

---

## Community

**Most Voted:** A


**Votes:** A: 60% | C: 40% (25 total)


**Top Comments:**

- (34 upvotes) with this you would also be getting logs for Preprod and other environments under the folder. Hence A is eliminated. Answer should be C

- (9 upvotes) But that is exactly what requiremnets says in the question. ALL development projects. Now we have 2 tomorrow we are going to have 10 . Clearly answer is A

- (9 upvotes) A. Correct: This is the most effective and scalable solution. By creating a log sink at the folder level (folders/NONPROD) with includeChildren set to True, you capture logs from all projects within t

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is the correct approach for exporting logs from all development projects under the NONPROD folder to a SIEM. By creating a folder-level aggregated sink with `includeChildren` set to `True`, you enable the collection of logs from the NONPROD folder and all child resources (projects and subfolders) within it. This includes all development projects, test projects, and pre-production projects under that folder.

The aggregated sink architecture provides several key advantages:
- **Centralized management**: Single sink configuration at the folder level instead of managing individual project-level sinks
- **Automatic inclusion**: Logs from all existing and future projects under the NONPROD folder are automatically exported
- **Efficient routing**: Pub/Sub topics provide real-time streaming of logs to the SIEM with reliable, scalable message delivery
- **Simplified permissions**: One service account grant for the folder-level sink rather than managing permissions across multiple projects

The `includeChildren` property is essential for aggregated sinks—when set to `True`, it ensures that log entries from all projects, folders, and billing accounts contained within the parent resource (NONPROD folder) are exported to the destination, subject to any filters specified in the sink configuration.

### Why Other Options Are Wrong

- **B:** Using `billingAccounts/ABC-BILLING` as the parent would export logs from ALL projects in the organization that share this billing account, including non-NONPROD projects. Additionally, setting `includeChildren` to `False` would only export logs owned by the billing account itself, not from the projects. This doesn't meet the requirement of exporting only development project logs.

- **C:** Creating individual log exports in each development project would work functionally but is operationally inefficient and difficult to maintain. This approach requires configuring and managing a separate sink in every development project, and you must remember to configure sinks for any new development projects created in the future. This violates best practices for centralized log management.

- **D:** Creating publicly shared Cloud Storage buckets is a significant security risk and completely inappropriate for log data, which often contains sensitive information. Additionally, managing individual buckets per project creates the same operational complexity as option C. This option violates security best practices and should never be considered.

### References

- [Collate and route organization- and folder-level logs to supported destinations](https://docs.cloud.google.com/logging/docs/export/aggregated_sinks)
- [Route log entries | Cloud Logging](https://docs.cloud.google.com/logging/docs/routing/overview)
- [Aggregated sinks overview](https://docs.cloud.google.com/logging/docs/export/aggregated_sinks_overview)
