# Question 084

**Source:** https://www.examtopics.com/discussions/google/view/30374-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** service account, undelete, recovery, service account deletion

---

## Question

Your team uses a service account to authenticate data transfers from a given Compute Engine virtual machine instance of to a specified Cloud Storage bucket. An engineer accidentally deletes the service account, which breaks application functionality. You want to recover the application as quickly as possible without compromising security. What should you do?
## Choices

- **A.** Temporarily disable authentication on the Cloud Storage bucket.
- **B.** Use the undelete command to recover the deleted service account. Most Voted
- **C.** Create a new service account with the same name as the deleted service account.
- **D.** Update the permissions of another existing service account and supply those credentials to the applications.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (6 total)


**Top Comments:**

- (9 upvotes) B is correct answer here. https://cloud.google.com/iam/docs/reference/rest/v1/projects.serviceAccounts/undelete

- (7 upvotes) Thank you for sharing link, I agree B is right

- (3 upvotes) B. Use the undelete command to recover the deleted service account.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Using the `undelete` command is the correct solution for recovering an accidentally deleted service account. Google Cloud provides a 30-day window during which deleted service accounts can be undeleted. This approach is optimal because:

1. **Preserves Identity and Permissions**: When you undelete a service account, it retains its original numeric ID, and all previously granted IAM roles remain intact. This means the VM instance can immediately resume data transfers to Cloud Storage without any configuration changes.

2. **Fastest Recovery**: The undelete operation is a single command: `gcloud beta iam service-accounts undelete SERVICE_ACCOUNT_ID`. No need to reconfigure applications, update IAM bindings, or modify VM service account attachments.

3. **No Security Compromise**: Unlike creating a new account or using another account's credentials, undeleting restores the exact security posture that existed before the accidental deletion.

4. **30-Day Recovery Window**: Service accounts deleted within the last 30 days can be recovered. After this period, IAM permanently removes the service account and recovery becomes impossible.

The undelete command requires the service account's numeric ID (21-digit identifier), which can be found in audit logs or IAM policy bindings where it appears with a `deleted:` prefix.

### Why Other Options Are Wrong

- **A**: Temporarily disabling authentication on the Cloud Storage bucket creates a significant security vulnerability by allowing unauthenticated access to potentially sensitive data. This violates the requirement to not compromise security and exposes the bucket to unauthorized access.

- **C**: Creating a new service account with the same name creates a completely separate identity with a different numeric ID. This new account won't inherit any of the roles or permissions from the deleted account. You would need to manually recreate all IAM bindings, update the VM's service account attachment, and potentially modify application configurations—a time-consuming process that's slower than undeleting.

- **D**: Using another existing service account's credentials requires granting it all the necessary permissions, updating the VM instance to use the different service account, and potentially modifying application configurations. This is slower than undeleting and may create security concerns if the other service account has broader permissions than needed (violating least privilege).

### References

- [Delete and undelete service accounts | IAM Documentation](https://docs.cloud.google.com/iam/docs/service-accounts-delete-undelete)
- [Method: projects.serviceAccounts.undelete | IAM API](https://docs.cloud.google.com/iam/docs/reference/rest/v1/projects.serviceAccounts/undelete)
