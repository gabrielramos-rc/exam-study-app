# Question 170

**Source:** https://www.examtopics.com/discussions/google/view/79858-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, unmanaged accounts, transfer tool, user management, consumer accounts

---

## Question

You are onboarding new users into Cloud Identity and discover that some users have created consumer user accounts using the corporate domain name. How should you manage these consumer user accounts with Cloud Identity?
## Choices

- **A.** Use Google Cloud Directory Sync to convert the unmanaged user accounts.
- **B.** Create a new managed user account for each consumer user account.
- **C.** Use the transfer tool for unmanaged user accounts. Most Voted
- **D.** Configure single sign-on using a customer's third-party provider.

---

## Community

**Most Voted:** C


**Votes:** A: 6% | C: 94% (17 total)


**Top Comments:**

- (5 upvotes) C is the answer. https://support.google.com/a/answer/6178640?hl=en The transfer tool enables you to see what unmanaged users exist, and then invite those unmanaged users to the domain.

- (5 upvotes) C is right

- (3 upvotes) C. https://cloud.google.com/architecture/identity/migrating-consumer-accounts "In addition to showing you all unmanaged accounts, the transfer tool for unmanaged users lets you initiate an account tra

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

The **transfer tool for unmanaged users** is the correct solution for managing consumer accounts that were created using your corporate domain name. When you verify a domain in Cloud Identity or Google Workspace, consumer accounts using that domain automatically become "unmanaged accounts." Within approximately 12 hours, these accounts appear in the transfer tool at `https://admin.google.com/ac/unmanaged`.

The transfer tool enables super administrators to:
- View all unmanaged accounts linked to verified domains
- Send account transfer requests to affected users
- Track request status and manage migrations in batches
- Transfer account ownership and all associated data to your organization

The migration process requires explicit user consent. Users receive an email notification with the transfer request, and once they accept, their consumer account becomes a managed account under your Cloud Identity organization, with all data preserved. This is the official Google-recommended method for consolidating consumer accounts into managed organizational accounts.

### Why Other Options Are Wrong

- **A:** Google Cloud Directory Sync (GCDS) is used to synchronize users and groups from an external LDAP directory (like Active Directory) to Cloud Identity. It does not convert existing consumer Google accounts to managed accounts. GCDS is for provisioning new users from an authoritative directory source, not for migrating existing consumer accounts.

- **B:** Creating new managed accounts would result in duplicate accounts and does not address the existing consumer accounts. Users would lose access to their existing data and services associated with the consumer account. This approach creates user confusion and administrative overhead without actually solving the unmanaged account problem.

- **D:** Single sign-on (SSO) configuration with a third-party identity provider is for authentication purposes and does not convert or transfer consumer accounts to managed accounts. SSO is about how users authenticate, not about account ownership or management. The consumer accounts would still exist outside your organizational control.

### References

- [Migrate consumer accounts | Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/migrating-consumer-accounts)
- [Evict consumer accounts | Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/evicting-consumer-accounts)
