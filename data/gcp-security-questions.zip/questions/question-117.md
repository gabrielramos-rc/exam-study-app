# Question 117

**Source:** https://www.examtopics.com/discussions/google/view/75902-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** service account, organization policy, CI/CD security, service account keys

---

## Question

You plan to deploy your cloud infrastructure using a CI/CD cluster hosted on Compute Engine. You want to minimize the risk of its credentials being stolen by a third party. What should you do?
## Choices

- **A.** Create a dedicated Cloud Identity user account for the cluster. Use a strong self-hosted vault solution to store the user's temporary credentials.
- **B.** Create a dedicated Cloud Identity user account for the cluster. Enable the constraints/iam.disableServiceAccountCreation organization policy at the project level.
- **C.** Create a custom service account for the cluster. Enable the constraints/iam.disableServiceAccountKeyCreation organization policy at the project level Most Voted
- **D.** Create a custom service account for the cluster. Enable the constraints/iam.allowServiceAccountCredentialLifetimeExtension organization policy at the project level.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (17 total)


**Top Comments:**

- (7 upvotes) Yes C. Create a custom service account for the cluster. Enable the constraints/iam.disableServiceAccountKeyCreation organization policy at the project level

- (4 upvotes) Answer is (C). To minimize the risk of credentials being stolen by third parties, it is desirable to control the use of unmanaged long-term credentials. ・"constraints/iam.allowServiceAccountCredential

- (2 upvotes) Also think it is C

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is correct because it implements two critical security best practices for CI/CD workloads on Compute Engine:

1. **Uses a custom service account**: Service accounts are the correct identity type for compute workloads and applications, not Cloud Identity user accounts. Service accounts provide machine-to-machine authentication.

2. **Enables the `constraints/iam.disableServiceAccountKeyCreation` organization policy**: This constraint prevents the creation of user-managed service account keys (long-lived credentials), which are the primary credential theft risk. When this policy is enforced, the cluster must use the service account attached to the Compute Engine VM instance, which provides short-lived, auto-rotating credentials through the metadata server. This eliminates the need to store and manage persistent credential files that could be stolen.

By preventing service account key creation, you force the use of more secure authentication methods like:
- Attached service accounts on Compute Engine (credentials automatically managed via metadata service)
- Workload Identity Federation for external systems
- Short-lived access tokens instead of long-lived keys

This approach follows Google's security recommendation to "avoid user-managed service account keys whenever possible" and instead use managed workload identities.

### Why Other Options Are Wrong

- **A:** Cloud Identity user accounts are for human users, not machine/application workloads. Using a vault to store credentials still creates a long-lived credential that must be managed and protected, which doesn't minimize risk as effectively as not having keys at all.

- **B:** This option incorrectly uses a Cloud Identity user account instead of a service account. Additionally, the `disableServiceAccountCreation` constraint prevents creating new service accounts entirely, which doesn't address the credential theft concern—it's about limiting service account proliferation, not securing their credentials.

- **D:** The `allowServiceAccountCredentialLifetimeExtension` policy is not a real Google Cloud organization policy constraint. Even if it existed, extending credential lifetime would increase security risk, not minimize it.

### References

- [Best practices for managing service account keys](https://docs.cloud.google.com/iam/docs/best-practices-for-managing-service-account-keys)
- [Restricting service account usage with organization policies](https://docs.cloud.google.com/resource-manager/docs/organization-policy/restricting-service-accounts)
- [Troubleshoot organization policy errors for service accounts](https://docs.cloud.google.com/iam/docs/troubleshoot-org-policies)
