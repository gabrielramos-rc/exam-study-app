# Question 291

**Source:** https://www.examtopics.com/discussions/google/view/147085-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Workforce Identity Federation, external identity provider, attribute mapping, CEL, syncless authentication

---

## Question

Your organization шs using a third-party identity and authentication provider to centrally manage users. You want to use this identity provider to grant access to the Google Cloud console without syncing identities to Google Cloud. Users should receive permissions based on attributes. What should you do?
## Choices

- **A.** Configure the central identity provider as a workforce identity pool provider in Workforce Identity Federation. Create an attribute mapping by using the Common Expression Language (CEL). Most Voted
- **B.** Configure a periodic synchronization of relevant users and groups with attributes to Cloud Identity. Activate single sign-on by using the Security Assertion Markup Language (SAML).
- **C.** Set up the Google Cloud Identity Platform. Configure an external authentication provider by using OpenID Connect and link user accounts based on attributes.
- **D.** Activate external identities on the Identity-Aware Proxy. Use the Security Assertion Markup Language (SAML) to configure authentication based on attributes to the central authentication provider.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (7 total)


**Top Comments:**

- (4 upvotes) I was wrong. Correct answer is C.

- (1 upvotes) A is good.

- (1 upvotes) Clearly A.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

**Workforce Identity Federation** is specifically designed for this exact use case: allowing workforce users (employees, partners, contractors) to access the Google Cloud console using their existing external identity provider credentials without syncing identities to Google Cloud.

Key features that match the requirements:

1. **Syncless authentication**: Workforce Identity Federation is explicitly syncless, meaning you don't need to use directory synchronization tools to copy user identities from your IdP to Google Cloud Identity. Users authenticate directly with their external IdP.

2. **Google Cloud console access**: Workforce Identity Federation enables single sign-on (SSO) to the Google Cloud console through federated identities, allowing users to access Google Cloud resources using their external credentials.

3. **Attribute-based permissions**: The Common Expression Language (CEL) is used to create attribute mappings that transform IdP claims into Google Cloud attributes. You can map attributes like `google.subject` (unique user ID), `google.groups` (group membership), and custom attributes prefixed with `attribute.` for authorization decisions. CEL expressions can transform attribute values using standard functions plus custom functions like `split` and `join`.

4. **Attribute conditions**: You can also use CEL expressions to define attribute conditions that control which users can authenticate. For example: `assertion.role == 'gcp-users'` ensures only users with specific attributes can sign in.

The workflow is: External IdP → Workforce Identity Pool → Attribute Mapping (CEL) → Google Cloud Console Access with IAM-based permissions.

### Why Other Options Are Wrong

- **B:** This approach requires periodic synchronization of users and groups to Cloud Identity, which directly contradicts the requirement of "without syncing identities to Google Cloud." While SAML SSO would work for authentication, the synchronization overhead is unnecessary when Workforce Identity Federation provides a syncless solution.

- **C:** Google Cloud Identity Platform is designed for customer-facing applications (customer identity and access management - CIAM), not for granting workforce users access to the Google Cloud console. It's used when you're building applications that need to authenticate your customers, not when you want your employees to access Google Cloud resources.

- **D:** Identity-Aware Proxy (IAP) is used to control access to specific applications and resources, not to provide general access to the Google Cloud console. IAP is a resource-level access control mechanism that works in conjunction with identity management, but it doesn't replace the need for a proper workforce identity solution. Additionally, IAP doesn't provide the attribute mapping capabilities needed for this use case.

### References

- [Workforce Identity Federation Overview](https://docs.cloud.google.com/iam/docs/workforce-identity-federation)
- [Configure Workforce Identity Federation](https://docs.cloud.google.com/iam/docs/configuring-workforce-identity-federation)
