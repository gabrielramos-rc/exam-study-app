# Question 336

**Source:** https://www.examtopics.com/discussions/google/view/311197-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** CMEK, customer-managed encryption keys, Cloud KMS, Cloud Storage encryption, key migration

---

## Question

Your organization is storing regulated data in Cloud Storage. Data in Cloud Storage buckets is encrypted by Google-managed encryption keys. To meet compliance requirements, you need to update the existing data to use customer-managed encryption keys instead. What should you do?
## Choices

- **A.** Create a new key ring and key in the Cloud Key Management Service. In each Cloud Storage bucket configuration, change the encryption type to customer-managed encryption key.
- **B.** Identify which projects contain Cloud Storage buckets with regulated data. Apply the restrictNonCmekServices organization policy constraint to the identified projects or parent folder.
- **C.** Create a new key ring and key in the Cloud Key Management Service. Identify which projects contain Cloud Storage buckets with regulated data. Perform a write action on all existing objects in the buckets.
- **D.** Create a customer-managed encryption key. Change the encryption type in each Cloud Storage bucket configuration to the newly created key. Perform a write action on all existing objects in the buckets. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (1 total)

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

To migrate existing Cloud Storage objects from Google-managed encryption keys (GMEK) to customer-managed encryption keys (CMEK), you must perform **both** actions described in option D:

1. **Create a CMEK in Cloud KMS**: Create a key ring and key that will be used for encryption
2. **Set the CMEK as the bucket's default encryption key**: This ensures new objects uploaded to the bucket will automatically use the CMEK
3. **Rewrite all existing objects**: Critically, changing the bucket's default encryption key does **not** automatically re-encrypt existing objects. The documentation explicitly states: "You cannot encrypt an object with a CMEK by updating the object's metadata. Include the key as part of a rewrite of the object instead."

The rewrite operation (write action) causes Cloud Storage to decrypt each object with its current key and re-encrypt it with the new CMEK. This must be done for every existing object in the bucket to complete the migration.

### Why Other Options Are Wrong

- **A:** Only changes the bucket's default encryption key, which applies to new uploads going forward. Existing objects remain encrypted with GMEK until they are explicitly rewritten. This does not meet the requirement to "update the existing data."

- **B:** The `restrictNonCmekServices` organization policy constraint prevents creating new resources without CMEK, but it is a preventive control for future resources. It does not migrate or re-encrypt existing data that is already encrypted with GMEK.

- **C:** Missing the critical step of setting the CMEK on the bucket configuration. While it correctly identifies the need to perform a write action on existing objects, without setting the bucket's default encryption key first, the rewrite operations would have no CMEK to use (unless you specify the key for each individual object, which is inefficient). The bucket configuration change is necessary to establish the default CMEK.

### References

- [Customer-managed encryption keys | Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption/customer-managed-keys)
- [Customer-managed encryption keys (CMEK) | Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/cmek)
