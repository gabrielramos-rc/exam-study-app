# Question 113

**Source:** https://www.examtopics.com/discussions/google/view/74830-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, service perimeter, Shared VPC, BigQuery

---

## Question

You are troubleshooting access denied errors between Compute Engine instances connected to a Shared VPC and BigQuery datasets. The datasets reside in a project protected by a VPC Service Controls perimeter. What should you do?
## Choices

- **A.** Add the host project containing the Shared VPC to the service perimeter. Most Voted
- **B.** Add the service project where the Compute Engine instances reside to the service perimeter.
- **C.** Create a service perimeter between the service project where the Compute Engine instances reside and the host project that contains the Shared VPC.
- **D.** Create a perimeter bridge between the service project where the Compute Engine instances reside and the perimeter that contains the protected BigQuery datasets.

---

## Community

**Most Voted:** A


**Votes:** A: 72% | B: 22% | D: 6% (32 total)


**Top Comments:**

- (13 upvotes) Why D. Create a perimeter bridge is Correct: Problem Analysis: The BigQuery datasets reside within a service perimeter. The Compute Engine instances are in a service project connected to a Shared VPC,

- (4 upvotes) but the instance will communicate via the host project from the shared subnet

- (3 upvotes) A. Add the host project containing the Shared VPC to the service perimeter.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

When Compute Engine instances in a Shared VPC service project need to access BigQuery datasets protected by a VPC Service Controls perimeter, you must add the **service project** (where the Compute Engine instances reside) to the same service perimeter that protects the BigQuery datasets.

VPC Service Controls enforces perimeter boundaries at the **project level**, not the network level. The key principle is that all projects involved in a resource access operation must be within the same service perimeter. In this scenario:

1. The BigQuery datasets are in a project protected by a VPC Service Controls perimeter
2. The Compute Engine instances making the requests are in a service project (attached to Shared VPC)
3. For the Compute Engine instances to access BigQuery, their **service project** must be added to the perimeter

The Shared VPC architecture separates network management (host project) from resource deployment (service projects). The host project only provides the network infrastructure - it doesn't contain the Compute Engine instances themselves. Since VPC Service Controls evaluates the **source project** of API requests (the service project with the Compute instances), that's the project that needs perimeter membership.

### Why Other Options Are Wrong

- **A:** Adding only the host project doesn't solve the problem because the Compute Engine instances and their API requests originate from the **service project**, not the host project. VPC Service Controls evaluates the project containing the resource making the request. While it's recommended to keep host and service projects in the same perimeter for Shared VPC scenarios, adding only the host project won't grant the Compute instances access to BigQuery.

- **C:** You cannot create a service perimeter "between" projects. VPC Service Controls perimeters are boundaries that contain projects - they're not created between projects. Projects are either inside or outside a perimeter. This option describes an invalid configuration.

- **D:** A perimeter bridge would only be appropriate if the service project needed to remain in a **different** perimeter from the BigQuery project. However, the question indicates the Compute instances need direct access to BigQuery datasets, which is best achieved by adding the service project to the existing perimeter. Perimeter bridges add complexity and are used for controlled communication between separate perimeters, not for resolving basic access within a single security boundary.

### References

- [Supported products and limitations - VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/supported-products)
- [Service perimeter details and configuration](https://docs.cloud.google.com/vpc-service-controls/docs/service-perimeters)
- [Troubleshoot common issues - VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/troubleshooting)
