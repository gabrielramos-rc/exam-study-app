# Question 044

**Source:** https://www.examtopics.com/discussions/google/view/16554-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Identity-Aware Proxy, IAP, App Engine, authentication, context-aware access, internal application

---

## Question

Your company is using GSuite and has developed an application meant for internal usage on Google App Engine. You need to make sure that an external user cannot gain access to the application even when an employee's password has been compromised. What should you do?
## Choices

- **A.** Enforce 2-factor authentication in GSuite for all users.
- **B.** Configure Cloud Identity-Aware Proxy for the App Engine Application. Most Voted
- **C.** Provision user passwords using GSuite Password Sync.
- **D.** Configure Cloud VPN between your private network and GCP.

---

## Community

**Most Voted:** B


**Votes:** A: 47% | B: 53% (15 total)


**Top Comments:**

- (22 upvotes) IAP Benefits: Zero-trust access control at the application level Verifies user identity and context before allowing access Blocks access even with valid credentials if context is suspicious Integratio

- (4 upvotes) The key is external user. Best practice is to have internal users/datacenter connect via VPN for security purpose, correct? External users will try to connect via Internet - they still cannot reach th

- (3 upvotes) But if the user's password is compromised and there is no 2FA configured for that account, an attacker would be able to authenticate even if the application uses IAP.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud Identity-Aware Proxy (IAP) provides the strongest protection against unauthorized access, even when employee credentials are compromised. IAP establishes a centralized authorization layer for applications accessed by HTTPS, replacing network-level firewalls with application-level access control.

The key security advantage is that IAP goes beyond simple authentication:

1. **Context-Aware Access**: IAP can enforce additional security requirements such as device posture (trusted corporate device, secure password, up-to-date patch level), IP address restrictions, and access levels. Even if an attacker has a valid password, they cannot access the application from an untrusted device or unauthorized location.

2. **Centralized Authorization**: IAP uses IAM roles to control who can access the application. Only users with the "IAP-secured Web App User" role can access the resource, providing fine-grained authorization separate from authentication.

3. **Request Attribute Validation**: IAP evaluates multiple factors including access levels, URL host/path, date/time, and request context - meaning access decisions consider when, where, and what resources are being accessed, not just who is requesting access.

4. **Integration with Google Workspace**: Since the company uses GSuite (now Google Workspace), IAP seamlessly integrates with existing identity infrastructure while adding additional security layers.

For an App Engine application meant for internal usage, IAP is the recommended Google Cloud-native solution that provides defense-in-depth protection.

### Why Other Options Are Wrong

- **A (2-factor authentication):** While 2FA adds an additional authentication factor, it only protects against password compromise - it doesn't prevent access if the second factor is also compromised (e.g., through phishing, SIM swapping, or malware). The question specifically states "even when an employee's password has been compromised," implying we need protection beyond just stronger authentication. IAP can work in conjunction with 2FA but adds context-aware authorization.

- **C (GSuite Password Sync):** Password Sync synchronizes passwords between Active Directory and Google Workspace, which is useful for user experience but provides no additional security protection. It actually has nothing to do with preventing unauthorized access when credentials are compromised - it's simply a password management convenience feature.

- **D (Cloud VPN):** Configuring a VPN between a private network and GCP would restrict access to users on the corporate network, but this doesn't address the core requirement. If an employee's password is compromised, an attacker could potentially gain access to the corporate network and then access the application through the VPN. Additionally, VPN doesn't provide the granular, application-level access control that IAP offers, and it's less flexible for modern work environments with remote employees.

### References

- [Identity-Aware Proxy Overview](https://docs.cloud.google.com/iap/docs/concepts-overview)
- [Enabling IAP for App Engine](https://docs.cloud.google.com/iap/docs/enabling-app-engine)
- [Setting up Context-Aware Access with IAP](https://docs.cloud.google.com/iap/docs/cloud-iap-context-aware-access-howto)
