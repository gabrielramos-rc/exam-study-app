# Question 102

**Source:** https://www.examtopics.com/discussions/google/view/75400-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** IAM, billing, least privilege, Billing Account Viewer, Billing Account Costs Manager

---

## Question

An office manager at your small startup company is responsible for matching payments to invoices and creating billing alerts. For compliance reasons, the office manager is only permitted to have the Identity and Access Management (IAM) permissions necessary for these tasks. Which two IAM roles should the office manager have? (Choose two.)
## Choices

- **A.** Organization Administrator
- **B.** Project Creator
- **C.** Billing Account Viewer Most Voted
- **D.** Billing Account Costs Manager Most Voted
- **E.** Billing Account User

---

## Community

**Most Voted:** CD


**Votes:** CD: 90% | DE: 10% (29 total)


**Top Comments:**

- (15 upvotes) CD is right

- (6 upvotes) Billing Account Costs Manager - does not exist! ?!

- (3 upvotes) the link you post talking about Permissions required to ACCESS billing documentsn not to link project to a billing account you should have the Billing Account User role, the good answer is D,E

---

## Answer

**Correct:** C, D

**Confidence:** high

### Explanation

The office manager has two specific responsibilities that require distinct IAM roles following the principle of least privilege:

1. **Matching payments to invoices** requires **Billing Account Viewer (C)**. This role provides read-only access to billing information with permissions including:
   - `billing.accounts.get` and `billing.accounts.getSpendingInformation` - view billing account details
   - `billing.accounts.getPricing` - view pricing information
   - Access to view invoices, payment transactions, and billing documents
   - Cannot modify any billing settings (read-only access)

2. **Creating billing alerts** requires **Billing Account Costs Manager (D)**. This role provides permissions to manage budgets and alerts:
   - `billing.budgets.create`, `billing.budgets.update`, `billing.budgets.delete` - full budget management
   - `billing.anomaliesConfigs.update` - configure cost anomaly detection
   - `billing.accounts.updateUsageExportSpec` - manage cost export configurations
   - Includes all viewer permissions plus write access for cost management features

Together, these two roles provide exactly the permissions needed for the office manager's duties without granting excessive privileges like administrative access.

### Why Other Options Are Wrong

- **A. Organization Administrator:** Far too broad - grants full administrative control over the entire organization including all resources, IAM policies, and organizational settings. Violates the principle of least privilege and compliance requirements.

- **B. Project Creator:** Completely unrelated to billing tasks. This role allows creating new GCP projects and would grant unnecessary permissions that have nothing to do with viewing invoices or managing billing alerts.

- **E. Billing Account User:** This role is designed for linking projects to billing accounts (`billing.accounts.get` and `resourcemanager.projects.createBillingAssignment`). It does not provide permissions to view invoices, payment transactions, or create/manage billing budgets and alerts. It's used by project creators to associate projects with billing, not for financial oversight tasks.

### References

- [Cloud Billing access control and permissions](https://docs.cloud.google.com/billing/docs/how-to/billing-access)
- [Cloud Billing roles and permissions](https://docs.cloud.google.com/iam/docs/roles-permissions/billing)
- [IAM roles for billing-related job functions](https://docs.cloud.google.com/iam/docs/job-functions/billing)
