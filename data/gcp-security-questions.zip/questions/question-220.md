# Question 220

**Source:** https://www.examtopics.com/discussions/google/view/117339-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, service perimeter, ingress policy, least privilege

---

## Question

You manage one of your organization's Google Cloud projects (Project A). A VPC Service Control (SC) perimeter is blocking API access requests to this project, including Pub/Sub. A resource running under a service account in another project (Project B) needs to collect messages from a Pub/Sub topic in your project. Project B is not included in a VPC SC perimeter. You need to provide access from Project B to the Pub/Sub topic in Project A using the principle of least privilege. What should you do?
## Choices

- **A.** Configure an ingress policy for the perimeter in Project A, and allow access for the service account in Project B to collect messages. Most Voted
- **B.** Create an access level that allows a developer in Project B to subscribe to the Pub/Sub topic that is located in Project A.
- **C.** Create a perimeter bridge between Project A and Project B to allow the required communication between both projects.
- **D.** Remove the Pub/Sub API from the list of restricted services in the perimeter configuration for Project A.

---

## Community

**Most Voted:** A


**Votes:** A: 67% | B: 13% | C: 20% (15 total)


**Top Comments:**

- (3 upvotes) Ingress: Refers to any access by an API client from outside the service perimeter to resources within a service perimeter. Example: A Cloud Storage client outside a service perimeter calling Cloud Sto

- (3 upvotes) This is the correct reason why the answer is A

- (2 upvotes) Principle of Least Privilege: By configuring an ingress policy, you can precisely define which specific service account from Project B is allowed to access the Pub/Sub topic in Project A. This approac

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Configuring an ingress policy for the VPC Service Controls perimeter in Project A is the correct solution that follows the principle of least privilege. Ingress rules allow you to grant access to Google Cloud resources inside a perimeter based on the context of the API request from clients outside the perimeter.

For this scenario, you would create an ingress rule that specifies:
- **Identity**: The specific service account from Project B (using `identities: [serviceAccount:EMAIL_ADDRESS]`)
- **Source**: The source project (Project B) using `resource: projects/PROJECT_NUMBER`
- **Service operations**: Specific Pub/Sub methods needed to collect messages (such as `pubsub.subscriptions.pull` or `pubsub.subscriptions.consume`)
- **Resources**: The protected Project A

According to the documentation, "a request from a client outside the perimeter to a Google Cloud resource within the perimeter is allowed if the conditions of the necessary ingress rule are satisfied." This approach maintains security by only allowing the specific service account to perform specific operations on specific resources, without opening the entire perimeter or adding unnecessary projects to it.

### Why Other Options Are Wrong

- **B.** Access levels define network origins (IP addresses, VPCs, etc.) or device attributes, not user identities like developers. Access levels cannot grant a developer permission to subscribe to Pub/Sub topics—this requires IAM permissions and ingress policies. Additionally, this focuses on a developer rather than the service account that actually needs access.

- **C.** A perimeter bridge would add both Project A and Project B to the same logical perimeter, effectively merging their security boundaries. This violates least privilege because it would allow unrestricted access between all resources in both projects, not just the specific Pub/Sub topic. Perimeter bridges are appropriate when you need bidirectional, broad access between projects, which is not the requirement here.

- **D.** Removing Pub/Sub from the list of restricted services would completely eliminate VPC Service Controls protection for all Pub/Sub resources in Project A, exposing them to access from anywhere. This is the opposite of least privilege and defeats the purpose of having VPC Service Controls in place. The perimeter was intentionally configured to protect Pub/Sub, so removing this protection is not acceptable.

### References

- [Ingress and egress rules | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/ingress-egress-rules)
- [Secure data exchange with ingress and egress rules | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/secure-data-exchange)
