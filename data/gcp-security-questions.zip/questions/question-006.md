# Question 006

**Source:** https://www.examtopics.com/discussions/google/view/15920-exam-professional-cloud-security-engineer-topic-1-question-6/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Cloud Armor, DDoS, WAF, load balancer, CIDR

---

## Question

A customer needs to launch a 3-tier internal web application on Google Cloud Platform (GCP). The customer's internal compliance requirements dictate that end- user access may only be allowed if the traffic seems to originate from a specific known good CIDR. The customer accepts the risk that their application will only have SYN flood DDoS protection. They want to use GCP's native SYN flood protection. Which product should be used to meet these requirements?
## Choices

- **A.** Cloud Armor
- **B.** VPC Firewall Rules Most Voted
- **C.** Cloud Identity and Access Management
- **D.** Cloud CDN

---

## Community

**Most Voted:** B


**Votes:** A: 47% | B: 53% (36 total)


**Top Comments:**

- (18 upvotes) GCP doesn't have a native VPC firewall for SYN flood protection; that function is handled by Cloud Armor, which is a separate, edge-based service for DDoS mitigation. Cloud Armor uses security policie

- (4 upvotes) For internal web application, it shall be used by VPC Firewall Rules

- (4 upvotes) Answer A if no Load balancer used

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Cloud Armor is the correct choice because it meets both critical requirements:

1. **Native SYN flood DDoS protection**: Cloud Armor provides always-on DDoS protection against network protocol and volumetric attacks, specifically including SYN floods. When used with external Application Load Balancers, Cloud Armor automatically detects and mitigates Layer 3 and Layer 4 attacks (including SYN floods) at Google's edge, before traffic reaches the application. This protection is automatic and built into the service.

2. **CIDR-based access control**: Cloud Armor security policies support IP allowlist/denylist rules. You can configure rules in Basic mode to allow traffic only from specific IP addresses or CIDR ranges. The policy can restrict access to the load balancer to only the customer's known good CIDR block, meeting the compliance requirement.

Cloud Armor works with external Application Load Balancers to provide both layer 7 (application) and layer 3/4 (network/transport) protection. For a 3-tier internal web application exposed through a load balancer, Cloud Armor provides the exact combination of DDoS protection and IP-based access control required.

### Why Other Options Are Wrong

- **B (VPC Firewall Rules):** While VPC firewall rules can filter traffic based on IP ranges and protocols, they do not provide native SYN flood DDoS protection. Firewall rules operate at the VPC level and filter based on simple IP/port/protocol criteria, but they lack the sophisticated DDoS mitigation capabilities that Cloud Armor provides at Google's edge infrastructure.

- **C (Cloud Identity and Access Management):** IAM is for authentication and authorization of users and service accounts accessing GCP resources and APIs. It does not provide network-level traffic filtering based on source IP CIDR ranges, nor does it offer any DDoS protection capabilities. IAM is not designed for perimeter security.

- **D (Cloud CDN):** Cloud CDN is a content delivery network for caching and accelerating content delivery. While it can improve performance and provide some incidental DDoS protection through its distributed nature, it does not offer configurable SYN flood protection or CIDR-based access control policies. CDN is primarily focused on performance, not security.

### References

- [Cloud Armor Security Policy Overview](https://docs.cloud.google.com/armor/docs/security-policy-overview)
- [Configure Cloud Armor Security Policies](https://docs.cloud.google.com/armor/docs/configure-security-policies)
- [Cloud Armor Product Overview](https://docs.cloud.google.com/armor/docs/cloud-armor-overview)
- [Configure Advanced Network DDoS Protection](https://docs.cloud.google.com/armor/docs/advanced-network-ddos)
