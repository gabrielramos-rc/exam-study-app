# Question 103

**Source:** https://www.examtopics.com/discussions/google/view/75889-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Secret Manager, IAM, CMEK, environment separation, granular access control

---

## Question

You are designing a new governance model for your organization's secrets that are stored in Secret Manager. Currently, secrets for Production and Non- Production applications are stored and accessed using service accounts. Your proposed solution must: ✑ Provide granular access to secrets ✑ Give you control over the rotation schedules for the encryption keys that wrap your secrets ✑ Maintain environment separation ✑ Provide ease of management Which approach should you take?
## Choices

- **A.** 1. Use separate Google Cloud projects to store Production and Non-Production secrets. 2. Enforce access control to secrets using project-level identity and Access Management (IAM) bindings. 3. Use customer-managed encryption keys to encrypt secrets. Most Voted
- **B.** 1. Use a single Google Cloud project to store both Production and Non-Production secrets. 2. Enforce access control to secrets using secret-level Identity and Access Management (IAM) bindings. 3. Use Google-managed encryption keys to encrypt secrets.
- **C.** 1. Use separate Google Cloud projects to store Production and Non-Production secrets. 2. Enforce access control to secrets using secret-level Identity and Access Management (IAM) bindings. 3. Use Google-managed encryption keys to encrypt secrets.
- **D.** 1. Use a single Google Cloud project to store both Production and Non-Production secrets. 2. Enforce access control to secrets using project-level Identity and Access Management (IAM) bindings. 3. Use customer-managed encryption keys to encrypt secrets.

---

## Community

**Most Voted:** A


**Votes:** A: 84% | C: 16% (19 total)


**Top Comments:**

- (13 upvotes) It is possible to grant IAM bindind to secret-level which is more granular than project-level but considering that it is necessary to manage encryption keys life-cycle, then the answer is A due to C d

- (6 upvotes) That's Answer A....

- (4 upvotes) Yes , A is right

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A satisfies all four requirements:

1. **Granular access to secrets**: With separate projects for Production and Non-Production, project-level IAM provides environment-based granularity. Service accounts for each environment only access secrets in their respective project.

2. **Control over encryption key rotation schedules**: **CMEK (Customer-Managed Encryption Keys) is explicitly required** by this requirement. The question states "Give you control over the rotation schedules for the encryption keys that wrap your secrets." Google-managed keys rotate automatically without customer control. Only CMEK gives you explicit control over when and how encryption keys rotate.

3. **Environment separation**: Separate Google Cloud projects for Production and Non-Production provide strong isolation boundaries - a security best practice.

4. **Ease of management**: Project-level IAM is simpler to manage than secret-level IAM when environments are already separated by project. CMEK adds some overhead but is required by the explicit encryption key control requirement.

The key insight is that the requirement for "control over encryption key rotation schedules" explicitly mandates CMEK. This eliminates Options B and C which use Google-managed keys.

### Why Other Options Are Wrong

- **B:** Uses a single project for both Production and Non-Production secrets, failing to maintain environment separation. Also uses Google-managed keys, which don't give control over rotation schedules.

- **C:** Uses Google-managed encryption keys, which rotate automatically without customer control. This fails the explicit requirement to "give you control over the rotation schedules for the encryption keys."

- **D:** Uses a single project (no environment separation) and project-level IAM in a single project provides no granularity at all. While it uses CMEK, it fails two other requirements.

### References

- [Access control with IAM | Secret Manager](https://cloud.google.com/secret-manager/docs/access-control)
- [Enable customer-managed encryption keys for Secret Manager](https://cloud.google.com/secret-manager/docs/cmek)
- [Cloud KMS key rotation](https://cloud.google.com/kms/docs/key-rotation)
