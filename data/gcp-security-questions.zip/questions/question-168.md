# Question 168

**Source:** https://www.examtopics.com/discussions/google/view/79803-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, service perimeter, data exfiltration, Cloud Storage, defense-in-depth

---

## Question

Your security team wants to implement a defense-in-depth approach to protect sensitive data stored in a Cloud Storage bucket. Your team has the following requirements: ✑ The Cloud Storage bucket in Project A can only be readable from Project B. ✑ The Cloud Storage bucket in Project A cannot be accessed from outside the network. ✑ Data in the Cloud Storage bucket cannot be copied to an external Cloud Storage bucket. What should the security team do?
## Choices

- **A.** Enable domain restricted sharing in an organization policy, and enable uniform bucket-level access on the Cloud Storage bucket.
- **B.** Enable VPC Service Controls, create a perimeter around Projects A and B, and include the Cloud Storage API in the Service Perimeter configuration. Most Voted
- **C.** Enable Private Access in both Project A and B's networks with strict firewall rules that allow communication between the networks.
- **D.** Enable VPC Peering between Project A and B's networks with strict firewall rules that allow communication between the networks.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (12 total)


**Top Comments:**

- (7 upvotes) Answer is B, but you can ave vpc peering between two projects in the same organization, nothing prevents that if you have only two prjects to communicates vpc peering i better than shared vpc ;)

- (4 upvotes) B: https://cloud.google.com/vpc-service-controls/docs/overview

- (4 upvotes) https://www.examtopics.com/discussions/google/view/33958-exam-professional-cloud-security-engineer-topic-1-question/

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

VPC Service Controls is the correct solution because it directly addresses all three defense-in-depth requirements:

1. **Cross-project access control**: By creating a perimeter around Projects A and B, VPC Service Controls allows free communication within the perimeter while blocking access from outside. This means Project B can read from the Cloud Storage bucket in Project A because both projects are inside the same perimeter.

2. **Network-level protection**: VPC Service Controls prevents access to the Cloud Storage bucket from outside the defined network perimeter by default. The documentation states that "VPC Service Controls complements network egress controls by preventing clients within those networks from accessing the resources of Google-managed services outside the perimeter."

3. **Data exfiltration prevention**: The most critical requirement is preventing data copying to external buckets. VPC Service Controls explicitly blocks this: "a copy operation between two Cloud Storage buckets succeeds if both buckets are in the same service perimeter, but if one of the buckets is outside the perimeter, the copy operation fails." This prevents operations like `gcloud storage cp` to external buckets.

VPC Service Controls operates at the organization level, creating security boundaries that are independent of IAM controls, providing an additional "extra layer of security defense." The perimeter configuration includes the Cloud Storage API, which applies these protections to all Cloud Storage operations within the scope.

### Why Other Options Are Wrong

- **A:** Domain restricted sharing and uniform bucket-level access control IAM permissions and sharing domains, but they do not prevent data exfiltration through copy operations to external buckets. Domain restricted sharing only limits which domains can access resources, not whether data can be copied to buckets outside the organization or perimeter. This doesn't provide network-level isolation.

- **C:** Private Google Access enables VMs without external IP addresses to access Google APIs, but it does not create security boundaries or prevent data exfiltration. Firewall rules control network traffic between VMs and networks, but they cannot prevent application-level operations like copying data to external Cloud Storage buckets using authenticated API calls. This is a network-layer control, not an API-layer data protection mechanism.

- **D:** VPC Peering connects two VPC networks, allowing resources to communicate using internal IP addresses. However, VPC Peering does not provide any protection against data exfiltration to external Cloud Storage buckets. Firewall rules in a peered network setup cannot prevent API-based copy operations to buckets outside the network. This solution addresses network connectivity but not data boundary protection.

### References

- [VPC Service Controls Overview](https://docs.cloud.google.com/vpc-service-controls/docs/overview)
- [Service Perimeter Details and Configuration](https://docs.cloud.google.com/vpc-service-controls/docs/service-perimeters)
- [Design and Architect Service Perimeters](https://docs.cloud.google.com/vpc-service-controls/docs/architect-perimeters)
