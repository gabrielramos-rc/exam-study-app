# Question 195

**Source:** https://www.examtopics.com/discussions/google/view/117172-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** Policy Analyzer, IAM permissions, audit, firewall rules

---

## Question

You are auditing all your Google Cloud resources in the production project. You want to identify all principals who can change firewall rules. What should you do?
## Choices

- **A.** Use Policy Analyzer to query the permissions compute.firewalls.get or compute.firewalls.list.
- **B.** Use Firewall Insights to understand your firewall rules usage patterns.
- **C.** Reference the Security Health Analytics – Firewall Vulnerability Findings in the Security Command Center.
- **D.** Use Policy Analyzer to query the permissions compute.firewalls.create or compute.firewalls.update or compute.firewalls.delete. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (11 total)


**Top Comments:**

- (3 upvotes) D. You can use the Policy Analyzer to check which resources within your organization a principal has a certain roles or permissions on. To get this information, create a query that includes the princi

- (3 upvotes) D is correct!

- (2 upvotes) Must be D

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Policy Analyzer is specifically designed to analyze IAM allow policies and identify which principals have specific permissions across your Google Cloud resources. To find all principals who can **change** firewall rules, you must query for the write/modify permissions:

- `compute.firewalls.create` - Permission to create new firewall rules
- `compute.firewalls.update` - Permission to modify existing firewall rules
- `compute.firewalls.delete` - Permission to delete firewall rules

These three permissions collectively represent the ability to change firewall rules. Policy Analyzer will return all principals (users, service accounts, groups, domains) who have been granted roles containing any of these permissions, either directly or through group membership. This provides a comprehensive audit of who can modify your firewall configuration.

### Why Other Options Are Wrong

- **A:** `compute.firewalls.get` and `compute.firewalls.list` are read-only permissions that allow viewing firewall rules but not changing them. Querying these permissions would identify principals who can view firewalls, not modify them, which doesn't answer the audit requirement.

- **B:** Firewall Insights is a Network Intelligence Center tool that analyzes firewall rule usage patterns, shadowed rules, and overly permissive rules. It provides operational visibility into how firewall rules are being used but does not identify which principals have IAM permissions to change those rules.

- **C:** Security Health Analytics in Security Command Center identifies security vulnerabilities and misconfigurations, including firewall-related findings like overly permissive rules or public access. However, it does not provide IAM permission auditing to identify which principals can modify firewall rules.

### References

- [Policy Analyzer Overview](https://docs.cloud.google.com/policy-intelligence/docs/policy-analyzer-overview)
- [Compute Engine IAM Permissions](https://docs.cloud.google.com/compute/docs/access/iam)
