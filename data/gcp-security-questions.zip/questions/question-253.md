# Question 253

**Source:** https://www.examtopics.com/discussions/google/view/147047-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, Cloud DLP, PII, generative AI, chatbot security, de-identification

---

## Question

Your organization is building a chatbot that is powered by generative AI to deliver automated conversations with internal employees. You must ensure that no data with personally identifiable information (PII) is communicated through the chatbot. What should you do?
## Choices

- **A.** Encrypt data at rest for both input and output by using Cloud KMS, and apply least privilege access to the encryption keys.
- **B.** Discover and transform PII data in both input and output by using the Cloud Data Loss Prevention (Cloud DLP) API. Most Voted
- **C.** Prevent PII data exfiltration by using VPC-SC to create a safe scope around your chatbot.
- **D.** Scan both input and output by using data encryption tools from the Google Cloud Marketplace.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (6 total)


**Top Comments:**

- (2 upvotes) https://cloud.google.com/blog/topics/developers-practitioners/how-keep-sensitive-data-out-your-chatbots

- (1 upvotes) its B yokoyan is just right all the time

- (1 upvotes) I think it's B.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud Data Loss Prevention (DLP) API, now part of Sensitive Data Protection, is specifically designed to protect PII in generative AI workloads by providing real-time detection and transformation capabilities for both input prompts and generated responses. The service offers:

- **150+ built-in infoType detectors** that identify sensitive data elements including personal names, email addresses, financial data, medical context, and demographic data
- **Inline transformation capabilities** that scan data in real-time as it flows to and from the generative AI model
- **Multiple de-identification strategies** including type-based replacement (replacing PII with data type labels like [PERSON_NAME]), random replacement, format-preserving encryption, and redaction
- **Dual-direction protection** that scans user input prompts before they reach the foundation model AND scans AI-generated responses before returning to users

This approach is critical for chatbots because it allows the system to "reduce risk while preserving the utility of your data" - maintaining semantic understanding and context while protecting PII. The service preserves surrounding context that the model needs to function properly while obscuring only the sensitive elements.

The Cloud DLP API's inline content methods enable real-time protection during inference, making it ideal for conversational AI applications where both user inputs and model outputs must be continuously monitored for PII exposure.

### Why Other Options Are Wrong

- **A:** Encryption at rest protects stored data from unauthorized access but does nothing to prevent PII from being processed, displayed, or transmitted by the chatbot during runtime. The requirement is to ensure no PII is "communicated through the chatbot," which means preventing it from appearing in conversations - encryption doesn't address this functional requirement.

- **C:** VPC Service Controls creates security perimeters to prevent data exfiltration across service boundaries, but it doesn't inspect or transform the content of conversations. VPC-SC is a network boundary control that prevents services from being accessed from outside the perimeter - it cannot detect or redact PII within chatbot messages themselves.

- **D:** Generic "data encryption tools" from the Marketplace are not designed for real-time PII detection and transformation in AI workloads. Encryption tools focus on protecting data confidentiality through cryptographic methods, not identifying and redacting specific sensitive data elements within conversational text. Cloud DLP is the purpose-built GCP service for this use case.

### References

- [How Sensitive Data Protection can help secure generative AI workloads](https://cloud.google.com/blog/products/identity-security/how-sensitive-data-protection-can-help-secure-generative-ai-workloads)
- [De-identification and re-identification of PII using Sensitive Data Protection](https://cloud.google.com/architecture/de-identification-re-identification-pii-using-cloud-dlp)
- [Cloud Data Loss Prevention](https://cloud.google.com/security/products/dlp)
