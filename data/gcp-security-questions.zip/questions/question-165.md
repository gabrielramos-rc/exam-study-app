# Question 165

**Source:** https://www.examtopics.com/discussions/google/view/83349-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** IAM, authentication, authorization, SSO, SAML, Cloud Identity, predefined roles, basic roles, best practices

---

## Question

You are a security administrator at your company and are responsible for managing access controls (identification, authentication, and authorization) on Google Cloud. Which Google-recommended best practices should you follow when configuring authentication and authorization? (Choose two.)
## Choices

- **A.** Use Google default encryption.
- **B.** Manually add users to Google Cloud.
- **C.** Provision users with basic roles using Google's Identity and Access Management (IAM) service.
- **D.** Use SSO/SAML integration with Cloud Identity for user authentication and user lifecycle management. Most Voted
- **E.** Provide granular access with predefined roles. Most Voted

---

## Community

**Most Voted:** DE


**Votes:** D: 17% | DE: 83% (18 total)


**Top Comments:**

- (6 upvotes) https://cloud.google.com/iam/docs/using-iam-securely#least_privilege Basic roles include thousands of permissions across all Google Cloud services. In production environments, do not grant basic roles

- (5 upvotes) DE is perfect

- (4 upvotes) D. Use SSO/SAML integration with Cloud Identity for user authentication and user lifecycle management. E. Provide granular access with predefined roles.

---

## Answer

**Correct:** D, E

**Confidence:** high

### Explanation

**D. Use SSO/SAML integration with Cloud Identity for user authentication and user lifecycle management** - This is a core Google-recommended best practice for authentication. Google strongly recommends federating Cloud Identity with your existing identity provider (such as Active Directory, Microsoft Entra ID, or Okta) rather than manually adding users. Federation ensures that existing account management processes apply to Google Cloud, keeps passwords centralized in your identity provider, and enables single sign-on (SSO) via SAML. This approach maintains your on-premises or external provider as the authoritative source for user identities and lifecycle management.

**E. Provide granular access with predefined roles** - This is a fundamental authorization best practice. Google explicitly advises against using basic roles (Owner, Editor, Viewer), stating "We strongly recommend that you avoid basic roles...and use predefined roles instead. Basic roles are overly permissive and a potential security risk." The recommended pattern is to assign users to groups based on job functions, then grant predefined IAM roles to those groups rather than individuals. This follows the principle of least privilege and provides granular access control tailored to specific job responsibilities.

### Why Other Options Are Wrong

- **A. Use Google default encryption** - While Google does provide default encryption for data at rest and in transit, this is a data protection practice, not an authentication or authorization best practice. The question specifically asks about access controls (identification, authentication, and authorization), not encryption mechanisms. This answer is out of scope.

- **B. Manually add users to Google Cloud** - This directly contradicts Google's best practices. Manual user provisioning creates management overhead, doesn't integrate with existing identity management processes, and fails to leverage centralized authentication. Google recommends using Cloud Identity federation with SSO/SAML instead of manually creating and managing individual user accounts.

- **C. Provision users with basic roles using Google's Identity and Access Management (IAM) service** - This is explicitly discouraged by Google. Basic roles (Owner, Editor, Viewer) grant overly broad permissions and represent a security risk. Google strongly recommends using predefined roles or custom roles that follow the principle of least privilege, not basic roles which violate this fundamental security principle.

### References

- [Authentication and authorization | Cloud Architecture Center](https://docs.cloud.google.com/architecture/blueprints/security-foundations/authentication-authorization)
- [Best practices for using service accounts securely | Identity and Access Management (IAM)](https://docs.cloud.google.com/iam/docs/best-practices-service-accounts)
- [Identity and Access Management documentation](https://docs.cloud.google.com/iam/docs)
