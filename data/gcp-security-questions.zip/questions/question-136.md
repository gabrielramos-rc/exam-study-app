# Question 136

**Source:** https://www.examtopics.com/discussions/google/view/81740-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** Cloud KMS, key rotation, encryption keys, symmetric encryption, key compromise

---

## Question

Your security team uses encryption keys to ensure confidentiality of user data. You want to establish a process to reduce the impact of a potentially compromised symmetric encryption key in Cloud Key Management Service (Cloud KMS). Which steps should your team take before an incident occurs? (Choose two.)
## Choices

- **A.** Disable and revoke access to compromised keys.
- **B.** Enable automatic key version rotation on a regular schedule. Most Voted
- **C.** Manually rotate key versions on an ad hoc schedule.
- **D.** Limit the number of messages encrypted with each key version. Most Voted
- **E.** Disable the Cloud KMS API.

---

## Community

**Most Voted:** BD


**Votes:** AB: 4% | BD: 96% (24 total)


**Top Comments:**

- (10 upvotes) BD is the answer. The steps need to be done BEFORE an incident occurs.

- (9 upvotes) Yes, B and D

- (4 upvotes) A. Disable and revoke access to compromised keys. B. Enable automatic key version rotation on a regular schedule.

---

## Answer

**Correct:** B, D

**Confidence:** high

### Explanation

The question asks for preventive measures to take **before an incident occurs** to reduce the impact of a potentially compromised key. The two correct answers are:

**B. Enable automatic key version rotation on a regular schedule** - Google Cloud documentation explicitly recommends automatic rotation as a best practice for symmetric encryption keys. According to the official documentation: "We recommend that you rotate keys automatically on a regular schedule." Automatic rotation provides several benefits:
- Limits the number of actual messages vulnerable to compromise if a key is breached
- Helps prevent attacks enabled by cryptanalysis
- Ensures operational resilience by validating that your system can handle rotation before a real incident occurs
- Meets industry standards like PCI DSS that require regular key rotation

**D. Limit the number of messages encrypted with each key version** - This is a fundamental security principle for cryptographic keys. The documentation states: "Limiting the number of messages encrypted with the same key version helps prevent attacks enabled by cryptanalysis." By restricting how many messages are encrypted with a single key version, you:
- Reduce the mathematical patterns that attackers could exploit
- Minimize the blast radius if a specific key version is compromised
- Comply with NIST standards that specify message-count limits for certain algorithms (e.g., symmetric keys using Galois/Counter Mode)

Together, these two preventive controls work synergistically: automatic rotation creates new key versions regularly, while message limiting ensures that each key version has a bounded exposure.

### Why Other Options Are Wrong

- **A. Disable and revoke access to compromised keys** - This is a reactive measure taken **during or after** an incident, not a preventive measure taken before an incident occurs. While the documentation does recommend "If you suspect that a key version is compromised, disable it and revoke access to it as soon as possible," this is incident response, not prevention.

- **C. Manually rotate key versions on an ad hoc schedule** - While manual rotation is possible, it's not a recommended best practice for prevention. Ad hoc (irregular, unscheduled) rotation doesn't provide the consistent protection that automatic scheduled rotation offers. The documentation emphasizes regular, automatic rotation to ensure systematic protection and operational readiness.

- **E. Disable the Cloud KMS API** - This would completely break all encryption and decryption operations for your applications. This is not a security best practice and would make your encrypted data inaccessible. There is no documentation support for this approach.

### References

- [Key rotation | Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/key-rotation)
- [Best practices for using CMEKs | Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/cmek-best-practices)
