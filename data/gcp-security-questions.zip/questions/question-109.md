# Question 109

**Source:** https://www.examtopics.com/discussions/google/view/74827-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Cloud DNS, DNSSEC, DNS Security, DDoS protection, authentication

---

## Question

Your organization has had a few recent DDoS attacks. You need to authenticate responses to domain name lookups. Which Google Cloud service should you use?
## Choices

- **A.** Cloud DNS with DNSSEC Most Voted
- **B.** Cloud NAT
- **C.** HTTP(S) Load Balancing
- **D.** Google Cloud Armor

---

## Community

**Most Voted:** A


**Votes:** A: 100% (10 total)


**Top Comments:**

- (19 upvotes) Agreed, A is right

- (4 upvotes) A, as explained by Tabayashi

- (2 upvotes) To authenticate responses to domain name lookups and protect your organization from DDoS attacks, you can use Cloud DNS with DNSSEC. DNS Security Extensions (DNSSEC) is a feature of the Domain Name Sy

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Cloud DNS with DNSSEC is the correct solution because DNSSEC (Domain Name System Security Extensions) is specifically designed to authenticate responses to domain name lookups. According to Google Cloud documentation, DNSSEC "authenticates responses to domain name lookups" by digitally signing DNS data, which enables validation that responses haven't been tampered with during transit.

While the question mentions DDoS attacks as context, the specific requirement is to "authenticate responses to domain name lookups." DNSSEC addresses DNS-based attack vectors that could be part of a DDoS strategy, such as DNS cache poisoning and DNS spoofing attacks. DNSSEC prevents attackers from manipulating or poisoning DNS responses by:

1. Using zone-level digital signatures (RRSIG records)
2. Maintaining DNSKEY records for validation
3. Providing a chain of trust through DS records at the registry level

When DNS resolvers (like Google Public DNS) perform DNSSEC validation, they can cryptographically verify that DNS responses are authentic and haven't been modified, protecting against DNS manipulation attacks that could redirect traffic or facilitate broader DDoS campaigns.

### Why Other Options Are Wrong

- **B. Cloud NAT:** Cloud NAT provides network address translation for outbound traffic from private instances to the internet. It has no relationship to DNS authentication or validating domain name lookups. NAT is for IP address translation, not DNS security.

- **C. HTTP(S) Load Balancing:** HTTP(S) Load Balancing distributes HTTP/HTTPS traffic across backend instances and can integrate with Cloud Armor for DDoS protection at the application layer. However, it operates at the application level (Layer 7) and does not authenticate DNS responses. It doesn't interact with the DNS resolution process itself.

- **D. Google Cloud Armor:** Cloud Armor provides DDoS protection and web application firewall (WAF) capabilities for applications behind HTTP(S) load balancers. While it does protect against volumetric DDoS attacks, it operates at the edge of your application infrastructure and does not authenticate DNS lookups. Cloud Armor protects HTTP/HTTPS endpoints, not the DNS layer.

### References

- [DNS Security Extensions (DNSSEC) overview](https://docs.cloud.google.com/dns/docs/dnssec)
- [Cloud DNS overview](https://docs.cloud.google.com/dns/docs/overview)
