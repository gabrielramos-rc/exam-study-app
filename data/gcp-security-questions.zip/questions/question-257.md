# Question 257

**Source:** https://www.examtopics.com/discussions/google/view/147051-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** Workload Identity Federation, GKE, service account, Cloud Storage, pod authentication

---

## Question

You are running code in Google Kubernetes Engine (GKE) containers in Google Cloud that require access to objects stored in a Cloud Storage bucket. You need to securely grant the Pods access to the bucket while minimizing management overhead. What should you do?
## Choices

- **A.** Create a service account. Grant bucket access to the Pods by using Workload Identity Federation for GKE. Most Voted
- **B.** Create a service account with keys. Store the keys in Secret Manager with a 30-day rotation schedule. Reference the keys in the Pods.
- **C.** Create a service account with keys. Store the keys as a Kubernetes secret. Reference the keys in the Pods.
- **D.** Create a service account with keys. Store the keys in Secret Manager. Reference the keys in the Pods.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (5 total)


**Top Comments:**

- (1 upvotes) A: Workload Identity Federation for GKE is the recommended way for your workloads running on Google Kubernetes Engine (GKE) to access Google Cloud services in a secure and manageable way. https://clou

- (1 upvotes) It's A i thikn

- (1 upvotes) I think it's A.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Workload Identity Federation for GKE is Google's recommended and most secure method for granting GKE pods access to Google Cloud resources like Cloud Storage buckets. This approach:

**Eliminates static credentials:** No service account keys are created, stored, or rotated. The system uses short-lived, automatically-managed tokens instead of long-lived credentials.

**Automatic token management:** The GKE metadata server intercepts authentication requests from pods and exchanges Kubernetes ServiceAccount tokens for federated access tokens on-demand. These tokens have short lifespans and are refreshed automatically.

**Minimal management overhead:** Once configured, the authentication mechanism works transparently with Google Cloud client libraries without code changes. You simply:
1. Enable Workload Identity Federation on the cluster and node pools
2. Create a Kubernetes ServiceAccount
3. Grant IAM permissions to the ServiceAccount using principal identifiers
4. Deploy pods with the ServiceAccount annotation

**Security benefits:** All token usage can be audited through Cloud Audit Logs, there's no risk of accidentally exposing keys in container images or logs, and you follow the principle of least privilege by granting specific permissions to specific ServiceAccounts.

### Why Other Options Are Wrong

- **B:** Creating service account keys with rotation introduces significant management overhead (key rotation, secure storage, distribution) and security risks (key exposure, accidental commits). Even with Secret Manager and rotation, you still need to manage the lifecycle of static credentials. This violates the requirement to "minimize management overhead."

- **C:** Storing service account keys as Kubernetes secrets is highly insecure and considered a security anti-pattern. Kubernetes secrets are base64-encoded (not encrypted by default), can be accessed by anyone with kubectl access to the namespace, and may be logged or exposed. This is the worst security option among all choices.

- **D:** While Secret Manager provides better security than Kubernetes secrets, this approach still requires managing service account keys (creation, storage, distribution, eventual rotation). It adds unnecessary complexity and doesn't minimize management overhead as requested. You're managing both Secret Manager permissions and service account key lifecycle.

### References

- [Authenticate to Google Cloud APIs from GKE workloads](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/workload-identity)
- [About Workload Identity Federation for GKE](https://docs.cloud.google.com/kubernetes-engine/docs/concepts/workload-identity)
