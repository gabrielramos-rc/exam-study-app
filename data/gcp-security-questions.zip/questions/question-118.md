# Question 118

**Source:** https://www.examtopics.com/discussions/google/view/75738-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** network segmentation, NGFW, virtual appliance, multiple network interfaces, VPC

---

## Question

You need to set up two network segments: one with an untrusted subnet and the other with a trusted subnet. You want to configure a virtual appliance such as a next-generation firewall (NGFW) to inspect all traffic between the two network segments. How should you design the network to inspect the traffic?
## Choices

- **A.** 1. Set up one VPC with two subnets: one trusted and the other untrusted. 2. Configure a custom route for all traffic (0.0.0.0/0) pointed to the virtual appliance.
- **B.** 1. Set up one VPC with two subnets: one trusted and the other untrusted. 2. Configure a custom route for all RFC1918 subnets pointed to the virtual appliance.
- **C.** 1. Set up two VPC networks: one trusted and the other untrusted, and peer them together. 2. Configure a custom route on each network pointed to the virtual appliance.
- **D.** 1. Set up two VPC networks: one trusted and the other untrusted. 2. Configure a virtual appliance using multiple network interfaces, with each interface connected to one of the VPC networks. Most Voted

---

## Community

**Most Voted:** D


**Votes:** B: 8% | D: 92% (12 total)


**Top Comments:**

- (11 upvotes) Agreed. Ref: For Cisco Firepower Threat Defense Virtual: https://www.cisco.com/c/en/us/td/docs/security/firepower/quick_start/gcp/ftdv-gcp-gsg/ftdv-gcp-intro.html

- (5 upvotes) A, we need to define routing to divert all traffic through the network appliance https://cloud.google.com/architecture/architecture-centralized-network-appliances-on-google-cloud

- (4 upvotes) B , 100% !

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D is the correct architecture for inspecting traffic between trusted and untrusted network segments using a virtual appliance (NGFW). The Google Cloud documentation explicitly confirms that multi-NIC (multiple network interface) instances are designed for this exact use case.

The key architectural principles are:

1. **Separate VPC Networks**: Using two distinct VPC networks (one trusted, one untrusted) provides true network isolation and boundary segmentation between security zones.

2. **Multi-NIC Virtual Appliance**: The virtual appliance is configured with multiple network interfaces, with each interface attached to a different VPC network. As documented: "multi-NIC instances can connect to resources located in different VPC networks that aren't connected to each other through VPC Network Peering or Network Connectivity Center."

3. **Traffic Inspection**: Software running in the guest OS of the multi-NIC instance performs "packet inspection, network address translation (NAT), or another network security function." The NGFW sits in the path between the two VPCs, forcing all traffic to flow through the appliance for inspection.

4. **Best Practice Pattern**: This is the standard architecture for virtual security appliances in Google Cloud. For production deployments, it's recommended to use two or more multi-NIC instances as backends for an internal passthrough Network Load Balancer in each VPC network for high availability.

This design ensures complete traffic inspection because the two VPC networks have no direct connectivity - all traffic must traverse the virtual appliance's network interfaces to communicate between the trusted and untrusted segments.

### Why Other Options Are Wrong

- **A:** Using a single VPC with two subnets does not provide adequate network segmentation. Subnets within the same VPC can communicate directly without going through a virtual appliance. A custom route pointing to 0.0.0.0/0 would route all traffic (including internet-bound) through the appliance, which is overly broad and doesn't specifically address inter-subnet traffic inspection.

- **B:** This has the same fundamental flaw as option A - subnets in the same VPC can communicate directly. Additionally, routing only RFC1918 private address ranges doesn't guarantee that all traffic between the two subnets will be inspected, as the VPC's native routing will allow direct communication between subnets.

- **C:** VPC peering creates direct connectivity between the two VPC networks, allowing traffic to flow between them without necessarily traversing the virtual appliance. Custom routes cannot override peering routes effectively. The architecture also doesn't specify how the virtual appliance connects to both networks, making it incomplete and ineffective for mandatory traffic inspection.

### References

- [Multiple network interfaces | Virtual Private Cloud | Google Cloud Documentation](https://docs.cloud.google.com/vpc/docs/multiple-interfaces-concepts)
- [FortiGate architecture in Google Cloud | Cloud Architecture Center | Google Cloud Documentation](https://docs.cloud.google.com/architecture/partners/fortigate-architecture-in-cloud)
- [Secure virtual private cloud networks with the Palo Alto VM-Series NGFW | Cloud Architecture Center | Google Cloud Documentation](https://docs.cloud.google.com/architecture/partners/palo-alto-networks-ngfw)
