# Question 196

**Source:** https://www.examtopics.com/discussions/google/view/117173-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** CMEK, Cloud KMS, Cloud Storage encryption, key rotation, rewrite operation

---

## Question

Your organization previously stored files in Cloud Storage by using Google Managed Encryption Keys (GMEK), but has recently updated the internal policy to require Customer Managed Encryption Keys (CMEK). You need to re-encrypt the files quickly and efficiently with minimal cost. What should you do?
## Choices

- **A.** Reupload the files to the same Cloud Storage bucket specifying a key file by using gsutil.
- **B.** Encrypt the files locally, and then use gsutil to upload the files to a new bucket.
- **C.** Copy the files to a new bucket with CMEK enabled in a secondary region.
- **D.** Change the encryption type on the bucket to CMEK, and rewrite the objects. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (5 total)


**Top Comments:**

- (3 upvotes) Copying the files to a new bucket in a secondary region would incur data egress charges and take time.

- (2 upvotes) https://cloud.google.com/storage/docs/encryption/using-customer-managed-keys

- (2 upvotes) re-writing the objects is not quick and efficient. Option D is incorrect. C. Copy the files to a new bucket with CMEK enabled in a secondary region.Option C is the most efficient and cost-effective so

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The most efficient and cost-effective way to re-encrypt existing Cloud Storage objects from GMEK to CMEK is to change the default encryption key on the bucket to CMEK, then use the rewrite operation to re-encrypt the existing objects in-place. This approach is correct because:

1. **Rewrite Operation is the Official Method**: Google Cloud documentation explicitly states that "you can't change an object's encryption key directly. Instead, you must rewrite the object using the new key." The rewrite operation creates a new encrypted copy with the different key.

2. **In-Place Re-encryption**: Setting CMEK as the bucket's default encryption key and rewriting objects allows re-encryption without changing bucket locations or creating unnecessary copies, minimizing data transfer costs.

3. **Efficient Implementation**: You can use `gcloud storage objects update gs://BUCKET_NAME/OBJECT_NAME --encryption-key=KMS_KEY_RESOURCE` or client libraries to rewrite objects programmatically. For large objects, the rewrite operation supports continuation tokens.

4. **No Downtime Required**: Objects remain in the same bucket with the same paths, avoiding application configuration changes or redirects.

5. **Minimal Cost**: Since objects stay in the same bucket and region, there are no cross-region data transfer charges, and no additional storage costs from duplicate buckets.

### Why Other Options Are Wrong

- **A:** Re-uploading files is inefficient and would require downloading all data first. The `--encryption-key` flag is used for Customer-Supplied Encryption Keys (CSEK), not CMEK. This approach would be slower and more costly than using the rewrite operation.

- **B:** Encrypting files locally and re-uploading defeats the purpose of CMEK, which is managed in Cloud KMS. This would use Customer-Supplied Encryption Keys (CSEK), not CMEK, and requires managing keys outside of Cloud KMS. It's also the most inefficient option with double data transfer costs.

- **C:** Copying to a new bucket in a secondary region is unnecessary and adds significant costs (cross-region transfer charges, duplicate storage costs). The question asks for minimal cost, and changing regions is not required by the policy requirement. This wastes resources and creates operational complexity.

### References

- [Use customer-managed encryption keys - Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption/using-customer-managed-keys)
- [Customer-managed encryption keys (CMEK) - Cloud KMS](https://cloud.google.com/kms/docs/cmek)
