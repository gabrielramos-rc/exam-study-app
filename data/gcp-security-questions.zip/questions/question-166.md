# Question 166

**Source:** https://www.examtopics.com/discussions/google/view/79853-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Packet Mirroring, deep packet inspection, VPC Flow Logs, network security, intrusion detection

---

## Question

You have been tasked with inspecting IP packet data for invalid or malicious content. What should you do?
## Choices

- **A.** Use Packet Mirroring to mirror traffic to and from particular VM instances. Perform inspection using security software that analyzes the mirrored traffic. Most Voted
- **B.** Enable VPC Flow Logs for all subnets in the VPC. Perform inspection on the Flow Logs data using Cloud Logging.
- **C.** Configure the Fluentd agent on each VM Instance within the VPC. Perform inspection on the log data using Cloud Logging.
- **D.** Configure Google Cloud Armor access logs to perform inspection on the log data.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (14 total)


**Top Comments:**

- (6 upvotes) A is right

- (4 upvotes) A. https://cloud.google.com/vpc/docs/packet-mirroring#enterprise_security "Packet Mirroring clones the traffic of specified instances in your Virtual Private Cloud (VPC) network and forwards it for ex

- (4 upvotes) Sorry, it should be A, not B.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Packet Mirroring is specifically designed for deep packet inspection (DPI) use cases where you need to analyze actual packet payloads for malicious or invalid content. It clones the complete traffic (including headers and payloads) of specified VM instances and forwards it to collector instances running security software for comprehensive analysis.

The Google Cloud documentation explicitly states that "Intrusion detection system (IDS) tools require multiple packets of a single flow to match a signature" and "Deep Packet Inspection engines inspect packet payloads to detect protocol anomalies." Packet Mirroring captures all traffic, not just samples, enabling security software to detect threats comprehensively. It mirrors traffic to an internal load balancer backend that runs third-party security appliances (IDS/IPS, Network Detection and Response tools, etc.) that perform the actual inspection.

This approach is the only option that provides access to the actual packet data needed to identify malicious content, protocol anomalies, and sophisticated attacks that span multiple packets.

### Why Other Options Are Wrong

- **B:** VPC Flow Logs only capture metadata about network flows (source/destination IPs, ports, protocols, byte/packet counts) using sampling. They do NOT capture the actual packet payloads or content, making them unsuitable for deep packet inspection. Flow Logs are designed for network troubleshooting and traffic analysis, not malware detection or content inspection.

- **C:** Fluentd agents collect application logs, system logs, and structured log data from VMs. They do not capture network packet data or provide access to IP packet payloads. This is for log aggregation, not network traffic inspection.

- **D:** Cloud Armor access logs record information about HTTP/HTTPS requests to load balancers (like request headers, source IPs, and security policy decisions). They do not provide access to raw IP packet data and only apply to HTTP(S) load balancer traffic, not general VM-to-VM or egress traffic inspection.

### References

- [Packet Mirroring Overview](https://docs.cloud.google.com/vpc/docs/packet-mirroring)
- [Out-of-band Integration for Deep Packet Inspection](https://docs.cloud.google.com/network-security-integration/docs/out-of-band/out-of-band-integration-overview)
