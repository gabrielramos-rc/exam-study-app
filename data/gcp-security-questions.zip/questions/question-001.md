# Question 001

**Source:** https://www.examtopics.com/discussions/google/view/15917-exam-professional-cloud-security-engineer-topic-1-question-1/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Private Google Access, network isolation, external IP, VPC, Compute Engine

---

## Question

Your team needs to make sure that a Compute Engine instance does not have access to the internet or to any Google APIs or services. Which two settings must remain disabled to meet these requirements? (Choose two.)
## Choices

- **A.** Public IP Most Voted
- **B.** IP Forwarding
- **C.** Private Google Access Most Voted
- **D.** Static routes
- **E.** IAM Network User Role

---

## Community

**Most Voted:** AC


**Votes:** AC: 100% (8 total)


**Top Comments:**

- (34 upvotes) You are right

- (9 upvotes) KILLMAD You're correct it is A C Public IP Private Google Access

- (8 upvotes) A and C

---

## Answer

**Correct:** A, C

**Confidence:** high

### Explanation

To prevent a Compute Engine instance from accessing the internet or Google APIs/services, two specific settings must remain disabled:

**A. Public IP (External IP)**: When a Compute Engine VM lacks an external IP address assigned to its network interface, it can only send packets to other internal IP address destinations within the VPC network. Without an external IP, the VM cannot directly reach the internet. This is the primary control for internet isolation.

**C. Private Google Access**: This feature must be disabled on the subnet to prevent access to Google APIs and services. Private Google Access is a subnet-level setting that allows VMs without external IP addresses to reach Google APIs and services through internal routing. When disabled, VMs with only internal IPs cannot reach Google APIs and services. According to the documentation: "If you disable Private Google Access, the VM instances can no longer reach Google APIs and services; they can only send traffic within the VPC network."

Together, disabling both settings ensures complete network isolation - no internet access (via disabled external IP) and no Google API access (via disabled Private Google Access).

### Why Other Options Are Wrong

- **B. IP Forwarding**: This setting controls whether the VM can forward packets not destined for its own IP address. It's used for routing scenarios (like making the VM act as a router or NAT gateway) but doesn't control internet or API access.

- **D. Static routes**: Routes control where network traffic is directed within and between networks. While routes are part of the networking configuration, simply having or not having static routes doesn't prevent access to the internet or Google APIs. The VM would need specific routes plus connectivity (external IP or Private Google Access) to reach these destinations.

- **E. IAM Network User Role**: This is an IAM role that controls who can perform network administration tasks. It's not a network-level setting that controls whether a VM can access the internet or Google APIs.

### References

- [Configure Private Google Access](https://docs.cloud.google.com/vpc/docs/configure-private-google-access)
- [Private access options for services](https://docs.cloud.google.com/vpc/docs/private-access-options)
