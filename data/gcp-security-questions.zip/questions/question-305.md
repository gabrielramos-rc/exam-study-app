# Question 305

**Source:** https://www.examtopics.com/discussions/google/view/148660-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.3 - Securing AI workloads
**Tags:** Vertex AI Workbench, organization policy, root access, automatic upgrades

---

## Question

Your organization is using Vertex AI Workbench Instances. You must ensure that newly deployed Instances are automatically kept up-to-date and that users cannot accidentally alter settings in the operating system. What should you do?
## Choices

- **A.** Enforce the disableRootAccesa and requireAutoUpgradeSchedule organization policies for newly deployed Instances. Most Voted
- **B.** Enable the VM Manager and ensure the corresponding Google Compute Engine instances are added.
- **C.** Implement a firewall rule that prevents Secure Shell access to the corresponding Google Compute Engine instances by using tags.
- **D.** Assign the AI Notebooks Runner and AI Notebooks Viewer roles to the users of the AI Workbench Instances.

---

## Community

**Most Voted:** A


**Votes:** A: 86% | B: 14% (7 total)


**Top Comments:**

- (2 upvotes) https://cloud.google.com/vertex-ai/docs/workbench/instances/manage-metadata

- (2 upvotes) Why B is Correct: VM Manager: VM Manager automates the management of Compute Engine instances, including patch management and configuration updates. By enabling VM Manager, you ensure that operating s

- (2 upvotes) A - disableRootAccess: This organization policy prevents users from accessing the root account of the underlying Google Compute Engine instance, which helps to prevent accidental configuration changes

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is correct because it uses the specific organization policy constraints designed for Vertex AI Workbench Instance security:

**`constraints/ainotebooks.disableRootAccess`** - When enforced, this boolean constraint prevents newly created Vertex AI Workbench user-managed notebooks and instances from enabling root access. This ensures users cannot accidentally alter operating system settings by preventing root-level access to the underlying VM.

**`constraints/ainotebooks.requireAutoUpgradeSchedule`** - This constraint mandates that newly created Vertex AI Workbench instances have an automatic upgrade schedule configured. Users must specify an upgrade schedule using metadata flags (e.g., `--metadata=notebook-upgrade-schedule="00 19 * * MON"`), which ensures instances are automatically kept up-to-date with security patches and updates.

Together, these two organization policies enforce the exact requirements: automatic updates (keeping instances up-to-date) and preventing users from altering OS settings (by blocking root access). Organization policies are the appropriate mechanism for enforcing security standards across all newly deployed resources in your organization.

### Why Other Options Are Wrong

- **B.** VM Manager is a valid tool for patch management, but it requires manual configuration for each instance and doesn't prevent root access. Organization policies provide centralized, automatic enforcement for all new instances, which is more scalable and prevents configuration drift.

- **C.** Implementing a firewall rule to block SSH access is overly restrictive and doesn't address the core requirements. Users still need SSH access to use the notebook instances effectively, and blocking SSH entirely would prevent legitimate use. Additionally, this doesn't address the automatic upgrade requirement at all.

- **D.** Assigning AI Notebooks Runner and AI Notebooks Viewer roles only controls IAM permissions for who can access and use the instances. These roles don't prevent root access once a user is authenticated, nor do they enforce automatic upgrade schedules. This is about access control, not OS-level security configuration.

### References

- [Organization policy constraints | Resource Manager Documentation](https://docs.cloud.google.com/resource-manager/docs/organization-policy/org-policy-constraints)
- [Vertex AI Workbench instances access control](https://docs.cloud.google.com/vertex-ai/docs/workbench/instances/iam)
