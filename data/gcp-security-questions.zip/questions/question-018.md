# Question 018

**Source:** https://www.examtopics.com/discussions/google/view/16105-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Managing authentication
**Tags:** Cloud Identity, password policy, authentication, password length

---

## Question

An organization adopts Google Cloud Platform (GCP) for application hosting services and needs guidance on setting up password requirements for their Cloud Identity account. The organization has a password policy requirement that corporate employee passwords must have a minimum number of characters. Which Cloud Identity password guidelines can the organization use to inform their new requirements?
## Choices

- **A.** Set the minimum length for passwords to be 8 characters. Most Voted
- **B.** Set the minimum length for passwords to be 10 characters.
- **C.** Set the minimum length for passwords to be 12 characters.
- **D.** Set the minimum length for passwords to be 6 characters.

---

## Community

**Most Voted:** A


**Votes:** A: 43% | B: 7% | C: 21% | D: 29% (14 total)


**Top Comments:**

- (19 upvotes) It asked for Cloud Indentity password requirements... Minimum is 8 Maximum is 100

- (12 upvotes) Default password length is 8 characters. https://support.google.com/cloudidentity/answer/33319?hl=en

- (11 upvotes) That page is about the default for the form, not the recommended best practice.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Cloud Identity password policies have a **minimum password length requirement of 8 characters**. According to Google Cloud documentation, administrators can configure password length requirements between 8 and 100 characters for their organization's Cloud Identity accounts. The absolute minimum that can be enforced is 8 characters - you cannot set a password policy below this threshold.

This is the baseline guideline that organizations must use when informing their password requirements. While they can choose to enforce stricter requirements (longer passwords), the minimum supported value is 8 characters.

### Why Other Options Are Wrong

- **B (10 characters):** While 10 characters is a valid and more secure password length that can be configured, it is not the minimum guideline. Organizations can set this, but the question asks for the minimum Cloud Identity guideline, which is 8 characters.

- **C (12 characters):** Similar to option B, 12 characters is a valid configuration for enhanced security, but it exceeds the minimum requirement. The question specifically asks what minimum guidelines Cloud Identity provides.

- **D (6 characters):** This is below the minimum allowed threshold for Cloud Identity. While Google Cloud Identity Platform (used for application authentication) supports a minimum of 6 characters, Cloud Identity for organizational user accounts requires a minimum of 8 characters. This option confuses two different Google authentication services.

### References

- [Enforce and monitor password requirements for users - Cloud Identity Help](https://support.google.com/cloudidentity/answer/139399)
- [Enable, disable, and use password policies - Identity Platform Documentation](https://docs.cloud.google.com/identity-platform/docs/password-policy)
