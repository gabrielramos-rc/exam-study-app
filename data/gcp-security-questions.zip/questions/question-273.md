# Question 273

**Source:** https://www.examtopics.com/discussions/google/view/147067-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.3 - Securing AI workloads
**Tags:** Vertex AI, CMEK, customer-managed encryption keys, training jobs, Cloud KMS, encryption at rest

---

## Question

You are working with developers to secure custom training jobs running on Vertex AI. For compliance reasons, all supported data types must be encrypted by key materials that reside in the Europe region and are controlled by your organization. The encryption activity must not impact the training operation in Vertex AI. What should you do?
## Choices

- **A.** Encrypt the code, training data, and metadata with Google default encryption. Use customer-managed encryption keys (CMEK) for the trained models exported to Cloud Storage buckets.
- **B.** Encrypt the code, training data, metadata, and exported trained models with customer-managed encryption keys (CMEK).
- **C.** Encrypt the code, training data, and exported trained models with customer-managed encryption keys (CMEK). Most Voted
- **D.** Encrypt the code, training data, and metadata with Google default encryption. Implement an organization policy that enforces a constraint to restrict the Cloud KMS location to the Europe region.

---

## Community

**Most Voted:** C


**Votes:** B: 23% | C: 62% | D: 15% (13 total)


**Top Comments:**

- (4 upvotes) C sounds right https://cloud.google.com/vertex-ai/docs/general/cmek#resources In general, the CMEK key does not encrypt metadata associated with your operation, like the job's name and region, or a da

- (2 upvotes) Option D enforces that all supported data types must be encrypted by key materials that reside in the Europe region.

- (2 upvotes) Answer is C The CMEK key doesn't encrypt metadata, like the instance's name and region, associated with your Vertex AI Workbench instance. Metadata associated with Vertex AI Workbench instances is alw

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is correct because it encrypts all **supported data types** that CMEK can protect for Vertex AI training jobs. According to Google Cloud documentation, when you configure CMEK for Vertex AI custom training jobs, the CMEK key encrypts:

1. **The copy of your code** on the VMs used to run the training operation
2. **Training data** that gets loaded by your code onto the local disk
3. **Temporary data** that gets saved to the local disk by your code during training

Additionally, for complete compliance coverage, you must separately configure CMEK for the **Cloud Storage buckets** that store exported trained models. The documentation explicitly states that "configuring CMEK for Vertex AI resources does not automatically configure CMEK for other Google Cloud products that you use together with Vertex AI."

By configuring CMEK for both Vertex AI training jobs and Cloud Storage buckets, with keys residing in the Europe region, you ensure:
- All supported data types are encrypted with organization-controlled keys
- Keys reside in the required Europe region (via Cloud KMS regional keys)
- No performance impact on training operations (CMEK encryption is transparent)

### Why Other Options Are Wrong

- **A:** This approach leaves code and training data encrypted only with Google default encryption, not CMEK. This violates the compliance requirement that "all supported data types must be encrypted by key materials...controlled by your organization." Google-managed keys are not controlled by your organization.

- **B:** This option incorrectly includes "metadata" as something to encrypt with CMEK. The Vertex AI documentation explicitly states that "the CMEK key does not encrypt metadata associated with your operation, like the job's name and region, or a dataset's display name." Metadata is always encrypted using Google's default encryption mechanism and cannot be encrypted with CMEK. This is not a supported data type for CMEK encryption.

- **D:** This option uses only Google default encryption for all data types, which fails the compliance requirement for organization-controlled encryption keys. While the organization policy would restrict KMS key locations to Europe, this is irrelevant when not actually using CMEK. Google-managed default encryption keys are not controlled by your organization.

### References

- [Customer-managed encryption keys (CMEK) | Vertex AI](https://docs.cloud.google.com/vertex-ai/docs/general/cmek)
- [CMEK for Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption/customer-managed-keys)
