# Question 145

**Source:** https://www.examtopics.com/discussions/google/view/80501-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** data residency, organization policy, compliance, resource locations constraint

---

## Question

You are a consultant for an organization that is considering migrating their data from its private cloud to Google Cloud. The organization's compliance team is not familiar with Google Cloud and needs guidance on how compliance requirements will be met on Google Cloud. One specific compliance requirement is for customer data at rest to reside within specific geographic boundaries. Which option should you recommend for the organization to meet their data residency requirements on Google Cloud?
## Choices

- **A.** Organization Policy Service constraints Most Voted
- **B.** Shielded VM instances
- **C.** Access control lists
- **D.** Geolocation access controls
- **E.** Google Cloud Armor

---

## Community

**Most Voted:** A


**Votes:** A: 100% (6 total)


**Top Comments:**

- (4 upvotes) yes A. is right. Organization Policy Service constraints

- (3 upvotes) https://cloud.google.com/blog/products/identity-security/meet-data-residency-requirements-with-google-cloud putting back at the top for others

- (3 upvotes) A. Organization Policy Service constraints to add org policy for Resource Location Restriction https://cloud.google.com/resource-manager/docs/organization-policy/using-constraints#list-constraint

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Organization Policy Service constraints with the **resource locations constraint** is the correct mechanism for enforcing data residency requirements in Google Cloud. This constraint allows administrators to restrict the physical locations (regions, multi-regions, or zones) where new resources can be created, ensuring that customer data at rest remains within specific geographic boundaries.

Key features that make this the right choice:

1. **Geographic boundary enforcement**: You can use value groups like `in:us-locations` or `in:eu-locations` to define allowed geographic regions, or specify individual locations explicitly
2. **Hierarchical application**: Policies can be applied at organization, folder, or project level, providing flexible control across the entire resource hierarchy
3. **Automatic expansion**: Value groups automatically include new locations as Google adds them, preventing policy drift
4. **Prevents non-compliant resource creation**: Once enforced, the policy prevents services from creating resources that violate the geographic constraints

The documentation explicitly states: "Organizations with data residency requirements can set up a Resource Locations organization policy constraint that restricts the location of new in-scope resources at the organization, project, or folder level of their resource hierarchy."

For more stringent compliance needs (such as EU sovereignty or FedRAMP), organizations can also use Assured Workloads, which builds on Organization Policy constraints to provide additional controls around data access and personnel.

### Why Other Options Are Wrong

- **B. Shielded VM instances:** Shielded VMs provide protection against rootkits and bootkits through secure boot, vTPM, and integrity monitoring. They are security hardening features for VM instances but have nothing to do with data residency or geographic location controls.

- **C. Access control lists:** ACLs control who can access resources (authorization), not where resources are physically located. ACLs are used for permissions management on resources like Cloud Storage buckets, but they don't enforce geographic boundaries.

- **D. Geolocation access controls:** This refers to restricting user access based on their geographic location (where users are connecting from), typically implemented through Access Context Manager or Cloud Armor policies. This is about controlling access based on user location, not about where data resides.

- **E. Google Cloud Armor:** Cloud Armor is a DDoS protection and web application firewall (WAF) service that operates at the edge of Google's network. While it can implement geolocation-based access controls to block traffic from certain countries, it doesn't control where data is stored at rest.

### References

- [Restricting Resource Locations](https://docs.cloud.google.com/resource-manager/docs/organization-policy/defining-locations)
- [Data residency - Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/data-residency)
