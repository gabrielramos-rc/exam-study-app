# Question 323

**Source:** https://www.examtopics.com/discussions/google/view/306211-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** folders, service accounts, IAM, Folder Admin role, least privilege, Infrastructure as Code

---

## Question

Your organization leverages folders to represent different teams within your Google Cloud environment. To support Infrastructure as Code (IaC) practices, each team receives a dedicated service account upon onboarding. You want to ensure that teams have comprehensive permissions to manage resources within their assigned folders while adhering to the principle of least privilege. You must design the permissions for these team-based service accounts in the most effective way possible. What should you do?
## Choices

- **A.** Grant each service account the folder administrator role on its respective folder. Most Voted
- **B.** Grant each service account the project creator role at the organization level and use folder-level IAM conditions to restrict project creation to specific folders.
- **C.** Assign each service account the project editor role at the organization level and instruct teams to use IAM bindings at the folder level for fine-grained permissions.
- **D.** Assign each service account the folder IAM administrator role on its respective folder to allow teams to create and manage additional custom roles if needed.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (1 total)

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The **Folder Admin role** (`roles/resourcemanager.folderAdmin`) is the correct choice because it provides comprehensive permissions to manage folders and their resources while adhering to the principle of least privilege by being scoped to a specific folder. According to Google Cloud documentation, the Folder Admin role "grants the user permission to create, edit, delete, move, and change IAM permissions on folders, as well as permission to move projects between folders."

This role is ideal for Infrastructure as Code (IaC) practices because it allows teams to:
- Create and manage projects within their assigned folder
- Modify IAM permissions on the folder and its resources
- Move projects between folders within their scope
- Manage the entire resource hierarchy under their folder

By granting this role at the folder level (not organization level), each team's service account is restricted to managing only their assigned folder's resources, which perfectly implements least privilege while providing the comprehensive access needed for IaC workflows.

### Why Other Options Are Wrong

- **B:** Granting Project Creator at the organization level violates least privilege, as it would allow service accounts to create projects anywhere in the organization. While IAM conditions could theoretically restrict this, using folder-scoped roles is the more straightforward and recommended approach. Additionally, this doesn't provide comprehensive folder management capabilities beyond project creation.

- **C:** Project Editor at the organization level is a massive security violation and grants far too many permissions across the entire organization. This completely violates the principle of least privilege and would allow teams to modify resources in folders they shouldn't have access to. Instructing teams to "use IAM bindings" doesn't actually limit what the service account can do.

- **D:** Folder IAM Admin role is specifically for managing IAM policies and entitlements, not for comprehensive resource management. Additionally, custom roles cannot be defined at the folder level - they must be defined at the organization level. This option doesn't provide the full range of permissions needed for managing folder resources in IaC scenarios.

### References

- [Create and manage folders | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/creating-managing-folders)
- [Access control for folders with IAM | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/access-control-folders)
- [Manage access to projects, folders, and organizations | IAM](https://docs.cloud.google.com/iam/docs/granting-changing-revoking-access)
- [Access control for projects with IAM | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/access-control-proj)
