# Question 022

**Source:** https://www.examtopics.com/discussions/google/view/25916-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Identity-Aware Proxy, IAP, App Engine, access control, Google Groups

---

## Question

A website design company recently migrated all customer sites to App Engine. Some sites are still in progress and should only be visible to customers and company employees from any location. Which solution will restrict access to the in-progress sites?
## Choices

- **A.** Upload an .htaccess file containing the customer and employee user accounts to App Engine.
- **B.** Create an App Engine firewall rule that allows access from the customer and employee networks and denies all other traffic.
- **C.** Enable Cloud Identity-Aware Proxy (IAP), and allow access to a Google Group that contains the customer and employee user accounts. Most Voted
- **D.** Use Cloud VPN to create a VPN connection between the relevant on-premises networks and the company's GCP Virtual Private Cloud (VPC) network.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (3 total)


**Top Comments:**

- (4 upvotes) C serves the purpose

- (3 upvotes) c is correct

- (2 upvotes) Answer is C

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Cloud Identity-Aware Proxy (IAP) is the correct solution for restricting access to App Engine applications based on user identity from any location. IAP establishes a central authorization layer for applications accessed via HTTPS, implementing an application-level access control model instead of relying on network-level restrictions.

The solution works by:
1. **Enabling IAP** on the App Engine application through the Google Cloud Console or gcloud CLI
2. **Granting the IAP-secured Web App User role** (roles/iap.httpsResourceAccessor) to a Google Group containing both customer and employee accounts
3. **Enforcing identity-based access** - only users with the assigned IAM role can access the application, regardless of their network location

This approach is ideal for the scenario because:
- **Location-independent**: Works "from any location" as required - users can access from home, office, or anywhere with internet
- **Centralized management**: The Google Group provides a single place to manage authorized users (customers and employees)
- **Application-level security**: Protects the App Engine application directly, not dependent on network topology
- **Google Cloud native**: Purpose-built for securing Google Cloud resources like App Engine, Cloud Run, and GKE

The documentation explicitly states: "Only accounts with the IAP-secured Web App User role on the project will be given access," ensuring precise control over who can view the in-progress sites.

### Why Other Options Are Wrong

- **A:** App Engine does not support .htaccess files (Apache-specific configuration). App Engine uses its own configuration files (app.yaml) and does not provide a mechanism for traditional web server authentication files. This is not a valid approach for App Engine applications.

- **B:** App Engine firewall rules operate at the IP address level, not user identity level. The requirement states access should be allowed "from any location," meaning customers and employees could be connecting from different networks (home, office, mobile). IP-based filtering would be impractical to maintain and wouldn't support users changing locations.

- **D:** Cloud VPN creates encrypted tunnels between on-premises networks and Google Cloud VPC networks, but this is excessive and impractical for this use case. It would require customers to have VPN infrastructure and connect through it just to view websites, creating significant operational overhead. Additionally, VPN doesn't provide user-level authentication - it only provides network connectivity.

### References

- [Identity-Aware Proxy Overview](https://docs.cloud.google.com/iap/docs/concepts-overview)
- [Enabling IAP for App Engine](https://docs.cloud.google.com/iap/docs/enabling-app-engine)
- [Managing Access to IAP-Secured Resources](https://docs.cloud.google.com/iap/docs/managing-access)
