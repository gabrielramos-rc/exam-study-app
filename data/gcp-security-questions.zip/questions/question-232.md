# Question 232

**Source:** https://www.examtopics.com/discussions/google/view/125660-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** IAM roles, logging.viewer, audit logs, least privilege, resource hierarchy

---

## Question

Your organization uses the top-tier folder to separate application environments (prod and dev). The developers need to see all application development audit logs, but they are not permitted to review production logs. Your security team can review all logs in production and development environments. You must grant Identity and Access Management (IAM) roles at the right resource level for the developers and security team while you ensure least privilege. What should you do?
## Choices

- **A.** 1. Grant logging.viewer role to the security team at the organization resource level. 2. Grant logging.viewer role to the developer team at the folder resource level that contains all the dev projects. Most Voted
- **B.** 1. Grant logging.viewer role to the security team at the organization resource level. 2. Grant logging.admin role to the developer team at the organization resource level.
- **C.** 1. Grant logging.admin role to the security team at the organization resource level. 2. Grant logging.viewer role to the developer team at the folder resource level that contains all the dev projects.
- **D.** 1. Grant logging.admin role to the security team at the organization resource level. 2. Grant logging.admin role to the developer team at the organization resource level.

---

## Community

**Most Voted:** A


**Votes:** A: 80% | C: 20% (5 total)


**Top Comments:**

- (3 upvotes) Grant logging.viewer role to the security team at the organization resource level. This allows the security team to view all logs in both production and development environments. Grant logging.viewer 

- (1 upvotes) The security team only needs to view logs, not manage log resources. logging.admin grants unnecessary permissions.

- (1 upvotes) Security team needs access to ALL logs. The only way they'll get that is with logging.admin. logging.viewer would not provide data access logs.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A correctly implements least privilege by granting the appropriate role at the correct resource level for each team:

**Security Team - logging.viewer at organization level:** The `roles/logging.viewer` role provides read-only access to logs, which is exactly what the security team needs to review logs across all environments (production and development). Granting this at the organization level allows them to view logs in all folders and projects beneath it, satisfying the requirement to "review all logs in production and development environments." The logging.viewer role is sufficient for viewing audit logs and does not grant unnecessary administrative permissions.

**Developer Team - logging.viewer at dev folder level:** Granting `roles/logging.viewer` at the folder resource level that contains all dev projects ensures developers can only see audit logs within that folder scope (development environment). This prevents them from accessing production logs while giving them the necessary read access to development audit logs. The role is granted at the most specific resource level needed, following the principle of least privilege.

Both teams only receive `logging.viewer` (read-only access), not `logging.admin`, which would grant unnecessary permissions to create, update, or delete log sinks, exclusions, and buckets.

### Why Other Options Are Wrong

- **B:** Grants `logging.admin` to developers at the organization level, violating least privilege by giving developers administrative logging permissions across the entire organization, including production. Developers only need to view logs, not manage logging configuration.

- **C:** Grants `logging.admin` to the security team when they only need `logging.viewer` for reviewing logs. The logging.admin role includes permissions to delete logs, create/modify sinks, and manage logging configuration, which are unnecessary for the security team's audit review function and violate least privilege.

- **D:** Grants `logging.admin` to both teams at the organization level, severely violating least privilege by giving both teams full administrative control over logging configuration organization-wide, and giving developers access to production logs.

### References

- [Access control with IAM | Cloud Logging](https://docs.cloud.google.com/logging/docs/access-control)
- [Cloud Logging roles and permissions | IAM](https://docs.cloud.google.com/iam/docs/roles-permissions/logging)
