# Question 230

**Source:** https://www.examtopics.com/discussions/google/view/116889-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Secret Manager, data residency, replication policy

---

## Question

For data residency requirements, you want your secrets in Google Clouds Secret Manager to only have payloads in europe-west1 and europe-west4. Your secrets must be highly available in both regions. What should you do?
## Choices

- **A.** Create your secret with a user managed replication policy, and choose only compliant locations. Most Voted
- **B.** Create your secret with an automatic replication policy, and choose only compliant locations.
- **C.** Create two secrets by using Terraform, one in europe-west1 and the other in europe-west4.
- **D.** Create your secret with an automatic replication policy, and create an organizational policy to deny secret creation in non-compliant locations.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (9 total)


**Top Comments:**

- (6 upvotes) B. Automatic Replication Policy: This does not allow you to specify locations, so it wouldn't meet your data residency requirements. C. Two Secrets with Terraform: This approach is more complex and le

- (2 upvotes) from ChatGPT-4: The correct answer is A. Create your secret with a user-managed replication policy, and choose only compliant locations. In Google Cloud's Secret Manager, secrets with a user-managed r

- (1 upvotes) A is correct as per https://cloud.google.com/secret-manager/docs/overview#:~:text=Ensure%20high%20availability%20and%20disaster,regardless%20of%20their%20geographic%20location.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

**User-managed replication policy** is the correct solution for data residency requirements. With this policy, you explicitly select the specific locations (europe-west1 and europe-west4) where Secret Manager will replicate your secret payloads. This ensures that your secret data remains only in compliant locations and never leaves those specified regions.

Key benefits of user-managed replication:
- **Precise location control**: You choose exactly which regions store your secret data
- **Data residency compliance**: Ensures secrets remain within required geographic boundaries
- **High availability**: Replicating to multiple regions (both europe-west1 and europe-west4) provides redundancy
- **Immutable once set**: The locations in the replication policy cannot be updated after creation, providing strong compliance guarantees

The documentation explicitly states that user-managed replication is designed for scenarios where "there are requirements around where the secret payload data can be stored."

### Why Other Options Are Wrong

- **B:** Automatic replication policy replicates secret data "without restriction" to multiple locations globally. You cannot configure automatic replication to limit to specific regions—it's designed for unrestricted global distribution. This violates data residency requirements.

- **C:** Creating two separate secrets in different regions is unnecessary and creates management overhead. A single secret with user-managed replication to both regions achieves the same high availability while maintaining a single secret resource. Additionally, managing two separate secrets requires application logic to handle failover between secrets.

- **D:** Automatic replication cannot be restricted to specific locations—it always replicates globally without restriction. Organization policies can prevent creation of secrets in certain locations, but they cannot force automatic replication to only use specific regions. This approach fundamentally misunderstands how automatic replication works.

### References

- [Choose a secret replication policy | Secret Manager](https://docs.cloud.google.com/secret-manager/docs/choosing-replication)
- [Secret Manager locations](https://docs.cloud.google.com/secret-manager/docs/locations)
- [About data residency and regional secrets](https://docs.cloud.google.com/secret-manager/regional-secrets/data-residency)
