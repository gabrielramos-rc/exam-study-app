# Question 201

**Source:** https://www.examtopics.com/discussions/google/view/117277-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Logging, log sink, aggregated sink, centralized logging, Security Reviewer

---

## Question

Your company's Google Cloud organization has about 200 projects and 1,500 virtual machines. There is no uniform strategy for logs and events management, which reduces visibility for your security operations team. You need to design a logs management solution that provides visibility and allows the security team to view the environment's configuration. What should you do?
## Choices

- **A.** 1. Create a dedicated log sink for each project that is in scope. 2. Use a BigQuery dataset with time partitioning enabled as a destination of the log sinks. 3. Deploy alerts based on log metrics in every project. 4. Grant the role "Monitoring Viewer" to the security operations team in each project.
- **B.** 1. Create one log sink at the organization level that includes all the child resources. 2. Use as destination a Pub/Sub topic to ingest the logs into the security information and event. management (SIEM) on-premises, and ensure that the right team can access the SIEM. 3. Grant the Viewer role at organization level to the security operations team. Most Voted
- **C.** 1. Enable network logs and data access logs for all resources in the "Production" folder. 2. Do not create log sinks to avoid unnecessary costs and latency. 3. Grant the roles "Logs Viewer" and "Browser" at project level to the security operations team.
- **D.** 1. Create one sink for the "Production" folder that includes child resources and one sink for the logs ingested at the organization level that excludes child resources. 2. As destination, use a log bucket with a minimum retention period of 90 days in a project that can be accessed by the security team. 3. Grant the security operations team the role of Security Reviewer at organization level.

---

## Community

**Most Voted:** B


**Votes:** B: 88% | D: 12% (8 total)


**Top Comments:**

- (2 upvotes) B. 1. Create one log sink at the organization level that includes all the child resources. 2. Use as destination a Pub/Sub topic to ingest the logs into the security information and event management (

- (2 upvotes) B is good

- (1 upvotes) D. Revised for a No-Folder Scenario: Create a single organization-level log sink: Include all child resources (projects) to centralize logging for the entire organization. Configure log filters: If yo

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B provides comprehensive centralized logging for all 200 projects:

1. **Organization-level sink including all child resources**: This single sink captures logs from ALL projects in the organization - Production, Development, Staging, and any other environment. The key phrase is "includes all the child resources," ensuring complete visibility across the entire organization.

2. **SIEM integration via Pub/Sub**: While this adds some complexity, SIEM integration is a common and valid pattern for security operations. Pub/Sub provides reliable, scalable log delivery to the SIEM where the security team already works.

3. **Viewer role at organization level**: Grants the security team comprehensive read access to view the environment's configuration across all 200 projects.

The question explicitly asks for visibility across the organization ("200 projects") and the ability to "view the environment's configuration" (singular environment = the entire org, not just Production).

### Why Other Options Are Wrong

- **A:** Creating 200 individual log sinks is operationally inefficient. Managing alerts per-project doesn't provide centralized visibility. "Monitoring Viewer" doesn't provide access to configurations and IAM policies.

- **C:** Limiting to only the "Production" folder ignores logs from Development, Staging, and other environments. Not creating sinks means logs remain scattered with default 30-day retention. Project-level access doesn't scale.

- **D:** **Critical flaw: Only captures Production folder logs.** The sink configuration explicitly targets "Production" folder + org-level logs excluding children. This misses all logs from non-Production projects (Dev, Staging, etc.). With 200 projects, many are likely outside the Production folder. The question requires visibility across the entire organization, not just Production.

### References

- [Aggregate and store your organization's logs](https://cloud.google.com/logging/docs/central-log-storage)
- [Aggregated sinks overview](https://cloud.google.com/logging/docs/export/aggregated_sinks)
- [IAM basic roles](https://cloud.google.com/iam/docs/understanding-roles#basic)
