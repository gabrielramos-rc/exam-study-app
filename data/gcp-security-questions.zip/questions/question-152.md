# Question 152

**Source:** https://www.examtopics.com/discussions/google/view/80449-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** centralized logging, aggregated sink, log bucket, Logs Explorer

---

## Question

You need to centralize your team's logs for production projects. You want your team to be able to search and analyze the logs using Logs Explorer. What should you do?
## Choices

- **A.** Enable Cloud Monitoring workspace, and add the production projects to be monitored.
- **B.** Use Logs Explorer at the organization level and filter for production project logs.
- **C.** Create an aggregate org sink at the parent folder of the production projects, and set the destination to a Cloud Storage bucket.
- **D.** Create an aggregate org sink at the parent folder of the production projects, and set the destination to a logs bucket. Most Voted

---

## Community

**Most Voted:** D


**Votes:** A: 12% | D: 88% (16 total)


**Top Comments:**

- (8 upvotes) D. Create an aggregate org sink at the parent folder of the production projects, and set the destination to a logs bucket.

- (7 upvotes) The answer is A because you want to search and analyze logs using Logs Explorer

- (4 upvotes) What is this link for? it supports C as well. The point is we cant use logs explorer on Cloud storage....Thats what makes D the answer

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Creating an aggregated sink at the parent folder with a log bucket as the destination is the correct approach for centralizing logs that need to be analyzed in Logs Explorer. Here's why:

**Aggregated sinks** allow you to collect logs from multiple projects within an organization or folder hierarchy and route them to a centralized location. By creating the sink at the parent folder of production projects, all logs from those projects are automatically routed to the specified destination.

**Log buckets** are the appropriate destination because:
1. They are specifically designed for centralized log storage
2. They integrate directly with Logs Explorer for querying and analysis
3. You can use log views to organize and control access to the centralized logs
4. Logs Explorer can directly query logs stored in log buckets without additional configuration

The workflow is: Create aggregated sink → Route logs to log bucket → Access via Logs Explorer using log views → Team can search and analyze logs using the native Logs Explorer interface.

### Why Other Options Are Wrong

- **A:** Cloud Monitoring workspaces are for metrics and monitoring, not for centralizing and searching logs in Logs Explorer. This doesn't provide the log centralization or Logs Explorer capabilities needed.

- **B:** While you can use Logs Explorer at the organization level, this approach doesn't centralize the log storage. Logs remain in their original projects, which can complicate retention policies, access control, and cost management. This also doesn't leverage the benefits of aggregated sinks for centralized log management.

- **C:** Cloud Storage buckets cannot be queried directly by Logs Explorer. When logs are exported to Cloud Storage, you would need to use other tools like BigQuery (by loading the data) or other analysis tools to query them. This doesn't meet the requirement to "search and analyze the logs using Logs Explorer."

### References

- [Aggregate and store your organization's logs](https://docs.cloud.google.com/logging/docs/central-log-storage)
- [Aggregated sinks overview](https://docs.cloud.google.com/logging/docs/export/aggregated_sinks_overview)
- [Route log entries - Centralized Storage](https://docs.cloud.google.com/logging/docs/routing/overview)
