# Question 057

**Source:** https://www.examtopics.com/discussions/google/view/34238-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Configuring network security
**Tags:** organization policy, external IP restriction, Compute Engine, vmExternalIpAccess

---

## Question

Your team wants to make sure Compute Engine instances running in your production project do not have public IP addresses. The frontend application Compute Engine instances will require public IPs. The product engineers have the Editor role to modify resources. Your team wants to enforce this requirement. How should your team meet these requirements?
## Choices

- **A.** Enable Private Access on the VPC network in the production project.
- **B.** Remove the Editor role and grant the Compute Admin IAM role to the engineers.
- **C.** Set up an organization policy to only permit public IPs for the front-end Compute Engine instances. Most Voted
- **D.** Set up a VPC network with two subnets: one with public IPs and one without public IPs.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (4 total)


**Top Comments:**

- (12 upvotes) More specifically, it's the "Restrict VM IP Forwarding" constraint under Compute Engine

- (4 upvotes) Intitally I agreed with you but after looking at the link above it does say this. This list constraint defines the set of Compute Engine VM instances that are allowed to use external IP addresses. By 

- (4 upvotes) Sorry meant to comment this on the above post

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

The correct solution is to use an Organization Policy with the `constraints/compute.vmExternalIpAccess` constraint. This constraint allows you to specify an allowlist of specific Compute Engine instances that are permitted to have external (public) IP addresses. By configuring this policy, you can:

1. **Enforce the requirement programmatically** - The policy prevents engineers from assigning public IPs to instances that aren't explicitly allowed, even if they have Editor permissions
2. **Allow frontend instances to have public IPs** - You specify the frontend instances in the `allowedValues` list using their full resource URIs (e.g., `projects/PROJECT_ID/zones/ZONE/instances/frontend-vm`)
3. **Block all other instances** - Any instance not in the allowlist is automatically prevented from receiving external IP addresses
4. **Override IAM permissions** - Organization policies take precedence over IAM roles, so even users with Editor role cannot violate the constraint

The policy can be set at the organization or project level and provides declarative, enforceable control over external IP usage.

### Why Other Options Are Wrong

- **A:** Private Google Access allows instances without external IPs to access Google APIs and services, but it doesn't prevent instances from having public IPs. It's a complementary feature for private connectivity, not an enforcement mechanism.

- **B:** Changing IAM roles from Editor to Compute Admin doesn't solve the problem. The Compute Admin role (`roles/compute.admin`) still grants full permissions to create instances with external IPs. This is a lateral move that doesn't enforce the "no public IP" requirement.

- **D:** Creating separate subnets doesn't enforce anything - it's just network segmentation. Engineers with Editor permissions could still create instances with public IPs in either subnet. Subnets don't control whether instances can have external IPs; they only define IP ranges. This is a design pattern but not an enforcement mechanism.

### References

- [Configure static external IP addresses | Compute Engine Documentation](https://docs.cloud.google.com/compute/docs/ip-addresses/configure-static-external-ip-address)
- [IP addresses | Compute Engine Documentation](https://docs.cloud.google.com/compute/docs/ip-addresses)
