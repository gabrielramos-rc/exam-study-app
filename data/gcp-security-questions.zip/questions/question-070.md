# Question 070

**Source:** https://www.examtopics.com/discussions/google/view/30128-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** compliance, ISO 27017, ISO standards, cloud security, regulatory

---

## Question

Which international compliance standard provides guidelines for information security controls applicable to the provision and use of cloud services?
## Choices

- **A.** ISO 27001
- **B.** ISO 27002
- **C.** ISO 27017 Most Voted
- **D.** ISO 27018

---

## Community

**Most Voted:** C


**Votes:** C: 100% (6 total)


**Top Comments:**

- (11 upvotes) C is right

- (4 upvotes) C is correct. https://cloud.google.com/security/compliance/iso-27017

- (3 upvotes) CCSP Question...C is the Answer

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

ISO/IEC 27017:2015 is the international compliance standard specifically designed to provide guidelines for information security controls applicable to the provision and use of cloud services. This standard extends the foundational controls from ISO 27002 by adding cloud-specific implementation guidance.

ISO 27017 provides:
- 37 controls from ISO 27002 with additional cloud-specific implementation guidance
- 7 new controls that are unique to cloud computing environments
- Guidance for both cloud service providers and cloud service customers
- Controls addressing cloud-specific risks such as:
  - Shared responsibility between provider and customer
  - Multi-tenancy and data isolation
  - Virtual machine configuration and management
  - Virtual and cloud network environment alignment
  - Asset return and removal at end of contract

Google Cloud, AWS, Microsoft Azure, and other major cloud providers maintain ISO 27017 compliance, demonstrating adherence to internationally recognized cloud security practices.

### Why Other Options Are Wrong

- **A. ISO 27001:** This is the foundational standard for Information Security Management Systems (ISMS). While it provides the overall framework for managing information security, it is not specifically focused on cloud services. It defines what must be done to manage risk and secure information in general, but lacks cloud-specific controls and implementation guidance.

- **B. ISO 27002:** This standard provides implementation guidance for the controls listed in ISO 27001 Annex A. While it offers detailed reference for generic information security controls, it does not specifically address cloud service provision and usage scenarios. ISO 27017 actually builds upon ISO 27002 by adding cloud-specific context.

- **D. ISO 27018:** This standard focuses specifically on protecting Personally Identifiable Information (PII) in cloud computing environments. While it is cloud-related, its scope is limited to privacy and PII protection as a data processor, not general information security controls for cloud services. ISO 27018 addresses a subset of cloud security (privacy), whereas ISO 27017 provides comprehensive security controls for cloud services.

### References

- [ISO/IEC 27017 - Google Cloud Compliance](https://cloud.google.com/security/compliance/iso-27017)
- [ISO/IEC 27017:2015 - Official ISO Standard](https://www.iso.org/standard/43757.html)
- [ISO 27000 Standards Comparison](https://www.barradvisory.com/resource/iso-27001-27002-27701-27017-27018/)
