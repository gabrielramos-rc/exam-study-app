# Question 061

**Source:** https://www.examtopics.com/discussions/google/view/30329-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** network segmentation, firewall rules, service account, microsegmentation, N-tier

---

## Question

A customer wants to deploy a large number of 3-tier web applications on Compute Engine. How should the customer ensure authenticated network separation between the different tiers of the application?
## Choices

- **A.** Run each tier in its own Project, and segregate using Project labels.
- **B.** Run each tier with a different Service Account (SA), and use SA-based firewall rules. Most Voted
- **C.** Run each tier in its own subnet, and use subnet-based firewall rules.
- **D.** Run each tier with its own VM tags, and use tag-based firewall rules.

---

## Community

**Most Voted:** B


**Votes:** B: 56% | C: 33% | D: 11% (9 total)


**Top Comments:**

- (32 upvotes) Thank you for this great explanation with link to documentation.

- (3 upvotes) B exists?

- (2 upvotes) Agreed with you and B is right

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Service account-based firewall rules provide **authenticated** (identity-based) network separation, which is the key requirement in the question. When you assign different service accounts to each tier (web, application, database) and create firewall rules that use source and target service accounts, you achieve microsegmentation based on VM identity rather than just network characteristics.

Google Cloud best practices explicitly recommend: "Isolate VMs using service accounts when possible." Service account-based firewall rules offer several advantages:

1. **Identity-based security**: Traffic is controlled based on the identity (service account) of the VM, not just network location
2. **Authenticated separation**: The service account provides cryptographic authentication of the VM's identity
3. **Dynamic and flexible**: VMs can move between subnets or networks while maintaining the same security posture
4. **IAM integration**: Service accounts integrate with IAM for robust access control and auditing

For a 3-tier application, you would create:
- One service account for web tier VMs
- One service account for app tier VMs
- One service account for database tier VMs

Then create firewall rules like:
- Allow ingress from web-tier SA to app-tier SA on port 8080
- Allow ingress from app-tier SA to db-tier SA on port 3306
- Deny all other inter-tier traffic

### Why Other Options Are Wrong

- **A.** Running each tier in separate projects is operationally complex and expensive for "a large number of 3-tier applications." Project labels don't provide network-level firewall controls - they're metadata tags for organization and billing. This doesn't achieve authenticated network separation.

- **C.** VPC firewall rules don't support subnet-based targeting. Firewall rules target individual instances through service accounts or network tags, not subnets. Even if you could achieve this, subnet-based rules would be location-based, not identity-based, and wouldn't provide "authenticated" separation.

- **D.** Network tags provide network-based segmentation but lack the robust IAM controls needed for authenticated separation. As the documentation notes: "Network tags don't offer the robust IAM controls needed for strict traffic segmentation." Tags can be modified by anyone with compute.instances.setTags permission and don't provide identity verification like service accounts do.

### References

- [VPC firewall rules](https://docs.cloud.google.com/firewall/docs/firewalls)
- [Best practices and reference architectures for VPC design](https://docs.cloud.google.com/architecture/best-practices-vpc-design)
- [Use VPC firewall rules](https://docs.cloud.google.com/firewall/docs/using-firewalls)
