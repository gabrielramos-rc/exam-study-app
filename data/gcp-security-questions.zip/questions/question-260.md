# Question 260

**Source:** https://www.examtopics.com/discussions/google/view/147054-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** data residency, CMEK, regional storage, compliance, BigQuery, encryption

---

## Question

Your organization uses Google Cloud to process large amounts of location data for analysis and visualization. The location data is potentially sensitive. You must design a solution that allows storing and processing the location data securely, minimizing data exposure risks, and adhering to both regulatory guidelines and your organization's internal data residency policies. What should you do?
## Choices

- **A.** Enable location restrictions on Compute Engine instances and virtual disk resources where the data is handled. Apply labels to tag geographic metadata for all stored data.
- **B.** Use the Cloud Data Loss Prevention (Cloud DLP) API to scan for sensitive location data before any storage or processing. Create Cloud Storage buckets with global availability for optimal performance, relying on Cloud DLP results to filter and control data access.
- **C.** Create regional Cloud Storage buckets with Object Lifecycle Management policies that limit data lifetime. Enable fine-grained access controls by using IAM conditions. Encrypt data with customer-managed encryption keys (CMEK) generated within specific Cloud KMS key locations.
- **D.** Store data within BigQuery in a specified region by using dataset location configuration. Use authorized views and row-level security to enforce geographic access restrictions. Encrypt data within BigQuery tables by using customer-managed encryption keys (CMEK). Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (12 total)


**Top Comments:**

- (5 upvotes) D. provides the most comprehensive and secure solution specifically tailored for structured data analysis. BigQuery Dataset Location: This directly enforces the data residency requirement, ensuring th

- (2 upvotes) BigQuery

- (1 upvotes) Key word in the Q to look out for... analysis of data. Analysis of data typically = BQ required

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D provides the most comprehensive solution for meeting data residency requirements while ensuring security for sensitive location data. BigQuery's regional dataset configuration directly addresses data residency policies by ensuring data remains in a specific geographic location. The combination of regional datasets with CMEK provides multiple layers of protection:

1. **Regional Dataset Location**: BigQuery allows you to specify a region for dataset creation, ensuring data is stored and processed only in that geographic location. BigQuery automatically stores copies of data in two different zones within the selected region.

2. **CMEK for Data Residency**: Customer-managed encryption keys (CMEK) must be created in Cloud KMS key rings that match the dataset location. Regional datasets require matching regional keys - for example, a dataset in asia-northeast1 must use a key ring from asia-northeast1. This enforces data residency by preventing data from being encrypted with keys from mismatched regions, effectively blocking unauthorized cross-border data movement.

3. **Fine-Grained Access Controls**: Authorized views and row-level security provide granular access control, allowing you to enforce geographic access restrictions and minimize data exposure by limiting what data users can see based on their permissions.

4. **Regulatory Compliance**: The combination of regional storage, CMEK, and access controls satisfies both regulatory guidelines and internal data residency policies, which is explicitly required in the question.

### Why Other Options Are Wrong

- **A:** While location restrictions on Compute Engine instances can help, this approach doesn't provide a complete solution for data residency. Simply applying labels to tag geographic metadata doesn't enforce actual data residency - labels are just metadata and don't control where data physically resides or is processed. This option lacks encryption controls and doesn't address the processing and analysis requirements mentioned in the question.

- **B:** Creating Cloud Storage buckets with "global availability" directly violates data residency policies. Global buckets don't guarantee data stays in a specific region. While Cloud DLP is valuable for identifying sensitive data, using it as the primary control mechanism before storage doesn't address the fundamental requirement of keeping data within specific geographic boundaries. DLP is for data classification and protection, not data residency enforcement.

- **C:** While regional Cloud Storage buckets with CMEK and IAM conditions are good security practices, this option has limitations for the use case. The question specifically mentions "process large amounts of location data for analysis and visualization" - BigQuery is purpose-built for this type of large-scale data analysis, whereas Cloud Storage is object storage. Object Lifecycle Management policies that "limit data lifetime" don't directly enforce data residency. Additionally, Cloud Storage doesn't provide the same level of fine-grained access controls or query capabilities needed for complex data analysis and visualization workflows.

### References

- [Customer-managed Cloud KMS keys for BigQuery](https://docs.cloud.google.com/bigquery/docs/customer-managed-encryption)
- [BigQuery dataset locations](https://docs.cloud.google.com/bigquery/docs/locations)
- [Customer-managed encryption keys for Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption/customer-managed-keys)
- [Cloud KMS encryption overview](https://docs.cloud.google.com/docs/security/key-management-deep-dive)
