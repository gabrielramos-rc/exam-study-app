# Question 100

**Source:** https://www.examtopics.com/discussions/google/view/75710-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** encryption at rest, FIPS 140-2, default encryption, Cloud KMS, Cloud EKM, key management, key rotation

---

## Question

You need to implement an encryption at-rest strategy that reduces key management complexity for non-sensitive data and protects sensitive data while providing the flexibility of controlling the key residency and rotation schedule. FIPS 140-2 L1 compliance is required for all data types. What should you do?
## Choices

- **A.** Encrypt non-sensitive data and sensitive data with Cloud External Key Manager.
- **B.** Encrypt non-sensitive data and sensitive data with Cloud Key Management Service
- **C.** Encrypt non-sensitive data with Google default encryption, and encrypt sensitive data with Cloud External Key Manager.
- **D.** Encrypt non-sensitive data with Google default encryption, and encrypt sensitive data with Cloud Key Management Service. Most Voted

---

## Community

**Most Voted:** D


**Votes:** B: 14% | D: 86% (21 total)


**Top Comments:**

- (6 upvotes) I agree, D is right

- (5 upvotes) https://cloud.google.com/kms/docs/key-management-service#choose For example, you might use software keys for your least sensitive data and hardware or external keys for your most sensitive data. FIPS 

- (3 upvotes) "reduces key management" &amp; "FIPS 140-2 L1 compliance is required for all data types" - strongly suggests answer B

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D provides the optimal balance between reduced key management complexity and flexibility for sensitive data while meeting FIPS 140-2 L1 compliance for all data types:

**For non-sensitive data (Google default encryption):**
- Automatically encrypts all customer content at rest with no configuration required
- Uses FIPS 140-2 validated encryption module (BoringCrypto, certificate 4407) meeting L1 compliance
- Minimal key management complexity - keys are managed automatically by Google Cloud
- No operational overhead for key rotation, access control, or lifecycle management
- Cannot view, manage, or control these keys, which is acceptable for non-sensitive data

**For sensitive data (Cloud KMS):**
- Provides full control over key residency through multiple protection levels (SOFTWARE for L1, HSM for L3)
- Enables customizable automatic key rotation schedules that you control
- Allows you to control key creation, access control, rotation, use, and destruction
- Maintains FIPS 140-2 L1 compliance with SOFTWARE protection level (exceeds requirement with L3 for HSM)
- Provides audit logs for all key usage operations
- Offers cryptographic isolation and logical data separation for sensitive workloads

This two-tier approach minimizes complexity for non-sensitive data while providing the necessary flexibility and control for sensitive data, all within FIPS 140-2 L1 compliance requirements.

### Why Other Options Are Wrong

- **A:** Using Cloud EKM for both non-sensitive and sensitive data creates unnecessary key management complexity for non-sensitive data. EKM is designed for external key control requirements and adds operational overhead (external key management partner, network dependencies, potential availability risks) that provides no value for non-sensitive data. This violates the requirement to "reduce key management complexity for non-sensitive data."

- **B:** While Cloud KMS for all data meets FIPS requirements and provides flexibility, it creates unnecessary key management complexity for non-sensitive data. You would need to create keys, manage rotation schedules, configure IAM permissions, and monitor key usage even for data that doesn't require such controls. This violates the principle of reducing complexity where it's not needed.

- **C:** Cloud EKM adds unnecessary complexity and external dependencies for sensitive data when Cloud KMS provides sufficient control over key residency and rotation. EKM is designed for scenarios requiring keys to remain outside Google's infrastructure (regulatory requirements, key sovereignty), which isn't specified in this scenario. EKM introduces additional complexity (external partner management, network connectivity requirements, potential availability issues) without providing additional benefit over Cloud KMS for the stated requirements.

### References

- [Default encryption at rest](https://docs.cloud.google.com/docs/security/encryption/default-encryption)
- [Cloud Key Management Service overview](https://docs.cloud.google.com/kms/docs/key-management-service)
- [Cloud Key Management Service encryption](https://docs.cloud.google.com/docs/security/key-management-deep-dive)
