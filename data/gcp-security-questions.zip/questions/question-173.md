# Question 173

**Source:** https://www.examtopics.com/discussions/google/view/79866-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** Cloud HSM, CMEK, FIPS 140-2, key rotation, multi-region

---

## Question

You are working with a client who plans to migrate their data to Google Cloud. You are responsible for recommending an encryption service to manage their encrypted keys. You have the following requirements: ✑ The master key must be rotated at least once every 45 days. ✑ The solution that stores the master key must be FIPS 140-2 Level 3 validated. ✑ The master key must be stored in multiple regions within the US for redundancy. Which solution meets these requirements?
## Choices

- **A.** Customer-managed encryption keys with Cloud Key Management Service
- **B.** Customer-managed encryption keys with Cloud HSM Most Voted
- **C.** Customer-supplied encryption keys
- **D.** Google-managed encryption keys

---

## Community

**Most Voted:** B


**Votes:** B: 100% (36 total)


**Top Comments:**

- (10 upvotes) B. Customer-managed encryption keys with Cloud HSM

- (7 upvotes) Cloud HSM helps you enforce regulatory compliance for your workloads in Google Cloud. With Cloud HSM, you can generate encryption keys and perform cryptographic operations in FIPS 140-2 Level 3 valida

- (6 upvotes) In all options only HMS have L3 validation

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Customer-managed encryption keys (CMEK) with Cloud HSM is the correct solution because it meets all three requirements:

1. **FIPS 140-2 Level 3 validation**: Cloud HSM uses FIPS 140-2 Level 3 certified Hardware Security Modules (HSMs). The documentation explicitly states: "Cloud HSM is a cloud-hosted Hardware Security Module (HSM) service that lets you host encryption keys and perform cryptographic operations in a cluster of FIPS 140-2 Level 3 certified HSMs." Keys with the HSM protection level, and cryptographic operations performed with them, comply with FIPS 140-2 Level 3.

2. **Key rotation every 45 days**: Cloud HSM supports configurable automatic key rotation. You can create keys with the `--rotation-period` flag to specify rotation frequency (for example, 45 days or even more frequent like 7 days), and `--next-rotation-time` to set when the next rotation occurs. This gives you full control over the rotation schedule to meet the 45-day requirement.

3. **Multi-region storage within the US**: Cloud HSM is available in US multi-regions including `us`, `nam3`, `nam4`, `nam6`, `nam7`, `nam8`, `nam9`, `nam10`, `nam11`, and `nam12`. These multi-regions provide redundancy by storing keys across multiple regions within the United States. Cloud HSM creates multi-regions using wrapping keys, ensuring keys are protected across all constituent locations.

Cloud HSM uses FIPS 140-2 Level 3 validated Marvell LiquidSecurity HSMs and is fully managed by Google, eliminating operational overhead while maintaining the highest security standards.

### Why Other Options Are Wrong

- **A. Customer-managed encryption keys with Cloud Key Management Service**: While Cloud KMS supports CMEK and key rotation, standard Cloud KMS uses software-based protection (FIPS 140-2 Level 1) by default, not Level 3. The SOFTWARE protection level complies with FIPS 140-2 Level 1, which does not meet the requirement for Level 3 validation.

- **C. Customer-supplied encryption keys**: CSEK allows customers to provide their own encryption keys, but Google does not store or manage these keys. Since CSEK keys are managed entirely outside of Google Cloud, there is no Google-provided FIPS 140-2 Level 3 validated storage solution for the master key. Additionally, CSEK does not support automatic key rotation - customers must manually manage rotation.

- **D. Google-managed encryption keys**: While Google-managed keys are FIPS 140-2 validated and automatically rotated, customers have no control over the rotation schedule. The requirement specifies rotation "at least once every 45 days," but Google-managed keys follow Google's own rotation schedule which may not align with the specific 45-day requirement. Additionally, these are not customer-managed, which contradicts the need for customer control over encryption key management.

### References

- [Cloud HSM | Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/hsm)
- [Protection levels | Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/protection-levels)
- [Cloud KMS locations](https://docs.cloud.google.com/kms/docs/locations)
- [Cloud HSM architecture | Security](https://docs.cloud.google.com/docs/security/cloud-hsm-architecture)
