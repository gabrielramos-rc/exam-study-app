# Question 079

**Source:** https://www.examtopics.com/discussions/google/view/80811-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** shared responsibility model, PaaS, App Engine, application security

---

## Question

An organization's security and risk management teams are concerned about where their responsibility lies for certain production workloads they are running in Google Cloud and where Google's responsibility lies. They are mostly running workloads using Google Cloud's platform-as-a-Service (PaaS) offerings, including App Engine primarily. Which area in the technology stack should they focus on as their primary responsibility when using App Engine?
## Choices

- **A.** Configuring and monitoring VPC Flow Logs
- **B.** Defending against XSS and SQLi attacks Most Voted
- **C.** Managing the latest updates and security patches for the Guest OS
- **D.** Encrypting all stored data

---

## Community

**Most Voted:** B


**Votes:** B: 94% | D: 6% (16 total)


**Top Comments:**

- (7 upvotes) Why B. Defending against XSS and SQLi attacks is Correct: Application-Layer Security: When using PaaS offerings, developers are responsible for writing secure application code. This includes preventin

- (4 upvotes) Answer should be D. For SAAS solutions web based attacks are managed by Google. We just need to take care of the data as per the link below.

- (2 upvotes) B is correct

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

In Google Cloud's shared responsibility model for Platform-as-a-Service (PaaS) offerings like App Engine, the customer's primary responsibility is **application-level security**, which includes defending against application vulnerabilities such as Cross-Site Scripting (XSS) and SQL Injection (SQLi) attacks.

According to Google Cloud's shared responsibility framework, customers using PaaS services share responsibility for application-level controls and remain responsible for their data security and client protection. While Google manages the underlying infrastructure, runtime environment, and platform-level security, customers must secure their application code, implement secure coding practices, and protect against common application vulnerabilities.

App Engine is a fully managed PaaS platform where Google handles:
- Infrastructure security (physical data centers, hardware)
- Operating system patching and updates
- Runtime environment security
- Network infrastructure
- Default encryption mechanisms

The customer must focus on:
- **Application code security** (the primary responsibility)
- Defending against application-layer attacks (XSS, SQLi, CSRF, etc.)
- Access management through IAM
- Secure coding practices
- Managing secrets and API keys
- Data classification and protection

Since the question asks about the "primary responsibility" for App Engine users, defending against XSS and SQL injection attacks represents the core application security responsibility that falls squarely on the customer's shoulders.

### Why Other Options Are Wrong

- **A:** VPC Flow Logs are more relevant to Infrastructure-as-a-Service (IaaS) workloads running on Compute Engine. App Engine is a PaaS offering where Google manages the underlying network infrastructure. While flow logs can be enabled, configuring and monitoring them is not the primary responsibility for App Engine users, as the platform abstracts away most network-level concerns.

- **C:** Google automatically manages OS updates and security patches for App Engine. The documentation explicitly states that App Engine includes "automatic in-place security patches" and that Google's management services apply necessary operating system and security updates. This is one of the key benefits of using PaaS - customers don't need to worry about OS-level maintenance.

- **D:** Google Cloud provides default encryption at rest and in transit for all data stored in App Engine. While customers remain responsible for their data security and may choose to implement additional encryption layers (like customer-managed encryption keys), encryption of stored data is automatically handled by Google by default. This is not the primary focus area for customer responsibility in the shared model.

### References

- [Google Cloud Architecture Framework - Shared Responsibility and Shared Fate](https://docs.cloud.google.com/architecture/framework/security/shared-responsibility-shared-fate)
- [Google Infrastructure Security Design Overview](https://docs.cloud.google.com/security/infrastructure/design)
