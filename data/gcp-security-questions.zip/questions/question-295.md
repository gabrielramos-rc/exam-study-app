# Question 295

**Source:** https://www.examtopics.com/discussions/google/view/148650-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Binary Authorization, Cloud Build, attestation, CI/CD, container security, image provenance

---

## Question

Your organization heavily utilizes serverless applications while prioritizing security best practices. You are responsible for enforcing image provenance and compliance with security standards before deployment. You leverage Cloud Build as your continuous integration and continuous deployment (CI/CD) tool for building container images. You must configure Binary Authorization to ensure that only images built by your Cloud Build pipeline are deployed and that the images pass security standard compliance checks. What should you do?
## Choices

- **A.** Create a Binary Authorization attestor that uses a scanner to assess source code management repositories. Deploy images only if the attestor validates results against a security policy.
- **B.** Create a Binary Authorization attestor that utilizes a scanner to evaluate container image build processes. Define a policy that requires deployment of images only if this attestation is present.
- **C.** Create a Binary Authorization attestor that retrieves the Cloud Build build ID of the container image. Configure a policy to allow deployment only if there's a matching build ID attestation.
- **D.** Utilize a custom Security Health Analytics module to create a policy. Enforce the policy through Binary Authorization to prevent deployment of images that do not meet predefined security standards.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Cloud Build provides a built-in attestor called `built-by-cloud-build` that automatically creates and signs attestations for successfully built images. This attestor verifies that images were built by your Cloud Build pipeline by checking the Cloud Build build ID. When you configure a Binary Authorization policy to require the `built-by-cloud-build` attestor, only images with valid Cloud Build attestations (matching build IDs) can be deployed.

The workflow operates as follows:
1. Cloud Build automatically generates attestations for successfully built images
2. These attestations include the build ID and are cryptographically signed
3. Binary Authorization policy requires the `built-by-cloud-build` attestor
4. At deployment time, Binary Authorization verifies the attestation matches a Cloud Build build ID
5. Only verified images are permitted; failures are blocked and logged

This provides strong image provenance guarantees - you can ensure that deployed images were built by your trusted CI/CD pipeline rather than arbitrary sources.

### Why Other Options Are Wrong

- **A:** Scanning source code management repositories is not how Binary Authorization enforces image provenance. Binary Authorization works with container image attestations, not source code repositories. This approach doesn't verify that the deployed image was actually built by Cloud Build.

- **B:** While you can create custom attestors with vulnerability scanners, the question specifically asks to ensure "only images built by your Cloud Build pipeline are deployed." The built-in `built-by-cloud-build` attestor is the correct mechanism for this requirement, not a custom scanner-based attestor. Scanner-based attestors are for compliance checks, not build provenance.

- **D:** Security Health Analytics is used for security posture monitoring and detecting misconfigurations across Google Cloud resources. It is not integrated with Binary Authorization for deployment enforcement and doesn't provide image provenance verification. This is the wrong tool for the stated requirement.

### References

- [Deploy only images built by Cloud Build](https://docs.cloud.google.com/binary-authorization/docs/deploy-cloud-build)
- [Create a Binary Authorization attestation in a Cloud Build pipeline](https://docs.cloud.google.com/binary-authorization/docs/cloud-build)
- [Attestations overview](https://docs.cloud.google.com/binary-authorization/docs/attestations)
