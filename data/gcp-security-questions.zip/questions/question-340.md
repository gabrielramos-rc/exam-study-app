# Question 340

**Source:** https://www.examtopics.com/discussions/google/view/311187-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Protecting sensitive data and preventing data loss
**Tags:** Vertex AI, generative AI, data privacy, foundation models, AI/ML Privacy Commitment

---

## Question

Your organization is building an application powered by generative AI that uses sensitive internal data lo train the AI model. The application is built using Vertex AI, which is generally available in your region. You must ensure Google does not use your sensitive data when tuning public models because it could result in your data being shared with other Google Cloud customers. What should you do?
## Choices

- **A.** Do not use Vertex AI for sensitive data. Use only public data with minimal privacy requirements.
- **B.** Encrypt your data by using customer-managed encryption keys (CMEK) to have full control over encryption key access.
- **C.** Do nothing. Vertex AI foundation models are frozen by default and do not use your data for model-tuning purposes. Most Voted
- **D.** Contact Google support to opt out of model tuning.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (1 total)

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is correct. Google has made an explicit AI/ML Privacy Commitment that applies to all Vertex AI services. According to Google Cloud's official documentation, **Google will not use customer data to train or fine-tune any AI/ML models without explicit permission or instruction**. This commitment applies to all managed models on Vertex AI, including both GA (generally available) and pre-GA models.

The foundation models available through Vertex AI are pre-trained and frozen - they do not incorporate customer data into their training or tuning processes. When you use sensitive internal data with Vertex AI for your own fine-tuning purposes, that data remains isolated to your project and is never used by Google to improve or tune the public foundation models that other customers use.

This is a fundamental part of Google Cloud's data governance commitment for generative AI services. While customer data may be temporarily cached in-memory (with a 24-hour TTL) to reduce latency, it is isolated at the project level and never used for training purposes. The only exception is minimal prompt logging for abuse detection as outlined in the Terms of Service, but this is not related to model tuning.

### Why Other Options Are Wrong

- **A:** This is unnecessarily restrictive. Vertex AI is specifically designed to handle sensitive data securely, and Google's AI/ML Privacy Commitment ensures customer data is not used for training public models. Avoiding Vertex AI for sensitive data would eliminate one of its key use cases and is not required.

- **B:** While CMEK encryption is a good security practice for protecting data at rest and provides additional control over encryption keys, it does not address the concern about Google using data for model tuning. CMEK protects stored data but doesn't prevent (nor is needed to prevent) data from being used in training - that protection comes from Google's privacy commitment, which applies regardless of encryption method.

- **D:** There is no opt-out process needed because Google does not use customer data for tuning public models by default. The AI/ML Privacy Commitment is the standard policy for all Vertex AI customers. Contacting support would be unnecessary since the desired protection is already in place automatically.

### References

- [Vertex AI and zero data retention](https://docs.cloud.google.com/vertex-ai/generative-ai/docs/vertex-ai-zero-data-retention)
- [Data governance and generative AI](https://docs.cloud.google.com/generative-ai-app-builder/docs/data-governance)
