# Question 053

**Source:** https://www.examtopics.com/discussions/google/view/30233-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** patch management, CI/CD, custom images, immutable infrastructure, image families

---

## Question

A customer deployed an application on Compute Engine that takes advantage of the elastic nature of cloud computing. How can you work with Infrastructure Operations Engineers to best ensure that Windows Compute Engine VMs are up to date with all the latest OS patches?
## Choices

- **A.** Build new base images when patches are available, and use a CI/CD pipeline to rebuild VMs, deploying incrementally. Most Voted
- **B.** Federate a Domain Controller into Compute Engine, and roll out weekly patches via Group Policy Object.
- **C.** Use Deployment Manager to provision updated VMs into new serving Instance Groups (IGs).
- **D.** Reboot all VMs during the weekly maintenance window and allow the StartUp Script to download the latest patches from the internet.

---

## Community

**Most Voted:** A


**Votes:** A: 86% | C: 14% (7 total)


**Top Comments:**

- (22 upvotes) Seems this is an old question, now Deployment Manager is able to update base images: https://cloud.google.com/deployment-manager/docs/reference/latest/deployments/patch

- (4 upvotes) Question is outdated, Since 2020 Google has VM Manager for updating VMs (Linux and Windows)

- (4 upvotes) Agreed.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Building new base images (known as "baking") when patches are available and using a CI/CD pipeline to rebuild and incrementally deploy VMs is the recommended Google Cloud best practice for patch management in elastic, cloud-native environments. This approach implements immutable infrastructure principles:

1. **Image baking**: Instead of patching running VMs, you create custom images that include the latest patches. Google's documentation explicitly recommends this approach over using startup scripts, noting benefits including "shorter time from boot to application readiness, enhanced reliability for application deployments, easier rollback to previous versions, fewer dependencies on external services during application bootstrap, and scaling up creates instances that contain identical software versions."

2. **CI/CD automation**: Using automated tools like Packer in a CI/CD pipeline makes image creation "more reproducible, auditable, configurable, and reliable" compared to manual processes.

3. **Incremental deployment**: By using image families with Managed Instance Groups (MIGs), you can perform rolling updates that incrementally replace VMs with the new patched images. This ensures zero-downtime updates and allows for testing and rollback capabilities.

4. **Cloud-native approach**: This method takes full advantage of the elastic nature of cloud computing mentioned in the question - treating VMs as disposable and replaceable rather than long-lived servers that need in-place patching.

The combination of automated image building and incremental deployment through MIGs provides the most secure, reliable, and scalable approach to Windows patch management on Compute Engine.

### Why Other Options Are Wrong

- **B:** While federating a Domain Controller and using Group Policy Objects (GPO) is a traditional enterprise approach that works, it doesn't leverage cloud-native capabilities and creates dependencies on domain infrastructure. It also requires VMs to be long-lived rather than ephemeral, which contradicts the "elastic nature of cloud computing" mentioned in the question.

- **C:** Deployment Manager can provision VMs, but simply provisioning new VMs into Instance Groups without the systematic image baking and CI/CD pipeline approach lacks automation, reproducibility, and proper version control. This is more of a one-off provisioning tool rather than a continuous patch management strategy.

- **D:** Using startup scripts to download patches at boot time is explicitly discouraged in Google's documentation. It increases boot time, creates external dependencies during bootstrap, lacks consistency (VMs might get different patch versions), and is unreliable if external update sources are unavailable. The documentation states that "baking your images" eliminates these problems.

### References

- [Image management best practices | Compute Engine](https://docs.cloud.google.com/compute/docs/images/image-management-best-practices)
- [Best practices for Windows Server VMs | Compute Engine](https://docs.cloud.google.com/compute/docs/instances/windows/windows-best-practices)
- [Performing one-click OS image upgrades in MIGs | Compute Engine](https://docs.cloud.google.com/compute/docs/instance-groups/upgrading-images-in-migs)
- [About VM Manager | Compute Engine](https://docs.cloud.google.com/compute/docs/vm-manager)
