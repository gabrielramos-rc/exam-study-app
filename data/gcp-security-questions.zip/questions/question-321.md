# Question 321

**Source:** https://www.examtopics.com/discussions/google/view/150195-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Security Command Center, security posture, Vertex AI, organization policy, Security Health Analytics, drift detection

---

## Question

Your organization strives to be a market leader in software innovation. You provided a large number of Google Cloud environments so developers can test the integration of Gemini in Vertex AI into their existing applications or create new projects. Your organization has 200 developers and a five-person security team. You must prevent and detect proper security policies across the Google Cloud environments. What should you do? (Choose two.)
## Choices

- **A.** Apply organization policy constraints. Detect and monitor drifts by using Security Health Analytics. Most Voted
- **B.** Publish internal policies and clear guidelines to securely develop applications.
- **C.** Use Cloud Logging to create log filters to detect misconfigurations. Trigger Cloud Run functions to remediate misconfigurations.
- **D.** Apply a predefined AI-recommended security posture template for Gemini in Vertex AI in Security Command Center Enterprise or Premium tiers. Most Voted
- **E.** Implement the least privileged access Identity and Access Management roles to prevent misconfigurations.

---

## Community

**Most Voted:** AD


**Votes:** AD: 89% | AE: 11% (9 total)


**Top Comments:**

- (4 upvotes) A &amp; D for sure.

- (2 upvotes) Specifically mentions gemini/vertex, so definitely D. https://cloud.google.com/security-command-center/docs/security-posture-essentials-secure-ai-template A &amp; E are both good, but the requirement 

- (2 upvotes) A. Apply organization policy constraints. Detect and monitor drifts by using Security Health Analytics. Organization Policies: Enforcing organization policies (e.g., constraints on resource locations,

---

## Answer

**Correct:** A, D

**Confidence:** high

### Explanation

For a small security team (5 people) managing 200 developers across multiple Google Cloud environments for Gemini in Vertex AI, the most effective approach combines automated policy enforcement with specialized AI security controls:

**Option A - Organization Policy Constraints + Security Health Analytics for Drift Detection** provides the foundational automated security posture management:
- **Organization policy constraints** are preventative controls that restrict resource behavior (e.g., blocking public IP exposure, enforcing encryption)
- **Security Health Analytics (SHA)** are detective controls that continuously scan for misconfigurations across all environments
- **Drift detection** automatically monitors for unauthorized changes from the defined security posture
- This combination scales efficiently - the small team defines policies once at the organization level, and the system automatically enforces and monitors across all 200 developers' environments
- Security Command Center reports drift instances as findings that can be filtered, reviewed, and resolved centrally

**Option D - Predefined AI Security Posture Template for Gemini/Vertex AI** provides specialized, ready-to-deploy AI workload protection:
- The "Secure AI, Essentials" template (v1.0.0) is specifically designed for Gemini and Vertex AI resources
- Contains **5 organization policy constraints** targeting Vertex AI Workbench security (file downloads, root access, terminal access, public IP, automatic upgrades)
- Includes **7 custom Security Health Analytics detectors** that verify encryption compliance across Vertex AI datasets, models, endpoints, training pipelines, custom jobs, and hyperparameter tuning jobs
- Available in **Security Command Center Enterprise or Premium tiers**
- Can be deployed **without modification**, providing immediate protection aligned with NIST SP 800-53 controls
- Eliminates the need for the small security team to manually design AI-specific security policies

Together, these options provide comprehensive, scalable, and automated security governance that leverages Security Command Center's posture management capabilities specifically tailored for AI workloads.

### Why Other Options Are Wrong

- **B (Publish internal policies and guidelines):** While documentation is helpful, it relies on manual compliance from 200 developers without automated enforcement or detection. A 5-person security team cannot effectively review all developer work manually. This approach doesn't scale and doesn't prevent or detect policy violations automatically.

- **C (Cloud Logging filters + Cloud Run remediation):** This requires the security team to manually create and maintain log filters for every possible misconfiguration, write custom remediation code, and manage Cloud Run functions. This is operationally complex, error-prone, and doesn't leverage the purpose-built security posture management capabilities of Security Command Center. Additionally, Cloud Logging is reactive (after-the-fact detection) rather than preventative.

- **E (Least privilege IAM roles):** While important for general security, IAM roles alone don't prevent resource misconfigurations (e.g., VMs with public IPs, unencrypted datasets) or detect drift from security policies. IAM controls who can do what, but doesn't enforce how resources are configured or monitor for compliance violations specific to AI workloads.

### References

- [Predefined posture for secure AI, essentials](https://docs.cloud.google.com/security-command-center/docs/security-posture-essentials-secure-ai-template)
- [Security posture overview](https://docs.cloud.google.com/security-command-center/docs/security-posture-overview)
- [Overview of Security Health Analytics](https://docs.cloud.google.com/security-command-center/docs/concepts-security-health-analytics)
- [Manage a security posture](https://docs.cloud.google.com/security-command-center/docs/how-to-use-security-posture)
