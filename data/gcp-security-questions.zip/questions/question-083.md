# Question 083

**Source:** https://www.examtopics.com/discussions/google/view/33309-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, cost optimization, sampling, BigQuery, Cloud Storage

---

## Question

As adoption of the Cloud Data Loss Prevention (Cloud DLP) API grows within your company, you need to optimize usage to reduce cost. Cloud DLP target data is stored in Cloud Storage and BigQuery. The location and region are identified as a suffix in the resource name. Which cost reduction options should you recommend?
## Choices

- **A.** Set appropriate rowsLimit value on BigQuery data hosted outside the US and set appropriate bytesLimitPerFile value on multiregional Cloud Storage buckets.
- **B.** Set appropriate rowsLimit value on BigQuery data hosted outside the US, and minimize transformation units on multiregional Cloud Storage buckets.
- **C.** Use rowsLimit and bytesLimitPerFile to sample data and use CloudStorageRegexFileSet to limit scans. Most Voted
- **D.** Use FindingLimits and TimespanContfig to sample data and minimize transformation units.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (9 total)


**Top Comments:**

- (5 upvotes) To optimize usage of the Cloud Data Loss Prevention (Cloud DLP) API and reduce cost, you should consider using sampling and CloudStorageRegexFileSet to limit scans 1. By sampling data, you can limit t

- (4 upvotes) C . Use rowsLimit and bytesLimitPerFile to sample data and use CloudStorageRegexFileSet to limit scans.

- (4 upvotes) https://cloud.google.com/dlp/docs/inspecting-storage#sampling

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C correctly identifies the three primary cost optimization techniques for Cloud DLP (Sensitive Data Protection):

1. **rowsLimit** - For BigQuery tables, this parameter limits the maximum number of rows to scan, allowing you to inspect a sample subset rather than entire tables. This directly reduces processing costs proportional to the rows excluded.

2. **bytesLimitPerFile** - For Cloud Storage files, this parameter caps the number of bytes scanned per file. This is particularly effective for large documents where sampling provides adequate coverage without inspecting every byte.

3. **CloudStorageRegexFileSet** - This enables fine-grained file filtering using regular expressions to selectively include or exclude specific files and folders. The documentation specifically recommends this to "skip scanning files that you know have no sensitive data, such as backups, TMP files, static Web content."

These three parameters work together as filters that narrow the inspection scope before processing begins, thereby reducing API calls and processing expenses. The sampling approach provides representative scan results without incurring costs of full dataset inspection. Critically, these techniques apply to **inspection jobs** for both BigQuery and Cloud Storage, regardless of region or location.

### Why Other Options Are Wrong

- **A:** While rowsLimit and bytesLimitPerFile are correct sampling parameters, limiting them only to "data hosted outside the US" or "multiregional buckets" is an arbitrary restriction. Cost optimization through sampling applies universally to all regions and storage configurations, not just specific geographic locations. The question mentions location/region in resource names, but this doesn't mean the cost optimization techniques are region-specific.

- **B:** "Transformation units" relate to de-identification operations (like redaction, pseudonymization, or format-preserving encryption), not inspection/scanning operations. The documentation explicitly states that de-identification operations don't support sampling parameters like bytesLimitPerFile. Additionally, restricting rowsLimit to non-US data is an incorrect geographic limitation.

- **D:** FindingLimits controls the maximum number of findings returned in results, not the amount of data scanned. It doesn't reduce scanning costs because Cloud DLP still processes all the data—it just limits the output. TimespanConfig filters data by modification time, which is useful but not as fundamental as the sampling parameters. "Transformation units" again refers to de-identification, not inspection cost optimization. This option misses the critical CloudStorageRegexFileSet for file-level filtering.

### References

- [Keeping costs under control - Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/best-practices-costs)
- [InspectJobConfig API Reference](https://docs.cloud.google.com/sensitive-data-protection/docs/reference/rest/v2/InspectJobConfig)
- [Inspect storage with sampling](https://cloud.google.com/sensitive-data-protection/docs/samples/dlp-inspect-gcs-with-sampling)
