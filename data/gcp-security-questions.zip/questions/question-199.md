# Question 199

**Source:** https://www.examtopics.com/discussions/google/view/117343-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Identity-Aware Proxy, IAP, Audit Logs, data access logs, intrusion detection

---

## Question

As part of your organization's zero trust strategy, you use Identity-Aware Proxy (IAP) to protect multiple applications. You need to ingest logs into a Security Information and Event Management (SIEM) system so that you are alerted to possible intrusions. Which logs should you analyze?
## Choices

- **A.** Data Access audit logs Most Voted
- **B.** Policy Denied audit logs
- **C.** Cloud Identity user log events
- **D.** Admin Activity audit logs

---

## Community

**Most Voted:** A


**Votes:** A: 67% | B: 33% (21 total)


**Top Comments:**

- (8 upvotes) I will choose A. Not B because we won't get the valuable information - it just reports what were denied. We are looking for what were not get denied so those can be formed as alerts.

- (2 upvotes) Policy Denied Audit Logs: These logs capture access attempts denied by Identity-Aware Proxy (IAP) policies. They indicate potential unauthorized or suspicious activity, such as users attempting to acc

- (2 upvotes) Answer is B

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

**Data Access audit logs** are the correct choice for detecting intrusions against IAP-protected applications. When you enable Cloud Audit Logs for IAP, Data Access logs capture both authorized and unauthorized access attempts to your IAP-secured resources (App Engine applications, Compute Engine backend services, and VM instances accessed via IAP TCP forwarding).

In the Cloud Console Logs Explorer, these logs appear when you select `data_access` from the logs type dropdown. They include critical security information for intrusion detection:

- **authenticationInfo.principalEmail**: Identifies who attempted to access the resource
- **requestMetadata.callerIp**: Shows the IP address of the request origin
- **authorizationInfo.granted**: A boolean indicating whether IAP permitted or denied the access attempt
- Visual indicators: Authorized access appears with a blue "i" icon, while **unauthorized access displays an orange "!!" icon**

This makes Data Access logs essential for SIEM ingestion and alerting on possible intrusions, as they provide visibility into both successful authentications and blocked unauthorized access attempts—exactly what's needed for zero trust security monitoring.

### Why Other Options Are Wrong

- **B. Policy Denied audit logs:** This is not a standard Cloud Audit Logs category. The primary audit log types are Admin Activity, Data Access, System Event, and Policy Denied (for organization policy violations, not IAP access denials). Policy Denied logs relate to organization policy constraint violations, not IAP access attempts.

- **C. Cloud Identity user log events:** These logs track user account lifecycle events (user creation, deletion, password changes, group membership) within Cloud Identity. While useful for identity management monitoring, they don't capture actual access attempts to IAP-protected applications and wouldn't show intrusion attempts.

- **D. Admin Activity audit logs:** These logs record administrative configuration changes (like IAM policy updates with SetIamPolicy or IAP settings modifications). While important for detecting unauthorized policy changes, they don't capture user access attempts to protected resources. Admin Activity logs show who changed IAP configurations, not who tried to access IAP-protected applications.

### References

- [Identity-Aware Proxy audit logging](https://docs.cloud.google.com/iap/docs/audit-log-howto)
- [Setting up context-aware access with Identity-Aware Proxy](https://docs.cloud.google.com/iap/docs/cloud-iap-context-aware-access-howto)
