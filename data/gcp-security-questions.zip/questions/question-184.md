# Question 184

**Source:** https://www.examtopics.com/discussions/google/view/117157-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, service perimeter, access level, BigQuery, data exfiltration, IP allowlist, PII protection

---

## Question

You have a highly sensitive BigQuery workload that contains personally identifiable information (PII) that you want to ensure is not accessible from the internet. To prevent data exfiltration, only requests from authorized IP addresses are allowed to query your BigQuery tables. What should you do?
## Choices

- **A.** Use service perimeter and create an access level based on the authorized source IP address as the condition. Most Voted
- **B.** Use Google Cloud Armor security policies defining an allowlist of authorized IP addresses at the global HTTPS load balancer.
- **C.** Use the Restrict Resource Service Usage organization policy constraint along with Cloud Data Loss Prevention (DLP).
- **D.** Use the Restrict allowed Google Cloud APIs and services organization policy constraint along with Cloud Data Loss Prevention (DLP).

---

## Community

**Most Voted:** A


**Votes:** A: 100% (9 total)


**Top Comments:**

- (4 upvotes) I think its A.

- (2 upvotes) Option A is correct

- (2 upvotes) A is the correct.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

VPC Service Controls with service perimeters and IP-based access levels is the correct solution for restricting BigQuery access to authorized IP addresses and preventing data exfiltration. Here's why:

**Service Perimeters** create security boundaries around Google Cloud services like BigQuery that restrict access independently of IAM controls. They prevent unauthorized data movement by limiting which external sources can communicate with protected resources. By default, access from the internet to resources within a service perimeter is denied.

**Access Levels** define the conditions under which requests can enter a perimeter. An IP-based access level specifies a range of IP addresses (CIDR blocks) from which access is allowed—for example, corporate network IP ranges. You create an access level using IP subnets and attach it to the service perimeter protecting your BigQuery projects.

This combination provides:
- **Data exfiltration prevention**: Service perimeters block unauthorized access to BigQuery from the internet by default
- **IP-based allowlisting**: Access levels permit only requests originating from specified IP addresses
- **Defense in depth**: Works independently of IAM, providing an additional security layer
- **Context-aware access**: Can be combined with ingress/egress rules for fine-grained control

The implementation involves:
1. Creating a VPC Service Controls access level with authorized IP CIDR ranges
2. Creating a service perimeter that protects BigQuery
3. Attaching the access level to the perimeter as a condition for entry

### Why Other Options Are Wrong

- **B:** Google Cloud Armor operates at the load balancer layer and is designed to protect applications behind HTTPS load balancers from DDoS and web attacks. BigQuery is a managed service accessed via APIs, not through load balancers, so Cloud Armor cannot control access to BigQuery. This solution is architecturally incompatible with BigQuery's access model.

- **C:** The "Restrict Resource Service Usage" organization policy constraint controls which services can be used within a project or organization but does not provide IP-based access control or prevent data exfiltration. Cloud DLP helps identify and protect sensitive data within BigQuery but doesn't restrict network-level access based on source IP addresses. These tools address different security concerns (service usage governance and data classification) rather than network-based access control.

- **D:** The "Restrict allowed Google Cloud APIs and services" constraint (similar to option C) controls which APIs can be enabled in a project but doesn't implement IP-based access restrictions. Cloud DLP, as mentioned, handles sensitive data detection and transformation but not network access control. This combination doesn't address the requirement to restrict access based on source IP addresses.

### References

- [VPC Service Controls for BigQuery](https://docs.cloud.google.com/bigquery/docs/vpc-sc)
- [Context-aware access with ingress rules](https://docs.cloud.google.com/vpc-service-controls/docs/context-aware-access)
- [Design access levels - VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/access-level-design)
- [Overview of VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/overview)
