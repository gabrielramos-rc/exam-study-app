# Question 112

**Source:** https://www.examtopics.com/discussions/google/view/74829-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Google Cloud Directory Sync, GCDS, Cloud Identity, user lifecycle, LDAP

---

## Question

Your company has been creating users manually in Cloud Identity to provide access to Google Cloud resources. Due to continued growth of the environment, you want to authorize the Google Cloud Directory Sync (GCDS) instance and integrate it with your on-premises LDAP server to onboard hundreds of users. You are required to: ✑ Replicate user and group lifecycle changes from the on-premises LDAP server in Cloud Identity. ✑ Disable any manually created users in Cloud Identity. You have already configured the LDAP search attributes to include the users and security groups in scope for Google Cloud. What should you do next to complete this solution?
## Choices

- **A.** 1. Configure the option to suspend domain users not found in LDAP. 2. Set up a recurring GCDS task. Most Voted
- **B.** 1. Configure the option to delete domain users not found in LDAP. 2. Run GCDS after user and group lifecycle changes.
- **C.** 1. Configure the LDAP search attributes to exclude manually created Cloud Identity users not found in LDAP. 2. Set up a recurring GCDS task.
- **D.** 1. Configure the LDAP search attributes to exclude manually created Cloud Identity users not found in LDAP. 2. Run GCDS after user and group lifecycle changes.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (20 total)


**Top Comments:**

- (15 upvotes) A is right

- (3 upvotes) I think the answer is (A). When using Shared VPC, a service perimeter that includes projects that belong to a Shared VPC network must also include the project that hosts the network. When projects tha

- (3 upvotes) Sorry, this answer is question 113.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is correct because it follows Google Cloud Directory Sync (GCDS) best practices for handling users and automating synchronization:

1. **Suspend (not delete) users not found in LDAP**: This is the recommended best practice according to Google's official documentation. When user accounts aren't found in your LDAP directory, you should set GCDS to suspend rather than delete the accounts. This is critical because:
   - Deleted accounts cannot be retrieved after 20 days
   - Data is retained for suspended accounts
   - You can transfer email and Google Drive content from a suspended account to another account
   - This directly fulfills the requirement to "disable any manually created users in Cloud Identity" (suspending effectively disables them)

2. **Set up a recurring GCDS task**: GCDS should run on a scheduled basis (typically hourly) to automatically replicate user and group lifecycle changes from the on-premises LDAP server to Cloud Identity. This automated synchronization ensures:
   - Continuous replication of lifecycle changes (new users, updates, deletions)
   - No manual intervention required after initial configuration
   - Timely updates to Cloud Identity as changes occur in LDAP

The combination of suspending users not found in LDAP and running GCDS on a recurring schedule provides the automated, safe approach to onboarding hundreds of users while properly handling manually created accounts.

### Why Other Options Are Wrong

- **B:** Deleting users not found in LDAP is not recommended. Google's best practices explicitly state you should suspend rather than delete accounts because deleted accounts cannot be retrieved after 20 days, and data recovery becomes impossible. Running GCDS only after changes (manual trigger) also defeats the purpose of automation and doesn't fulfill the requirement to "replicate lifecycle changes."

- **C:** Using LDAP search attributes to exclude manually created users would leave them active in Cloud Identity, which violates the requirement to "disable any manually created users." The search attributes should focus on what to include from LDAP, not what to exclude from Cloud Identity. The suspension policy is the proper mechanism for handling users not found in LDAP.

- **D:** This combines two incorrect approaches: excluding manually created users (which leaves them enabled) and manual GCDS execution (which doesn't provide automated lifecycle replication). This fails both requirements of the question.

### References

- [GCDS Best Practices - Google Workspace Admin Help](https://support.google.com/a/answer/7177267?hl=en)
- [Active Directory user account provisioning - Google Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-synchronizing-user-accounts)
- [Omit data with exclusion rules & queries - Google Workspace Admin Help](https://support.google.com/a/answer/6138405?hl=en)
