# Question 182

**Source:** https://www.examtopics.com/discussions/google/view/117084-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** patch management, OS patch, vulnerability scanning, VM Manager, compliance reporting

---

## Question

For compliance reporting purposes, the internal audit department needs you to provide the list of virtual machines (VMs) that have critical operating system (OS) security updates available, but not installed. You must provide this list every six months, and you want to perform this task quickly. What should you do?
## Choices

- **A.** Run a Security Command Center security scan on all VMs to extract a list of VMs with critical OS vulnerabilities every six months.
- **B.** Run a gcloud CLI command from the Command Line Interface (CLI) to extract the VM's OS version information every six months.
- **C.** Ensure that the Cloud Logging agent is installed on all VMs, and extract the OS last update log date every six months.
- **D.** Ensure the OS Config agent is installed on all VMs and extract the patch status dashboard every six months. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (7 total)


**Top Comments:**

- (2 upvotes) D is correct. https://cloud.google.com/compute/docs/vm-manager

- (2 upvotes) I think is D since you can't "run" Security Command Center "security" scan's without vm manager enabled. "If you enable VM Manager with the Security Command Center Premium tier, VM Manager writes its 

- (1 upvotes) D is correct

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

VM Manager (using the OS Config agent) is specifically designed for OS patch management and compliance reporting. The patch dashboard provides exactly what's needed:

**Patch Compliance Dashboard Features:**
- Categorizes VMs into four compliance levels: Critical, Important/Security, Other, and Up-to-date
- Shows VMs with critical updates available but not installed at a glance
- Organizes VMs by operating system for easy inventory management
- Provides centralized monitoring and reporting of patch compliance status
- Allows access to individual VM details showing complete update lists and associated CVEs

**Requirements:**
- OS Config agent must be installed on all VMs
- OS inventory management must be enabled
- VMs must have appropriate service account with Cloud OS Config Service Agent role

This solution is designed specifically for compliance reporting scenarios where you need to identify VMs with missing critical security updates. The dashboard provides a quick, visual way to extract patch status every six months without manual scripting or data parsing.

### Why Other Options Are Wrong

- **A:** Security Command Center focuses on vulnerability detection and security findings, not specifically on OS patch management. While it can identify vulnerabilities, it's not optimized for tracking which specific OS security updates are available but not installed. SCC is more about threat detection than patch compliance reporting.

- **B:** Using gcloud CLI to extract OS version information only tells you what version is installed, not what updates are available or missing. You would need to manually compare versions against available patches for each OS distribution, which is time-consuming and error-prone. This doesn't provide the "quick" solution requested.

- **C:** Cloud Logging agent tracks logs and the last update date, but it doesn't provide information about which updates are available but not yet installed. Knowing when a system was last updated doesn't tell you what critical patches are currently missing. This is logging, not patch management.

### References

- [About Patch | VM Manager | Google Cloud Documentation](https://docs.cloud.google.com/compute/vm-manager/docs/patch)
- [VM Manager | Google Cloud Documentation](https://docs.cloud.google.com/compute/vm-manager/docs/overview)
