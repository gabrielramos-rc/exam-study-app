# Question 344

**Source:** https://www.examtopics.com/discussions/google/view/311182-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, super admin, 2-step verification, SSO, third-party IdP

---

## Question

Your organization currently uses a third-party identity provider (IdP) that only requires a username and password for authentication. You need to enforce 2-step verification (2SV) for the Super admins in Cloud Identity. What should you do?
## Choices

- **A.** Create an organizational unit (OU) for Super admins, and enable 2SV within Cloud Identity for the OU. Most Voted
- **B.** Collaborate with the third-party IdP to enable 2SV for Super admins while maintaining the current Cloud Identity configuration.
- **C.** Implement monitoring tools to track the authentication methods used by Super admins in Cloud Identity. Alert on those not using 2SV.
- **D.** Evaluate the 2SV options for Super admins offered by both the third-party IdP and Cloud Identity. Implement the solution that provides the strongest second factor.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (1 total)

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Super admins can bypass SSO, which means any multi-factor authentication enforced by the external third-party IdP does not apply to these privileged users. This is by design to ensure administrators can access their accounts even if the SSO configuration is misconfigured or the external identity provider becomes unavailable.

To protect super admin accounts in this scenario, you must enforce 2-step verification (2SV) directly within Cloud Identity, independent of the third-party IdP. Creating an organizational unit (OU) for Super admins and enabling 2SV for that OU is the correct approach because:

1. **OU-based enforcement**: Organizational unit settings apply to all users in the OU and descendant OUs, and override global settings. This provides targeted control specifically for super admin accounts.

2. **Independent from IdP**: Cloud Identity can enforce 2SV separately from the third-party IdP's authentication mechanisms, ensuring super admins are protected even when they bypass SSO.

3. **Best practice alignment**: Google documentation explicitly recommends enforcing 2-step verification with security keys for super admin accounts within Cloud Identity to protect these privileged accounts.

4. **Immediate implementation**: This solution can be implemented immediately without requiring changes to the third-party IdP or waiting for vendor coordination.

### Why Other Options Are Wrong

- **B:** Collaborating with the third-party IdP to enable 2SV will not protect super admins because they can bypass SSO. Any MFA enforced by the external IdP does not apply to users with super-admin privileges who use the SSO bypass capability.

- **C:** Monitoring and alerting is a detective control, not a preventive control. It does not enforce 2SV; it only notifies you when it's not being used. This leaves super admin accounts vulnerable during the time between detection and remediation.

- **D:** Evaluation is unnecessary because the third-party IdP's 2SV options cannot protect super admins due to the SSO bypass capability. The only effective solution is to enforce 2SV within Cloud Identity itself, making this option overly complex without addressing the core issue.

### References

- [Single sign-on - Google Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/single-sign-on)
- [Super administrator account best practices](https://docs.cloud.google.com/resource-manager/docs/super-admin-best-practices)
- [Multi-factor authentication requirement for Google Cloud](https://docs.cloud.google.com/docs/authentication/mfa-requirement)
- [Prepare your Google Workspace or Cloud Identity account](https://docs.cloud.google.com/architecture/identity/preparing-your-g-suite-or-cloud-identity-account)
