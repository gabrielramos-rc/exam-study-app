# Question 316

**Source:** https://www.examtopics.com/discussions/google/view/150188-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC network, private IP, network isolation, database security

---

## Question

You want to set up a secure, internal network within Google Cloud for database servers. The servers must not have any direct communication with the public internet. What should you do?
## Choices

- **A.** Assign a private IP address to each database server. Use a NAT gateway to provide internet connectivity to the database servers.
- **B.** Assign a static public IP address to each database server. Use firewall rules to restrict external access.
- **C.** Create a VPC with a private subnet. Assign a private IP address to each database server. Most Voted
- **D.** Assign both a private IP address and a public IP address to each database server.

---

## Community

**Most Voted:** C


**Votes:** A: 38% | C: 62% (13 total)


**Top Comments:**

- (4 upvotes) This is the way.

- (4 upvotes) ABSOLUTELY RIGHT MY FRIEND

- (3 upvotes) A seems better to me, as the question says "db servers must not have DIRECT access to the internet".

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C correctly implements the security requirement for database servers with no public internet access. According to Google Cloud documentation, internal IP addresses "cannot be reached from the internet and are not publicly routable" and are "local to a VPC network." By creating a VPC network and assigning only private (internal) IP addresses to database servers, you ensure complete isolation from the public internet.

In Google Cloud, all subnets use internal IP address ranges (RFC 1918 or private IPv6 ranges), so creating a VPC with subnets and assigning private IP addresses inherently prevents direct internet communication. The servers can still communicate with other resources within the VPC network, VPC peered networks, or on-premises networks connected via Cloud VPN or Cloud Interconnect, but they remain unreachable from the internet.

This configuration is the recommended approach for database servers that should maintain internal connectivity while being completely isolated from public internet threats.

### Why Other Options Are Wrong

- **A:** Using a NAT gateway explicitly provides internet connectivity to the database servers, which directly violates the requirement that "servers must not have any direct communication with the public internet." Cloud NAT enables outbound internet access for instances with only internal IP addresses.

- **B:** Assigning static public IP addresses makes the servers directly reachable from the internet. While firewall rules can restrict access, this creates an unnecessary attack surface and violates the core security principle. The requirement states no direct communication with the internet - having a public IP means the server is internet-addressable, which is fundamentally incompatible with this requirement.

- **D:** Assigning both private and public IP addresses provides internet connectivity through the public IP, again violating the "no direct communication with the public internet" requirement. Having a public IP address inherently creates internet accessibility, regardless of whether a private IP is also assigned.

### References

- [Learn about using private IP - Cloud SQL](https://docs.cloud.google.com/sql/docs/mysql/private-ip)
- [IP addresses - Virtual Private Cloud](https://docs.cloud.google.com/vpc/docs/ip-addresses)
- [Subnets - Virtual Private Cloud](https://docs.cloud.google.com/vpc/docs/subnets)
