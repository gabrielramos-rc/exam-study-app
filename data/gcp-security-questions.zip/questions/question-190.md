# Question 190

**Source:** https://www.examtopics.com/discussions/google/view/117226-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Managing authentication
**Tags:** SAML, SSO, single sign-on, Active Directory, identity provider

---

## Question

Your organization is using Active Directory and wants to configure Security Assertion Markup Language (SAML). You must set up and enforce single sign-on (SSO) for all users. What should you do?
## Choices

- **A.** 1. Create a new SAML profile. 2. Populate the sign-in and sign-out page URLs. 3. Upload the X.509 certificate. 4. Configure Entity ID and ACS URL in your IdP. Most Voted
- **B.** 1. Configure prerequisites for OpenID Connect (OIDC) in your Active Directory (AD) tenant. 2. Verify the AD domain. 3. Decide which users should use SAML. 4. Assign the pre-configured profile to the select organizational units (OUs) and groups.
- **C.** 1. Create a new SAML profile. 2. Upload the X.509 certificate. 3. Enable the change password URL. 4. Configure Entity ID and ACS URL in your IdP.
- **D.** 1. Manage SAML profile assignments. 2. Enable OpenID Connect (OIDC) in your Active Directory (AD) tenant. 3. Verify the domain.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (6 total)


**Top Comments:**

- (2 upvotes) Option A follows right steps

- (2 upvotes) A you need to enter sign-in/sign-out page URL https://support.google.com/cloudidentity/answer/12032922?hl=en (Configure the SSO profile for your org)

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A provides the correct and complete sequence for setting up SAML SSO with Active Directory:

1. **Create a new SAML profile** in Google Admin Console - This is the first step where you configure SSO settings for your organization
2. **Populate the sign-in and sign-out page URLs** - These are the URLs from your Active Directory Federation Services (AD FS) where users will authenticate and sign out
3. **Upload the X.509 certificate** - SAML assertions must be digitally signed, and you need to upload your IdP's public signing certificate to Google Cloud Identity/Workspace to verify the authenticity of SAML assertions
4. **Configure Entity ID and ACS URL in your IdP** - The Identity Provider (AD FS) needs to know:
   - **Entity ID**: The SAML identifier for Google (typically `google.com` or `google.com/a/DOMAIN`)
   - **ACS URL** (Assertion Consumer Service URL): The endpoint where the IdP posts SAML responses (e.g., `https://accounts.google.com/samlrp/acs?rpid=ID`)

This sequence follows the proper SAML 2.0 configuration flow where you first set up the service provider (Google) side, then configure the identity provider (AD FS) with the necessary endpoints and identifiers.

### Why Other Options Are Wrong

- **B:** Incorrectly mentions OIDC (OpenID Connect) prerequisites when the question specifically asks for SAML configuration. OIDC and SAML are different authentication protocols. Also, while verifying domain and assigning profiles are valid steps, mixing OIDC with SAML shows confusion between protocols.

- **C:** While it correctly includes creating a SAML profile, uploading the X.509 certificate, and configuring Entity ID/ACS URL, the "Enable the change password URL" step is not a required or standard step in the core SAML SSO setup process. This is an optional feature, not part of the essential configuration sequence.

- **D:** Incorrectly mentions OIDC when configuring SAML. Managing SAML profile assignments comes after the initial SAML setup is complete, not as the first step. This option confuses the protocol (OIDC vs SAML) and puts steps in the wrong order.

### References

- [Google Cloud Single Sign-On Architecture](https://docs.cloud.google.com/architecture/identity/single-sign-on)
- [SAML SSO Configuration Requirements for Google Cloud](https://docs.cloud.google.com/architecture/identity/single-sign-on)
