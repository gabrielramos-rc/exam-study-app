# Question 137

**Source:** https://www.examtopics.com/discussions/google/view/81553-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, Resource Location Restriction, data residency, folder structure, project

---

## Question

Your company's chief information security officer (CISO) is requiring business data to be stored in specific locations due to regulatory requirements that affect the company's global expansion plans. After working on a plan to implement this requirement, you determine the following: ✑ The services in scope are included in the Google Cloud data residency requirements. ✑ The business data remains within specific locations under the same organization. ✑ The folder structure can contain multiple data residency locations. ✑ The projects are aligned to specific locations. You plan to use the Resource Location Restriction organization policy constraint with very granular control. At which level in the hierarchy should you set the constraint?
## Choices

- **A.** Organization
- **B.** Resource
- **C.** Project Most Voted
- **D.** Folder

---

## Community

**Most Voted:** C


**Votes:** C: 84% | D: 16% (19 total)


**Top Comments:**

- (6 upvotes) C- granular

- (5 upvotes) D Why not C?: Project-level constraints might not offer sufficient granularity. You might have multiple projects within a region that require further segregation based on specific data residency deman

- (4 upvotes) D should be right , This is same as question 133

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

The Resource Location Restriction organization policy constraint should be set at the **Project level** based on the specific requirements outlined:

1. **Projects are aligned to specific locations**: This is the key requirement. Each project has its own specific location requirement that needs to be enforced independently.

2. **Folders contain multiple data residency locations**: Since folders span multiple data residency locations, setting the constraint at the folder level would not provide the granular control needed. A single folder-level policy cannot enforce different location requirements for different projects within that folder.

3. **Very granular control is required**: Project-level is the most granular level for Resource Location Restriction policies (option B "Resource" is not a valid hierarchy level for organization policies). The project level allows you to define specific allowed or denied locations for each project independently.

4. **Organization Policy inheritance**: Google Cloud's organization policy service allows policies to be set at organization, folder, or project levels. Projects can either inherit from parent folders/organization or override with their own specific constraints using `inheritFromParent` combined with additional restrictions.

Setting the constraint at the **Organization level** (A) would apply the same location restrictions globally, which contradicts the need for different locations per project. Setting it at the **Folder level** (D) would still be too broad since folders contain multiple data residency locations. **Resource level** (B) is not a valid hierarchy node for organization policies - policies are applied at org, folder, or project levels only.

### Why Other Options Are Wrong

- **A (Organization):** Setting the constraint at the organization level would enforce a single location policy across all projects in the organization. This does not support the requirement for "very granular control" or the fact that different projects need different location restrictions.

- **B (Resource):** "Resource" is not a valid level in the Google Cloud resource hierarchy for setting organization policies. Organization policies can only be set at organization, folder, or project levels. Individual resources inherit the policies from their parent project.

- **D (Folder):** While folders are part of the hierarchy, the requirement explicitly states that "The folder structure can contain multiple data residency locations." This means a single folder contains projects with different location requirements. Setting the constraint at the folder level would not provide the granular per-project control needed.

### References

- [Restricting Resource Locations - Google Cloud Documentation](https://docs.cloud.google.com/resource-manager/docs/organization-policy/defining-locations)
- [Introduction to Organization Policy Service - Google Cloud](https://cloud.google.com/resource-manager/docs/organization-policy/overview)
