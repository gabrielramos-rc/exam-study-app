# Question 269

**Source:** https://www.examtopics.com/discussions/google/view/147063-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Security Command Center, threat detection, Cloud NGFW, Threat Intelligence, egress firewall

---

## Question

Your organization is using Security Command Center Premium as a central tool to detect and alert on security threats. You also want to alert on suspicious outbound traffic that is targeting domains of known suspicious web services. What should you do?
## Choices

- **A.** Create a DNS Server Policy in Cloud DNS and turn on logs. Attach this policy to all Virtual Private Cloud networks with internet connectivity.
- **B.** Forward all logs to Chronicle Security Information and Event Management. Create an alert for suspicious egress traffic to the internet.
- **C.** Create a Cloud Intrusion Detection endpoint. Connect this endpoint to all Virtual Private Cloud networks with internet connectivity.
- **D.** Create an egress firewall policy with Threat Intelligence as the destination. Attach this policy to all Virtual Private Cloud networks with internet connectivity. Most Voted

---

## Community

**Most Voted:** D


**Votes:** B: 40% | D: 60% (10 total)


**Top Comments:**

- (3 upvotes) The question stats "Security Command Premium" so no SecOps :)

- (3 upvotes) I´m thinking D

- (2 upvotes) I think it's B.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The correct solution is to create an egress firewall policy with Google Threat Intelligence as the destination. Cloud Next Generation Firewall (Cloud NGFW) supports integrating Google Threat Intelligence lists directly into firewall policy rules to block traffic to known malicious IP addresses and domains.

For egress rules specifically, you specify destination Google Threat Intelligence lists using the `--dest-threat-intelligence` flag. The available threat intelligence lists include:
- `iplist-known-malicious-ips` - IP addresses known to be origins of web application attacks
- `iplist-tor-exit-nodes` - Tor exit node addresses
- Other curated threat feeds

This approach provides **proactive prevention** by blocking outbound traffic to suspicious destinations at the network layer before it leaves your VPC. The firewall policies can be attached to all VPCs with internet connectivity, providing comprehensive protection across your organization.

Security Command Center Premium integrates with Cloud NGFW and can alert on firewall policy violations and blocked suspicious traffic, maintaining your centralized threat detection workflow.

### Why Other Options Are Wrong

- **A:** DNS Server Policies with logging only capture DNS query logs and don't automatically block traffic to suspicious domains. DNS Armor (advanced threat detection) can detect DNS-based threats, but this requires specific DNS threat detector configuration, not just a basic DNS Server Policy with logs. Additionally, this is a detection-only approach, not prevention.

- **B:** Chronicle SIEM is an excellent tool for log analysis and alerting, but it provides detection and analysis only - it cannot prevent or block suspicious traffic. It's a reactive solution (alerting after the fact) rather than a proactive prevention mechanism. The question asks to "alert on suspicious outbound traffic," but the most effective solution is to prevent it entirely while also generating alerts.

- **C:** Cloud IDS (Intrusion Detection System) detects and alerts on threats but does not prevent them. The documentation explicitly states: "Cloud IDS detects and alerts on threats, but it does not take action to prevent attacks or repair damage." While Cloud IDS can detect suspicious outbound traffic to command-and-control servers, it's a detection-only solution. To take action on threats, you need enforcement mechanisms like Cloud NGFW.

### References

- [Firewall policy rules with Threat Intelligence](https://docs.cloud.google.com/firewall/docs/firewall-policies-rule-details)
- [Cloud IDS Overview](https://docs.cloud.google.com/intrusion-detection-system/docs/overview)
- [Use global network firewall policies and rules](https://docs.cloud.google.com/firewall/docs/use-network-firewall-policies)
- [Advanced threat detection with DNS Armor](https://docs.cloud.google.com/dns/docs/threat-detection)
