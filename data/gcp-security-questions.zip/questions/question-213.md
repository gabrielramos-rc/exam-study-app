# Question 213

**Source:** https://www.examtopics.com/discussions/google/view/117317-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** Workload Identity Federation, service account, GitHub Actions, CI/CD, OIDC

---

## Question

Your organization is using GitHub Actions as a continuous integration and delivery (CI/CD) platform. You must enable access to Google Cloud resources from the CI/CD pipelines in the most secure way. What should you do?
## Choices

- **A.** Create a service account key, and add it to the GitHub pipeline configuration file.
- **B.** Create a service account key, and add it to the GitHub repository content.
- **C.** Configure a Google Kubernetes Engine cluster that uses Workload Identity to supply credentials to GitHub.
- **D.** Configure workload identity federation to use GitHub as an identity pool provider. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (8 total)


**Top Comments:**

- (2 upvotes) D is correct. https://cloud.google.com/blog/products/identity-security/enabling-keyless-authentication-from-github-actions

- (2 upvotes) D is the correct.

- (1 upvotes) The most secure way to enable access to Google Cloud resources from CI/CD pipelines using GitHub Actions is: D. Configure workload identity federation to use GitHub as an identity pool provider. Workl

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Workload Identity Federation is specifically designed for this use case and represents the most secure authentication method for GitHub Actions workflows accessing Google Cloud resources. This solution eliminates the need for long-lived service account keys entirely.

GitHub Actions workflows can obtain OIDC tokens that uniquely identify the workflow and repository. By configuring a workload identity pool to trust GitHub's OIDC provider, workflows can exchange these GitHub-issued OIDC tokens for short-lived Google Cloud credentials automatically during pipeline execution.

The security advantages are significant:
- **No credential storage**: No service account keys stored in repositories or configuration files
- **Short-lived credentials**: Tokens are automatically scoped and expire quickly
- **Automatic rotation**: Credentials are generated fresh for each workflow run
- **Granular access control**: Can use attribute conditions to restrict access to specific repositories, branches, or workflows using claims like `repository_id`, `repository_owner`, and `ref`
- **Protection against attacks**: Using numeric ID fields (like `repository_id`) instead of names protects against cybersquatting and typosquatting attacks

The implementation uses the `google-github-actions/auth` action in your workflow with parameters specifying the workload identity pool, provider, and target service account for impersonation.

### Why Other Options Are Wrong

- **A:** Storing service account keys in pipeline configuration files exposes long-lived credentials that create significant security risks. Keys can be accidentally committed, logged, or exposed. This violates the principle of eliminating service account keys when better alternatives exist.

- **B:** Adding service account keys to repository content is even worse than option A. This stores sensitive credentials in version control where they can be discovered through repository history, forks, or if the repository becomes public. This is a critical security anti-pattern.

- **C:** This confuses GKE Workload Identity (for pods running in Kubernetes to access Google Cloud) with Workload Identity Federation (for external workloads like GitHub Actions). GKE Workload Identity is designed for workloads running inside GKE clusters, not for external CI/CD systems. Setting up an entire GKE cluster just to supply credentials to GitHub Actions is unnecessary, overly complex, and doesn't address the actual use case.

### References

- [Configure Workload Identity Federation with deployment pipelines](https://docs.cloud.google.com/iam/docs/workload-identity-federation-with-deployment-pipelines)
- [Workload Identity Federation overview](https://docs.cloud.google.com/iam/docs/workload-identity-federation)
- [Best practices for using Workload Identity Federation](https://docs.cloud.google.com/iam/docs/best-practices-for-using-workload-identity-federation)
