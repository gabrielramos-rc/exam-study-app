# Question 177

**Source:** https://www.examtopics.com/discussions/google/view/80406-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Packet Mirroring, network anomalies, payload capture, VPC Flow Logs, intrusion detection

---

## Question

Your company requires the security and network engineering teams to identify all network anomalies and be able to capture payloads within VPCs. Which method should you use?
## Choices

- **A.** Define an organization policy constraint.
- **B.** Configure packet mirroring policies. Most Voted
- **C.** Enable VPC Flow Logs on the subnet.
- **D.** Monitor and analyze Cloud Audit Logs.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (13 total)


**Top Comments:**

- (7 upvotes) B is right .

- (3 upvotes) Should be Cloud IDS ;)

- (3 upvotes) https://cloud.google.com/vpc/docs/packet-mirroring

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Packet Mirroring is the correct solution for this requirement because it captures all packet data, including payloads and headers. According to Google Cloud documentation, "Packet Mirroring captures all traffic and packet data, including payloads and headers," making it ideal for comprehensive network anomaly detection and forensic analysis.

The key capabilities that make Packet Mirroring the right choice are:

1. **Complete Payload Capture**: Unlike other logging methods, Packet Mirroring captures the actual packet payloads, not just metadata or connection information
2. **Full Packet Analysis**: Security teams can perform deep packet inspection (DPI) to detect protocol anomalies and intrusion attempts
3. **IDS Integration**: The mirrored traffic can be sent to intrusion detection systems (IDS) and network detection and response (NDR) tools that require multiple packets to match signatures and identify threats
4. **Network Forensics**: Captures all packets needed for forensic analysis required by compliance standards like PCI DSS

Packet Mirroring copies traffic from mirrored sources (VMs, subnets, or instances) to a collector destination where security tools can analyze the traffic in real-time or store it for later investigation.

### Why Other Options Are Wrong

- **A:** Organization policy constraints define governance rules and restrictions (like disabling service accounts or restricting resource types), but they don't capture network traffic or payloads. They're used for enforcing security policies, not network monitoring.

- **C:** VPC Flow Logs capture metadata about network flows (source/destination IPs, ports, protocols, byte counts) but do NOT capture packet payloads. The documentation explicitly states that "VPC Flow Logs doesn't log mirrored packets" and uses sampling rather than capturing every packet. Flow Logs are useful for network traffic analysis and troubleshooting but cannot identify payloads or perform deep packet inspection.

- **D:** Cloud Audit Logs record administrative activities and data access events on Google Cloud resources (who did what, when, and where). They do not capture network traffic or packet payloads. Audit logs are for tracking API calls and resource changes, not network anomaly detection.

### References

- [Packet Mirroring | Virtual Private Cloud](https://docs.cloud.google.com/vpc/docs/packet-mirroring)
- [VPC Flow Logs | Virtual Private Cloud](https://docs.cloud.google.com/vpc/docs/flow-logs)
