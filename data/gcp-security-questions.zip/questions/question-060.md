# Question 060

**Source:** https://www.examtopics.com/discussions/google/view/30381-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, redaction, de-identification, BigQuery, credit card, PII

---

## Question

A company is running their webshop on Google Kubernetes Engine and wants to analyze customer transactions in BigQuery. You need to ensure that no credit card numbers are stored in BigQuery What should you do?
## Choices

- **A.** Create a BigQuery view with regular expressions matching credit card numbers to query and delete affected rows.
- **B.** Use the Cloud Data Loss Prevention API to redact related infoTypes before data is ingested into BigQuery. Most Voted
- **C.** Leverage Security Command Center to scan for the assets of type Credit Card Number in BigQuery.
- **D.** Enable Cloud Identity-Aware Proxy to filter out credit card numbers before storing the logs in BigQuery.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (16 total)


**Top Comments:**

- (12 upvotes) https://cloud.google.com/bigquery/docs/scan-with-dlp

- (4 upvotes) sdfdfwerrwerweewrwr

- (3 upvotes) How can it be D? i'll go for B, DLP is the tool to scan and find sensible data

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud Data Loss Prevention API (now part of Sensitive Data Protection) is specifically designed to identify, classify, and protect sensitive data like credit card numbers. The key to this question is the proactive approach - preventing credit card numbers from being stored in BigQuery in the first place by redacting them **before data ingestion**.

The DLP API provides:
- **Built-in infoType detectors** for credit card numbers (CREDIT_CARD_NUMBER) that use pattern matching, checksums, and validation algorithms
- **Multiple de-identification methods** including redaction, masking, replacement, and format-preserving encryption
- **Pre-ingestion transformation** capability through the `content.deidentify` API method that can be integrated into data pipelines before data reaches BigQuery

The proper implementation involves:
1. Configuring detection for the CREDIT_CARD_NUMBER infoType
2. Defining transformation rules (e.g., replace with asterisks or placeholder text)
3. Processing transaction data through the DLP API before loading into BigQuery
4. Only ingesting the de-identified data into BigQuery

This approach ensures that sensitive credit card data never exists in its original form within BigQuery, providing true data protection rather than reactive detection and deletion.

### Why Other Options Are Wrong

- **A:** Creating a BigQuery view to query and delete credit card numbers is reactive, not preventive. The sensitive data would still be stored in BigQuery first, creating a compliance and security risk. Additionally, regex patterns alone may not accurately identify all credit card formats and could miss variations or produce false positives.

- **C:** Security Command Center (SCC) is a security posture management and threat detection service. While it can scan for vulnerabilities and security findings, it's not designed to prevent data from being ingested into BigQuery or to redact sensitive data from data streams. SCC is for monitoring and detection, not data transformation.

- **D:** Cloud Identity-Aware Proxy (IAP) is an access control service that verifies user identity and context before granting access to applications. It's not designed for data inspection, content filtering, or redaction of sensitive data within logs or data streams. IAP controls who can access resources, not what data is stored in them.

### References

- [Sensitive Data Protection overview](https://docs.cloud.google.com/sensitive-data-protection/docs/sensitive-data-protection-overview)
- [De-identifying sensitive data](https://docs.cloud.google.com/sensitive-data-protection/docs/deidentify-sensitive-data)
- [Using Sensitive Data Protection to scan BigQuery data](https://docs.cloud.google.com/bigquery/docs/scan-with-dlp)
- [Classification, redaction, and de-identification](https://docs.cloud.google.com/sensitive-data-protection/docs/classification-redaction)
