# Question 091

**Source:** https://www.examtopics.com/discussions/google/view/31621-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, Google Cloud Directory Sync, GCDS, user management, Transfer Tool for Unmanaged Users

---

## Question

You need to provide a corporate user account in Google Cloud for each of your developers and operational staff who need direct access to GCP resources. Corporate policy requires you to maintain the user identity in a third-party identity management provider and leverage single sign-on. You learn that a significant number of users are using their corporate domain email addresses for personal Google accounts, and you need to follow Google recommended practices to convert existing unmanaged users to managed accounts. Which two actions should you take? (Choose two.)
## Choices

- **A.** Use Google Cloud Directory Sync to synchronize your local identity management system to Cloud Identity. Most Voted
- **B.** Use the Google Admin console to view which managed users are using a personal account for their recovery email.
- **C.** Add users to your managed Google account and force users to change the email addresses associated with their personal accounts.
- **D.** Use the Transfer Tool for Unmanaged Users (TTUU) to find users with conflicting accounts and ask them to transfer their personal Google accounts. Most Voted
- **E.** Send an email to all of your employees and ask those users with corporate email addresses for personal Google accounts to delete the personal accounts immediately.

---

## Community

**Most Voted:** AD


**Votes:** AD: 100% (10 total)


**Top Comments:**

- (17 upvotes) Is the answer is A,D A - Requirement is third-party identity management provider and leverage single sign-on. D - https://cloud.google.com/architecture/identity/assessing-existing-user-accounts (Use t

- (8 upvotes) C, D are correct - https://cloud.google.com/architecture/identity/assessing-existing-user-accounts

- (4 upvotes) see other comments

---

## Answer

**Correct:** A, D

**Confidence:** high

### Explanation

This question addresses two distinct requirements:

1. **Synchronizing corporate identities with Cloud Identity** - This is achieved using **Google Cloud Directory Sync (GCDS)**, which performs one-way synchronization from your on-premises Active Directory or LDAP server to Cloud Identity. GCDS synchronizes users, groups, aliases, and other directory data to ensure your Google Cloud directory matches your corporate identity management system. This enables single sign-on (SSO) and maintains the third-party identity provider as the source of truth.

2. **Converting unmanaged consumer accounts to managed accounts** - The **Transfer Tool for Unmanaged Users (TTUU)**, accessible via the Admin Console at admin.google.com/ac/unmanaged, is Google's recommended practice for this scenario. When you verify a domain, the tool automatically identifies consumer (unmanaged) accounts using email addresses that match your verified domains. The tool allows you to:
   - Export the list of affected users as a CSV file
   - Send transfer requests to users asking them to consent to converting their consumer accounts to managed accounts
   - Track user responses and resend requests if necessary

The transfer process requires user consent and preserves their existing data while bringing the account under organizational control. This approach follows Google's best practices, which emphasize early communication with users, batch transfers starting small (around 10 users), and allowing adequate response time.

### Why Other Options Are Wrong

- **B.** Viewing which managed users are using a personal account for their recovery email is unrelated to converting unmanaged accounts to managed ones. This addresses recovery email settings for already-managed users, not the conversion of consumer accounts.

- **C.** Forcing users to add accounts and change email addresses creates "conflicting accounts" - a situation where two accounts (one consumer, one managed) share the same identity. This is explicitly what Google recommends avoiding. Forcing account creation before user consent violates best practices and creates authentication confusion.

- **E.** Asking users to delete their personal Google accounts is not a Google recommended practice and would result in data loss for users. The Transfer Tool exists specifically to preserve user data while migrating accounts. Deletion is unnecessarily destructive and doesn't follow the recommended migration path.

### References

- [Migrate consumer accounts - Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/migrating-consumer-accounts)
- [Active Directory user account provisioning - Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-synchronizing-user-accounts)
- [About Google Cloud Directory Sync - Cloud Identity Help](https://support.google.com/cloudidentity/answer/106368)
