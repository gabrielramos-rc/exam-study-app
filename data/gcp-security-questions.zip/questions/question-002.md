# Question 002

**Source:** https://www.examtopics.com/discussions/google/view/15918-exam-professional-cloud-security-engineer-topic-1-question-2/
**Section:** 2.1 - Designing and implementing security controls for network segmentation
**Tags:** VPC, firewall rules, implied rules, network security

---

## Question

Which two implied firewall rules are defined on a VPC network? (Choose two.)

## Choices

- **A.** A rule that allows all outbound connections Most Voted
- **B.** A rule that denies all inbound connections Most Voted
- **C.** A rule that blocks all inbound port 25 connections
- **D.** A rule that blocks all outbound connections
- **E.** A rule that allows all inbound port 80 connections

---

## Community

**Most Voted:** AB


**Votes:** AB: 100% (6 total)


**Top Comments:**

- (14 upvotes) AB AB AB

- (3 upvotes) A and B

- (2 upvotes) A and B

---

## Answer

**Correct:** A, B

**Confidence:** high

### Explanation

Every VPC network in Google Cloud has exactly two implied firewall rules that cannot be deleted:

1. **Implied allow egress rule (Option A)**: This rule allows all outbound connections from instances to any destination (0.0.0.0/0). It has the lowest priority (65535) and permits all egress traffic unless explicitly blocked by a higher-priority rule.

2. **Implied deny ingress rule (Option B)**: This rule denies all inbound connections to instances from any source. Like the egress rule, it has the lowest priority (65535) and blocks all ingress traffic unless explicitly allowed by a higher-priority rule.

These implied rules create a "deny-by-default" security posture for incoming traffic while allowing unrestricted outbound connectivity. To allow specific inbound traffic, you must create explicit firewall rules with higher priority.

### Why Other Options Are Wrong

- **C:** There is no implied rule that specifically blocks port 25 (SMTP). While blocking port 25 is a common practice to prevent spam, this is not an implied rule - it would need to be configured explicitly if desired.

- **D:** This contradicts the actual implied egress rule. The implied rule **allows** all outbound connections, not blocks them. Blocking all outbound traffic would require an explicit deny rule.

- **E:** There is no implied rule that allows inbound port 80 (HTTP) connections. All inbound traffic is denied by default via the implied deny ingress rule. To allow HTTP traffic, you must create an explicit allow rule.

### References

- [VPC firewall rules](https://docs.cloud.google.com/firewall/docs/firewalls)
- [Use VPC firewall rules](https://docs.cloud.google.com/firewall/docs/using-firewalls)
