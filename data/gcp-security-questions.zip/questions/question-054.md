# Question 054

**Source:** https://www.examtopics.com/discussions/google/view/30234-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** firewall rules, network tags, network isolation, VPC segmentation

---

## Question

Your team needs to make sure that their backend database can only be accessed by the frontend application and no other instances on the network. How should your team design this network?
## Choices

- **A.** Create an ingress firewall rule to allow access only from the application to the database using firewall tags. Most Voted
- **B.** Create a different subnet for the frontend application and database to ensure network isolation.
- **C.** Create two VPC networks, and connect the two networks using Cloud VPN gateways to ensure network isolation.
- **D.** Create two VPC networks, and connect the two networks using VPC peering to ensure network isolation.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (1 total)


**Top Comments:**

- (7 upvotes) You may be right but B doesn't mention anything about firewall rules, thus we need to assume there will be communication between both subnets

- (7 upvotes) A is correct

- (6 upvotes) A is correct , rest of the answers doesn't make any sence

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Using firewall rules with network tags is the recommended and most efficient approach for controlling access between instances within the same VPC network. Here's why this is the correct solution:

**Network Tags for Access Control:** You can apply network tags to both the frontend application instances (e.g., tag: "frontend") and database instances (e.g., tag: "database"). Then create an ingress firewall rule on the database instances that:
- **Target tag:** "database" (applies rule to database instances)
- **Source tag:** "frontend" (allows traffic only from instances with this tag)
- **Action:** Allow
- **Protocol/Port:** Specify the database port (e.g., TCP:3306 for MySQL)

This creates precise microsegmentation where the database can only be accessed by frontend instances, while all other instances on the network are blocked by default (deny all implicit rule).

**Three-Tier Architecture Pattern:** Google Cloud documentation explicitly describes this pattern for multi-tier applications: "Consider a three-tier (web, app, database) application for which all of the instances are deployed in the same subnet... the instances running the database tier have a network tag of db." Firewall rules with source and target tags enable secure communication between specific tiers while blocking unauthorized access.

**Simplicity and Flexibility:** This approach keeps instances in the same VPC network, avoiding unnecessary complexity while providing the exact security boundary needed. Tags can be easily modified, and firewall rules are evaluated efficiently without requiring VPN tunnels or separate networks.

### Why Other Options Are Wrong

- **B:** Creating different subnets alone does NOT provide network isolation in GCP. All subnets within a VPC can communicate by default. You would still need firewall rules to restrict access, making the separate subnet unnecessary. Subnets are routing boundaries, not security boundaries in GCP.

- **C:** Using Cloud VPN gateways to connect two VPC networks is massively over-engineered for this use case. VPN is designed for connecting on-premises networks to GCP or connecting across regions/projects with encryption. It introduces unnecessary latency, cost, and complexity. You would still need firewall rules even with VPN, making this approach both inefficient and expensive.

- **D:** VPC peering creates a connection between two separate VPC networks, which is unnecessary complexity when both the frontend and database can exist in the same VPC. Like option C, this adds administrative overhead, uses additional quota, and you would still need firewall rules to control access. Peering is meant for connecting workloads that need to be in different VPC networks (different projects, organizations, or administrative domains).

### References

- [VPC firewall rules | Cloud Next Generation Firewall](https://docs.cloud.google.com/firewall/docs/firewalls)
- [Best practices and reference architectures for VPC design](https://docs.cloud.google.com/architecture/best-practices-vpc-design)
