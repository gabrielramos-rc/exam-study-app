# Question 037

**Source:** https://www.examtopics.com/discussions/google/view/31467-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Configuring Cloud Identity and Access Management (IAM)
**Tags:** IAM, folders, resource hierarchy, inheritance, Project Viewer role

---

## Question

A company allows every employee to use Google Cloud Platform. Each department has a Google Group, with all department members as group members. If a department member creates a new project, all members of that department should automatically have read-only access to all new project resources. Members of any other department should not have access to the project. You need to configure this behavior. What should you do to meet these requirements?
## Choices

- **A.** Create a Folder per department under the Organization. For each department's Folder, assign the Project Viewer role to the Google Group related to that department. Most Voted
- **B.** Create a Folder per department under the Organization. For each department's Folder, assign the Project Browser role to the Google Group related to that department.
- **C.** Create a Project per department under the Organization. For each department's Project, assign the Project Viewer role to the Google Group related to that department.
- **D.** Create a Project per department under the Organization. For each department's Project, assign the Project Browser role to the Google Group related to that department.

---

## Community

**Most Voted:** A


**Votes:** A: 78% | C: 22% (9 total)


**Top Comments:**

- (21 upvotes) Correct, it is A. Project Browser does not have access to the resources inside the project, which is the requirement in the question.

- (8 upvotes) A please

- (3 upvotes) The answer is A: https://stackoverflow.com/questions/54778596/whats-the-difference-between-project-browser-role-and-project-viewer-role-in-go#:~:text=8-,What's%20the%20difference%20between%20Project%2

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is correct because it leverages GCP's resource hierarchy and IAM inheritance to automatically grant read-only access to all new projects created within a department's folder. Here's why this solution works:

**Folders and IAM Inheritance:**
- When you create a folder per department and assign the Project Viewer role (`roles/viewer`) to the department's Google Group at the folder level, IAM policies automatically inherit downward to all projects created within that folder.
- As stated in the GCP documentation: "Roles granted at the highest folder level will be inherited by projects or other folders that are contained in that parent folder."
- When a department member creates a new project under their department's folder, all members of that department's Google Group automatically receive read-only access to all resources in that project through inheritance.

**Project Viewer Role:**
- The Project Viewer role is a basic role that provides read-only access to all resources within a project, which is exactly what the requirement specifies.
- This role allows users to view resources but not modify them, meeting the "read-only access to all new project resources" requirement.

**Isolation Between Departments:**
- Since each department has its own folder, and IAM permissions are granted at the folder level, members of other departments have no access to projects in different department folders.
- This satisfies the requirement that "members of any other department should not have access to the project."

### Why Other Options Are Wrong

- **B:** The Project Browser role (`roles/browser`) only provides permissions to browse the resource hierarchy (folders, organizations, and projects) but does NOT grant permission to view resources within the project. According to the documentation, the Browser role "doesn't include permission to view resources in the project." It only grants permissions like `resourcemanager.projects.get`, `resourcemanager.projects.list`, and `resourcemanager.folders.list`, which allow navigation of the hierarchy but not access to actual resources like VMs, storage, or databases.

- **C:** Creating a Project per department would not satisfy the requirement because the IAM role would be assigned at the project level. When department members create NEW projects, those new projects would not automatically inherit the permissions since the role is granted on a different project, not on a parent resource. Projects are siblings, not parent-child resources, so they don't inherit permissions from each other.

- **D:** This option has two problems: (1) it uses the Project Browser role, which doesn't provide access to resources within projects, and (2) it uses the wrong resource hierarchy (projects instead of folders), which would not enable automatic inheritance for new projects.

### References

- [Using resource hierarchy for access control](https://docs.cloud.google.com/iam/docs/resource-hierarchy-access-control)
- [Browser roles and permissions](https://docs.cloud.google.com/iam/docs/roles-permissions/browser)
- [Access control for folders with IAM](https://docs.cloud.google.com/resource-manager/docs/access-control-folders)
