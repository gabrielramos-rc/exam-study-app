# Question 304

**Source:** https://www.examtopics.com/discussions/google/view/148659-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, IAM conditions, tags, folder structure, least privilege

---

## Question

You are managing a Google Cloud environment that is organized into folders that represent different teams. These teams need the flexibility to modify organization policies relevant to their work. You want to grant the teams the necessary permissions while upholding Google-recommended security practices and minimizing administrative complexity. What should you do?
## Choices

- **A.** Create a custom IAM role with the organization policy administrator permission and grant the permission to each team's folder. Limit policy modifications based on folder names within the custom role's definition.
- **B.** Assign the organization policy administrator role to a central service account and provide teams with the credentials to use the service account when needed.
- **C.** Create an organization-level tag. Attach the tag to relevant folders. Use an IAM condition to restrict the organization policy administrator role to resources with that tag. Most Voted
- **D.** Grant each team the organization policy administrator role at the organization level.

---

## Community

**Most Voted:** C


**Votes:** A: 50% | C: 50% (10 total)


**Top Comments:**

- (3 upvotes) Answer is C. The only inputs accepted while defining a new custom role are: Title, Description, ID, Role launch stage &amp; permissions. Any other option like "Limit policy modifications based on fold

- (2 upvotes) Answer is C. The only inputs accepted while defining a new custom role are: Title, Description, ID, Role launch stage &amp; permissions. Any other option like "Limit policy modifications based on fold

- (1 upvotes) A is the best approach, although it's worded slightly confusingly. The correct pattern is to grant a role with the necessary permissions (like a custom role with orgpolicy.policy.set or the built-in O

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is the correct approach for delegating organization policy administration to teams while maintaining security and minimizing administrative complexity. According to Google Cloud documentation, the Organization Policy Administrator role (`roles/orgpolicy.policyAdmin`) can only be granted at the organization level—it cannot be granted at the folder or project level. However, you can use **IAM Conditions with tags** to restrict which resources the role applies to.

The recommended approach is to:
1. Create organization-level tags representing different teams or purposes
2. Attach these tags to the relevant folders
3. Grant the Organization Policy Administrator role at the organization level with an IAM condition that restricts it to resources with specific tags (using `resource.matchTag()` or similar operators)

This allows teams to manage organization policies only for resources tagged with their team identifier, effectively scoping their administrative access to their own folders while technically granting the role at the required organization level. This follows Google's recommended security practice of using IAM Conditions for granular access control and implements the principle of least privilege.

### Why Other Options Are Wrong

- **A:** The Organization Policy Administrator role cannot be granted at the folder level—its lowest-level resource is the organization. Custom roles cannot change this fundamental constraint. Additionally, you cannot limit policy modifications based on folder names within a custom role definition; IAM conditions with tags are the proper mechanism for resource-scoped permissions.

- **B:** Sharing service account credentials violates Google-recommended security practices. Service account key sharing creates significant security risks including credential leakage, lack of individual accountability, and difficulty in auditing who performed which actions. Google explicitly recommends against sharing service account credentials and encourages using individual user identities with appropriate role bindings.

- **D:** Granting the Organization Policy Administrator role at the organization level without any restrictions gives teams permission to modify policies across the entire organization, not just their own folders. This violates the principle of least privilege and creates unnecessary security risk, as a team could accidentally or intentionally modify policies affecting other teams' resources.

### References

- [Setting an organization policy with tags](https://docs.cloud.google.com/resource-manager/docs/organization-policy/tags-organization-policy)
- [Access control for organization resources with IAM](https://docs.cloud.google.com/resource-manager/docs/access-control-org)
