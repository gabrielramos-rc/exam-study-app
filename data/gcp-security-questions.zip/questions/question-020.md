# Question 020

**Source:** https://www.examtopics.com/discussions/google/view/17838-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Logging, log export, aggregated sink, Pub/Sub, SIEM

---

## Question

How should a customer reliably deliver Stackdriver logs from GCP to their on-premises SIEM system?
## Choices

- **A.** Send all logs to the SIEM system via an existing protocol such as syslog.
- **B.** Configure every project to export all their logs to a common BigQuery DataSet, which will be queried by the SIEM system.
- **C.** Configure Organizational Log Sinks to export logs to a Cloud Pub/Sub Topic, which will be sent to the SIEM via Dataflow. Most Voted
- **D.** Build a connector for the SIEM to query for all logs in real time from the GCP RESTful JSON APIs.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (4 total)


**Top Comments:**

- (18 upvotes) I will go with C

- (4 upvotes) Ans : C

- (3 upvotes) C is correct

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is the recommended and most reliable approach for exporting Google Cloud logs to an on-premises SIEM system. This solution uses **aggregated sinks** at the organization level, which collate and route log entries from the entire organization and all child resources (folders, projects) to a centralized destination.

The architecture works as follows:
1. **Organizational Log Sink**: Creates an aggregated sink that captures logs from all projects and resources within the organization
2. **Cloud Pub/Sub**: Serves as the intermediate destination - Google Cloud documentation explicitly states "Select this destination when you want to export your log data from Google Cloud and then use third-party integrations like Splunk or Datadog"
3. **Dataflow**: Processes and transforms the log data stream before sending it to the on-premises SIEM
4. **SIEM Integration**: The SIEM subscribes to the Pub/Sub topic or receives processed data from Dataflow

This approach provides:
- **Centralized log collection** from all projects without needing to configure each project individually
- **Scalability** through Pub/Sub's managed message queue
- **Reliability** with at-least-once delivery guarantees
- **Flexibility** to transform logs via Dataflow before delivery
- **Real-time streaming** of log entries to the SIEM system

### Why Other Options Are Wrong

- **A:** Direct syslog export is not natively supported by Cloud Logging for organization-level log aggregation. This would require building custom solutions and doesn't provide the scalability and reliability of the Pub/Sub-based approach.

- **B:** While BigQuery can be used as a log sink destination, requiring the SIEM to query BigQuery introduces latency, complexity, and doesn't provide real-time log delivery. This is a pull-based model rather than the recommended push-based streaming model for SIEM integration.

- **D:** Building a custom connector to query RESTful JSON APIs is not scalable or reliable for production SIEM integration. The Logging API has rate limits, this approach would be expensive, complex to maintain, and wouldn't provide real-time streaming. It also doesn't leverage Google Cloud's native log export capabilities.

### References

- [Aggregated sinks overview](https://docs.cloud.google.com/logging/docs/export/aggregated_sinks_overview)
- [Route log entries](https://docs.cloud.google.com/logging/docs/routing/overview)
- [View logs routed to Pub/Sub](https://docs.cloud.google.com/logging/docs/export/pubsub)
- [Stream logs from Google Cloud to Splunk](https://docs.cloud.google.com/architecture/stream-logs-from-google-cloud-to-splunk)
