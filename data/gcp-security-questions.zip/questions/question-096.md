# Question 096

**Source:** https://www.examtopics.com/discussions/google/view/75708-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** Policy Intelligence, policy analyzer, access reviews, audit evidence, IAM

---

## Question

You are the project owner for a regulated workload that runs in a project you own and manage as an Identity and Access Management (IAM) admin. For an upcoming audit, you need to provide access reviews evidence. Which tool should you use?
## Choices

- **A.** Policy Troubleshooter
- **B.** Policy Analyzer Most Voted
- **C.** IAM Recommender
- **D.** Policy Simulator

---

## Community

**Most Voted:** B


**Votes:** B: 100% (15 total)


**Top Comments:**

- (10 upvotes) https://cloud.google.com/policy-intelligence/docs/policy-analyzer-overview

- (5 upvotes) B policy analyzer is the correct answer

- (5 upvotes) B is correct, guys

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Policy Analyzer is the correct tool for providing access reviews evidence for regulatory audits. It's specifically designed to answer critical access control questions like "which principals (users, service accounts, groups, domains) have what access to which Google Cloud resources based on your IAM allow policies."

For audit and compliance purposes, Policy Analyzer allows you to:

- Query who has access to specific resources (e.g., "Who can access this BigQuery dataset containing PII?")
- Identify which principals have specific roles or permissions across your project, folder, or organization
- Generate comprehensive access reports by exporting results to BigQuery or Cloud Storage for documentation
- Provide evidence of access configurations to auditors by analyzing the complete policy hierarchy

The tool supports four fundamental query types that are essential for access reviews:
1. Principal identification: "Who can access this resource?"
2. Permission discovery: "Which principals have these roles/permissions?"
3. Access mapping: "What access does this principal have on this resource?"
4. Resource enumeration: "Which resources can this principal access?"

The documentation explicitly states that Policy Analyzer helps you "effectively administer access" and that "you can also use Policy Analyzer for audit-related and compliance-related tasks," making it the ideal choice for providing access reviews evidence.

### Why Other Options Are Wrong

- **A. Policy Troubleshooter:** This tool is designed to diagnose why a specific principal was granted or denied access to a resource. It's used for troubleshooting access issues in real-time, not for generating comprehensive access reviews or audit evidence. It answers "why did this happen?" rather than "who has what access?"

- **C. IAM Recommender:** This tool provides recommendations for removing excessive permissions and optimizing IAM policies based on actual usage patterns. While useful for implementing least privilege, it's focused on improving security posture through recommendations, not providing comprehensive access reviews evidence for audits.

- **D. Policy Simulator:** This tool simulates the effect of IAM policy changes before you implement them. It helps you understand what would happen if you changed a policy, but it doesn't provide access reviews evidence or answer questions about current access configurations across your resources.

### References

- [Policy Analyzer for allow policies | Policy Intelligence](https://docs.cloud.google.com/policy-intelligence/docs/policy-analyzer-overview)
- [Analyze allow policies](https://docs.cloud.google.com/policy-intelligence/docs/analyze-iam-policies)
- [Policy Intelligence overview](https://docs.cloud.google.com/policy-intelligence/docs/overview)
