# Question 292

**Source:** https://www.examtopics.com/discussions/google/view/147086-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring network security
**Tags:** Cloud NGFW Enterprise, TLS inspection, hierarchical firewall policy, threat prevention, malware protection

---

## Question

You are implementing a new web application on Google Cloud that will be accessed from your on-premises network. To provide protection from threats like malware, you must implement transport layer security (TLS) interception for incoming traffic to your application. What should you do?
## Choices

- **A.** Configure Secure Web Proxy. Offload the TLS traffic in the load balancer, inspect the traffic, and forward the traffic to the web application.
- **B.** Configure an internal proxy load balancer. Offload the TLS traffic in the load balancer inspect, the traffic and forward the traffic to the web application.
- **C.** Configure a hierarchical firewall policy. Enable TLS interception by using Cloud Next Generation Firewall (NGFW) Enterprise. Most Voted
- **D.** Configure a VPC firewall rule. Enable TLS interception by using Cloud Next Generation Firewall (NGFW) Enterprise.

---

## Community

**Most Voted:** C


**Votes:** A: 38% | C: 62% (16 total)


**Top Comments:**

- (2 upvotes) C. is the correct solution because Cloud Next Generation Firewall (NGFW) Enterprise is the specific Google Cloud service designed to provide threat protection services like Intrusion Prevention (IPS) 

- (2 upvotes) This is not true. Google Cloud does not offer a native Secure Web Proxy with TLS interception for incoming traffic. Load balancers in Google Cloud do not provide deep TLS interception for security ins

- (2 upvotes) Secure Web Proxy: This setup allows you to intercept and inspect TLS traffic securely. By configuring a Secure Web Proxy, you can manage incoming traffic more effectively and implement security measur

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Cloud Next Generation Firewall (NGFW) Enterprise with hierarchical firewall policies is the correct solution for implementing TLS interception on incoming traffic to protect against malware. Cloud NGFW Enterprise provides signature-based intrusion detection and prevention service (IDS/IPS) with TLS interception and decryption, which specifically provides threat detection and prevention from malware, spyware, and command-and-control attacks.

To implement this solution:

1. **Create TLS inspection infrastructure**: Set up a CA pool in Certificate Authority Service, create a TLS inspection policy, and configure firewall endpoint associations
2. **Configure hierarchical firewall policy**: Create or update a hierarchical firewall policy with the `--tls-inspect` flag enabled in the rules
3. **Apply security profile groups**: Attach security profile groups to the policy rules to enable Layer 7 inspection services like intrusion prevention

Cloud NGFW Enterprise decrypts TLS traffic to perform Layer 7 inspection, detects threats, and then re-encrypts traffic before sending it to its destination. The hierarchical firewall policy approach is ideal because it allows you to create and enforce consistent security policies across your organization or specific folders, ensuring comprehensive protection for incoming traffic from on-premises networks.

### Why Other Options Are Wrong

- **A:** Secure Web Proxy is designed exclusively for **egress (outbound) traffic**, not for incoming traffic from on-premises to web applications. The documentation explicitly states it "helps you secure egress web traffic (HTTP/S)" where clients use the proxy as a gateway for outbound connections. It cannot handle incoming traffic scenarios.

- **B:** Internal proxy load balancers are not designed for TLS interception with threat inspection capabilities. While load balancers can perform TLS offloading/termination, they do not provide the malware detection, intrusion prevention, and threat intelligence capabilities required for the security requirements stated in the question. Load balancers focus on traffic distribution and availability, not deep packet inspection for malware.

- **D:** VPC firewall rules are Layer 3/4 stateful packet filtering rules that cannot enable TLS interception. Cloud NGFW Enterprise capabilities (including TLS inspection and threat prevention) are **only available through firewall policies** (network firewall policies or hierarchical firewall policies), not through basic VPC firewall rules. The documentation explicitly states "Cloud NGFW Enterprise capabilities are only available through firewall policies."

### References

- [TLS inspection overview - Cloud NGFW](https://docs.cloud.google.com/firewall/docs/about-tls-inspection)
- [Set up TLS inspection - Cloud NGFW](https://docs.cloud.google.com/firewall/docs/setup-tls-inspection)
- [Hierarchical firewall policies](https://docs.cloud.google.com/firewall/docs/firewall-policies)
- [Intrusion prevention service overview](https://docs.cloud.google.com/firewall/docs/about-intrusion-prevention)
- [Secure Web Proxy overview](https://docs.cloud.google.com/secure-web-proxy/docs/overview)
