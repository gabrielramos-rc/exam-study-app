# Question 110

**Source:** https://www.examtopics.com/discussions/google/view/75892-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Audit Logs, service account, unauthorized access, Logs Explorer, investigation

---

## Question

Your Security team believes that a former employee of your company gained unauthorized access to Google Cloud resources some time in the past 2 months by using a service account key. You need to confirm the unauthorized access and determine the user activity. What should you do?
## Choices

- **A.** Use Security Health Analytics to determine user activity.
- **B.** Use the Cloud Monitoring console to filter audit logs by user.
- **C.** Use the Cloud Data Loss Prevention API to query logs in Cloud Storage.
- **D.** Use the Logs Explorer to search for user activity. Most Voted

---

## Community

**Most Voted:** D


**Votes:** B: 12% | D: 88% (26 total)


**Top Comments:**

- (14 upvotes) D is right, I agree

- (8 upvotes) B is correct answer https://cloud.google.com/docs/security/compromised-credentials Monitor for anomalies in service account key usage using Cloud Monitoring.

- (3 upvotes) B is intended to mislead the public. Cloud Monitoring provides only metrics. To check user activity is necessary to go to Cloud Logging and search on Audit Logs.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

**Logs Explorer** is the correct tool for investigating service account unauthorized access because it is the primary interface for querying and analyzing Cloud Audit Logs. Cloud Audit Logs answer "who did what, where, and when?" within your Google Cloud resources, making them essential for investigating security incidents involving service account keys.

To investigate this incident, you would use Logs Explorer to:

1. **Search for service account activity** by filtering audit logs for the specific service account principal
2. **Filter by time range** (past 2 months as mentioned in the scenario)
3. **Examine authentication details** in the `AuthenticationInfo` field to identify caller identity
4. **Review service account credential usage** by filtering for `iamcredentials.googleapis.com` service entries
5. **Analyze Data Access logs** (if enabled) to see what resources were accessed or modified

The documentation specifically notes that "for service accounts, caller identity information is stored in the AuthenticationInfo field" and that audit logs track service account impersonation scenarios through the `serviceAccountDelegationInfo` section. This provides the complete audit trail needed to confirm unauthorized access and determine the full scope of user activity.

### Why Other Options Are Wrong

- **A:** Security Health Analytics is used to detect security misconfigurations and vulnerabilities in your GCP resources (like open firewall rules, weak IAM policies, or unencrypted resources). It does not provide historical user activity logs or track service account key usage over time. It's a posture management tool, not a log investigation tool.

- **B:** Cloud Monitoring console is designed for metrics, dashboards, and alerting on resource performance and health. It does not provide direct filtering of audit logs by user or service account. While you can create log-based metrics in Cloud Monitoring, the actual investigation and querying of audit logs is done through Logs Explorer, not the Monitoring console.

- **C:** Cloud Data Loss Prevention (DLP) API is specifically for discovering, classifying, and protecting sensitive data like PII, credit card numbers, or other regulated information. It does not query or analyze audit logs for security incidents. DLP inspects data content, not activity logs.

### References

- [Cloud Audit Logs overview](https://docs.cloud.google.com/logging/docs/audit)
- [Best practices for using service accounts securely](https://docs.cloud.google.com/iam/docs/best-practices-service-accounts)
- [Handle compromised Google Cloud credentials](https://docs.cloud.google.com/docs/security/compromised-credentials)
