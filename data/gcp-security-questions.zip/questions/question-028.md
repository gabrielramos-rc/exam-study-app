# Question 028

**Source:** https://www.examtopics.com/discussions/google/view/16994-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** load balancer, TCP Proxy, global load balancing, SSL, TLS

---

## Question

A company has redundant mail servers in different Google Cloud Platform regions and wants to route customers to the nearest mail server based on location. How should the company accomplish this?
## Choices

- **A.** Configure TCP Proxy Load Balancing as a global load balancing service listening on port 995. Most Voted
- **B.** Create a Network Load Balancer to listen on TCP port 995 with a forwarding rule to forward traffic based on location.
- **C.** Use Cross-Region Load Balancing with an HTTP(S) load balancer to route traffic to the nearest region.
- **D.** Use Cloud CDN to route the mail traffic to the closest origin mail server based on client IP address.

---

## Community

**Most Voted:** A


**Votes:** A: 50% | B: 50% (26 total)


**Top Comments:**

- (27 upvotes) A is the correct answer. D is not correct. CDN works with HTTP(s) traffic and requires caching, which is not a valid feature used for mail server

- (9 upvotes) NLB is regional and not global

- (3 upvotes) B) Create a Network Load Balancer to listen on TCP port 995 with a forwarding rule to forward traffic based on location. Explanation: Port 995 implies this is SSL/TLS encrypted mail traffic (IMAP). Ne

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

TCP Proxy Load Balancing is the correct solution for this scenario because:

1. **Global Load Balancing with Proximity Routing**: External proxy Network Load Balancers (TCP Proxy) automatically route traffic to the backends that are closest to the user when configured as a global service with Premium Tier. This provides the geographic routing capability required.

2. **Port 995 Support**: TCP Proxy supports any single port from 1-65535, making it suitable for port 995 (POP3S - secure mail retrieval over SSL).

3. **Protocol Compatibility**: The documentation explicitly states that TCP Proxy Load Balancers "can also be used for other protocols that use SSL, such as WebSockets and IMAP over SSL." This makes it ideal for secure mail protocols.

4. **Single Global IP Address**: TCP Proxy allows using a single IP address for all users worldwide, simplifying DNS configuration and client setup.

5. **SSL/TLS Termination**: TCP Proxy can handle SSL connections, which is essential for secure mail protocols on port 995.

### Why Other Options Are Wrong

- **B:** Network Load Balancer (passthrough) is a regional service, not global. It cannot automatically route traffic to the nearest region based on client location. While it supports port 995, it lacks the geographic routing intelligence needed for this scenario.

- **C:** HTTP(S) load balancers are designed for HTTP/HTTPS traffic, not mail protocols. Port 995 uses POP3S (mail retrieval over SSL), which is a TCP-based protocol but not HTTP. HTTP(S) load balancers expect HTTP requests and would not work with mail server protocols.

- **D:** Cloud CDN is a content delivery network designed for caching and distributing static content (web assets, media files) via HTTP/HTTPS. It is not designed for active TCP connections like mail server protocols, which require bidirectional communication and cannot be cached.

### References

- [External proxy Network Load Balancer overview](https://docs.cloud.google.com/load-balancing/docs/tcp)
- [Set up a global external proxy Network Load Balancer (TCP proxy)](https://docs.cloud.google.com/load-balancing/docs/tcp/set-up-global-ext-proxy-tcp)
