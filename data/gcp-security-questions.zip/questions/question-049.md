# Question 049

**Source:** https://www.examtopics.com/discussions/google/view/16557-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** VPC Flow Logs, firewall rules, migration, network segmentation, Lift & Shift

---

## Question

You are in charge of migrating a legacy application from your company datacenters to GCP before the current maintenance contract expires. You do not know what ports the application is using and no documentation is available for you to check. You want to complete the migration without putting your environment at risk. What should you do?
## Choices

- **A.** Migrate the application into an isolated project using a ג€Lift & Shiftג€ approach. Enable all internal TCP traffic using VPC Firewall rules. Use VPC Flow logs to determine what traffic should be allowed for the application to work properly. Most Voted
- **B.** Migrate the application into an isolated project using a ג€Lift & Shiftג€ approach in a custom network. Disable all traffic within the VPC and look at the Firewall logs to determine what traffic should be allowed for the application to work properly.
- **C.** Refactor the application into a micro-services architecture in a GKE cluster. Disable all traffic from outside the cluster using Firewall Rules. Use VPC Flow logs to determine what traffic should be allowed for the application to work properly.
- **D.** Refactor the application into a micro-services architecture hosted in Cloud Functions in an isolated project. Disable all traffic from outside your project using Firewall Rules. Use VPC Flow logs to determine what traffic should be allowed for the application to work properly.

---

## Community

**Most Voted:** A


**Votes:** A: 65% | B: 35% (26 total)


**Top Comments:**

- (20 upvotes) Agree "Disable all traffic within the VPC and look at the Firewall logs to determine what traffic should be allowed for the application to work properly." if you disable all the VPC traffic there will

- (13 upvotes) I agree.

- (8 upvotes) Answer is A.. You need VPC Flow Logs not "Firewall logs" stated in B

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is the correct approach because it balances migration urgency with security discovery. The strategy involves:

1. **Isolated Project**: Provides network and security boundary separation to contain any risks from the unknown application
2. **Lift & Shift Approach**: Meets the time constraint (maintenance contract expiration) without requiring application refactoring
3. **Enable Internal TCP Traffic**: Allows the application to function immediately while you discover its requirements - the application can actually run and process traffic
4. **VPC Flow Logs**: Captures actual network traffic patterns (5-tuple: source IP, destination IP, source port, destination port, protocol) by sampling packets sent from and received by VM instances

VPC Flow Logs aggregate traffic by IP connection and provide visibility into:
- Which internal systems communicate
- Which ports and protocols are actively used
- Traffic volume and patterns
- Top talkers in the network

After observing the actual traffic patterns through VPC Flow Logs, you can then implement a least-privilege firewall rule set that only allows the necessary traffic.

### Why Other Options Are Wrong

- **B:** Disabling all traffic within the VPC would prevent the application from functioning at all. If the application cannot run, it cannot generate any traffic to analyze. Additionally, while Firewall Rules Logging can show denied traffic, you need the application to actually attempt connections to generate those deny logs - but critical application components would likely fail before generating useful logs.

- **C:** Refactoring to microservices architecture in GKE requires significant development time and effort, which conflicts with the urgent timeline (maintenance contract expiration). This is not a "Lift & Shift" approach and introduces unnecessary complexity and risk when you don't even know the application's requirements.

- **D:** Refactoring to Cloud Functions has the same problems as option C - it requires complete application redesign, is not "Lift & Shift," and contradicts the time-sensitive migration requirement. Additionally, not all legacy applications are suitable for serverless architectures.

### References

- [VPC Flow Logs](https://docs.cloud.google.com/vpc/docs/flow-logs)
- [Firewall Rules Logging](https://docs.cloud.google.com/firewall/docs/firewall-rules-logging)
- [VPC Firewall Rules Overview](https://docs.cloud.google.com/firewall/docs/firewalls)
