# Question 204

**Source:** https://www.examtopics.com/discussions/google/view/117279-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Security Command Center, threat detection, Virtual Machine Threat Detection, cryptocurrency mining

---

## Question

You are using Security Command Center (SCC) to protect your workloads and receive alerts for suspected security breaches at your company. You need to detect cryptocurrency mining software. Which SCC service should you use?
## Choices

- **A.** Virtual Machine Threat Detection Most Voted
- **B.** Container Threat Detection
- **C.** Rapid Vulnerability Detection
- **D.** Web Security Scanner

---

## Community

**Most Voted:** A


**Votes:** A: 100% (5 total)


**Top Comments:**

- (3 upvotes) A - https://cloud.google.com/security-command-center/docs/how-to-use-vm-threat-detection#overview

- (2 upvotes) A is correct https://cloud.google.com/security-command-center/docs/concepts-vm-threat-detection-overview?hl=pt-br#how-cryptomining-detection-works

- (1 upvotes) https://cloud.google.com/security-command-center/docs/concepts-vm-threat-detection-overview#overview

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Virtual Machine Threat Detection (VMTD) is the correct SCC service for detecting cryptocurrency mining software on Compute Engine virtual machines. VMTD provides agentless memory scanning capabilities that can identify cryptocurrency mining malware running on VMs through specific detection signatures and behavioral analysis.

VMTD generates specific findings for cryptocurrency mining activities, including:
- **Execution: Cryptocurrency Mining Hash Match** - Detects known cryptocurrency mining software signatures
- **Execution: Cryptocurrency Mining YARA Rule** - Identifies mining activities using YARA pattern matching rules

This service works by performing memory scanning on running VMs without requiring agents to be installed, making it effective at detecting malicious cryptocurrency mining software that may have been deployed through security breaches or compromised instances. The detection covers both known mining software signatures and behavioral patterns characteristic of cryptomining operations.

### Why Other Options Are Wrong

- **B (Container Threat Detection):** This service is designed for detecting threats in Google Kubernetes Engine (GKE) containers and containerized environments. While it can detect "Execution: Cryptomining Docker Image" in containers, the question asks about detecting cryptocurrency mining software in general workloads, not specifically containerized applications. Virtual Machine Threat Detection is the more appropriate choice for VM-based workloads.

- **C (Rapid Vulnerability Detection):** This service (also known as Web Security Scanner for certain contexts) focuses on identifying security vulnerabilities in applications and infrastructure configurations, such as outdated software versions, misconfigurations, and known CVEs. It does not perform runtime threat detection for active malware or cryptocurrency mining software.

- **D (Web Security Scanner):** This service is specifically designed to scan web applications for common vulnerabilities like XSS, SQL injection, and other web-based security issues. It operates at the application layer and does not detect runtime threats like cryptocurrency mining malware on virtual machines.

### References

- [Security Command Center - Threat Detection Services](https://docs.cloud.google.com/security-command-center/docs/concepts-vulnerabilities-findings)
