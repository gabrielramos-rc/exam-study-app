# Question 156

**Source:** https://www.examtopics.com/discussions/google/view/81780-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Active Directory, GCDS, Cloud Identity, IAM groups, identity federation

---

## Question

Your company plans to move most of its IT infrastructure to Google Cloud. They want to leverage their existing on-premises Active Directory as an identity provider for Google Cloud. Which two steps should you take to integrate the company's on-premises Active Directory with Google Cloud and configure access management? (Choose two.)
## Choices

- **A.** Use Identity Platform to provision users and groups to Google Cloud.
- **B.** Use Cloud Identity SAML integration to provision users and groups to Google Cloud.
- **C.** Install Google Cloud Directory Sync and connect it to Active Directory and Cloud Identity. Most Voted
- **D.** Create Identity and Access Management (IAM) roles with permissions corresponding to each Active Directory group. Most Voted
- **E.** Create Identity and Access Management (IAM) groups with permissions corresponding to each Active Directory group.

---

## Community

**Most Voted:** CD


**Votes:** BC: 2% | BD: 2% | CD: 53% | CE: 43% (47 total)


**Top Comments:**

- (9 upvotes) How about BE? https://cloud.google.com/architecture/identity/federating-gcp-with-active-directory-introduction "Single sign-on: Whenever a user needs to authenticate, Google Cloud delegates the authen

- (7 upvotes) Agree: C &amp; E.

- (6 upvotes) CE are seems to be coorect. B is required only for SSO. GCDS would also provision user and group.

---

## Answer

**Correct:** C, E

**Confidence:** high

### Explanation

The correct approach to integrate on-premises Active Directory with Google Cloud involves two critical steps:

**Option C - Google Cloud Directory Sync (GCDS):** This is the official Google-provided tool for synchronizing users and groups from Active Directory to Cloud Identity or Google Workspace. GCDS connects to Active Directory via LDAP and provisions user accounts and groups to Google Cloud. The tool runs on-premises with LDAP access to Active Directory and communicates with Google Cloud over SSL. It automates the creation and maintenance of users, tying their lifecycle to the users in Active Directory. This is the foundational step for AD integration.

**Option E - Create IAM groups:** After provisioning users and groups from Active Directory using GCDS, you should grant permissions to groups rather than individual users. Google Cloud's best practice is to "define a set of groups that model common roles in your organization, and then assign those groups to a set of IAM roles." This allows you to map Active Directory security groups (synchronized via GCDS) to IAM roles, maintaining Active Directory as the primary place for managing access. By synchronizing role and organization groups from AD, you can use Active Directory group memberships to determine Google Cloud resource access.

### Why Other Options Are Wrong

- **A:** Identity Platform is designed for customer identity and access management (CIAM) for applications, not for enterprise workforce identity integration with Active Directory. It's not the appropriate tool for this use case.

- **B:** SAML integration is used for single sign-on (SSO) authentication, not for provisioning users and groups. While SAML SSO is typically configured after GCDS setup, it doesn't provision user accounts or groups to Cloud Identity.

- **D:** You don't create IAM roles for each Active Directory group. IAM roles are predefined sets of permissions in Google Cloud (either predefined or custom). The correct approach is to assign existing IAM roles to synchronized groups (Option E), not create new roles.

### References

- [Active Directory user account provisioning | Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-synchronizing-user-accounts)
- [Federate Google Cloud with Active Directory | Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-introduction)
