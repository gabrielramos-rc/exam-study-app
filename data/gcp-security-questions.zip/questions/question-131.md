# Question 131

**Source:** https://www.examtopics.com/discussions/google/view/80418-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and implementing security for networks
**Tags:** Cloud NAT, network security, public IP addresses, outbound connectivity

---

## Question

You perform a security assessment on a customer architecture and discover that multiple VMs have public IP addresses. After providing a recommendation to remove the public IP addresses, you are told those VMs need to communicate to external sites as part of the customer's typical operations. What should you recommend to reduce the need for public IP addresses in your customer's VMs?
## Choices

- **A.** Google Cloud Armor
- **B.** Cloud NAT Most Voted
- **C.** Cloud Router
- **D.** Cloud VPN

---

## Community

**Most Voted:** B


**Votes:** B: 100% (7 total)


**Top Comments:**

- (7 upvotes) B Cloud NAT

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud NAT (Network Address Translation) is the correct solution for allowing VMs without public IP addresses to access external sites on the internet. Cloud NAT is a managed Google Cloud service that provides outbound internet connectivity for VM instances that lack external IP addresses.

When you configure a Cloud NAT gateway for your VPC subnets, the service performs source NAT on egress traffic - translating the VM's private internal IP address to a shared external IP address allocated by the NAT gateway. This allows VMs to initiate outbound connections to the internet while remaining completely private (no direct public IP assignment).

Key security benefits include:
- **Reduced attack surface**: VMs without public IPs cannot receive unsolicited inbound connections from the internet, even if firewall rules would permit them
- **Controlled external identity**: Organizations can use a small set of known external IP addresses that can be whitelisted by external services
- **Simplified management**: No need to manage individual public IPs on each VM

Cloud NAT supports outbound connections and their corresponding inbound response packets, making it ideal for scenarios like software updates, API calls, and external service access.

### Why Other Options Are Wrong

- **A:** Google Cloud Armor is a DDoS protection and web application firewall (WAF) service that works with load balancers. It doesn't provide NAT functionality or enable internet access for VMs without public IPs. It's designed to protect against attacks, not to enable outbound connectivity.

- **C:** Cloud Router is a component used for dynamic routing with BGP, primarily for Cloud VPN and Cloud Interconnect connections. While Cloud Router is required to configure Cloud NAT (it provides the control plane), it doesn't by itself enable internet access for private VMs. Cloud Router alone doesn't perform NAT operations.

- **D:** Cloud VPN creates encrypted tunnels between Google Cloud and on-premises networks or other cloud environments. It's designed for private connectivity to specific networks, not for general outbound internet access. Using VPN for internet access would require routing all traffic through an on-premises network, which is inefficient and doesn't reduce the need for public IPs.

### References

- [Cloud NAT overview](https://docs.cloud.google.com/nat/docs/overview)
- [Public NAT](https://docs.cloud.google.com/nat/docs/public-nat)
