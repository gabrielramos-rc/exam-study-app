# Question 241

**Source:** https://www.examtopics.com/discussions/google/view/126781-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** service account, impersonation, token creator, batch jobs, least privilege

---

## Question

You are developing a new application that uses exclusively Compute Engine VMs. Once a day, this application will execute five different batch jobs. Each of the batch jobs requires a dedicated set of permissions on Google Cloud resources outside of your application. You need to design a secure access concept for the batch jobs that adheres to the least-privilege principle. What should you do?
## Choices

- **A.** 1. Create a general service account "g-sa" to orchestrate the batch jobs. 2. Create one service account per batch job 'b-sa-[1-5]'. Grant only the permissions required to run the individual batch jobs to the service accounts and generate service account keys for each of these service accounts. 3. Store the service account keys in Secret Manager. Grant g-sa access to Secret Manager and run the batch jobs with the permissions of b-sa-[1-5].
- **B.** 1. Create a general service account "g-sa" to execute the batch jobs. 2. Grant the permissions required to execute the batch jobs to g-sa. 3. Execute the batch jobs with the permissions granted to g-sa.
- **C.** 1. Create a workload identity pool and configure workload identity pool providers for each batch job. 2. Assign the workload identity user role to each of the identities configured in the providers. 3. Create one service account per batch job "b-sa-[1-5]", and grant only the permissions required to run the individual batch jobs to the service accounts. 4. Generate credential configuration files for each of the providers. Use these files to execute the batch jobs with the permissions of b-sa-[1-5].
- **D.** 1. Create a general service account "g-sa" to orchestrate the batch jobs. 2. Create one service account per batch job "b-sa-[1-5]", and grant only the permissions required to run the individual batch jobs to the service accounts. 3. Grant the Service Account Token Creator role to g-sa. Use g-sa to obtain short-lived access tokens for b-sa-[1-5] and to execute the batch jobs with the permissions of b-sa-[1-5]. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (5 total)


**Top Comments:**

- (1 upvotes) I picked D over B. "least privilege"

- (1 upvotes) Which is correct, B or D?

- (1 upvotes) The correct answer is D. 1. Create a general service account “g-sa” to orchestrate the batch jobs. 2. Create one service account per batch job “b-sa-[1-5]”, and grant only the permissions required to 

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D correctly implements the principle of least privilege using service account impersonation, which is the recommended best practice for this scenario. This approach involves:

1. **Creating dedicated service accounts**: Five separate service accounts (b-sa-1 through b-sa-5), each with only the specific permissions needed for its individual batch job
2. **Using a supervisor account**: The general service account (g-sa) orchestrates the batch jobs but doesn't have direct permissions to the resources
3. **Service Account Token Creator role**: Granting `roles/iam.serviceAccountTokenCreator` to g-sa on the batch job service accounts allows g-sa to request short-lived access tokens for each batch job
4. **Short-lived credentials**: The tokens obtained through impersonation are temporary and automatically expire, reducing security risk

This is the exact pattern recommended in Google Cloud's best practices documentation for scenarios where a supervisor application needs to run multiple tasks with different access requirements. The documentation explicitly states: "To help ensure that different parts of your application only have access to the resources they need, use the Service Account Credentials API for temporary privilege elevation: create dedicated service accounts for each part of the application or use case."

### Why Other Options Are Wrong

- **A:** This approach violates Google Cloud security best practices by using service account keys. The documentation strongly states: "We recommend that you avoid using service account keys whenever possible." Service account keys create a non-repudiation problem because Cloud Audit Logs cannot reliably identify who used the key. They are long-lived credentials that pose a greater security risk than short-lived tokens from impersonation.

- **B:** This violates the principle of least privilege by granting a single service account all permissions needed for all five batch jobs. If any batch job is compromised, the attacker would have access to all permissions across all batch jobs. This approach fails the requirement that "each of the batch jobs requires a dedicated set of permissions."

- **C:** Workload Identity Federation is designed for workloads running outside of Google Cloud (e.g., AWS, Azure, on-premises) to access Google Cloud resources without service account keys. Since the question specifically states the application "uses exclusively Compute Engine VMs," these are native Google Cloud workloads that should use standard service account attachment and impersonation, not Workload Identity Federation. This solution is unnecessarily complex for the use case.

### References

- [Service account impersonation - IAM Documentation](https://docs.cloud.google.com/iam/docs/service-account-impersonation)
- [Best practices for using service accounts securely](https://docs.cloud.google.com/iam/docs/best-practices-service-accounts)
- [Roles for service account authentication](https://docs.cloud.google.com/iam/docs/service-account-permissions)
