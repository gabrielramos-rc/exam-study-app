# Question 098

**Source:** https://www.examtopics.com/discussions/google/view/74822-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Cloud Armor, WAF, web application firewall, preview mode, DDoS

---

## Question

You have been tasked with implementing external web application protection against common web application attacks for a public application on Google Cloud. You want to validate these policy changes before they are enforced. What service should you use?
## Choices

- **A.** Google Cloud Armor's preconfigured rules in preview mode Most Voted
- **B.** Prepopulated VPC firewall rules in monitor mode
- **C.** The inherent protections of Google Front End (GFE)
- **D.** Cloud Load Balancing firewall rules
- **E.** VPC Service Controls in dry run mode

---

## Community

**Most Voted:** A


**Votes:** A: 100% (5 total)


**Top Comments:**

- (10 upvotes) A is right

- (2 upvotes) Answer is (A).

- (1 upvotes) ans is A

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Google Cloud Armor's preconfigured WAF rules in preview mode is the correct service for validating web application protection policies before enforcement. Cloud Armor provides preconfigured Web Application Firewall (WAF) rules that protect against common web application attacks such as SQL injection, cross-site scripting (XSS), remote code execution, and other OWASP Top 10 vulnerabilities.

Preview mode is specifically designed for policy validation. When you enable preview mode for a Cloud Armor security policy rule, the rule evaluates incoming requests and logs them, but does not enforce the deny or allow action. This allows you to:

1. Test rule logic without blocking legitimate traffic
2. Review request logs to verify the rule matches intended traffic patterns
3. Adjust expressions based on actual request data before enforcement
4. Prevent false positives that might disrupt users or applications

Google explicitly recommends deploying all new rules in preview mode first, then examining your request logs to verify that the policies and rules are behaving as expected before promoting them to enforcement mode. This is critical for web applications that might have legitimate requests matching WAF signatures.

You can enable preview mode using the `--preview` flag in gcloud CLI or the "Enable" checkbox in the console when creating or updating security policy rules.

### Why Other Options Are Wrong

- **B:** VPC firewall rules do not have a "monitor mode" capability, and they operate at the network layer (L3/L4) rather than providing web application protection against application-layer attacks. VPC firewall rules control traffic based on IP addresses, protocols, and ports, not HTTP/HTTPS request content.

- **C:** Google Front End (GFE) provides inherent protections against infrastructure-level DDoS attacks and some network-layer attacks, but it does not offer configurable, testable policies for web application attacks. GFE protections are automatic and cannot be validated before enforcement, nor do they provide WAF capabilities against OWASP-style application attacks.

- **D:** Cloud Load Balancing does not have "firewall rules" as a feature. While load balancers integrate with Cloud Armor for security policies, the load balancer itself doesn't provide WAF rules or a preview/validation mode for web application protection.

- **E:** VPC Service Controls in dry run mode is designed for testing access controls and data exfiltration protection for Google Cloud APIs and services, not for protecting external web applications against common web attacks. VPC Service Controls create security perimeters around Google Cloud resources to prevent unauthorized data access, which is a completely different use case than WAF protection.

### References

- [Cloud Armor preconfigured WAF rules overview](https://docs.cloud.google.com/armor/docs/waf-rules)
- [Configure Cloud Armor security policies](https://docs.cloud.google.com/armor/docs/configure-security-policies)
- [Cloud Armor best practices](https://docs.cloud.google.com/armor/docs/best-practices)
