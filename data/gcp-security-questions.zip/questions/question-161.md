# Question 161

**Source:** https://www.examtopics.com/discussions/google/view/82337-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** CMEK, Cloud KMS, GDPR, encryption, customer-managed encryption keys

---

## Question

You are implementing data protection by design and in accordance with GDPR requirements. As part of design reviews, you are told that you need to manage the encryption key for a solution that includes workloads for Compute Engine, Google Kubernetes Engine, Cloud Storage, BigQuery, and Pub/Sub. Which option should you choose for this implementation?
## Choices

- **A.** Cloud External Key Manager
- **B.** Customer-managed encryption keys Most Voted
- **C.** Customer-supplied encryption keys
- **D.** Google default encryption

---

## Community

**Most Voted:** B


**Votes:** A: 41% | B: 59% (78 total)


**Top Comments:**

- (21 upvotes) Obviously A is the better answer. Based on the GCP blog [1], you can utilize Cloud External Key Manager (Cloud EKM) to manage customer key easily and fulfill the compliance requirements as Key Access 

- (12 upvotes) unfortunately not supported for all services

- (4 upvotes) Cloud External Key Manager (option A) is an option for customers who require full control over their encryption keys while leveraging Google Cloud's Key Management Service. However, this option is gen

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Customer-managed encryption keys (CMEK) is the correct choice because it is the only option that supports ALL the services mentioned in the question (Compute Engine, GKE, Cloud Storage, BigQuery, and Pub/Sub) while providing the key management control required for GDPR compliance.

CMEK allows you to create and manage your own encryption keys in Cloud KMS while Google handles the encryption operations transparently. This provides:

1. **Universal service support**: CMEK is supported across all mentioned services - Compute Engine (for disks), GKE (for boot disks and persistent volumes), Cloud Storage (for buckets and objects), BigQuery (for tables and datasets), and Pub/Sub (for topics)

2. **Key management control**: You maintain ownership and control of the keys, including their lifecycle (creation, rotation, revocation, destruction), access permissions, and location - critical for GDPR's data protection by design principle

3. **Crypto-shredding capability**: CMEK enables crypto-shredding (destroying keys to make data unrecoverable), which supports GDPR's right to erasure requirements

4. **Centralized management**: All keys can be managed centrally through Cloud KMS, simplifying compliance and audit requirements across multiple services

5. **Operational balance**: CMEK provides strong security controls without the operational burden of supplying keys for every operation

### Why Other Options Are Wrong

- **A. Cloud External Key Manager**: While Cloud EKM provides even more control by storing keys outside Google Cloud, it is NOT supported by BigQuery. BigQuery only supports CMEK, making this option incompatible with the requirement to support all five services mentioned

- **C. Customer-supplied encryption keys**: CSEK is explicitly NOT supported by BigQuery and Pub/Sub. The BigQuery documentation clearly states "BigQuery and BigLake tables don't support Customer-Supplied Encryption Keys (CSEK)." This makes CSEK unsuitable for a solution requiring all five services

- **D. Google default encryption**: While all GCP services use encryption at rest by default, you cannot manage or control these keys. Google-managed encryption doesn't provide the key management capabilities needed for GDPR compliance requirements like data sovereignty, key lifecycle control, or crypto-shredding

### References

- [Customer-managed encryption keys (CMEK) | Cloud KMS](https://docs.cloud.google.com/kms/docs/cmek)
- [Customer-managed Cloud KMS keys | BigQuery](https://docs.cloud.google.com/bigquery/docs/customer-managed-encryption)
- [Use customer-managed encryption keys (CMEK) | GKE](https://cloud.google.com/kubernetes-engine/docs/how-to/using-cmek)
- [Customer-managed encryption keys | Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption/customer-managed-keys)
