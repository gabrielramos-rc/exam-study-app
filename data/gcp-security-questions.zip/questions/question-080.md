# Question 080

**Source:** https://www.examtopics.com/discussions/google/view/31140-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Cloud Armor, DDoS protection, IP deny list, load balancer

---

## Question

An engineering team is launching a web application that will be public on the internet. The web application is hosted in multiple GCP regions and will be directed to the respective backend based on the URL request. Your team wants to avoid exposing the application directly on the internet and wants to deny traffic from a specific list of malicious IP addresses. Which solution should your team implement to meet these requirements?
## Choices

- **A.** Cloud Armor Most Voted
- **B.** Network Load Balancing
- **C.** SSL Proxy Load Balancing
- **D.** NAT Gateway

---

## Community

**Most Voted:** A


**Votes:** A: 100% (10 total)


**Top Comments:**

- (8 upvotes) Think so

- (5 upvotes) you are correct. Answer is A The Cloud armor able to directed user traffic to an external HTTP(S) load balancer enters the PoP closest to the user in Premium Tier. https://cloud.google.com/armor/docs/

- (4 upvotes) A Is the only ans because you are asked to limit access by IP and CA is the only option

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Cloud Armor is the correct solution because it specifically addresses all the requirements:

1. **IP Deny Lists**: Cloud Armor security policies allow you to create deny rules based on IP addresses or CIDR ranges. You can block specific malicious IP addresses using rules like `--src-ip-ranges "192.0.2.0/24","198.51.100.0/24" --action "deny-403"`. For large deny lists, you can use address groups to manage thousands of IP addresses with a single security policy rule.

2. **Edge Protection**: Cloud Armor operates at Google's network edge, intercepting traffic before it reaches your backend services. This prevents direct exposure of your application to the internet by filtering malicious requests "as close as possible to the source of incoming traffic."

3. **Multi-Region Support with Load Balancers**: Cloud Armor integrates with Google Cloud load balancers (HTTPS Load Balancers, SSL Proxy Load Balancers, etc.) that support URL-based routing to backends across multiple regions. The security policy is attached to the load balancer's backend service, providing centralized protection.

4. **Layer 3-7 Filtering**: Cloud Armor supports rules that match on network attributes from Layers 3 through 7, enabling sophisticated traffic filtering beyond just IP addresses (geography, ASN, HTTP headers, etc.).

The architecture allows traffic to flow through: Client → Cloud Armor (at Google edge) → Load Balancer → Backend Services, ensuring malicious IPs are blocked before consuming any backend resources.

### Why Other Options Are Wrong

- **B. Network Load Balancing**: Network Load Balancing is a Layer 4 (TCP/UDP) load balancer that distributes traffic but does not provide security features like IP deny lists or protection against malicious traffic. It's designed for performance and availability, not security filtering.

- **C. SSL Proxy Load Balancing**: While SSL Proxy Load Balancing provides SSL/TLS termination and can distribute traffic globally, it does not inherently provide IP blocking capabilities or security policy enforcement. It would need Cloud Armor attached to it to provide the IP deny list functionality.

- **D. NAT Gateway**: Cloud NAT is designed for outbound traffic scenarios, allowing private instances to access the internet without public IP addresses. It does not provide inbound traffic protection, load balancing, or IP deny list capabilities for public-facing applications.

### References

- [Security policy overview | Google Cloud Armor](https://docs.cloud.google.com/armor/docs/security-policy-overview)
- [Configure Cloud Armor security policies](https://docs.cloud.google.com/armor/docs/configure-security-policies)
- [Common use cases for security policies](https://docs.cloud.google.com/armor/docs/common-use-cases)
