# Question 171

**Source:** https://www.examtopics.com/discussions/google/view/79861-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, policy constraints, compute.trustedImageProjects, image access control, IAM

---

## Question

You have created an OS image that is hardened per your organization's security standards and is being stored in a project managed by the security team. As a Google Cloud administrator, you need to make sure all VMs in your Google Cloud organization can only use that specific OS image while minimizing operational overhead. What should you do? (Choose two.)
## Choices

- **A.** Grant users the compute.imageUser role in their own projects.
- **B.** Grant users the compute.imageUser role in the OS image project. Most Voted
- **C.** Store the image in every project that is spun up in your organization.
- **D.** Set up an image access organization policy constraint, and list the security team managed project in the project's allow list. Most Voted
- **E.** Remove VM instance creation permission from users of the projects, and only allow you and your team to create VM instances.

---

## Community

**Most Voted:** BD


**Votes:** AD: 12% | BD: 88% (24 total)


**Top Comments:**

- (10 upvotes) Thank you for sharing link, BD correct

- (3 upvotes) the compute.imageUser is a Permission to list and read images without having other permissions on the image. Granting this role at the project level gives users the ability to list all images in the p

- (3 upvotes) Sorry Answer BD

---

## Answer

**Correct:** B, D

**Confidence:** high

### Explanation

This question requires two complementary controls to ensure all VMs organization-wide can only use the hardened OS image:

**Option B (Grant compute.imageUser role in the OS image project)** is correct because users need IAM permissions to access custom images stored in the security team's project. The `roles/compute.imageUser` role provides the minimum permissions required to list, read, and use images without granting other permissions. This role must be granted in the project where the image resides (the security team's project), not in users' own projects.

**Option D (Set up organization policy constraint)** is correct because the `constraints/compute.trustedImageProjects` organization policy constraint is the mechanism to restrict which image projects can be used across the entire organization. By setting this constraint at the organization level and adding only the security team's project to the allowed list, you enforce that all VM instances can only use images from that specific project. This prevents users from using any public images (debian-cloud, ubuntu-cloud, etc.) or images from other projects.

Together, these two controls create a complete solution:
- **Organization policy (D)**: Restricts the source of images to only the security team's project
- **IAM role (B)**: Grants necessary access permissions to use images from that project

This approach minimizes operational overhead because it requires only one-time configuration at the organization level, automatically applying to all current and future projects without per-project management.

### Why Other Options Are Wrong

- **A.** Granting compute.imageUser in users' own projects is incorrect because the hardened image is stored in the security team's project, not in users' projects. IAM permissions must be granted in the project where the resource (image) resides.

- **C.** Storing the image in every project creates massive operational overhead and defeats the purpose of centralized image management. This approach requires manual replication, wastes storage, creates version control issues, and makes updates extremely difficult when the image needs to be updated or patched.

- **E.** Removing VM creation permissions is unnecessarily restrictive and creates a bottleneck. This approach doesn't scale and adds significant operational overhead by requiring the admin team to create all VMs. The goal is to restrict image sources while still allowing users to self-service VM creation with approved images.

### References

- [Setting up trusted image policies](https://docs.cloud.google.com/compute/docs/images/restricting-image-access)
- [Managing access to custom images](https://docs.cloud.google.com/compute/docs/images/managing-access-custom-images)
- [Organization policy constraints](https://docs.cloud.google.com/resource-manager/docs/organization-policy/org-policy-constraints)
