# Question 280

**Source:** https://www.examtopics.com/discussions/google/view/147074-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Identity-Aware Proxy, IAP, Access Context Manager, access level, Cloud Run, IP restrictions, group-based access

---

## Question

Your organization has an application hosted in Cloud Run. You must control access to the application by using Cloud Identity-Aware Proxy (IAP) with these requirements:
- Only users from the AppDev group may have access.
- Access must be restricted to internal network IP addresses.

What should you do?

## Choices

- **A.** Deploy a VPN gateway and instruct the AppDev group to connect to the company network before accessing the application.
- **B.** Create an access level that includes conditions for internal IP address ranges and AppDev groups. Apply this access level to the application's IAP policy. Most Voted
- **C.** Configure firewall rules to limit access to IAP based on the AppDev group and source IP addresses.
- **D.** Configure IAP to enforce multi-factor authentication (MFA) for all users and use network intrusion detection systems (NIDS) to block unauthorized access attempts.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (5 total)


**Top Comments:**

- (1 upvotes) An access level is a set of attributes assigned to requests based on their origin. Using information such as device type, IP address, and user identity, you can designate what level of access to grant

- (1 upvotes) I think it's B.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B is the correct solution because it leverages **Access Context Manager** to create access levels that combine both IP-based and identity-based conditions, then applies these access levels to IAP policies through IAM conditional bindings.

Here's how this works:

1. **Access Levels in Access Context Manager**: You create an access level that defines conditions including:
   - Internal IP address ranges (CIDR blocks for your corporate network)
   - Group membership (AppDev group)

2. **Apply to IAP Policy**: Once the access level is created, you apply it to the Cloud Run application's IAP policy by:
   - Adding the AppDev group as a principal
   - Assigning the "IAP-secured Web App User" role
   - Adding a conditional binding that references the access level (e.g., `"accessPolicies/ORGANIZATION_NUMBER/accessLevels/ACCESS_LEVEL_NAME" in request.auth.access_levels`)

3. **Context-Aware Access**: This approach is called "context-aware access" and allows IAP to evaluate both user identity (group membership) and contextual attributes (source IP address) before granting access to the Cloud Run application.

This solution directly addresses both requirements: restricting access to the AppDev group AND limiting access to internal network IP addresses, all within the IAP framework.

### Why Other Options Are Wrong

- **A:** While a VPN gateway would technically limit access to internal network users, it's an infrastructure-heavy workaround that doesn't use IAP's native capabilities for access control. This adds unnecessary complexity and doesn't leverage the context-aware access features that IAP provides. Additionally, it requires manual user action (connecting to VPN) rather than enforcing access policy automatically.

- **C:** Firewall rules cannot filter based on group membership - they only work at the network layer (IP addresses, ports, protocols). Firewall rules have no awareness of Cloud Identity groups or user identities. Additionally, you cannot configure firewall rules to "limit access to IAP" based on groups - this conflates network-level controls with application-level identity controls.

- **D:** MFA enforcement addresses authentication strength but doesn't restrict access to the AppDev group specifically, nor does it limit access by IP address. NIDS (Network Intrusion Detection Systems) are reactive security monitoring tools that detect suspicious activity, not proactive access control mechanisms. This option completely fails to meet the stated requirements of group-based and IP-based access restrictions.

### References

- [Setting up context-aware access with Identity-Aware Proxy](https://docs.cloud.google.com/iap/docs/cloud-iap-context-aware-access-howto)
- [Configure IAP for Cloud Run](https://docs.cloud.google.com/run/docs/securing/identity-aware-proxy-cloud-run)
- [Manage access to IAP-secured resources](https://docs.cloud.google.com/iap/docs/managing-access)
