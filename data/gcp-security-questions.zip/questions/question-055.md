# Question 055

**Source:** https://www.examtopics.com/discussions/google/view/29917-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Managing authentication
**Tags:** MFA, multi-factor authentication, phishing protection, credential security, password policy

---

## Question

An organization receives an increasing number of phishing emails. Which method should be used to protect employee credentials in this situation?
## Choices

- **A.** Multifactor Authentication Most Voted
- **B.** A strict password policy
- **C.** Captcha on login pages
- **D.** Encrypted emails

---

## Community

**Most Voted:** A


**Votes:** A: 69% | D: 31% (16 total)


**Top Comments:**

- (11 upvotes) https://cloud.google.com/blog/products/g-suite/protecting-you-against-phishing

- (5 upvotes) Agree with A

- (4 upvotes) A https://cloud.google.com/blog/products/g-suite/7-ways-admins-can-help-secure-accounts-against-phishing-g-suite

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Multifactor Authentication (MFA) is the most effective method to protect employee credentials against phishing attacks. Even if an attacker successfully steals a user's password through a phishing email, they still cannot access the account without the second authentication factor. As Google Cloud documentation states: "Even if your password is stolen, hackers still need an additional factor to be able to access your account."

MFA requires "another proof of identity, known as an authentication factor, to successfully sign in to an account." This creates a layered defense where credential theft alone is insufficient for account compromise. Google strongly recommends enforcing multi-factor authentication, particularly with phishing-resistant mechanisms such as Titan Security Keys, to help prevent phishing attacks.

The documentation emphasizes that when the MFA requirement is enforced, users must have MFA enabled to sign in to the Google Cloud console or Firebase console. If someone gets access to your password and tries to sign in from an untrusted device, Google requests the second factor, preventing unauthorized access.

### Why Other Options Are Wrong

- **B:** A strict password policy helps prevent weak passwords but does nothing to protect against phishing attacks where users are tricked into revealing their credentials. Even the strongest password is vulnerable to phishing.

- **C:** CAPTCHA on login pages helps prevent automated bot attacks and credential stuffing, but it doesn't protect against phishing. A user can still be phished for their credentials, and the attacker can manually solve the CAPTCHA when logging in.

- **D:** Encrypted emails protect the confidentiality of email content in transit but do not prevent users from being deceived by phishing emails or protect credentials once they've been compromised. Encryption doesn't stop users from clicking malicious links or entering credentials on fake login pages.

### References

- [Multi-factor authentication requirement for Google Cloud](https://docs.cloud.google.com/docs/authentication/mfa-requirement)
- [Best practices for protecting against cryptocurrency mining attacks](https://docs.cloud.google.com/architecture/security/bps-for-protecting-against-crytocurrency-attacks)
