# Question 244

**Source:** https://www.examtopics.com/discussions/google/view/126784-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** IAM conditions, BigQuery, time-based access, temporal access control

---

## Question

Your company’s users access data in a BigQuery table. You want to ensure they can only access the data during working hours. What should you do?
## Choices

- **A.** Assign a BigQuery Data Viewer role along with an IAM condition that limits the access to specified working hours. Most Voted
- **B.** Run a gsutil script that assigns a BigQuery Data Viewer role, and remove it only during the specified working hours.
- **C.** Assign a BigQuery Data Viewer role to a service account that adds and removes the users daily during the specified working hours.
- **D.** Configure Cloud Scheduler so that it triggers a Cloud Functions instance that modifies the organizational policy constraint for BigQuery during the specified working hours.

---

## Community

**Most Voted:** A


**Votes:** A: 86% | D: 14% (7 total)


**Top Comments:**

- (2 upvotes) The correct answer is A. Assign a BigQuery Data Viewer role along with an IAM condition that limits the access to specified working hours. IAM conditions in Google Cloud can be used to fine-tune acces

- (1 upvotes) Anyone else take the exam recently? Handful of new questions or all new?

- (1 upvotes) It's been a year since the last update, hopefully there will be an update soon

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

IAM Conditions provide a native, declarative way to enforce time-based access controls on BigQuery resources. By assigning the BigQuery Data Viewer role with an IAM condition using the `request.time` attribute, you can restrict access to specific hours automatically and reliably.

The condition expression would use `request.time.getHours()` to evaluate the current time in a specified timezone. For example, to limit access to 9 AM - 5 PM Berlin time:

```
request.time.getHours('Europe/Berlin') >= 9 && request.time.getHours('Europe/Berlin') <= 17
```

This approach is:
- **Fully managed**: Google Cloud automatically evaluates the condition on every access attempt
- **Secure**: No manual intervention or scripting required, reducing human error
- **Scalable**: Works for any number of users without additional infrastructure
- **Real-time**: Access is granted/denied immediately based on current time
- **Auditable**: All access attempts are logged with condition evaluation results

IAM conditions can be applied at organization, folder, project, or dataset levels, providing flexible enforcement across your resource hierarchy.

### Why Other Options Are Wrong

- **B:** Using gsutil scripts to dynamically assign/remove IAM roles is operationally complex, error-prone, and creates a management burden. Scripts could fail, leaving users with incorrect permissions. Additionally, gsutil is for Cloud Storage, not BigQuery IAM management. This approach requires constant execution and doesn't scale well.

- **C:** Using a service account to add/remove users daily is unnecessarily complex and creates several problems: requires custom automation infrastructure, introduces security risks (service account needs broad IAM permissions), creates audit trail gaps during user modifications, and is operationally inefficient compared to declarative conditions.

- **D:** Organization policy constraints control what types of resources can be created or configured, not who can access existing data. They don't provide time-based access control for data viewing. Using Cloud Scheduler and Cloud Functions to modify organization policies is architecturally incorrect for this use case and adds unnecessary complexity and cost.

### References

- [Control access with IAM Conditions - BigQuery](https://docs.cloud.google.com/bigquery/docs/conditions)
- [Overview of IAM Conditions](https://docs.cloud.google.com/iam/docs/conditions-overview)
