# Question 051

**Source:** https://www.examtopics.com/discussions/google/view/30125-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, compute.trustedImageProjects, policy constraints

---

## Question

You want to limit the images that can be used as the source for boot disks. These images will be stored in a dedicated project. What should you do?
## Choices

- **A.** Use the Organization Policy Service to create a compute.trustedimageProjects constraint on the organization level. List the trusted project as the whitelist in an allow operation. Most Voted
- **B.** Use the Organization Policy Service to create a compute.trustedimageProjects constraint on the organization level. List the trusted projects as the exceptions in a deny operation.
- **C.** In Resource Manager, edit the project permissions for the trusted project. Add the organization as member with the role: Compute Image User.
- **D.** In Resource Manager, edit the organization permissions. Add the project ID as member with the role: Compute Image User.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (10 total)


**Top Comments:**

- (13 upvotes) Correct Answer is: A. Option B suggests listing the trusted projects as exceptions in a deny operation, which is not necessary or recommended. It's simpler and more secure to explicitly allow only the

- (4 upvotes) Nope, I think I am getting confused. The correct answer is A.

- (4 upvotes) Yes, A made sense to me too.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is the correct approach to restrict boot disk images to a trusted project. The `constraints/compute.trustedImageProjects` organization policy constraint uses a list policy with an **allow operation** (allowedValues) to specify which projects are trusted sources for VM images.

The proper configuration uses:
```yaml
constraint: constraints/compute.trustedImageProjects
listPolicy:
  allowedValues:
    - projects/YOUR_TRUSTED_PROJECT
```

This whitelist approach explicitly defines which image projects can be used as sources for boot disks. When this constraint is applied at the organization level, it ensures that all projects within the organization can only create VMs using images from the specified trusted project(s). The constraint uses the format `projects/IMAGE_PROJECT` where IMAGE_PROJECT is the ID of the trusted project containing approved images.

This is the recommended best practice for centralized image management, allowing you to maintain a curated set of approved, hardened, and compliant VM images in a dedicated project.

### Why Other Options Are Wrong

- **B:** While Organization Policy Service is correct, using a "deny operation with exceptions" is not the standard approach for this use case. The deny-all approach (`allValues: DENY`) would block all public images but doesn't effectively whitelist your trusted project. The allow operation with a whitelist is the proper configuration method for specifying trusted image projects.

- **C:** This approach is backwards and incorrect. You cannot add an organization as a member with a role in Resource Manager - organizations are at the top of the hierarchy and contain projects, not the other way around. Additionally, the Compute Image User role controls who can use images, not which images can be used. This doesn't enforce image restrictions across the organization.

- **D:** This approach is also incorrect for similar reasons. Adding a project ID as a member of an organization doesn't make sense in GCP's resource hierarchy. Organizations contain projects, and you cannot grant a project IAM roles on an organization. Furthermore, IAM roles control access permissions, not organizational policy constraints that restrict which resources can be used.

### References

- [Setting up trusted image policies - Compute Engine Documentation](https://docs.cloud.google.com/compute/docs/images/restricting-image-access)
- [Introduction to the Organization Policy Service](https://docs.cloud.google.com/resource-manager/docs/organization-policy/overview)
