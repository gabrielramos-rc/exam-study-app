# Question 094

**Source:** https://www.examtopics.com/discussions/google/view/82897-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, Cloud DLP, de-identification, tokenization, pseudonymization, BigQuery

---

## Question

You are responsible for protecting highly sensitive data in BigQuery. Your operations teams need access to this data, but given privacy regulations, you want to ensure that they cannot read the sensitive fields such as email addresses and first names. These specific sensitive fields should only be available on a need-to- know basis to the Human Resources team. What should you do?
## Choices

- **A.** Perform data masking with the Cloud Data Loss Prevention API, and store that data in BigQuery for later use.
- **B.** Perform data redaction with the Cloud Data Loss Prevention API, and store that data in BigQuery for later use.
- **C.** Perform data inspection with the Cloud Data Loss Prevention API, and store that data in BigQuery for later use.
- **D.** Perform tokenization for Pseudonymization with the Cloud Data Loss Prevention API, and store that data in BigQuery for later use. Most Voted

---

## Community

**Most Voted:** D


**Votes:** A: 19% | D: 81% (16 total)


**Top Comments:**

- (5 upvotes) D. Perform tokenization for Pseudonymization with the Cloud Data Loss Prevention API, and store that data in BigQuery for later use.

- (5 upvotes) Both A &amp; D will do the job. But, A is preferred as the data is PII and needs to be secure. https://cloud.google.com/dlp/docs/pseudonymization#how-tokenization-works Why A is not a apt response: ht

- (4 upvotes) A https://cloud.google.com/bigquery/docs/column-data-masking-intro

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Tokenization for pseudonymization is the correct approach because it provides **reversible de-identification** that allows different access levels based on team roles. When you tokenize sensitive data using Cloud DLP's cryptographic methods (such as format-preserving encryption with `CryptoReplaceFfxFpeConfig` or deterministic encryption), the original values are replaced with encrypted tokens that maintain data utility for operations teams while protecting privacy.

The key advantages for this scenario:

1. **Operations teams** can query and work with the tokenized BigQuery data without seeing actual sensitive values (email addresses, first names)
2. **HR team** can re-identify the data using the cryptographic key to access original values on a need-to-know basis
3. **Referential integrity** is maintained - the same email always produces the same token, allowing joins and analytics
4. **Compliance** is achieved - sensitive PII is protected while maintaining data utility

Cloud DLP supports multiple tokenization approaches including format-preserving encryption (FFX) and deterministic encryption (AES-SIV), both of which are reversible with proper key management through Cloud KMS.

### Why Other Options Are Wrong

- **A (Masking):** Character masking replaces sensitive data with fixed symbols (e.g., "###") and is **irreversible**. Once data is masked, the original values cannot be recovered, preventing the HR team from accessing the actual email addresses and names when needed. This is a one-way transformation.

- **B (Redaction):** Redaction completely removes sensitive data, leaving gaps in the content. This is also **irreversible** and provides no mechanism for the HR team to access the original values. The data is permanently lost, which doesn't meet the requirement for need-to-know access.

- **C (Inspection):** Data inspection only **identifies and classifies** sensitive data using Cloud DLP's detectors - it doesn't transform or protect the data. The sensitive fields would remain in plaintext in BigQuery, violating the requirement to prevent operations teams from reading them.

### References

- [De-identifying sensitive data | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/deidentify-sensitive-data)
- [De-identification and re-identification of PII in large-scale datasets](https://docs.cloud.google.com/architecture/de-identification-re-identification-pii-using-cloud-dlp)
- [Introduction to column-level access control | BigQuery](https://docs.cloud.google.com/bigquery/docs/column-level-security-intro)
- [Data Masking/Tokenization from Cloud Storage to BigQuery template](https://docs.cloud.google.com/dataflow/docs/guides/templates/provided/dlp-text-to-bigquery)
