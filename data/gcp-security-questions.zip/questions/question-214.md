# Question 214

**Source:** https://www.examtopics.com/discussions/google/view/117318-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** encryption in use, Confidential VM, Confidential Computing, organization policy, health information

---

## Question

Your organization processes sensitive health information. You want to ensure that data is encrypted while in use by the virtual machines (VMs). You must create a policy that is enforced across the entire organization. What should you do?
## Choices

- **A.** Implement an organization policy that ensures that all VM resources created across your organization use customer-managed encryption keys (CMEK) protection.
- **B.** Implement an organization policy that ensures all VM resources created across your organization are Confidential VM instances. Most Voted
- **C.** Implement an organization policy that ensures that all VM resources created across your organization use Cloud External Key Manager (EKM) protection.
- **D.** No action is necessary because Google encrypts data while it is in use by default.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (7 total)


**Top Comments:**

- (4 upvotes) B - Confidential VM is a type of Compute Engine VM that ensures that your data and applications stay private and encrypted even while in use. + By enabling Confidential Computing organization policy c

- (3 upvotes) B- is correct

- (2 upvotes) B is correct: https://www.youtube.com/watch?v=cAEGCE1vNh4&amp;t=22s

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Confidential VM instances are specifically designed to encrypt data **while in use** (in memory) through hardware-based memory encryption. This is the only Google Cloud feature that provides encryption-in-use protection for VM workloads processing sensitive health information.

Google Cloud provides the **"Restrict Non-Confidential Computing"** organization policy constraint (`constraints/compute.restrictNonConfidentialComputing`) that can be applied at the organization level to enforce that all new VM instances must be Confidential VMs. This ensures organization-wide compliance with the requirement to encrypt data in use.

Confidential VMs use hardware technologies like:
- **AMD SEV/SEV-SNP**: Hardware-based memory encryption through the AMD Secure Processor
- **Intel TDX**: Hardware extensions for managing and encrypting memory in isolated trust domains
- **NVIDIA Confidential Computing**: TEE (Trusted Execution Environment) for GPU workloads

The policy can be configured via gcloud:
```
gcloud resource-manager org-policies deny \
    constraints/compute.restrictNonConfidentialComputing compute.googleapis.com \
    --organization=ORGANIZATION_ID
```

### Why Other Options Are Wrong

- **A:** CMEK (Customer-Managed Encryption Keys) provides encryption at rest for stored data (disks, snapshots), not encryption in use. CMEK gives you control over encryption keys but does not encrypt data while it's being processed in VM memory.

- **C:** Cloud EKM (External Key Manager) is another encryption-at-rest solution that allows you to use encryption keys stored in an external key management system outside of Google Cloud. Like CMEK, it does not provide encryption in use for data being actively processed by VMs.

- **D:** This is incorrect. While Google encrypts data at rest by default and data in transit using TLS, data in use (in VM memory) is **not** encrypted by default. You must explicitly enable Confidential VM instances to achieve encryption in use through hardware-based memory encryption.

### References

- [Confidential VM Overview](https://docs.cloud.google.com/confidential-computing/confidential-vm/docs/confidential-vm-overview)
- [Enforcing Confidential VM with Organization Policies](https://docs.cloud.google.com/confidential-computing/confidential-vm/docs/org-policy-constraints)
