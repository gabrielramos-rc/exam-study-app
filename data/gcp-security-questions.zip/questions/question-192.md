# Question 192

**Source:** https://www.examtopics.com/discussions/google/view/117376-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** CI/CD, pipeline security, service account, Workload Identity Federation, GKE security, least privilege

---

## Question

Your organization is rolling out a new continuous integration and delivery (CI/CD) process to deploy infrastructure and applications in Google Cloud. Many teams will use their own instances of the CI/CD workflow. It will run on Google Kubernetes Engine (GKE). The CI/CD pipelines must be designed to securely access Google Cloud APIs. What should you do?
## Choices

- **A.** 1. Create two service accounts, one for the infrastructure and one for the application deployment. 2. Use workload identities to let the pods run the two pipelines and authenticate with the service accounts. 3. Run the infrastructure and application pipelines in separate namespaces.
- **B.** 1. Create a dedicated service account for the CI/CD pipelines. 2. Run the deployment pipelines in a dedicated nodes pool in the GKE cluster. 3. Use the service account that you created as identity for the nodes in the pool to authenticate to the Google Cloud APIs.
- **C.** 1. Create individual service accounts for each deployment pipeline. 2. Add an identifier for the pipeline in the service account naming convention. 3. Ensure each pipeline runs on dedicated pods. 4. Use workload identity to map a deployment pipeline pod with a service account. Most Voted
- **D.** 1. Create service accounts for each deployment pipeline. 2. Generate private keys for the service accounts. 3. Securely store the private keys as Kubernetes secrets accessible only by the pods that run the specific deploy pipeline.

---

## Community

**Most Voted:** C


**Votes:** A: 44% | C: 50% | D: 6% (16 total)


**Top Comments:**

- (5 upvotes) C is best

- (3 upvotes) A is correct

- (2 upvotes) it is D

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C follows all the best practices for securing CI/CD pipelines on GKE:

1. **Individual service accounts per pipeline**: Google Cloud documentation explicitly recommends maintaining a "1:1 relationship between deployment pipelines and service accounts." This allows IAM to differentiate between pipelines, provides clear audit trails, and adheres to the principle of least privilege. Each pipeline gets only the permissions it needs.

2. **Pipeline identifier in naming convention**: The documentation states to "incorporate the name or ID of the deployment pipeline into the service account's email address" for traceability and easier management.

3. **Dedicated pods per pipeline**: Running each pipeline on dedicated pods provides isolation and enables precise workload-to-service-account mapping.

4. **Workload Identity Federation**: This is the recommended method for GKE workloads to authenticate to Google Cloud APIs. It allows pods to use IAM service accounts without storing long-lived credentials like service account keys. Workload Identity Federation for GKE provides "distinct, fine-grained identities and authorization for each application in your cluster."

This approach ensures security through separation of duties, clear accountability, and avoidance of credential exposure risks.

### Why Other Options Are Wrong

- **A:** Only creates two service accounts (infrastructure and application) which violates the 1:1 pipeline-to-service-account principle. The question states "many teams will use their own instances of the CI/CD workflow," requiring individual service accounts per pipeline, not just two shared accounts. This overly broad approach violates least privilege.

- **B:** Uses node-level service account attachment rather than Workload Identity Federation. Attaching service accounts directly to nodes gives all pods on those nodes the same permissions, violating least privilege. The documentation warns against attaching service accounts to VM instances (nodes) used by CI/CD systems. Additionally, a single shared service account contradicts the 1:1 principle.

- **D:** Generates and stores service account private keys, which is explicitly discouraged. The documentation states "service account keys are a security risk if not managed correctly" and to "choose a more secure alternative to service account keys whenever possible." Storing keys as Kubernetes secrets creates spoofing risks, potential credential theft, and management overhead. Workload Identity Federation eliminates the need for key files entirely.

### References

- [Best practices for using service accounts in deployment pipelines](https://docs.cloud.google.com/iam/docs/best-practices-for-using-service-accounts-in-deployment-pipelines)
- [Authenticate to Google Cloud APIs from GKE workloads](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/workload-identity)
- [Best practices for using service accounts securely](https://docs.cloud.google.com/iam/docs/best-practices-service-accounts)
- [About Workload Identity Federation for GKE](https://docs.cloud.google.com/kubernetes-engine/docs/concepts/workload-identity)
