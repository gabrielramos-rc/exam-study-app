# Question 332

**Source:** https://www.examtopics.com/discussions/google/view/311201-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Monitoring and responding to security and compliance events
**Tags:** Access Transparency, audit logging, Google personnel access, compliance

---

## Question

Your organization has recently migrated sensitive customer data to Cloud Storage buckets. For compliance reasons, you must ensure that all vendor data access and administrative access by Google personnel is logged. What should you do?
## Choices

- **A.** Configure Data Access audit logs for Cloud Storage on the project hosting the Cloud Storage buckets.
- **B.** Enable Access Transparency for the organization. Most Voted
- **C.** Configure Data Access audit logs for Cloud Storage at the organization level.
- **D.** Enable Access Transparency for the project hosting the Cloud Storage buckets.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (1 total)

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Access Transparency is specifically designed to log actions taken by Google personnel when they access customer data. The question explicitly requires logging "vendor data access and administrative access by Google personnel," which is exactly what Access Transparency provides.

Key points:
- **Access Transparency logs Google personnel access**: It records when Google employees access your data, including the affected resource, timestamp, reason for access (e.g., support case number), and details about the accessor (location, job category)
- **Organization-level scope**: While configured through a project page, Access Transparency is enabled for the entire organization. This ensures all vendor and Google administrative access across all projects is logged
- **Compliance requirement**: Access Transparency is essential for compliance scenarios requiring audit trails of cloud provider access to customer data

The documentation states: "Cloud Audit Logs record the actions that members of your Google Cloud organization have taken in your Google Cloud resources, whereas Access Transparency logs record the actions taken by Google personnel."

### Why Other Options Are Wrong

- **A:** Data Access audit logs track actions by users and service accounts within your organization (customer actions), not Google personnel access. This would log your own organization's access to Cloud Storage, not vendor/Google employee access.

- **C:** Same issue as option A—Data Access audit logs at any level (project or organization) only track customer actions, not Google personnel access. While organization-level scope is broader than project-level, it still doesn't log vendor administrative access.

- **D:** While Access Transparency does log Google personnel access, it cannot be enabled at the project level. Access Transparency is always enabled at the organization level—even when configured through a project interface, it applies to the entire organization. The documentation explicitly states: "if Access Transparency is configured on a Google Cloud project, Access Transparency is enabled for the entire organization."

### References

- [Overview of Access Transparency](https://docs.cloud.google.com/assured-workloads/access-transparency/docs/overview)
- [Enabling Access Transparency](https://docs.cloud.google.com/assured-workloads/access-transparency/docs/enable)
- [Introduction to Access Transparency](https://docs.cloud.google.com/assured-workloads/access-approval/docs/access-transparency)
