# Question 123

**Source:** https://www.examtopics.com/discussions/google/view/75990-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and implementing security over hybrid and multi-cloud networks
**Tags:** Cloud Interconnect, VPC Service Controls, Private Google Access, restricted.googleapis.com, on-premises connectivity

---

## Question

You need to connect your organization's on-premises network with an existing Google Cloud environment that includes one Shared VPC with two subnets named Production and Non-Production. You are required to: ✑ Use a private transport link. ✑ Configure access to Google Cloud APIs through private API endpoints originating from on-premises environments. ✑ Ensure that Google Cloud APIs are only consumed via VPC Service Controls. What should you do?
## Choices

- **A.** 1. Set up a Cloud VPN link between the on-premises environment and Google Cloud. 2. Configure private access using the restricted.googleapis.com domains in on-premises DNS configurations.
- **B.** 1. Set up a Partner Interconnect link between the on-premises environment and Google Cloud. 2. Configure private access using the private.googleapis.com domains in on-premises DNS configurations.
- **C.** 1. Set up a Direct Peering link between the on-premises environment and Google Cloud. 2. Configure private access for both VPC subnets.
- **D.** 1. Set up a Dedicated Interconnect link between the on-premises environment and Google Cloud. 2. Configure private access using the restricted.googleapis.com domains in on-premises DNS configurations. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (6 total)


**Top Comments:**

- (13 upvotes) D. 1. Set up a Dedicated Interconnect link between the on-premises environment and Google Cloud. 2. Configure private access using the restricted.googleapis.com domains in on-premises DNS configuratio

- (4 upvotes) Tough call between A and D. "✑ Use a private transport link" pushes me towards VPN connection, but the dedicated interconnect probably also fulfills that.

- (3 upvotes) restricted.googleapis.com makes it clear choice

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D is correct because it satisfies all three requirements:

1. **Private transport link**: Dedicated Interconnect provides a direct, private connection between on-premises and Google Cloud. The documentation confirms "Traffic flows directly between networks, not through the public internet." This is a true private transport link.

2. **Private API endpoints from on-premises**: Both Cloud VPN and Cloud Interconnect enable on-premises hosts to access Google APIs privately. The documentation states: "For on-premises hosts, ensure that you have an existing Cloud VPN tunnel or a Cloud Interconnect connection to your VPC network."

3. **VPC Service Controls compliance**: The use of `restricted.googleapis.com` is critical. The documentation emphasizes: "restricted.googleapis.com provides additional risk mitigation for data exfiltration" and "denies access to Google APIs and services that are not supported by VPC Service Controls." This ensures that only VPC Service Controls-compatible APIs are accessible.

The combination of Dedicated Interconnect (private transport) + restricted.googleapis.com (VPC Service Controls enforcement) meets all requirements.

### Why Other Options Are Wrong

- **A:** Cloud VPN does not provide a "private transport link" as required. The documentation clearly states that Cloud VPN uses "IPsec VPN tunnels" that "traverse the public internet." While the tunnels are encrypted, the traffic still goes over the public internet, not a private transport link. Although it correctly uses restricted.googleapis.com, it fails the first requirement.

- **B:** Partner Interconnect provides a private transport link through a service provider, which would satisfy the first requirement. However, it uses `private.googleapis.com` instead of `restricted.googleapis.com`. The documentation explains that `private.googleapis.com` "can allow access to services that are not compliant with VPC Service Controls that might have data exfiltration risks," directly violating the VPC Service Controls requirement.

- **C:** Direct Peering is not mentioned in the documentation as a supported option for private access to Google APIs from on-premises. The documentation only lists Cloud VPN and Cloud Interconnect (Dedicated/Partner) as the valid options for on-premises connectivity to Google APIs. Additionally, this option doesn't specify using restricted.googleapis.com, which is required for VPC Service Controls compliance.

### References

- [Set up private connectivity to Google APIs and services](https://docs.cloud.google.com/vpc-service-controls/docs/set-up-private-connectivity)
- [Private Google Access with VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/private-connectivity)
- [Choosing a Network Connectivity product](https://docs.cloud.google.com/network-connectivity/docs/how-to/choose-product)
- [Cloud Interconnect overview](https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/overview)
