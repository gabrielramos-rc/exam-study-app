# Question 281

**Source:** https://www.examtopics.com/discussions/google/view/147075-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Secure Web Proxy, egress proxy, explicit proxy configuration, client configuration

---

## Question

You just implemented a Secure Web Proxy instance on Google Cloud for your organization. You were able to reach the internet when you tested this configuration on your test instance. However, developers cannot access the allowed URLs on the Secure Web Proxy instance from their Linux instance on Google Cloud. You want to solve this problem with developers. What should you do?
## Choices

- **A.** Configure a Cloud NAT gateway to enable internet access from the developer instance subnet.
- **B.** Ensure that the developers have restarted their instance and HTTP service is enabled.
- **C.** Ensure that the developers have explicitly configured the proxy address on their instance. Most Voted
- **D.** Configure a firewall rule to allow HTTP/S from the developer instance.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (5 total)


**Top Comments:**

- (1 upvotes) https://cloud.google.com/secure-web-proxy/docs/overview Secure Web Proxy is a cloud first service that helps you secure egress web traffic (HTTP/S). You configure your clients to explicitly use Secure

- (1 upvotes) This step is crucial because Secure Web Proxy acts as an explicit proxy server, which requires clients to have the proxy address configured on their instances to route traffic through the proxy https:

- (1 upvotes) C is good.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Secure Web Proxy operates in **explicit proxy mode**, which means clients must actively configure the proxy address to route traffic through it. Unlike transparent proxies that intercept traffic automatically, explicit proxies require client-side configuration.

The key evidence from the documentation:
- Secure Web Proxy instances in explicit routing mode function as an "explicit proxy"
- Documentation states: "You configure your clients to explicitly use Secure Web Proxy as a gateway"
- Testing examples show using curl with the `-x IP_ADDRESS:443` flag, demonstrating that clients must specify the proxy address

For Linux instances, developers need to configure proxy settings either through:
1. **Environment variables**: Set `http_proxy` and `https_proxy` to point to the Secure Web Proxy IP address and port (443)
2. **Application-specific settings**: Configure individual applications to use the proxy
3. **System-wide proxy settings**: Configure the OS-level proxy settings

Since the test instance was able to reach the internet, the Secure Web Proxy itself is working correctly. The issue is that developers haven't configured their instances to use it.

### Why Other Options Are Wrong

- **A.** Cloud NAT is not needed here. Secure Web Proxy provides egress internet access, and adding Cloud NAT would create an alternative path that bypasses the proxy, defeating its security purpose. The proxy itself handles internet connectivity when properly configured.

- **B.** Restarting the instance and enabling HTTP service is not the solution. Secure Web Proxy requires explicit configuration on the client side. Simply restarting without configuring the proxy address will not enable connectivity through the proxy.

- **D.** Firewall rules for HTTP/S are not the issue. If the test instance successfully accessed the internet through the proxy, firewall connectivity to the proxy is already working. The problem is the lack of client-side proxy configuration, not network-level blocking.

### References

- [Secure Web Proxy Overview](https://docs.cloud.google.com/secure-web-proxy/docs/overview)
- [Quickstart: Deploy a Secure Web Proxy instance](https://docs.cloud.google.com/secure-web-proxy/docs/quickstart)
