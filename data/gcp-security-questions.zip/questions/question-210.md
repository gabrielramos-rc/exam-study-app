# Question 210

**Source:** https://www.examtopics.com/discussions/google/view/117314-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Cloud Asset Inventory, Web Security Scanner, Security Command Center, vulnerability scanning, publicly exposed assets

---

## Question

Your company uses Google Cloud and has publicly exposed network assets. You want to discover the assets and perform a security audit on these assets by using a software tool in the least amount of time. What should you do?
## Choices

- **A.** Run a platform security scanner on all instances in the organization.
- **B.** Identify all external assets by using Cloud Asset Inventory, and then run a network security scanner against them. Most Voted
- **C.** Contact a Google approved security vendor to perform the audit.
- **D.** Notify Google about the pending audit, and wait for confirmation before performing the scan.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (8 total)


**Top Comments:**

- (2 upvotes) Should be B

- (1 upvotes) The most efficient approach to discover publicly exposed network assets and perform a security audit on them in the least amount of time is: B. Identify all external assets by using Cloud Asset Invent

- (1 upvotes) Option A (Running a platform security scanner on all instances) might be time-consuming, especially if you have a large number of instances, and it doesn't address other types of publicly exposed asse

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B is the correct approach for discovering and auditing publicly exposed network assets in the least amount of time. This two-step process leverages native Google Cloud tools:

1. **Cloud Asset Inventory** automatically discovers and inventories all Google Cloud resources across your organization, including identifying resources that are publicly exposed. Cloud Asset Inventory is designed to "find resources that are over-permissioned, publicly exposed, or unused to minimize attack surface." Asset discovery happens automatically without requiring manual configuration, and asset updates are typically available within minutes.

2. **Web Security Scanner** (part of Security Command Center) performs actual security audits by scanning publicly accessible web applications for vulnerabilities. It identifies security issues across OWASP Top Ten categories including XSS, SQL injection, outdated libraries, misconfigured headers, and more. Web Security Scanner supports public URLs and IPs on App Engine, GKE, and Compute Engine applications.

This combination provides the fastest path to both asset discovery and security auditing using Google Cloud's built-in security tools. Cloud Asset Inventory handles the "discover" requirement, while Web Security Scanner (or other Security Command Center scanning capabilities) handles the "security audit" requirement.

### Why Other Options Are Wrong

- **A:** Running a generic "platform security scanner" on all instances is inefficient because you need to first identify which assets are publicly exposed. This approach wastes time scanning internal-only resources and doesn't leverage Google Cloud's purpose-built asset discovery capabilities.

- **C:** Contacting an external security vendor adds unnecessary time and cost to the process. The requirement is to complete the audit "in the least amount of time," and Google Cloud provides native tools (Cloud Asset Inventory and Web Security Scanner) that can accomplish this task immediately without vendor engagement.

- **D:** There is no requirement to notify Google or wait for confirmation before scanning your own Google Cloud assets. You have the right to perform security audits on your own infrastructure using appropriate tools. This option would introduce significant delays and is completely unnecessary.

### References

- [Cloud Asset Inventory overview](https://docs.cloud.google.com/asset-inventory/docs/asset-inventory-overview)
- [Overview of Web Security Scanner](https://docs.cloud.google.com/security-command-center/docs/concepts-web-security-scanner-overview)
- [Security Command Center documentation](https://docs.cloud.google.com/security-command-center/docs)
- [Configuring asset discovery using the Security Command Center API](https://docs.cloud.google.com/security-command-center/docs/how-to-api-configure-asset-discovery)
