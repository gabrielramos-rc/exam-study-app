# Question 016

**Source:** https://www.examtopics.com/discussions/google/view/17818-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** CI/CD, infrastructure as code, policy enforcement, security automation, shift-left security

---

## Question

An organization's typical network and security review consists of analyzing application transit routes, request handling, and firewall rules. They want to enable their developer teams to deploy new applications without the overhead of this full review. How should you advise this organization?
## Choices

- **A.** Use Forseti with Firewall filters to catch any unwanted configurations in production.
- **B.** Mandate use of infrastructure as code and provide static analysis in the CI/CD pipelines to enforce policies. Most Voted
- **C.** Route all VPC traffic through customer-managed routers to detect malicious patterns in production.
- **D.** All production applications will run on-premises. Allow developers free rein in GCP as their dev and QA platforms.

---

## Community

**Most Voted:** B


**Votes:** A: 25% | B: 75% (4 total)


**Top Comments:**

- (16 upvotes) Its B. Reasons: 1. They are asking for advise for Developers. (IaC is the suitable as they don't have to worry about managing infrastructure manually). Moreover "An organization’s typical network and 

- (10 upvotes) They want to enable their developer teams to deploy new applications without the overhead of this full review - Questions says this . I am not sure if that feature is available in Forseti as per it, i

- (10 upvotes) kkkkkkkkkkkkk then research than being angry

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B represents Google Cloud's recommended best practice for implementing **shift-left security** through infrastructure as code (IaC) with automated policy enforcement in CI/CD pipelines. This approach directly addresses the organization's goal of reducing security review overhead while maintaining security controls.

Google's official documentation emphasizes that "preventive security controls are most effective when implemented through infrastructure as code." By combining IaC with automation, organizations can:

1. **Run automated policy checks** before deployment using tools like Open Policy Agent (OPA) or `gcloud beta terraform vet` to enforce policy compliance
2. **Detect configuration violations early** in the development lifecycle, before code reaches production
3. **Enable developer velocity** by providing immediate feedback within established guardrails
4. **Reduce manual review burden** by automating routine validation of firewall rules, routing configurations, and request handling patterns

The enterprise foundations blueprint exemplifies this approach by using Terraform for declarative IaC with Cloud Build as the CI/CD automation tool, enforcing policy-as-code checks to validate resources meet expected configurations before deployment.

This shift-left approach moves security validation earlier in the software lifecycle, catching misconfigurations during development rather than in production reviews, allowing developers to deploy with confidence while maintaining security standards.

### Why Other Options Are Wrong

- **A.** Forseti (now deprecated in favor of Security Command Center) provides detective controls that catch issues *after* they reach production. This doesn't reduce the security review overhead - it only detects problems post-deployment. Additionally, Forseti has been superseded by Security Command Center's Security Health Analytics.

- **C.** Routing all VPC traffic through customer-managed routers is operationally complex, creates a single point of failure, and still relies on reactive detection in production rather than preventive controls. This increases overhead rather than reducing it and doesn't address the core problem of deployment friction.

- **D.** Allowing "free rein" in any environment contradicts security best practices and creates configuration drift between dev/QA and production. This approach would likely cause issues when promoting workloads to production and fails to establish consistent security guardrails across environments.

### References

- [Infrastructure as Code on Google Cloud](https://docs.cloud.google.com/docs/terraform/iac-overview)
- [Implement shift-left security](https://docs.cloud.google.com/architecture/framework/security/implement-shift-left-security)
- [Policy validation with Terraform](https://docs.cloud.google.com/docs/terraform/policy-validation)
- [Design secure deployment pipelines](https://docs.cloud.google.com/architecture/design-secure-deployment-pipelines-bp)
