# Question 198

**Source:** https://www.examtopics.com/discussions/google/view/117177-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Configuring network security perimeter controls
**Tags:** Private Google Access, Cloud VPN, hybrid connectivity, on-premises

---

## Question

Your organization has on-premises hosts that need to access Google Cloud APIs. You must enforce private connectivity between these hosts, minimize costs, and optimize for operational efficiency. What should you do?
## Choices

- **A.** Set up VPC peering between the hosts on-premises and the VPC through the internet.
- **B.** Route all on-premises traffic to Google Cloud through an IPsec VPN tunnel to a VPC with Private Google Access enabled. Most Voted
- **C.** Enforce a security policy that mandates all applications to encrypt data with a Cloud Key Management Service (KMS) key before you send it over the network.
- **D.** Route all on-premises traffic to Google Cloud through a dedicated or Partner Interconnect to a VPC with Private Google Access enabled.

---

## Community

**Most Voted:** B


**Votes:** B: 80% | D: 20% (10 total)


**Top Comments:**

- (4 upvotes) I think it optimize operational efficiency too as in Interconnect we have more complexity in network security operation. You are right B should be the answer.

- (3 upvotes) VPN tunnel is less costly than interconnect

- (1 upvotes) While Option B can be cost-effective and simpler to set up initially, Option D provides a more robust, reliable, and scalable solution for private connectivity to Google Cloud APIs. If you have any mo

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B is correct because it satisfies all three requirements: enforces private connectivity, minimizes costs, and optimizes for operational efficiency.

**Private Google Access for on-premises hosts** enables on-premises systems to connect to Google APIs and services through a Cloud VPN tunnel (or Cloud Interconnect). The traffic flows through a secure IPsec VPN tunnel to a VPC network with Private Google Access enabled, then reaches Google APIs without traversing the public internet.

**Cloud VPN is the cost-effective choice** for this scenario. According to Google Cloud documentation, Cloud VPN is designed for organizations with lower bandwidth requirements and provides a cost-effective solution compared to Cloud Interconnect. While both VPN and Interconnect support Private Google Access for on-premises hosts, VPN has lower setup and maintenance costs, directly addressing the requirement to "minimize costs."

**Operational efficiency** is achieved because Cloud VPN is straightforward to configure and manage, requiring only:
- IPsec VPN tunnels to connect on-premises to VPC
- DNS configuration to direct traffic to private.googleapis.com or restricted.googleapis.com
- Cloud Router to advertise custom routes for Google API IP ranges

This provides a complete, secure, and cost-optimized solution for on-premises hosts to access Google Cloud APIs privately.

### Why Other Options Are Wrong

- **A:** VPC peering cannot be established between on-premises hosts and VPC networks. VPC peering only works between two VPC networks within Google Cloud. Additionally, routing "through the internet" contradicts the requirement to "enforce private connectivity."

- **C:** Encrypting data with Cloud KMS before transmission does not address the core requirement of establishing private connectivity from on-premises to Google Cloud APIs. This option focuses on data encryption (which is already handled by VPN's IPsec encryption) but doesn't solve the connectivity problem. It also doesn't minimize costs or provide operational efficiency for API access.

- **D:** While Cloud Interconnect (Dedicated or Partner) does support Private Google Access and provides private connectivity, it does NOT minimize costs. Cloud Interconnect is an enterprise-grade solution with higher setup and maintenance costs compared to Cloud VPN. The documentation states that Interconnect is suitable for high-throughput enterprise connections requiring dedicated bandwidth, which is not necessary just for API access when cost minimization is a priority.

### References

- [Configure Private Google Access for on-premises hosts](https://docs.cloud.google.com/vpc/docs/configure-private-google-access-hybrid)
- [Choose a Network Connectivity product](https://docs.cloud.google.com/network-connectivity/docs/how-to/choose-product)
