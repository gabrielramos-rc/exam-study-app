# Question 032

**Source:** https://www.examtopics.com/discussions/google/view/16999-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** service account, domain-wide delegation, Google Workspace, impersonation, Google Drive

---

## Question

You are creating an internal App Engine application that needs to access a user's Google Drive on the user's behalf. Your company does not want to rely on the current user's credentials. It also wants to follow Google-recommended practices. What should you do?
## Choices

- **A.** Create a new Service account, and give all application users the role of Service Account User.
- **B.** Create a new Service account, and add all application users to a Google Group. Give this group the role of Service Account User.
- **C.** Use a dedicated G Suite Admin account, and authenticate the application's operations with these G Suite credentials.
- **D.** Create a new service account, and grant it G Suite domain-wide delegation. Have the application use it to impersonate the user. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (8 total)


**Top Comments:**

- (16 upvotes) A and B are wrong Service Account User is use to grant someone the ability to impersonate a service account (ref: https://cloud.google.com/iam/docs/understanding-roles) So with those solution, the use

- (3 upvotes) D. Create a new service account, and grant it G Suite domain-wide delegation. Have the application use it to impersonate the user.

- (2 upvotes) Clearly D is the right answer

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Domain-wide delegation is the Google-recommended approach for accessing Google Workspace (G Suite) resources like Google Drive on behalf of users without requiring their manual consent. This solution:

1. **Designed for Google Workspace access**: Domain-wide delegation specifically allows service accounts to authenticate as Google Workspace or Cloud Identity users and access their data (like Google Drive files)

2. **No user credentials needed**: The service account can impersonate any user in the domain to access their Google Drive data without storing or managing individual user credentials

3. **Follows best practices**: Google's documentation explicitly states that domain-wide delegation is the appropriate mechanism for applications that need to access user data in Google Workspace services

4. **How it works**:
   - Create a service account in Google Cloud
   - Grant domain-wide delegation authority in Google Workspace Admin console
   - Application impersonates specific users at runtime using the service account
   - API calls are authorized as the impersonated user, so Drive files are created/accessed in that user's Drive

### Why Other Options Are Wrong

- **A:** The Service Account User role (roles/iam.serviceAccountUser) is for GCP resource impersonation (like attaching service accounts to Compute instances). It does NOT grant access to Google Workspace data like Google Drive. This role contains the iam.serviceAccounts.actAs permission which is for GCP resources, not Workspace APIs.

- **B:** Similar to option A, using a Google Group doesn't change the fundamental issue - the Service Account User role is not designed for accessing Google Workspace user data. This role allows users to impersonate the service account for GCP operations, but doesn't provide the domain-wide delegation needed for Workspace APIs.

- **C:** Using a dedicated G Suite Admin account violates the security principle of least privilege and creates a single point of failure. It also doesn't allow per-user impersonation - all operations would appear to come from the admin account rather than individual users. Google recommends avoiding shared admin credentials.

### References

- [Service accounts overview - Domain-wide delegation](https://docs.cloud.google.com/iam/docs/service-account-overview)
- [Best practices for using service accounts securely](https://docs.cloud.google.com/iam/docs/best-practices-service-accounts)
- [Roles for service account authentication](https://docs.cloud.google.com/iam/docs/service-account-permissions)
- [Control API access with domain-wide delegation](https://support.google.com/a/answer/162106?hl=en)
