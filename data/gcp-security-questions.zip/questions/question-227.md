# Question 227

**Source:** https://www.examtopics.com/discussions/google/view/117241-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Managing authentication
**Tags:** session management, 2-step verification, reauthentication, cookie replay attack, OAuth

---

## Question

You are migrating your users to Google Cloud. There are cookie replay attacks with Google web and Google Cloud CLI SDK sessions on endpoint devices. You need to reduce the risk of these threats. What should you do? (Choose two.)
## Choices

- **A.** Configure Google session control to a shorter duration. Most Voted
- **B.** Set an organizational policy for OAuth 2.0 access token with a shorter duration.
- **C.** Set a reauthentication policy for Google Cloud services to a shorter duration.
- **D.** Configure a third-party identity provider with session management.
- **E.** Enforce Security Key Authentication with 2SV.

---

## Community

**Most Voted:** A


**Votes:** A: 79% | C: 21% (14 total)


**Top Comments:**

- (9 upvotes) B and E Set an organizational policy for OAuth 2.0 access token with a shorter duration is a good approach to reduce the time during which a stolen access token could be exploited. Shortening the acce

- (5 upvotes) A and B A. Configure Google session control to a shorter duration. Reducing the session duration decreases the time a session cookie remains valid, thus limiting the risk of a replay attack. Shorter s

- (4 upvotes) A and E

---

## Answer

**Correct:** C, E

**Confidence:** high

### Explanation

Cookie replay attacks occur when attackers steal session cookies or OAuth tokens from endpoint devices and use them to impersonate legitimate users. The two most effective mitigations are:

**Option C - Reauthentication Policy**: Setting a reauthentication policy for Google Cloud services to a shorter duration forces users to regularly reauthenticate with their password or security key. According to Google Cloud documentation, reauthentication policies invalidate refresh tokens and require users to reauthenticate the gcloud CLI (and other services) at configured intervals (1-24 hours). New customers have a default 16-hour limit. This significantly reduces the window of opportunity for attackers using stolen tokens, as the tokens expire more frequently and require fresh authentication credentials (password or security key) that the attacker doesn't possess.

**Option E - Security Key Authentication with 2SV**: Enforcing security key authentication with 2-step verification (2SV) adds a hardware-based authentication factor that cannot be replayed. Even if an attacker steals session cookies or OAuth tokens, they cannot complete reauthentication when the token expires because they lack the physical security key. The Chrome Enterprise Premium documentation explicitly recommends the SECURITY_KEY method as the most restrictive reauthentication option. This is particularly effective against endpoint-based attacks where cookies/tokens are stolen from compromised devices.

These two controls work synergistically: the reauthentication policy ensures tokens expire regularly, and security key enforcement ensures that when reauthentication is triggered, the attacker cannot proceed without the physical hardware token.

### Why Other Options Are Wrong

- **A:** "Google session control" is too vague and not a specific Google Cloud control mechanism. While session controls exist in Chrome Enterprise Premium via Access Context Manager, they are configured through reauthentication policies (option C), not separately. This option lacks the specificity of option C.

- **B:** There is no organizational policy specifically for OAuth 2.0 access token duration. OAuth token lifetimes are controlled through reauthentication policies and session controls, not through organizational policies. Organizational policies in Google Cloud control resource configurations, not authentication token durations.

- **D:** Configuring a third-party identity provider doesn't inherently solve cookie replay attacks. The issue exists with Google web and gcloud CLI sessions regardless of the identity provider. Additionally, migrating to a third-party IdP is a much more complex solution than implementing Google's native session controls and would not necessarily provide better protection against this specific threat.

### References

- [Best practices for mitigating compromised OAuth tokens for Google Cloud CLI](https://docs.cloud.google.com/architecture/bps-for-mitigating-gcloud-oauth-tokens)
- [Reauthentication | Authentication](https://docs.cloud.google.com/docs/authentication/reauthentication)
- [Configure session controls for re-authentication | Chrome Enterprise Premium](https://docs.cloud.google.com/chrome-enterprise-premium/docs/session-controls-for-reauthentication)
