# Question 186

**Source:** https://www.examtopics.com/discussions/google/view/117324-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, egress policy, service perimeter, external resources

---

## Question

You have stored company approved compute images in a single Google Cloud project that is used as an image repository. This project is protected with VPC Service Controls and exists in the perimeter along with other projects in your organization. This lets other projects deploy images from the image repository project. A team requires deploying a third-party disk image that is stored in an external Google Cloud organization. You need to grant read access to the disk image so that it can be deployed into the perimeter. What should you do?
## Choices

- **A.** Allow the external project by using the organizational policy, constraints/compute.trustedImageProjects.
- **B.** 1. Update the perimeter. 2. Configure the egressTo field to include the external Google Cloud project number as an allowed resource and the serviceName to compute.googleapis.com. 3. Configure the egressFrom field to set identityType to ANY_IDENTITY. Most Voted
- **C.** 1. Update the perimeter. 2. Configure the ingressFrom field to set identityType to ANY_IDENTITY. 3. Configure the ingressTo field to include the external Google Cloud project number as an allowed resource and the serviceName to compute.googleapis.com.
- **D.** 1. Update the perimeter. 2. Configure the egressTo field to set identityType to ANY_IDENTITY. 3. Configure the egressFrom field to include the external Google Cloud project number as an allowed resource and the serviceName to compute.googleapis.com.

---

## Community

**Most Voted:** B


**Votes:** B: 88% | C: 12% (16 total)


**Top Comments:**

- (4 upvotes) A Compute Engine client within a service perimeter calling a Compute Engine create operation where the image resource is outside the perimeter. https://cloud.google.com/vpc-service-controls/docs/ingre

- (4 upvotes) I choose option C. Since the external disk image needs to be deployed into the perimeter, resources inside the perimeter need read access to the external disk image. This requires configuring ingress 

- (4 upvotes) Why not C?

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

To allow resources inside a VPC Service Controls perimeter to access external resources (like a third-party disk image in another organization), you must configure an **egress policy**. The egress policy has two required components that must be configured correctly:

1. **egressTo** - Specifies WHAT resources and operations are allowed outside the perimeter:
   - `resources`: The external project using format `projects/PROJECT_NUMBER`
   - `operations`: The allowed service (`compute.googleapis.com`) and methods

2. **egressFrom** - Specifies WHO (identities within the perimeter) can access those external resources:
   - `identityType: ANY_IDENTITY` - Allows any identity within the perimeter to use this egress rule

Option B correctly configures both fields:
- **egressTo**: Includes the external project number as an allowed resource and specifies `compute.googleapis.com` as the service
- **egressFrom**: Sets `identityType` to `ANY_IDENTITY` to allow any identity in the perimeter to access the external image

This follows the standard VPC Service Controls egress policy structure documented by Google Cloud. When a Compute Engine client within a service perimeter needs to create an instance using an image resource outside the perimeter, an egress policy is required to allow this read access.

### Why Other Options Are Wrong

- **A:** Organization policy constraint `constraints/compute.trustedImageProjects` restricts which image projects can be used across the organization, but it does NOT bypass VPC Service Controls perimeter restrictions. This constraint is about project-level image trust, not perimeter boundary controls. VPC Service Controls operates at a different layer and requires explicit egress policies.

- **C:** Uses **ingress** rules instead of egress rules. Ingress rules control access FROM outside the perimeter TO resources inside the perimeter. This scenario requires the opposite - access FROM inside the perimeter TO external resources (the third-party image), which requires egress rules. Additionally, the field structure is incorrect (ingressFrom/ingressTo vs egressFrom/egressTo).

- **D:** Has the field assignments reversed. It incorrectly puts `identityType` in `egressTo` (which should contain the target resources and operations) and puts the external project number in `egressFrom` (which should contain the source identities). The correct structure is: egressFrom identifies WHO can access (identities), and egressTo identifies WHAT can be accessed (external resources and services).

### References

- [Ingress and egress rules | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/ingress-egress-rules)
- [Protecting resources with VPC Service Controls | Compute Engine](https://docs.cloud.google.com/compute/docs/instances/protecting-resources-vpc-service-controls)
- [Secure data exchange with ingress and egress rules](https://docs.cloud.google.com/vpc-service-controls/docs/secure-data-exchange)
