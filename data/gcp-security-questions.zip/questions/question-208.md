# Question 208

**Source:** https://www.examtopics.com/discussions/google/view/117311-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Security Command Center, Cloud Storage, audit logs, organization policy, public access prevention

---

## Question

Your organization recently activated the Security Command Center (SCC) standard tier. There are a few Cloud Storage buckets that were accidentally made accessible to the public. You need to investigate the impact of the incident and remediate it. What should you do?
## Choices

- **A.** 1. Remove the Identity and Access Management (IAM) granting access to all Users from the buckets. 2. Apply the organization policy storage.uniformBucketLevelAccess to prevent regressions. 3. Query the data access logs to report on unauthorized access.
- **B.** 1. Change permissions to limit access for authorized users. 2. Enforce a VPC Service Controls perimeter around all the production projects to immediately stop any unauthorized access. 3. Review the administrator activity audit logs to report on any unauthorized access.
- **C.** 1. Change the bucket permissions to limit access. 2. Query the bucket's usage logs to report on unauthorized access to the data. 3. Enforce the organization policy storage.publicAccessPrevention to avoid regressions. Most Voted
- **D.** 1. Change bucket permissions to limit access. 2. Query the data access audit logs for any unauthorized access to the buckets. 3. After the misconfiguration is corrected, mute the finding in the Security Command Center.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (11 total)


**Top Comments:**

- (4 upvotes) Option A is not as comprehensive because it doesn't include enforcing the organization policy to prevent regressions (storage.publicAccessPrevention). Option B suggests enforcing VPC Service Controls,

- (2 upvotes) c -looks good

- (2 upvotes) C - usage logs to track access that occurs because a resource has allUsers or allAuthenticatedUsers - https://cloud.google.com/storage/docs/access-logs#should-you-use and the constraint - https://clou

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C provides the complete and correct approach for remediating public Cloud Storage bucket incidents:

1. **Change bucket permissions to limit access** - This immediately addresses the security incident by removing public access (allUsers and allAuthenticatedUsers permissions) from the buckets.

2. **Query the bucket's usage logs** - This is the correct log type for investigating unauthorized access to publicly accessible buckets. Cloud Storage audit logs have a critical limitation: "Cloud Audit Logs does not track access to public objects." Since the buckets were publicly accessible, Data Access audit logs would not have captured the unauthorized access events. Cloud Storage usage logs are the proper mechanism to track who accessed public bucket data.

3. **Enforce storage.publicAccessPrevention organization policy** - This is the correct organization policy constraint to prevent regressions. When applied at the project, folder, or organization level, the `constraints/storage.publicAccessPrevention` constraint restricts public access for all buckets (both new and existing) under that resource, preventing future accidental public exposure.

### Why Other Options Are Wrong

- **A:** Uses data access logs which don't track access to public objects, making investigation impossible. The `storage.uniformBucketLevelAccess` policy enforces uniform bucket-level access (disabling ACLs) but doesn't prevent public access - buckets can still be made public through IAM policies even with uniform bucket-level access enabled.

- **B:** VPC Service Controls perimeters are excessive for this scenario and primarily protect against data exfiltration from within authorized networks. They don't specifically address the public bucket issue and add unnecessary complexity. Administrator activity audit logs only track configuration changes (like who modified IAM policies), not actual data access by unauthorized users.

- **D:** While data access audit logs might be useful after remediation (once public access is removed), they cannot investigate the incident that already occurred when buckets were public. Simply muting the SCC finding without implementing preventive controls (organization policy) ignores the need to prevent future regressions and doesn't follow security best practices.

### References

- [Public access prevention | Cloud Storage](https://docs.cloud.google.com/storage/docs/public-access-prevention)
- [Cloud Audit Logs with Cloud Storage](https://docs.cloud.google.com/storage/docs/audit-logging)
- [Organization policy constraints for Cloud Storage](https://docs.cloud.google.com/storage/docs/org-policy-constraints)
- [Enable public bucket remediation | Security Command Center](https://docs.cloud.google.com/security-command-center/docs/playbooks-public-bucket-acl)
