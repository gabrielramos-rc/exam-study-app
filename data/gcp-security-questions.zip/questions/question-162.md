# Question 162

**Source:** https://www.examtopics.com/discussions/google/view/79850-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Identity-Aware Proxy, IAP, IAM roles, HTTPS access

---

## Question

Which Identity-Aware Proxy role should you grant to an Identity and Access Management (IAM) user to access HTTPS resources?
## Choices

- **A.** Security Reviewer
- **B.** IAP-Secured Tunnel User
- **C.** IAP-Secured Web App User Most Voted
- **D.** Service Broker Operator

---

## Community

**Most Voted:** C


**Votes:** C: 100% (10 total)


**Top Comments:**

- (4 upvotes) C, https://cloud.google.com/iap/docs/managing-access "IAP-Secured Web App User: Grants access to the app and other HTTPS resources that use IAP."

- (3 upvotes) C. IAP-Secured Web App User

- (3 upvotes) Should be C. It is clearly mentioned here in Documentation: https://cloud.google.com/iap/docs/managing-access#roles IAP-Secured Web App User (roles/iap.httpsResourceAccessor)

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

The **IAP-Secured Web App User** role (`roles/iap.httpsResourceAccessor`) is the correct role to grant users access to HTTPS resources protected by Identity-Aware Proxy. This role provides the `iap.webServiceVersions.accessViaIAP` permission, which specifically grants access to App Engine and Compute Engine HTTPS resources protected by IAP.

When IAP is enabled on a resource, it requires login credentials for all connections, and only accounts with the IAP-Secured Web App User role on the project will be granted access to the protected HTTPS applications. This is true even for project owners - the IAP-Secured Web App User role must be explicitly assigned to access IAP-protected web applications.

### Why Other Options Are Wrong

- **A. Security Reviewer:** This role grants permission to view and audit IAP policies, but does not provide access to IAP-secured resources. It's an administrative role for policy review, not for end-user access to applications.

- **B. IAP-Secured Tunnel User:** This role (`roles/iap.tunnelResourceAccessor`) is specifically for accessing VM instances and destination groups secured via IAP TCP forwarding/tunneling, not for accessing HTTPS web applications. This is used for SSH/RDP access through IAP tunnels, not web browsing.

- **D. Service Broker Operator:** This is not an IAP-related role. This role is associated with Service Broker functionality for managing service instances and bindings, completely unrelated to Identity-Aware Proxy access control.

### References

- [Manage access to IAP-secured resources](https://docs.cloud.google.com/iap/docs/managing-access)
- [Identity-Aware Proxy roles and permissions](https://docs.cloud.google.com/iam/docs/roles-permissions/iap)
