# Question 021

**Source:** https://www.examtopics.com/discussions/google/view/16379-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** PCI DSS, egress controls, VPC network controls, compliance

---

## Question

In order to meet PCI DSS requirements, a customer wants to ensure that all outbound traffic is authorized. Which two cloud offerings meet this requirement without additional compensating controls? (Choose two.)
## Choices

- **A.** App Engine
- **B.** Cloud Functions
- **C.** Compute Engine Most Voted
- **D.** Google Kubernetes Engine Most Voted
- **E.** Cloud Storage

---

## Community

**Most Voted:** CD


**Votes:** AB: 39% | AD: 22% | CD: 39% (18 total)


**Top Comments:**

- (18 upvotes) It is CD. App Engine ingress firewall rules are available, but egress rules are not currently available. Per requirements 1.2.1 and 1.3.4, you must ensure that all outbound traffic is authorized. SAQ 

- (7 upvotes) Answer is AB, . App Engine Standard Environment Provides built-in network restrictions and outbound traffic controls Only allows connections to specific Google services and approved external APIs Inhe

- (4 upvotes) hey. can anyone explain why isn't A correct? the decumantion mentions app engine as an option but not compute engine https://cloud.google.com/architecture/pci-dss-compliance-in-gcp

---

## Answer

**Correct:** C, D

**Confidence:** high

### Explanation

PCI DSS sections 1.2 and 1.3 require tight controls on inbound and outbound traffic, specifically requiring that all outbound traffic be authorized and auditable. The two services that meet these requirements without additional compensating controls are:

**Compute Engine (C)** and **Google Kubernetes Engine (D)** both provide complete VPC network controls, including:
- Configurable egress firewall rules that can restrict outbound traffic to authorized destinations
- VPC Flow Logs for auditing all network traffic
- Network tags and service accounts for granular traffic control
- Full network visibility and control over all connections

Google's official PCI DSS compliance documentation explicitly states that "Cloud Run functions and App Engine don't offer a two-way configurable firewall, so you must either create compensating controls or deploy the tokenization service on Compute Engine or Google Kubernetes Engine." This confirms that Compute Engine and GKE are the production environments with complete network controls that satisfy PCI DSS requirements for outbound traffic authorization without needing additional compensating controls.

### Why Other Options Are Wrong

- **A (App Engine):** Does not offer a two-way configurable firewall. According to Google's PCI DSS documentation, App Engine requires either compensating controls or migration to Compute Engine/GKE to meet PCI DSS sections 1.2 and 1.3 requirements for tight traffic controls. App Engine has limited egress control capabilities compared to VPC-based compute services.

- **B (Cloud Functions):** Similar to App Engine, Cloud Functions does not provide two-way configurable firewall capabilities. The serverless nature of Cloud Functions means it lacks the comprehensive VPC network controls needed to fully authorize and audit all outbound traffic without additional compensating controls.

- **E (Cloud Storage):** Cloud Storage is an object storage service, not a compute platform. While it can be secured with VPC Service Controls to control data exfiltration, it doesn't have "outbound traffic" in the traditional networking sense that PCI DSS sections 1.2 and 1.3 address. The question is asking about compute services that generate outbound network connections.

### References

- [Tokenizing sensitive cardholder data for PCI DSS](https://docs.cloud.google.com/architecture/tokenizing-sensitive-cardholder-data-for-pci-dss)
- [PCI Data Security Standard compliance in Google Cloud](https://docs.cloud.google.com/architecture/pci-dss-compliance-in-gcp)
