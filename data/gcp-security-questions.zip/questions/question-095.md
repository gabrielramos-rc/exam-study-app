# Question 095

**Source:** https://www.examtopics.com/discussions/google/view/74821-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, service account, constraints, iam.disableServiceAccountCreation

---

## Question

You are a Security Administrator at your organization. You need to restrict service account creation capability within production environments. You want to accomplish this centrally across the organization. What should you do?
## Choices

- **A.** Use Identity and Access Management (IAM) to restrict access of all users and service accounts that have access to the production environment.
- **B.** Use organization policy constraints/iam.disableServiceAccountKeyCreation boolean to disable the creation of new service accounts.
- **C.** Use organization policy constraints/iam.disableServiceAccountKeyUpload boolean to disable the creation of new service accounts.
- **D.** Use organization policy constraints/iam.disableServiceAccountCreation boolean to disable the creation of new service accounts. Most Voted

---

## Community

**Most Voted:** D


**Votes:** A: 17% | D: 83% (6 total)


**Top Comments:**

- (11 upvotes) Answer D You can use the iam.disableServiceAccountCreation boolean constraint to disable the creation of new service accounts. This allows you to centralize management of service accounts while not re

- (2 upvotes) D. Use organization policy constraints/iam.disableServiceAccountCreation boolean to disable the creation of new service accounts.

- (2 upvotes) D is the answer.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The correct answer is **D** because the organization policy constraint `constraints/iam.disableServiceAccountCreation` is specifically designed to prevent the creation of new service accounts across projects in your organization. When enforced at the organization level, this constraint prevents service account creation in all projects centrally, which directly addresses the requirement to "restrict service account creation capability within production environments...centrally across the organization."

According to Google Cloud documentation, this constraint "lets you centralize management of service accounts while not restricting the other permissions your developers have on projects." When enforced, any attempt to create a service account will fail with the error: `FAILED_PRECONDITION: Service account creation is not allowed on this project.`

This approach provides centralized control and can be applied at the organization level with exemptions for specific projects or folders using conditional policies if needed.

### Why Other Options Are Wrong

- **A:** While IAM can restrict who has the `iam.serviceAccounts.create` permission, this approach is not centralized and requires managing IAM policies across multiple projects individually. It's also more error-prone than using an organization policy constraint that applies uniformly across the entire organization.

- **B:** The `constraints/iam.disableServiceAccountKeyCreation` constraint focuses on preventing the creation of external service account keys and Cloud Storage HMAC keys (credentials), not the creation of service accounts themselves. This constraint controls unmanaged long-term credentials but doesn't prevent service account creation.

- **C:** The `constraints/iam.disableServiceAccountKeyUpload` constraint specifically prevents uploading external public keys to service accounts. It blocks importing pre-existing credentials but has no effect on service account creation itself.

### References

- [Restricting service account usage](https://docs.cloud.google.com/resource-manager/docs/organization-policy/restricting-service-accounts)
- [Troubleshoot organization policy errors for service accounts](https://docs.cloud.google.com/iam/docs/troubleshoot-org-policies)
- [Organization policy constraints](https://docs.cloud.google.com/resource-manager/docs/organization-policy/org-policy-constraints)
