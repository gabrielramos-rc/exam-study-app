# Question 046

**Source:** https://www.examtopics.com/discussions/google/view/17005-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Cloud Bigtable, data replication, multi-region, storage durability, geographic redundancy

---

## Question

A company is deploying their application on Google Cloud Platform. Company policy requires long-term data to be stored using a solution that can automatically replicate data over at least two geographic places. Which Storage solution are they allowed to use?
## Choices

- **A.** Cloud Bigtable
- **B.** Cloud BigQuery Most Voted
- **C.** Compute Engine SSD Disk
- **D.** Compute Engine Persistent Disk

---

## Community

**Most Voted:** B


**Votes:** A: 25% | B: 56% | D: 19% (16 total)


**Top Comments:**

- (15 upvotes) Correct answer is A. B is not correct because: "BigQuery does not automatically provide a backup or replica of your data in another geographic region." https://cloud.google.com/bigquery/docs/availabil

- (8 upvotes) B. Cloud BigQuery Explanation: Cloud BigQuery is a fully managed data warehouse that automatically replicates data across multiple geographic regions to ensure high availability and durability. This a

- (6 upvotes) "In either case, BigQuery automatically stores copies of your data in two different Google Cloud zones within the selected location." your link

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Cloud Bigtable is the only option that provides **automatic replication across multiple geographic regions**. When you create a Bigtable instance with multiple clusters in different regions, Bigtable automatically replicates all data between those clusters without requiring any manual configuration.

Specifically:
- Bigtable instances can have clusters in **up to 8 different regions**
- When you add a second cluster to an instance, **replication starts automatically** - Bigtable immediately begins synchronizing data between clusters
- The replication is **multi-primary** (write to any cluster) and **eventually consistent**
- This configuration provides both geographic redundancy and high availability

The company's requirement is for "automatic" replication over "at least two geographic places" - Bigtable directly satisfies both criteria by automatically maintaining synchronized copies in each cluster's region.

### Why Other Options Are Wrong

- **B (Cloud BigQuery):** While BigQuery multi-region datasets sound promising, they do **NOT** automatically replicate across regions. According to Google Cloud documentation, "multi-regions don't provide regional redundancy. Data is stored in a single region and compute is only provided within that region." BigQuery stores data in only ONE region within the multi-region area (e.g., US multi-region stores data in Iowa, Oregon, OR Oklahoma - not all three). Cross-region replication in BigQuery requires manual setup using cross-region dataset replication features, which is not automatic.

- **C (Compute Engine SSD Disk):** SSD disks are zonal resources with no automatic replication across geographic regions. They exist in a single zone only and provide no built-in geographic redundancy.

- **D (Compute Engine Persistent Disk):** Regional Persistent Disks only replicate **synchronously between two zones in the SAME region** - not across geographic regions. For cross-region replication, you would need to manually configure Asynchronous Replication, which is not automatic and requires explicit setup of primary and secondary disks in different regions.

### References

- [Replication overview | Bigtable](https://docs.cloud.google.com/bigtable/docs/replication-overview)
- [Examples of replication configurations | Bigtable](https://docs.cloud.google.com/bigtable/docs/replication-settings)
- [BigQuery locations](https://docs.cloud.google.com/bigquery/docs/locations)
- [About synchronous disk replication | Compute Engine](https://docs.cloud.google.com/compute/docs/disks/about-regional-persistent-disk)
- [About Asynchronous Replication | Compute Engine](https://docs.cloud.google.com/compute/docs/disks/async-pd/about)
