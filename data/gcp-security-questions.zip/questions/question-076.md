# Question 076

**Source:** https://www.examtopics.com/discussions/google/view/31536-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** encryption at rest, Cloud Storage, customer-supplied encryption keys, CSEK, data encryption key, DEK

---

## Question

Your company is storing sensitive data in Cloud Storage. You want a key generated on-premises to be used in the encryption process. What should you do?
## Choices

- **A.** Use the Cloud Key Management Service to manage a data encryption key (DEK).
- **B.** Use the Cloud Key Management Service to manage a key encryption key (KEK).
- **C.** Use customer-supplied encryption keys to manage the data encryption key (DEK). Most Voted
- **D.** Use customer-supplied encryption keys to manage the key encryption key (KEK).

---

## Community

**Most Voted:** C


**Votes:** A: 3% | C: 53% | D: 45% (38 total)


**Top Comments:**

- (34 upvotes) Reference Links: https://cloud.google.com/kms/docs/envelope-encryption https://cloud.google.com/security/encryption-at-rest/customer-supplied-encryption-keys

- (9 upvotes) Answer is C: Customer-Supplied DEK.

- (3 upvotes) C, KEK is google managed

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Customer-supplied encryption keys (CSEK) are the correct solution when you need to use a key generated on-premises for Cloud Storage encryption. With CSEK, you generate your own AES-256 encryption key (anywhere, including on-premises), encode it in Base64, and provide it with each Cloud Storage operation. Cloud Storage uses this key as a **data encryption key (DEK)** to directly encrypt the object's data, CRC32C checksum, and MD5 hash.

The key is never permanently stored by Google Cloud - it's purged from Cloud Storage servers after each operation completes. Only a cryptographic hash of the key is retained for validation purposes, which cannot be used to decrypt data or recover the original key. This gives you complete control over the encryption key while still leveraging Cloud Storage.

### Why Other Options Are Wrong

- **A:** Cloud KMS manages keys within Google Cloud's infrastructure, not keys generated on-premises. While you can import keys to Cloud KMS, the question specifically asks for on-premises generated keys to be used directly in the encryption process, which is what CSEK provides.

- **B:** Cloud KMS uses customer-managed encryption keys (CMEK) as key encryption keys (KEK) that wrap data encryption keys, but these keys are managed by Google Cloud KMS, not supplied by you for each operation. This doesn't meet the requirement of using a key generated on-premises.

- **D:** Customer-supplied encryption keys function as data encryption keys (DEK), not key encryption keys (KEK). CSEK directly encrypts object data rather than encrypting other keys. KEKs are used in envelope encryption patterns, which is not how CSEK operates.

### References

- [Customer-supplied encryption keys | Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption/customer-supplied-keys)
- [Data encryption options | Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption)
