# Question 143

**Source:** https://www.examtopics.com/discussions/google/view/80496-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** VPC peering, cross-organization, encryption in transit, private IP

---

## Question

Your organization hosts a financial services application running on Compute Engine instances for a third-party company. The third-party company's servers that will consume the application also run on Compute Engine in a separate Google Cloud organization. You need to configure a secure network connection between the Compute Engine instances. You have the following requirements: ✑ The network connection must be encrypted. ✑ The communication between servers must be over private IP addresses. What should you do?
## Choices

- **A.** Configure a Cloud VPN connection between your organization's VPC network and the third party's that is controlled by VPC firewall rules.
- **B.** Configure a VPC peering connection between your organization's VPC network and the third party's that is controlled by VPC firewall rules. Most Voted
- **C.** Configure a VPC Service Controls perimeter around your Compute Engine instances, and provide access to the third party via an access level.
- **D.** Configure an Apigee proxy that exposes your Compute Engine-hosted application as an API, and is encrypted with TLS which allows access only to the third party.

---

## Community

**Most Voted:** B


**Votes:** A: 33% | B: 67% (21 total)


**Top Comments:**

- (4 upvotes) Also ask for private IP communication, so technically no routing (policy or other) should be involved

- (3 upvotes) the traffic between the VPCs is not encrypted by default.

- (3 upvotes) i don't think that Cloud VPN use public IP, but encrypted. ref: https://cloud.google.com/network-connectivity/docs/vpn/concepts/overview &gt; Traffic traveling between the two networks is encrypted by

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

VPC Network Peering is the optimal solution because it satisfies both requirements:

1. **Encryption requirement**: Google Cloud automatically encrypts all private IP traffic within the same VPC or across peered VPC networks at the network layer. According to Google's encryption in transit documentation, "Encryption of private IP traffic within the same VPC or across peered VPC networks within Google Cloud's virtual network is performed at the network layer." Each pair of communicating hosts establishes a session key using a control channel protected by ALTS (Application Layer Transport Security) for authenticated, integrity-protected, and encrypted communications. Session keys are rotated periodically for enhanced security.

2. **Private IP requirement**: VPC peering provides internal IPv4 and IPv6 connectivity, allowing resources in each network to communicate using private IP addresses. Traffic between peered VPCs remains entirely within Google's internal network infrastructure.

3. **Cross-organization support**: VPC peering explicitly supports cross-organization scenarios. The documentation states: "Peered VPC networks can be in the same project, different projects of the same organization, or different projects of different organizations."

4. **Firewall control**: Each VPC network maintains administrative separation and must independently configure VPC firewall rules to control ingress and egress traffic, providing granular security controls while maintaining connectivity.

### Why Other Options Are Wrong

- **A (Cloud VPN):** While Cloud VPN provides IPsec encryption and works across organizations, it is overly complex for this scenario. VPN is typically used for hybrid connectivity (connecting Google Cloud to on-premises networks) or when you need explicit IPsec encryption. For VPC-to-VPC connectivity within Google Cloud, VPC peering is simpler, has lower latency, and provides automatic encryption for private IP traffic without the overhead of VPN tunnel management.

- **C (VPC Service Controls):** VPC Service Controls creates security perimeters around Google Cloud resources to prevent data exfiltration, but it does not establish network connectivity between VPCs. It's a data protection control, not a networking solution. It cannot enable Compute Engine instances in different organizations to communicate via private IPs.

- **D (Apigee proxy):** Apigee is an API management platform designed for exposing and managing APIs, not for providing VM-to-VM connectivity. This solution would expose the application through public endpoints (even if encrypted with TLS) and would not provide direct private IP communication between Compute Engine instances. It also adds unnecessary complexity and latency for simple inter-VPC communication.

### References

- [VPC Network Peering](https://docs.cloud.google.com/vpc/docs/vpc-peering)
- [Encryption in transit for Google Cloud](https://docs.cloud.google.com/docs/security/encryption-in-transit)
