# Question 317

**Source:** https://www.examtopics.com/discussions/google/view/150189-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Cloud Interconnect, MACsec, hybrid connectivity, encryption in transit, on-premises

---

## Question

You work for a large organization that recently implemented a 100GB Cloud Interconnect connection between your Google Cloud and your on-premises edge router. While routinely checking the connectivity, you noticed that the connection is operational but there is an error message that indicates MACsec is operationally down. You need to resolve this error. What should you do?
## Choices

- **A.** Ensure that the Cloud Interconnect connection supports MACsec.
- **B.** Ensure that the on-premises router is not down.
- **C.** Ensure that the active pre-shared key created for MACsec is not expired on both the on-premises and Google edge routers.
- **D.** Ensure that the active pre-shared key matches on both the on-premises and Google edge routers. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (5 total)


**Top Comments:**

- (2 upvotes) Answer D

- (1 upvotes) You successfully enabled MACsec on your Cloud Interconnect connection and on your on-premises router, but the MACsec session displays that it is operationally down on your Cloud Interconnect connectio

- (1 upvotes) D, rather than C here since its a new implementation and unlikely that it will be the PSK expired.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

When MACsec shows as operationally down on Cloud Interconnect despite the connection being otherwise operational, the most common cause is that **the active pre-shared keys don't match** between your on-premises router and Google's edge routers. According to Google Cloud's troubleshooting documentation, you need to verify that the active Connectivity Key Name (CKN), Connectivity Association Key (CAK), and start times on your on-premises router exactly match the values displayed in MACsec for Cloud Interconnect.

MACsec uses pre-shared keys (consisting of CKN/CAK pairs) to establish a secure channel at Layer 2. When these keys mismatch, the MACsec protocol cannot establish a secure association, resulting in the "operationally down" status while the underlying physical connection remains active.

The troubleshooting process involves:
1. Verifying the active key's CKN and CAK values match on both sides
2. Confirming the start time listed for the active key matches between systems
3. Updating the values on your on-premises router if they don't match
4. Verifying whether a MACsec session can be established after the correction

### Why Other Options Are Wrong

- **A:** This is not the issue since the question states you "implemented a 100GB Cloud Interconnect connection" with MACsec - the connection already supports MACsec. Only 10 Gbps and 100 Gbps Dedicated Interconnect connections support MACsec, and this is a 100GB connection.

- **B:** The question explicitly states "the connection is operational," which means the on-premises router is functioning and communicating. The issue is specifically with MACsec being operationally down, not the router being down.

- **C:** MACsec pre-shared keys in Google Cloud **do not expire**. According to the documentation, all configured keys have infinite expiration times. Keys are selected based on their start time (the key with the latest start time that isn't in the future is selected as active), not expiration. To rotate keys, you must explicitly remove old keys rather than relying on expiration.

### References

- [Troubleshoot MACsec | Cloud Interconnect](https://docs.cloud.google.com/network-connectivity/docs/interconnect/how-to/macsec/troubleshoot-macsec)
- [MACsec for Cloud Interconnect overview](https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/macsec-overview)
- [Rotate MACsec keys | Cloud Interconnect](https://docs.cloud.google.com/network-connectivity/docs/interconnect/how-to/macsec/rotate-macsec-keys)
