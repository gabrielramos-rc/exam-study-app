# Question 141

**Source:** https://www.examtopics.com/discussions/google/view/80422-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Security Command Center, Event Threat Detection, Security Health Analytics, crypto mining, misconfigurations

---

## Question

You have been tasked with configuring Security Command Center for your organization's Google Cloud environment. Your security team needs to receive alerts of potential crypto mining in the organization's compute environment and alerts for common Google Cloud misconfigurations that impact security. Which Security Command Center features should you use to configure these alerts? (Choose two.)

## Choices

- **A.** Event Threat Detection Most Voted
- **B.** Container Threat Detection
- **C.** Security Health Analytics Most Voted
- **D.** Cloud Data Loss Prevention
- **E.** Google Cloud Armor

---

## Community

**Most Voted:** AC


**Votes:** AC: 100% (16 total)


**Top Comments:**

- (11 upvotes) on the exam

- (5 upvotes) Agree with AC

- (2 upvotes) It must be AC

---

## Answer

**Correct:** A, C

**Confidence:** high

### Explanation

The two Security Command Center features needed for this scenario are:

**A. Event Threat Detection** - This service monitors Cloud Logging streams to detect threats including cryptocurrency mining activities. Event Threat Detection identifies both stage-0 events (pre-attack indicators like leaked credentials) and stage-1 events (active mining) by detecting connections to known cryptomining domains and IP addresses. It generates findings for:
- **Malware: Bad IP** - connections to IP addresses known for cryptomining
- **Malware: Bad Domain** - connections to domains used by cryptomining applications
- **Account_Has_Leaked_Credentials** - service account keys leaked on GitHub (common cryptomining precursor)

Event Threat Detection uses log data from inside your systems and watches Cloud Logging streams for projects to detect these threats in real-time.

**C. Security Health Analytics** - This built-in detection service provides managed scans of cloud resources to detect common misconfigurations that impact security. It runs in two modes:
- **Batch mode** - automatically runs once each day
- **Real-time mode** - scans against asset configuration changes as they occur

Security Health Analytics uses built-in detectors to identify vulnerabilities and misconfigurations across numerous categories and resource types, with findings mapped to security standard controls for compliance assessment.

### Why Other Options Are Wrong

- **B. Container Threat Detection** - This service analyzes runtime behavior in containerized environments (GKE and Cloud Run) to detect malicious binaries, credential theft, shell escapes, and privilege escalation. While it can detect crypto mining in containers specifically, it doesn't provide broad crypto mining detection across the entire compute environment (VMs, Cloud Run, etc.) nor does it detect general GCP misconfigurations. Event Threat Detection provides broader coverage for crypto mining detection.

- **D. Cloud Data Loss Prevention** - This is now called Sensitive Data Protection and is used to discover, classify, and protect sensitive data like PII through redaction, de-identification, and tokenization. It does not detect crypto mining or general security misconfigurations.

- **E. Google Cloud Armor** - This is a web application firewall (WAF) and DDoS protection service that operates at the load balancer edge to protect applications from attacks. It does not detect crypto mining activities or scan for security misconfigurations in your cloud environment.

### References

- [Cryptomining detection best practices](https://docs.cloud.google.com/security-command-center/docs/cryptomining-detection-best-practices)
- [Overview of Security Health Analytics](https://docs.cloud.google.com/security-command-center/docs/concepts-security-health-analytics)
- [Detection services](https://docs.cloud.google.com/security-command-center/docs/concepts-security-sources)
