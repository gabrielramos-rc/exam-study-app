# Question 045

**Source:** https://www.examtopics.com/discussions/google/view/17525-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** BigQuery, CMEK, encryption at rest, Cloud KMS, customer-managed encryption keys

---

## Question

A large financial institution is moving its Big Data analytics to Google Cloud Platform. They want to have maximum control over the encryption process of data stored at rest in BigQuery. What technique should the institution use?
## Choices

- **A.** Use Cloud Storage as a federated Data Source.
- **B.** Use a Cloud Hardware Security Module (Cloud HSM).
- **C.** Customer-managed encryption keys (CMEK). Most Voted
- **D.** Customer-supplied encryption keys (CSEK).

---

## Community

**Most Voted:** C


**Votes:** C: 86% | D: 14% (7 total)


**Top Comments:**

- (19 upvotes) Option 'C' is correct. Option 'D' is not correct as CSEK a feature in Google Cloud Storage and Google Compute Engine only.

- (5 upvotes) BigQuery and BigLake tables don't support Customer-Supplied Encryption Keys (CSEK). https://cloud.google.com/bigquery/docs/customer-managed-encryption#before_you_begin

- (4 upvotes) I also feeel D is right

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Customer-Managed Encryption Keys (CMEK) is the correct technique for maximizing control over encryption of data at rest in BigQuery. CMEK allows the financial institution to:

- **Control and manage key encryption keys** in Cloud KMS rather than relying solely on Google-managed keys
- **Set protection levels and locations** for encryption keys to meet regulatory requirements
- **Define rotation schedules** and access permissions for keys
- **Track key usage** through Cloud Audit Logs for compliance auditing
- **Manage key lifecycles independently**, including the ability to revoke access to data by disabling or destroying keys

BigQuery uses envelope encryption where data is encrypted with data encryption keys (DEKs), and those DEKs are then encrypted with the CMEK key encryption keys (KEKs) stored in Cloud KMS. This architecture provides maximum control while maintaining BigQuery's performance and functionality.

### Why Other Options Are Wrong

- **A:** Using Cloud Storage as a federated data source doesn't address encryption control requirements for BigQuery. While Cloud Storage supports CMEK, this approach creates unnecessary complexity and doesn't provide encryption control for data processed within BigQuery itself. The question specifically asks about BigQuery data at rest.

- **B:** Cloud HSM is a protection level for keys within Cloud KMS (FIPS 140-2 Level 3 validated hardware), not a standalone encryption technique. While CMEK keys can use Cloud HSM as their protection level for enhanced security, you must still implement CMEK to use HSM-backed keys in BigQuery.

- **D:** BigQuery does NOT support Customer-Supplied Encryption Keys (CSEK). The documentation explicitly states that "BigQuery and BigLake tables don't support Customer-Supplied Encryption Keys (CSEK)." CSEK is available for services like Cloud Storage and Compute Engine, but not for BigQuery.

### References

- [Customer-managed Cloud KMS keys - BigQuery](https://docs.cloud.google.com/bigquery/docs/customer-managed-encryption)
- [Encryption at rest - BigQuery](https://docs.cloud.google.com/bigquery/docs/encryption-at-rest)
- [Customer-managed encryption keys (CMEK) - Cloud KMS](https://docs.cloud.google.com/kms/docs/cmek)
