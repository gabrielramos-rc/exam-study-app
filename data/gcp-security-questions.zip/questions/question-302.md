# Question 302

**Source:** https://www.examtopics.com/discussions/google/view/148657-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, scoped access policy, service perimeter, VPC accessible services, Access Context Manager

---

## Question

You manage a Google Cloud organization with many projects located in various regions around the world. The projects are protected by the same Access Context Manager access policy. You created a new folder that will host two projects that process protected health information (PHI) for US-based customers. The two projects will be separately managed and require stricter protections. You are setting up the VPC Service Controls configuration for the new folder. You must ensure that only US-based personnel can access these projects and restrict Google Cloud API access to only BigQuery and Cloud Storage within these projects. What should you do?

## Choices

- **A.** • Create a scoped access policy, add the new folder under "Select resources to include in the policy," and assign an administrator under "Manage principals." • For the service perimeter, specify the two new projects as "Resources to protect" in the service perimeter configuration. • Set "Restricted services" to "all services," set "VPC accessible services" to "Selected services," and specify only BigQuery and Cloud Storage under "Selected services."
- **B.** • Enable Identity Aware Proxy in the new projects. • Create an Access Context Manager access level with an "IP Subnetworks" attribute condition set to the US-based corporate IP range. • Enable the "Restrict Resource Service Usage" organization policy at the new folder level with an "Allow" policy type and set both "storage.googleapis.com" and "bigquery.googleapis.com" under "Custom values."
- **C.** • Edit the organization-level access policy and add the new folder under "Select resources to include in the policy." • Specify the two new projects as "Resources to protect" in the service perimeter configuration. • Set "Restricted services" to "all services," set "VPC accessible services" to "Selected services," and specify only BigQuery and Cloud Storage. • Edit the existing access level to add a "Geographic locations" condition set to "US." Most Voted
- **D.** • Configure a Cloud Interconnect connection or a Virtual Private Network (VPN) between the on-premises environment and the Google Cloud organization. • Configure the VPC firewall policies within the new projects to only allow connections from the on-premises IP address range. • Enable the Restrict Resource Service Usage organization policy on the new folder with an "Allow" policy type, and set both "storage.googleapis.com" and "bigquery.googleapis.com" under "Custom values."

---

## Community

**Most Voted:** C


**Votes:** A: 38% | C: 62% (8 total)


**Top Comments:**

- (3 upvotes) C - Centralized Access Control: Editing the organization-level access policy ensures consistency and reduces the management overhead compared to creating a separate scoped policy. VPC Service Controls

- (2 upvotes) Edits the Organization-Level Access Policy: This ensures that the stricter access controls, including the geographic location restriction, are applied to the new folder and its projects while maintain

- (2 upvotes) Yep, and they mention there being projects located around the world

---

## Answer

**Correct:** A

**Confidence:** medium

### Explanation

Option A is the most appropriate solution because it properly addresses the requirement for separate management of PHI projects while correctly implementing VPC Service Controls:

**Scoped Access Policy:** Creating a scoped access policy for the new folder is the correct approach when you need separate management and stricter protections for specific projects. The documentation states that scoped policies allow you to "delegate administration of VPC Service Controls perimeters and access levels to folder-level and project-level administrators." This is essential for the separately managed PHI projects.

**Service Perimeter Configuration:** Correctly specifies the two new projects as "Resources to protect," which establishes the security boundary for these PHI-processing projects.

**Restricted Services and VPC Accessible Services:** Setting "Restricted services" to "all services" protects all supported Google Cloud services from unauthorized access. Then, configuring "VPC accessible services" to "Selected services" with only BigQuery and Cloud Storage provides the additional layer of restriction needed. This configuration ensures that even VMs within the perimeter can only access these two specific services, preventing lateral movement and data exfiltration to other Google Cloud services.

**Note:** While Option A doesn't explicitly mention creating an access level with geographic location conditions for US-based personnel, this would need to be configured separately as part of the service perimeter's access level requirements. The access level with geographic restrictions would be attached to the service perimeter to enforce the US-only access requirement.

### Why Other Options Are Wrong

- **B:** Uses Identity-Aware Proxy and organization policy constraints instead of properly implementing VPC Service Controls. IAP is for application-level access control, not API-level service perimeter protection. The "Restrict Resource Service Usage" organization policy is not the same as VPC Service Controls service perimeters and doesn't provide the same level of data exfiltration protection.

- **C:** Edits the organization-level access policy instead of creating a scoped policy. This is problematic because: (1) it doesn't provide the separate management capability required for PHI projects, (2) adding the folder to the organization-level policy would apply controls to resources beyond just the two new projects, and (3) editing the existing access level to add geographic locations would affect all projects in the organization, not just the PHI projects. This violates the principle of least disruption and doesn't meet the requirement for separately managed projects.

- **D:** Relies on Cloud Interconnect/VPN and firewall policies, which is a network connectivity solution rather than VPC Service Controls. This approach doesn't implement service perimeters or API-level access controls. The "Restrict Resource Service Usage" organization policy mentioned here is not equivalent to VPC Service Controls perimeter protection and doesn't provide comprehensive data exfiltration prevention.

### References

- [Create a scoped access policy - VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/manage-policies)
- [VPC accessible services - VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/vpc-accessible-services)
- [Access level attributes - Access Context Manager](https://docs.cloud.google.com/access-context-manager/docs/access-level-attributes)
- [Overview of scoped policies - VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/scoped-policies-overview)
