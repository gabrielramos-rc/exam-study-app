# Question 063

**Source:** https://www.examtopics.com/discussions/google/view/74818-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** GKE, Kubernetes, taints and tolerations, PCI compliance, node isolation

---

## Question

For compliance reasons, an organization needs to ensure that in-scope PCI Kubernetes Pods reside on `in-scope` Nodes only. These Nodes can only contain the `in-scope` Pods. How should the organization achieve this objective?
## Choices

- **A.** Add a nodeSelector field to the pod configuration to only use the Nodes labeled inscope: true.
- **B.** Create a node pool with the label inscope: true and a Pod Security Policy that only allows the Pods to run on Nodes with that label.
- **C.** Place a taint on the Nodes with the label inscope: true and effect NoSchedule and a toleration to match in the Pod configuration. Most Voted
- **D.** Run all in-scope Pods in the namespace ג€in-scope-pciג€.

---

## Community

**Most Voted:** C


**Votes:** A: 33% | C: 67% (27 total)


**Top Comments:**

- (11 upvotes) A is correct.

- (9 upvotes) C is the ans as per chatgpt

- (8 upvotes) The only way to stop a pod to be scheduled on a node is using taint.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is correct because it provides **bidirectional isolation** required for PCI compliance—ensuring that in-scope Pods run ONLY on in-scope Nodes, AND that in-scope Nodes contain ONLY in-scope Pods.

According to Google Cloud's official documentation on isolating workloads in dedicated node pools, the recommended approach combines:

1. **Node taints with NoSchedule effect**: This prevents any Pods WITHOUT the matching toleration from being scheduled on the in-scope nodes. This is critical because it blocks regular workloads, GKE system Pods (that tolerate most taints), and other non-PCI workloads from contaminating the dedicated nodes.

2. **Pod tolerations**: Only in-scope PCI Pods are configured with the matching toleration (inscope: true:NoSchedule), allowing them to schedule on the tainted nodes.

3. **Node labels and affinity**: While not explicitly mentioned in the answer choice, best practice includes adding node affinity rules to ensure the in-scope Pods preferentially or exclusively schedule on the designated nodes.

The key advantage of taints and tolerations is that they provide **repulsion** (keeping unwanted Pods off) rather than just **attraction** (directing wanted Pods to specific nodes). This creates the strict isolation required for compliance workloads.

### Why Other Options Are Wrong

- **A:** nodeSelector only provides unidirectional control—it directs the PCI Pods to run on labeled nodes, but it does NOT prevent other Pods from also running on those same nodes. Any Pod without a nodeSelector could still schedule there, violating the requirement that in-scope nodes contain ONLY in-scope Pods.

- **B:** Pod Security Policy (PSP) is deprecated in Kubernetes 1.21+ and removed in 1.25+. Additionally, PSPs control what Pods can do (security context, capabilities, volumes), not where they can schedule. Labels alone have the same unidirectional problem as option A.

- **D:** Namespaces provide logical separation for resource management and RBAC, but they do NOT provide node-level isolation. Pods in different namespaces can run on the same nodes. This does not satisfy the requirement that in-scope nodes are physically/logically dedicated to in-scope workloads only.

### References

- [Isolate your workloads in dedicated node pools | GKE security](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/isolate-workloads-dedicated-nodes)
- [Configure workload separation in GKE](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/workload-separation)
