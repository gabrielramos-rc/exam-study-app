# Question 121

**Source:** https://www.examtopics.com/discussions/google/view/74832-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Packet Mirroring, VPC Flow Logs, Cloud IDS, network monitoring, deep packet inspection

---

## Question

You manage your organization's Security Operations Center (SOC). You currently monitor and detect network traffic anomalies in your Google Cloud VPCs based on packet header information. However, you want the capability to explore network flows and their payload to aid investigations. Which Google Cloud product should you use?
## Choices

- **A.** Marketplace IDS
- **B.** VPC Flow Logs
- **C.** VPC Service Controls logs
- **D.** Packet Mirroring Most Voted
- **E.** Google Cloud Armor Deep Packet Inspection

---

## Community

**Most Voted:** D


**Votes:** D: 100% (5 total)


**Top Comments:**

- (9 upvotes) Agree with D

- (3 upvotes) D. Packet Mirroring

- (2 upvotes) D is the answer.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Packet Mirroring is the correct solution for exploring network flows and their payload content. According to Google Cloud documentation, "Packet Mirroring captures all traffic and packet data, **including payloads and headers**." This capability enables deep packet inspection, which is exactly what's needed for SOC investigations.

The question states that the SOC currently monitors based on "packet header information" (which VPC Flow Logs provide), but now needs to analyze payload content. Packet Mirroring specifically addresses this requirement by:

1. **Capturing complete packet data**: Unlike VPC Flow Logs which only capture metadata (source/destination IPs, ports, bytes transferred), Packet Mirroring clones the entire packet including the payload
2. **Enabling deep packet inspection**: Security teams can inspect packet payloads to detect protocol anomalies and analyze attack patterns
3. **Supporting comprehensive threat detection**: IDS tools require multiple packets of a single flow to match signatures and detect persistent threats, which requires access to full packet content
4. **Providing forensic capabilities**: Teams can examine different attack vectors including infrequent communication or attempted but unsuccessful communication

The mirrored traffic is forwarded to collector instances (typically behind an internal load balancer) where security analysis tools can perform deep inspection and investigation.

### Why Other Options Are Wrong

- **A (Marketplace IDS):** While third-party IDS solutions exist in the Marketplace, they typically require Packet Mirroring as the underlying mechanism to receive traffic. This is not a Google Cloud native product and doesn't directly provide the capability - you would still need Packet Mirroring to feed data to it.

- **B (VPC Flow Logs):** VPC Flow Logs only capture network flow metadata (packet header information) such as source/destination IPs, ports, protocols, and byte counts. The documentation specifically states that bytes reported include "user payload bytes and packet header bytes" in aggregate but does NOT provide access to the actual payload content for inspection. This is what they're already using according to the question.

- **C (VPC Service Controls logs):** VPC Service Controls logs track access attempts to services within security perimeters, showing allow/deny decisions for API calls crossing perimeter boundaries. These logs are for monitoring service-level access control, not for analyzing network packet payloads.

- **E (Google Cloud Armor Deep Packet Inspection):** This is not a real Google Cloud product. Cloud Armor is a DDoS protection and web application firewall (WAF) service that operates at the application layer (L7) for HTTP/HTTPS traffic at load balancers. While it inspects application-layer traffic, it doesn't provide the general-purpose packet payload inspection capability needed for SOC investigations across all network traffic types.

### References

- [Packet Mirroring Overview](https://docs.cloud.google.com/vpc/docs/packet-mirroring)
- [VPC Flow Logs Records](https://docs.cloud.google.com/vpc/docs/about-flow-logs-records)
- [VPC Flow Logs Overview](https://docs.cloud.google.com/vpc/docs/flow-logs)
