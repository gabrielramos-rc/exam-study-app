# Question 236

**Source:** https://www.examtopics.com/discussions/google/view/126775-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** Assured Workloads, compliance, data residency, regional support

---

## Question

You are deploying regulated workloads on Google Cloud. The regulation has data residency and data access requirements. It also requires that support is provided from the same geographical location as where the data resides. What should you do?
## Choices

- **A.** Enable Access Transparency Logging.
- **B.** Deploy Assured Workloads. Most Voted
- **C.** Deploy resources only to regions permitted by data residency requirements.
- **D.** Use Data Access logging and Access Transparency logging to confirm that no users are accessing data from another region.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (8 total)


**Top Comments:**

- (3 upvotes) B https://cloud.google.com/security/products/assured-workloads?hl=en

- (2 upvotes) We should deploy Assured Workloads. Assured Workloads helps businesses in regulated sectors meet compliance requirements by providing a secure and compliant environment with features like data residen

- (2 upvotes) The correct answer is B. Deploy Assured Workloads. Assured Workloads for Google Cloud allows you to deploy regulated workloads with data residency, access, and support requirements. It helps you confi

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Assured Workloads is specifically designed to meet comprehensive regulatory compliance requirements including data residency, data access controls, and regional support personnel. When you deploy Assured Workloads, you select a control package (such as Canada Data Boundary and Support, Australia Data Boundary and Support, or regulatory packages like CJIS, FedRAMP, ITAR) that enforces:

1. **Data Residency Controls**: Restricts resource deployment to specific regions through organization policy constraints. For example, the Canada Data Boundary package restricts resources to Canada-only regions.

2. **Data Access Controls**: Implements personnel access controls ensuring Google support staff meet specific geographical and background requirements.

3. **Regional Support Personnel**: Routes support cases to personnel located in the same geographical location as the data. For instance, Canada Data Boundary and Support workloads route support cases to Canadian personnel located in Canada, CJIS workloads route to US Persons in the US who completed CJIS background checks.

Assured Workloads creates a comprehensive compliance boundary through predefined control packages applied at the folder level, which then governs all projects and resources within that hierarchy. This goes far beyond simple geographic deployment to provide layered enforcement mechanisms specifically for regulated workloads.

### Why Other Options Are Wrong

- **A:** Access Transparency Logging only provides visibility into Google Cloud staff access to customer data. While useful for compliance auditing, it does not enforce data residency requirements or ensure support is provided from specific geographical locations. It's a logging feature, not a compliance enforcement mechanism.

- **C:** Simply deploying resources to permitted regions only addresses the data residency requirement but does not handle data access controls or ensure that support personnel are located in the same geographical region. This is a partial solution that doesn't meet all three requirements stated in the question (data residency, data access, and regional support).

- **D:** Data Access logging and Access Transparency logging are monitoring and auditing tools that provide visibility after the fact. They do not prevent or enforce compliance requirements - they only help detect violations. Additionally, they cannot control where support personnel are located. This is a reactive approach rather than a proactive enforcement mechanism.

### References

- [Overview of Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/overview)
- [Data residency | Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/data-residency)
- [Canada Data Boundary and Support | Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/control-packages/canada-data-boundary-support)
- [Australia Data Boundary and Support | Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/control-packages/australia-data-boundary-support)
