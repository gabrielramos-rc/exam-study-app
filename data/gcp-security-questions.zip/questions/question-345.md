# Question 345

**Source:** https://www.examtopics.com/discussions/google/view/311181-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and implementing security for networks and workloads
**Tags:** Private Google Access, Cloud Interconnect, hybrid cloud, on-premises connectivity

---

## Question

Your organization has a hybrid cloud environment with a data center connected to Google Cloud through a dedicated Cloud Interconnect connection. You need to configure private access from your on-premises hosts to Google APIs, specifically Cloud Storage and BigQuery, without exposing traffic to the public internet. What should you do?
## Choices

- **A.** Configure Shared VPC to extend your Google Cloud VPC network to your on-premises environment. Use Private Google Access to access Google APIs.
- **B.** Establish VPC peering between your on-premises network and your Google Cloud VPC network. Configure Cloud Firewall rules to allow traffic to Google API IP ranges.
- **C.** Use Private Google Access for on-premises hosts. Configure DNS resolution to point to the private.googleapis.com domain. Most Voted
- **D.** Configure Cloud NAT on your on-premises network. Configure DNS records in a private DNS zone to send requests to 199.36.153.8/30 to access Google APIs.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (3 total)

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Private Google Access for on-premises hosts is the correct solution for enabling on-premises systems to access Google APIs and services through Cloud Interconnect without traversing the public internet. This feature specifically addresses the hybrid cloud scenario described in the question.

The configuration requires:

1. **Connectivity**: Cloud Interconnect VLAN attachment connecting on-premises network to a VPC network (already in place per the question)

2. **VPC Routing**: Custom static routes in the VPC network with destination `199.36.153.8/30` (private.googleapis.com VIP range) or `199.36.153.4/30` (restricted.googleapis.com VIP range) pointing to the default internet gateway as next hop

3. **On-premises Routing**: Cloud Router configured in custom route advertisement mode to announce the googleapis.com VIP ranges to the on-premises network through the Interconnect attachment

4. **DNS Configuration**: Private DNS zones mapping `*.googleapis.com` to `private.googleapis.com`, which resolves to the VIP addresses (199.36.153.8/30)

Traffic sent to these VIP ranges stays within Google's network infrastructure rather than going over the public internet. The `private.googleapis.com` domain provides access to all Google APIs including Cloud Storage and BigQuery.

### Why Other Options Are Wrong

- **A:** Shared VPC extends VPC networks across projects within Google Cloud; it does not extend VPC networks to on-premises environments. Regular Private Google Access only works for VMs within Google Cloud subnets, not on-premises hosts.

- **B:** VPC peering cannot be established between on-premises networks and Google Cloud VPC networks. VPC peering only works between two VPC networks within Google Cloud. On-premises connectivity requires Cloud VPN or Cloud Interconnect, not peering.

- **D:** Cloud NAT is a Google Cloud service that provides outbound internet connectivity for resources without external IP addresses. It cannot be "configured on your on-premises network" as it's a Google Cloud-managed service. While the IP range 199.36.153.8/30 is correct for private.googleapis.com, Cloud NAT is not the appropriate solution for this scenario.

### References

- [Configure Private Google Access for on-premises hosts](https://docs.cloud.google.com/vpc/docs/configure-private-google-access-hybrid)
- [Private Google Access for on-premises hosts](https://docs.cloud.google.com/vpc/docs/private-google-access-hybrid)
- [Cloud Interconnect overview](https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/overview)
