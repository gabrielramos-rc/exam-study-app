# Question 224

**Source:** https://www.examtopics.com/discussions/google/view/117307-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Identity-Aware Proxy, IAP, SSH access, TCP forwarding, private VMs

---

## Question

You have numerous private virtual machines on Google Cloud. You occasionally need to manage the servers through Secure Socket Shell (SSH) from a remote location. You want to configure remote access to the servers in a manner that optimizes security and cost efficiency. What should you do?
## Choices

- **A.** Create a site-to-site VPN from your corporate network to Google Cloud.
- **B.** Configure server instances with public IP addresses. Create a firewall rule to only allow traffic from your corporate IPs.
- **C.** Create a firewall rule to allow access from the Identity-Aware Proxy (IAP) IP range. Grant the role of an IAP-secured Tunnel User to the administrators. Most Voted
- **D.** Create a jump host instance with public IP. Manage the instances by connecting through the jump host.

---

## Community

**Most Voted:** C


**Votes:** A: 10% | C: 90% (10 total)


**Top Comments:**

- (3 upvotes) I think only option A is cost effective. so, I choose option A

- (1 upvotes) C - https://cloud.google.com/iap#section-2

- (1 upvotes) Using IAP is more secure and cost effective than Bastion VM (VM cost+ maintenace). Specially IAP is a managed security solution.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Identity-Aware Proxy (IAP) TCP forwarding is the optimal solution for secure SSH access to private VMs, providing both maximum security and cost efficiency. IAP TCP forwarding establishes an encrypted tunnel over which SSH traffic is forwarded to VM instances without requiring public IP addresses.

The implementation requires two key components:

1. **Firewall rule allowing IAP IP range (35.235.240.0/20)**: This allows inbound connections from IAP's service to reach your private VMs on port 22 (SSH)
2. **IAM role assignment (roles/iap.tunnelResourceAccessor)**: The IAP-Secured Tunnel User role grants administrators permission to establish SSH tunnels through IAP

When administrators connect using `gcloud compute ssh INSTANCE_NAME --tunnel-through-iap`, the connection is:
- Encrypted end-to-end through HTTPS
- Authenticated and authorized through IAM before reaching the VM
- Proxied to the VM's primary internal IPv4 address without exposing it to the internet
- Fully auditable through Cloud Audit Logs

This approach is the most cost-efficient because it requires no additional infrastructure (no VPN gateways, no jump hosts, no public IPs), only the firewall rule configuration.

### Why Other Options Are Wrong

- **A:** Site-to-site VPN is significantly more expensive (requires Cloud VPN gateway resources and ongoing VPN tunnel costs) and more complex to set up and maintain. While secure, it's over-engineered for occasional SSH access and doesn't optimize cost efficiency.

- **B:** Exposing VMs with public IP addresses violates the security principle of least exposure. Even with firewall rules limiting access to corporate IPs, this creates unnecessary attack surface, increases IP address costs, and doesn't align with best practices for private VM infrastructure. Corporate IP ranges can also change, requiring constant firewall rule updates.

- **D:** A jump host (bastion host) requires maintaining an additional VM instance with public IP, increasing both infrastructure costs and operational overhead. The jump host itself becomes a security concern that needs hardening, monitoring, and patching. IAP eliminates the need for this intermediary infrastructure while providing superior security through IAM-based access control.

### References

- [Using IAP for TCP forwarding](https://docs.cloud.google.com/iap/docs/using-tcp-forwarding)
- [Connect to Linux VMs using Identity-Aware Proxy](https://docs.cloud.google.com/compute/docs/connect/ssh-using-iap)
- [TCP forwarding overview](https://docs.cloud.google.com/iap/docs/tcp-forwarding-overview)
