# Question 072

**Source:** https://www.examtopics.com/discussions/google/view/31624-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** shared responsibility model, IaaS, network security, access policies

---

## Question

In a shared security responsibility model for IaaS, which two layers of the stack does the customer share responsibility for? (Choose two.)
## Choices

- **A.** Hardware
- **B.** Network Security Most Voted
- **C.** Storage Encryption
- **D.** Access Policies Most Voted
- **E.** Boot

---

## Community

**Most Voted:** BD


**Votes:** BD: 100% (13 total)


**Top Comments:**

- (12 upvotes) B and D

- (4 upvotes) B. Network Security D. Access Policies

- (4 upvotes) B and D is correct option.

---

## Answer

**Correct:** B, D

**Confidence:** high

### Explanation

In Google Cloud's shared responsibility model for IaaS, customers share or have primary responsibility for **Network Security (B)** and **Access Policies (D)**. The documentation clearly states: "The cloud provider always remains responsible for the underlying network and infrastructure, and customers always remain responsible for their access policies and data."

**Network Security**: While Google is responsible for the underlying network infrastructure and physical security, customers are responsible for configuring network security controls on top of that infrastructure. This includes:
- Configuring VPC firewall rules
- Setting up VPC Service Controls
- Implementing network segmentation
- Configuring Cloud NGFW policies
- Managing load balancer security settings

**Access Policies**: Customers have full and exclusive responsibility for managing who can access their resources and data. This includes:
- Configuring IAM roles and permissions
- Managing service account access
- Implementing least privilege principles
- Setting up authentication and authorization controls
- Defining access control lists (ACLs)

The documentation specifically states: "In the infrastructure as a service (IaaS) model, only the hardware, storage, and network are Google's responsibility," with the infrastructure layer being Google's domain. Everything else, particularly access policies and security configurations, falls to the customer.

### Why Other Options Are Wrong

- **A (Hardware):** Google has exclusive responsibility for physical hardware infrastructure in IaaS. Customers have no access to or responsibility for the physical servers, storage devices, or network equipment. The documentation explicitly states hardware is Google's responsibility.

- **C (Storage Encryption):** While customers can configure additional encryption options (like CMEK), Google provides default encryption at rest for all data with no customer action required. Google owns the base encryption layer. This is not a shared responsibility—Google handles the foundational encryption, and customers optionally add layers of control. Storage infrastructure itself is Google's responsibility.

- **E (Boot):** Boot processes and boot infrastructure are part of the underlying IaaS platform that Google manages. While customers may configure boot images or startup scripts, the boot mechanism itself is not a shared responsibility layer in the traditional stack model.

### References

- [Shared responsibilities and shared fate on Google Cloud](https://docs.cloud.google.com/architecture/framework/security/shared-responsibility-shared-fate)
- [Google security overview whitepaper](https://docs.cloud.google.com/docs/security/overview/whitepaper)
