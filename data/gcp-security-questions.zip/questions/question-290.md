# Question 290

**Source:** https://www.examtopics.com/discussions/google/view/147084-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, service perimeter, scoped policy, Access Context Manager, folder-level delegation

---

## Question

You are implementing communications restrictions for specific services in your Google Cloud organization. Your data analytics team works in a dedicated folder. You need to ensure that access to BigQuery is controlled for that folder and its projects. The data analytics team must be able to control the restrictions only at the folder level. What should you do?
## Choices

- **A.** Create an organization-level access policy with a service perimeter to restrict BigQuery access. Assign the data analytics team the Access Context Manager Editor role on the access policy to allow the team to configure the access policy.
- **B.** Create a scoped policy on the folder with a service perimeter to restrict BigQuery access. Assign the data analytics team the Access Context Manager Editor role on the scoped policy to allow the team to configure the scoped policy. Most Voted
- **C.** Define a hierarchical firewall policy on the folder to deny BigQuery access. Assign the data analytics team the Compute Organization Firewall Policy Admin role to allow the team to configure rules for the firewall policy.
- **D.** Enforce the Restrict Resource Service Usage organization policy constraint on the folder to restrict BigQuery access. Assign the data analytics team the Organization Policy Administrator role to allow the team to manage exclusions within the folder.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (7 total)


**Top Comments:**

- (3 upvotes) I think using a service perimeter is key.

- (1 upvotes) This approach allows you to apply a service perimeter specifically to the folder, ensuring that BigQuery access is controlled at the desired level. By assigning the Access Context Manager Editor role 

- (1 upvotes) B is good.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

**Scoped policies** are specifically designed to delegate VPC Service Controls administration at the folder or project level. This is the perfect solution for this scenario where:

1. **Folder-level scope**: A scoped policy can be created on the specific folder where the data analytics team works, applying VPC Service Controls (service perimeters) to that folder and all its projects
2. **BigQuery access control**: Service perimeters within the scoped policy can restrict access to BigQuery and prevent data exfiltration
3. **Delegated administration**: By granting the Access Context Manager Editor role (`roles/accesscontextmanager.policyEditor`) on the scoped policy itself, the data analytics team can configure service perimeters and access levels within their folder without requiring organization-level permissions
4. **Meets the requirement**: The team can control restrictions "only at the folder level" - they cannot change the scope to other folders or create new policies, but they have full control over service perimeters within their scoped policy

As documented: "A scoped policy administrator can configure service perimeters and access levels in policies. However, a scoped policy administrator cannot create a new policy or change the scope of the policy to apply to another folder or project."

### Why Other Options Are Wrong

- **A:** An organization-level access policy applies to the entire organization, not just the folder. Granting the Access Context Manager Editor role on an organization-level policy would give the team permissions across the entire organization, violating the requirement that they control restrictions "only at the folder level"

- **C:** Hierarchical firewall policies control network traffic (Layer 3/4), not service-level access controls. They cannot restrict access to specific Google Cloud services like BigQuery. VPC Service Controls are required to restrict access to Google Cloud APIs and services

- **D:** Organization policy constraints control resource configurations and usage (like which regions can be used or which services can be enabled), but they don't provide the same level of data exfiltration protection and service perimeter controls that VPC Service Controls offer. Organization policies cannot create the boundary protection needed to restrict BigQuery access in the way that service perimeters can

### References

- [Overview of scoped policies | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/scoped-policies-overview)
- [Access control with IAM | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/access-control)
- [VPC Service Controls for BigQuery](https://docs.cloud.google.com/bigquery/docs/vpc-sc)
- [Create a scoped access policy](https://docs.cloud.google.com/vpc-service-controls/docs/manage-policies)
