# Question 339

**Source:** https://www.examtopics.com/discussions/google/view/311190-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and implementing security for infrastructure and applications
**Tags:** hybrid connectivity, Dedicated Interconnect, Cloud VPN, network security

---

## Question

Your company is migrating a three-tier web application to Google Cloud. The application consists of a web frontend, an application backend, and a database. Due to regulatory requirements and existing on-premises infrastructure dependencies, you need to implement a hybrid cloud architecture. The web frontend will be hosted on Google Cloud, while the application backend and the database will remain on-premises initially. You need to ensure secure and efficient communication between the cloud-based frontend and the on-premises backend and database, minimizing latency and maximizing availability. What should you do?
## Choices

- **A.** Establish a Dedicated Interconnect connection between the Google Cloud VPC network and the on-premises network. Configure firewall rules to allow communication between the three tiers. Most Voted
- **B.** Establish a direct internet connection between the Google Cloud VPC network hosting the web frontend and the on-premises network that hosts the backend and database. Configure firewall rules to allow communication between the three tiers.
- **C.** Replicate the on-premises backend and database to Google Cloud. Use a hybrid connectivity network endpoint group for the primary. Backup to the zonal network endpoint group.
- **D.** Use a highly-available Cloud VPN connection over the public internet to connect the Google Cloud VPC network to the on-premises network.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (1 total)

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Dedicated Interconnect is the optimal solution for this hybrid cloud scenario because it directly addresses the requirements of minimizing latency and maximizing availability. Dedicated Interconnect provides a direct, physical connection between the Google Cloud VPC network and the on-premises network, with traffic flowing directly between networks without traversing the public internet. This results in:

**Low Latency:** The dedicated link eliminates internet routing variability and provides predictable, low-latency performance critical for communication between the cloud-based frontend and on-premises backend/database tiers.

**High Availability:** Dedicated Interconnect can achieve SLAs of 99.99% or 99.9% service availability when properly configured with redundant connections across different edge availability domains. This ensures reliable communication for the three-tier application.

**Enterprise-Grade Performance:** With 10-Gbps or 100-Gbps circuit options, Dedicated Interconnect provides the bandwidth and performance needed for production workloads.

**Direct IP Addressing:** VPC network internal IP addresses are directly accessible from on-premises without requiring NAT devices or VPN tunnels, simplifying the architecture and improving security.

The solution properly implements firewall rules to control access between tiers, maintaining security while enabling efficient hybrid communication.

### Why Other Options Are Wrong

- **B:** Using a direct internet connection is fundamentally insecure and inappropriate for production workloads. It exposes backend and database traffic to the public internet without encryption, violating security best practices and likely failing to meet regulatory requirements. It also provides no latency guarantees or availability SLA.

- **C:** This option contradicts the stated requirement that "the application backend and the database will remain on-premises initially" due to regulatory requirements and existing infrastructure dependencies. Replicating to Google Cloud would violate these constraints. Additionally, the terminology "hybrid connectivity network endpoint group" is not a standard Google Cloud construct.

- **D:** While Cloud VPN provides encrypted connectivity and is a valid hybrid solution, it does not meet the requirement to "minimize latency and maximize availability" as effectively as Dedicated Interconnect. Cloud VPN operates over the public internet, introducing latency variability and bandwidth limitations compared to the direct, dedicated connection. VPN is better suited for lower-bandwidth needs or experimental workloads, not production applications requiring optimal performance.

### References

- [Cloud Interconnect Overview](https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/overview)
- [Choosing a Network Connectivity Product](https://docs.cloud.google.com/network-connectivity/docs/how-to/choose-product)
- [Dedicated Interconnect Overview](https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/dedicated-overview)
- [Establish 99.99% Availability for Dedicated Interconnect](https://docs.cloud.google.com/network-connectivity/docs/interconnect/tutorials/dedicated-creating-9999-availability)
