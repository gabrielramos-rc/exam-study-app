# Question 294

**Source:** https://www.examtopics.com/discussions/google/view/147088-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** load balancer, HTTPS, TLS, encryption in transit, compliance

---

## Question

Your organization has an internet-facing application behind a load balancer. Your regulators require end-to-end encryption of user login credentials. You must implement this requirement. What should you do?
## Choices

- **A.** Generate a symmetric key with Cloud KMS. Encrypt client-side user credentials by using the symmetric key.
- **B.** Concatenate the credential with a timestamp. Submit the timestamp and hashed value of credentials to the network.
- **C.** Deploy the TLS certificate at Google Cloud Global HTTPs Load Balancer, and submit the user credentials through HTTPs. Most Voted
- **D.** Generate an asymmetric key with Cloud KMS. Encrypt client-side user credentials using the public key.

---

## Community

**Most Voted:** C


**Votes:** C: 67% | D: 33% (12 total)


**Top Comments:**

- (2 upvotes) I think it's C.

- (1 upvotes) Option C provides encryption in transit, but it's not truly end-to-end because the load balancer must decrypt the traffic to inspect it. Option D is correct because it encrypts the credential data its

- (1 upvotes) D. is the best solution for achieving true end-to-end encryption of the credentials. This method, known as asymmetric or public-key cryptography, ensures the data is encrypted on the client-side using

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

When regulators require "end-to-end encryption of user login credentials" for web applications, they are referring to encryption in transit using TLS/HTTPS to protect credentials from interception during transmission. Option C correctly implements this by deploying a TLS certificate at the Global HTTPS Load Balancer and requiring HTTPS connections.

Google Cloud's HTTPS load balancers provide:
- **TLS termination using Google's BoringCrypto library** (FIPS 140-2 compliant) for external Application Load Balancers
- **Strong encryption protocols** via configurable SSL policies (COMPATIBLE, MODERN, or RESTRICTED profiles)
- **Industry-standard protection** for credentials in transit from client to Google Cloud infrastructure

This is the standard and recommended approach for protecting authentication credentials in cloud applications. The load balancer handles TLS termination, which is considered "end-to-end" from a regulatory perspective because it protects data from the client through to the application infrastructure.

Additionally, if true end-to-end encryption to backends is needed, you can configure **encryption from the load balancer to the backends** by setting the backend service protocol to HTTPS or HTTP/2, ensuring the entire path remains encrypted.

### Why Other Options Are Wrong

- **A:** Using symmetric keys for client-side encryption adds unnecessary complexity and creates operational challenges. You would need to securely distribute the same symmetric key to all clients and manage it on the backend for decryption. This is not a standard solution for web application credential protection and introduces significant security risks around key distribution.

- **B:** Hashing credentials with a timestamp does not provide encryption - it only provides integrity verification. Hashing is a one-way function that cannot be reversed to obtain the original credentials. This approach fails to meet the encryption requirement and would prevent the backend from validating user credentials. Additionally, transmitting hashed values over an unencrypted channel still leaves them vulnerable to interception and replay attacks.

- **D:** While asymmetric encryption with Cloud KMS would technically provide end-to-end encryption, it introduces unnecessary complexity for a standard web authentication scenario. You would need to implement custom client-side encryption logic, manage public key distribution, and implement server-side decryption using the private key. This approach is typically reserved for specific use cases like encrypting sensitive data at rest or in specialized scenarios, not for standard HTTPS-based credential transmission.

### References

- [SSL policies for SSL and TLS protocols](https://docs.cloud.google.com/load-balancing/docs/ssl-policies-concepts)
- [Encryption from the load balancer to the backends](https://docs.cloud.google.com/load-balancing/docs/ssl-certificates/encryption-to-the-backends)
- [Encryption in transit for Google Cloud](https://docs.cloud.google.com/docs/security/encryption-in-transit)
- [External Application Load Balancer overview](https://docs.cloud.google.com/load-balancing/docs/https)
