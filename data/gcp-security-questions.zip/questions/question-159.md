# Question 159

**Source:** https://www.examtopics.com/discussions/google/view/81820-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, de-identification, BigQuery, Cloud KMS

---

## Question

You discovered that sensitive personally identifiable information (PII) is being ingested to your Google Cloud environment in the daily ETL process from an on- premises environment to your BigQuery datasets. You need to redact this data to obfuscate the PII, but need to re-identify it for data analytics purposes. Which components should you use in your solution? (Choose two.)
## Choices

- **A.** Secret Manager
- **B.** Cloud Key Management Service Most Voted
- **C.** Cloud Data Loss Prevention with cryptographic hashing
- **D.** Cloud Data Loss Prevention with automatic text redaction
- **E.** Cloud Data Loss Prevention with deterministic encryption using AES-SIV Most Voted

---

## Community

**Most Voted:** BE


**Votes:** BE: 96% | DE: 4% (25 total)


**Top Comments:**

- (14 upvotes) BE is correct. Ghost links are correct and this link here shows a reference architecture using cloud KMS and Cloud DLP https://cloud.google.com/architecture/de-identification-re-identification-pii-usi

- (6 upvotes) KMS for storing the encryption key Deterministic encryption so that you can reverse the process

- (4 upvotes) BE is the answer.

---

## Answer

**Correct:** B, E

**Confidence:** high

### Explanation

The requirement is to both **obfuscate PII** (de-identify) and **re-identify it** for data analytics, which requires a reversible cryptographic transformation method. The correct components are:

**B. Cloud Key Management Service (Cloud KMS):** Cloud KMS is required to securely store and manage the cryptographic keys used for de-identification and re-identification. The token encryption key used during de-identification must be securely preserved to enable re-identification later. Cloud KMS provides the most secure method for wrapping and storing these keys, protecting them with KMS-managed encryption keys.

**E. Cloud Data Loss Prevention with deterministic encryption using AES-SIV:** Deterministic encryption using AES-SIV (Advanced Encryption Standard in Synthetic Initialization Vector mode) is a reversible cryptographic method that enables re-identification. It provides:
- **Reversibility:** The original PII can be recovered using the same cryptographic key
- **Referential integrity:** The same input value always produces the same encrypted output (essential for data analytics, joins, and aggregations)
- **High security:** AES-SIV provides the highest level of security among all reversible cryptographic methods supported by Sensitive Data Protection

The data flow would be: ETL process → Cloud DLP de-identifies PII using AES-SIV with a key stored in Cloud KMS → Tokenized data in BigQuery → For analytics requiring original values, re-identify using the same Cloud KMS key.

### Why Other Options Are Wrong

- **A. Secret Manager:** While Secret Manager is used for storing application secrets like API keys and passwords, it is not the appropriate service for managing encryption keys used in cryptographic de-identification. Cloud KMS is specifically designed for cryptographic key management and provides the wrapping functionality needed for DLP transformations.

- **C. Cloud Data Loss Prevention with cryptographic hashing:** Cryptographic hashing (HMAC-SHA-256) is a **one-way transformation** that cannot be reversed. Once data is hashed, the original PII cannot be recovered for analytics purposes. Hashing is only suitable when you need to preserve referential integrity but never need to see the original values again.

- **D. Cloud Data Loss Prevention with automatic text redaction:** Text redaction completely deletes or replaces sensitive data with placeholder values (like "[REDACTED]" or "***"). This is a permanent, irreversible operation that destroys the original information, making re-identification impossible. Redaction is appropriate only when you never need to recover the original data.

### References

- [De-identification and re-identification of PII in large-scale datasets using Sensitive Data Protection](https://docs.cloud.google.com/architecture/de-identification-re-identification-pii-using-cloud-dlp)
- [Pseudonymization - Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/pseudonymization)
- [De-identify content through deterministic encryption](https://docs.cloud.google.com/sensitive-data-protection/docs/samples/dlp-deidentify-deterministic)
