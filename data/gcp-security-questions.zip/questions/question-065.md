# Question 065

**Source:** https://www.examtopics.com/discussions/google/view/30429-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** firewall rules, egress, priority, VPC, perimeter security

---

## Question

A customer has an analytics workload running on Compute Engine that should have limited internet access. Your team created an egress firewall rule to deny (priority 1000) all traffic to the internet. The Compute Engine instances now need to reach out to the public repository to get security updates. What should your team do?
## Choices

- **A.** Create an egress firewall rule to allow traffic to the CIDR range of the repository with a priority greater than 1000.
- **B.** Create an egress firewall rule to allow traffic to the CIDR range of the repository with a priority less than 1000. Most Voted
- **C.** Create an egress firewall rule to allow traffic to the hostname of the repository with a priority greater than 1000.
- **D.** Create an egress firewall rule to allow traffic to the hostname of the repository with a priority less than 1000.

---

## Community

**Most Voted:** B


**Votes:** A: 10% | B: 90% (21 total)


**Top Comments:**

- (26 upvotes) I think I am confusing myself by overthinking the wording of this question. I know the answer is A or B since "using hostname is not one of the options in firewall egress rule destination" I also know

- (5 upvotes) While the priority is correct, Google Cloud firewall rules do not support hostname-based filtering. You must use a CIDR range.

- (4 upvotes) B is correct

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

In VPC firewall rules, **lower priority numbers indicate higher priority**. When you have a deny rule with priority 1000, you need to create an allow rule with a **priority less than 1000** (e.g., 900, 500, or 100) to override it. This is because Cloud NGFW evaluates rules from highest priority (lowest number) to lowest priority (highest number), and the first matching rule wins.

The existing egress deny rule at priority 1000 blocks all internet traffic. To selectively allow traffic to the security update repository, you must create an allow rule with a lower priority number (higher precedence) than 1000. This allow rule should target the specific CIDR range of the repository.

Firewall rules support CIDR ranges as destination filters (options A and B), but not hostnames (options C and D are invalid). You must specify IP addresses or CIDR blocks in the destination IP ranges field.

### Why Other Options Are Wrong

- **A:** Priority greater than 1000 (e.g., 1001, 2000) means **lower priority** than the existing deny rule. The deny rule at priority 1000 would be evaluated first and would block the traffic before the allow rule is ever considered.

- **C:** VPC firewall rules do not support hostname-based filtering in the destination field. You must use IP addresses or CIDR ranges. Additionally, a priority greater than 1000 would have lower priority than the deny rule.

- **D:** While the priority less than 1000 is correct, firewall rules cannot use hostnames as destination targets. You must specify the repository's CIDR range or IP addresses.

### References

- [VPC firewall rules | Cloud Next Generation Firewall](https://docs.cloud.google.com/firewall/docs/firewalls)
- [Use VPC firewall rules | Cloud Next Generation Firewall](https://docs.cloud.google.com/firewall/docs/using-firewalls)
