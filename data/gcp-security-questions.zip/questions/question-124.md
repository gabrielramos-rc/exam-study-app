# Question 124

**Source:** https://www.examtopics.com/discussions/google/view/74833-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, de-identification, cryptographic hashing, PHI

---

## Question

You are working with protected health information (PHI) for an electronic health record system. The privacy officer is concerned that sensitive data is stored in the analytics system. You are tasked with anonymizing the sensitive data in a way that is not reversible. Also, the anonymized data should not preserve the character set and length. Which Google Cloud solution should you use?
## Choices

- **A.** Cloud Data Loss Prevention with deterministic encryption using AES-SIV
- **B.** Cloud Data Loss Prevention with format-preserving encryption
- **C.** Cloud Data Loss Prevention with cryptographic hashing Most Voted
- **D.** Cloud Data Loss Prevention with Cloud Key Management Service wrapped cryptographic keys

---

## Community

**Most Voted:** C


**Votes:** C: 100% (9 total)


**Top Comments:**

- (20 upvotes) Agreed C is right

- (4 upvotes) C. Cloud Data Loss Prevention with cryptographic hashing

- (2 upvotes) https://cloud.google.com/dlp/docs/pseudonymization

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Cloud Data Loss Prevention (now Sensitive Data Protection) with **cryptographic hashing** is the correct solution because it meets all three requirements:

1. **Not reversible (irreversible)**: Cryptographic hashing uses HMAC-SHA-256, which is a one-way transformation. According to Google Cloud documentation, "This transformation can't be reversed. That is, given the hashed output value of the transformation and the original cryptographic key, there is no way to restore the original value."

2. **Does NOT preserve character set**: Cryptographic hashing produces a base64-encoded representation of the hash output (e.g., "L7k0BHmF1ha5U3NfGykjro4xWi1MPVQPjhMAZbSV9mM="), regardless of the input character set.

3. **Does NOT preserve length**: The hashed output is always a fixed length (32-byte hash encoded in base64), not dependent on the input value's length.

This method provides true anonymization for PHI data in analytics systems where re-identification is not needed and data format preservation is not required.

### Why Other Options Are Wrong

- **A (Deterministic encryption using AES-SIV):** While it doesn't preserve character set or length (produces base64-encoded output), it IS reversible. With the original cryptographic key, you can decrypt and restore the original value using the `reidentify` method. This violates the "not reversible" requirement.

- **B (Format-preserving encryption):** This method is explicitly designed to preserve both the character set (alphabet) and length of the input value. It also supports re-identification when you have the encryption key. This violates both the "not reversible" and "should not preserve character set and length" requirements.

- **D (Cloud KMS wrapped cryptographic keys):** This option describes a key management approach, not a transformation method. Cloud KMS wrapped keys can be used with any of the cryptographic transformation methods (deterministic encryption, format-preserving encryption, or cryptographic hashing). It doesn't specify which transformation technique to use, making it incomplete as an answer.

### References

- [De-identification and re-identification of PII in large-scale datasets using Sensitive Data Protection](https://docs.cloud.google.com/architecture/de-identification-re-identification-pii-using-cloud-dlp)
- [Transformation reference - Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/transformations-reference)
- [De-identifying sensitive data - Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/deidentify-sensitive-data)
