# Question 337

**Source:** https://www.examtopics.com/discussions/google/view/311196-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Workforce Identity Federation, SSO, third-party IdP, external identity, user lifecycle

---

## Question

There is a vendor who needs access to your company's Google Cloud environment. The vendor uses a third-party identity provider (IdP). You need to integrate this IdP with your company's Google Cloud environment to enable single sign-on (SSO) for the vendor's users in the most secure way. You don't want to manage any of the vendor users' lifecycle management. What should you do?
## Choices

- **A.** Use Google Cloud Directory Sync to synchronize user accounts from the IdP to Google Workspace, and then configure SSO between Google Workspace and Google Cloud.
- **B.** Develop a custom application that queries the IdP for user authentication and then programmatically creates Google Cloud user accounts.
- **C.** Connect the vendor's IdP with Google Cloud using Workforce Identify Federation. Most Voted
- **D.** Create Google Cloud accounts for each user and synchronize their passwords with the third-party IdP.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (1 total)

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Workforce Identity Federation is the correct and most secure solution for this scenario. It enables your organization to use the vendor's existing third-party identity provider (IdP) to authenticate users directly to Google Cloud without any synchronization or lifecycle management overhead.

Key advantages that make this the optimal choice:

**Syncless authentication**: Workforce Identity Federation is explicitly designed to be "syncless," meaning you don't need to synchronize user identities from the vendor's IdP to Google-managed identities. The vendor's IdP remains the authoritative source for user authentication and lifecycle management.

**Native SSO support**: Users can access Google Cloud using single sign-on (SSO) through their existing IdP credentials. Google Cloud's Security Token Service (STS) uses OAuth 2.0 Token Exchange (RFC 8693) to verify identities with the external IdP and issue short-lived access tokens.

**Broad IdP compatibility**: The solution supports any identity provider that offers OpenID Connect (OIDC) or SAML 2.0 protocols, including Microsoft Entra ID, Okta, Active Directory Federation Services, and other third-party providers.

**Zero lifecycle management**: Since authentication happens directly through the vendor's IdP, all user provisioning, deprovisioning, and lifecycle management remain with the vendor. You don't need to create, update, or delete any user accounts.

**Enhanced security**: Short-lived federated tokens replace long-lived credentials, attribute-based access control can be applied, and the vendor maintains centralized control over their users' authentication policies and MFA requirements.

### Why Other Options Are Wrong

- **A:** Google Cloud Directory Sync requires active synchronization of user accounts from the IdP to Google Workspace, which directly contradicts the requirement of not managing vendor user lifecycle. This introduces synchronization overhead, potential delays, and requires ongoing management of synchronized accounts.

- **B:** Developing a custom application to programmatically create Google Cloud user accounts requires significant development effort and creates the exact lifecycle management burden you want to avoid. You would need to handle user creation, updates, deletions, and synchronization - all of which Workforce Identity Federation eliminates.

- **D:** Creating Google Cloud accounts for each vendor user and synchronizing passwords is the worst option from both security and management perspectives. This requires manual or automated account provisioning, password synchronization (a security anti-pattern), and ongoing lifecycle management for all vendor users.

### References

- [Workforce Identity Federation](https://docs.cloud.google.com/iam/docs/workforce-identity-federation)
- [Configure Workforce Identity Federation](https://docs.cloud.google.com/iam/docs/configuring-workforce-identity-federation)
