# Question 039

**Source:** https://www.examtopics.com/discussions/google/view/17001-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** folders, resource hierarchy, Google Groups, IAM permissions, environment organization

---

## Question

A customer has 300 engineers. The company wants to grant different levels of access and efficiently manage IAM permissions between users in the development and production environment projects. Which two steps should the company take to meet these requirements? (Choose two.)
## Choices

- **A.** Create a project with multiple VPC networks for each environment.
- **B.** Create a folder for each development and production environment. Most Voted
- **C.** Create a Google Group for the Engineering team, and assign permissions at the folder level. Most Voted
- **D.** Create an Organizational Policy constraint for each folder environment.
- **E.** Create projects for each environment, and grant IAM rights to each engineering user.

---

## Community

**Most Voted:** BC


**Votes:** BC: 100% (6 total)


**Top Comments:**

- (23 upvotes) B and C are viable

- (4 upvotes) CE - A general recommendation is to have one project per application per environment. For example, if you have two applications, "app1" and "app2", each with a development and production environment, 

- (2 upvotes) Which Policy Constriaint allow to manage permission?!??!?! D is not an option. The answer is B and C

---

## Answer

**Correct:** B, C

**Confidence:** high

### Explanation

The correct approach combines **folders for environment organization** (B) and **Google Groups for efficient IAM management** (C):

**Option B - Create folders for development and production environments:** Google Cloud documentation explicitly recommends using folders to "group resources that belong to applications or different environments, such as development, production, test." Folders provide isolation boundaries and serve as attachment points for access policies. When you grant a role to a user at the folder level, that user inherits the role for every resource underneath that folder, enabling hierarchical permission management.

**Option C - Create a Google Group and assign permissions at the folder level:** Google Cloud best practices emphasize that "each member of a Google group inherits the Identity and Access Management (IAM) roles granted to that group." This allows you to "use a group's membership to manage users' roles instead of granting IAM roles to individual users." For 300 engineers, using groups is essential for scalability. The recommended pattern is to create "access groups" for specific job functions (e.g., `access.dev-engineers@example.com`, `access.prod-engineers@example.com`) and grant these groups permissions at the folder level.

Together, these two steps enable:
- **Environment isolation** through folder structure
- **Different access levels** by assigning different groups to development vs. production folders
- **Efficient management** by adding/removing users from groups rather than managing 300 individual IAM bindings

### Why Other Options Are Wrong

- **A:** Creating multiple VPC networks within a single project does not provide IAM-level separation between development and production environments. VPC networks are networking constructs, not access control boundaries. This doesn't address the requirement to grant "different levels of access" between environments.

- **D:** Organization Policy constraints enforce governance rules (e.g., restricting which services can be used, requiring encryption), not access permissions. They complement IAM but don't grant or manage user access to resources. The question specifically asks about managing "IAM permissions," which Organization Policies don't control.

- **E:** Granting IAM rights to each individual engineer is the opposite of "efficiently manage" - it creates 300 individual IAM bindings per project/folder. This approach is unscalable, difficult to audit, and violates the best practice of using groups. Documentation states: "When managing multiple principals with the same access configurations, use groups instead."

### References

- [Create and manage folders | Resource Manager](https://cloud.google.com/resource-manager/docs/creating-managing-folders)
- [Best practices for using Google groups | IAM](https://cloud.google.com/iam/docs/groups-best-practices)
- [Access control for folders with IAM | Resource Manager](https://cloud.google.com/resource-manager/docs/access-control-folders)
- [Create and manage Google groups in the Cloud console | IAM](https://cloud.google.com/iam/docs/groups-in-cloud-console)
