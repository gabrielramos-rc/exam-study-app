# Question 315

**Source:** https://www.examtopics.com/discussions/google/view/150187-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Binary Authorization, vulnerability scanning, container security, CI/CD, ML security

---

## Question

Your organization is building a real-time recommendation engine using ML models that process live user activity data stored in BigQuery and Cloud Storage. Each new model developed is saved to Artifact Registry. This new system deploys models to Google Kubernetes Engine, and uses Pub/Sub for message queues. Recent industry news have been reporting attacks exploiting ML model supply chains. You need to enhance the security in this serverless architecture, specifically against risks to the development and deployment pipeline. What should you do?
## Choices

- **A.** Enable container image vulnerability scanning during development and pre-deployment. Enforce Binary Authorization on images deployed from Artifact Registry to your continuous integration and continuous deployment (CVCD) pipeline. Most Voted
- **B.** Thoroughly sanitize all training data prior to model development to reduce risk of poisoning attacks. Use IAM for authorization, and apply role-based restrictions to code repositories and cloud services.
- **C.** Limit external libraries and dependencies that are used for the ML models as much as possible. Continuously rotate encryption keys that are used to access the user data from BigQuery and Cloud Storage.
- **D.** Develop strict firewall rules to limit external traffic to Cloud Run instances. Integrate intrusion detection systems (IDS) for real-time anomaly detection on Pub/Sub message flows.

---

## Community

**Most Voted:** A


**Votes:** A: 80% | D: 20% (5 total)


**Top Comments:**

- (1 upvotes) A should be the answer. Supply chain risks happen by exploiting vulnerabilities in the images. So scanning the image and blocking deployment secures against supply chain risks. This also matches with 

- (1 upvotes) The question asked "...attacks exploiting ML model supply chains" and "...risks to the development and deployment pipeline", so we should look anything related to these: A: No. Image scanning and enfo

- (1 upvotes) Answer A

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is correct because it directly addresses **ML model supply chain security** by implementing two critical Google Cloud services specifically designed to protect container deployment pipelines:

1. **Container Image Vulnerability Scanning** - Artifact Analysis automatically scans container images when they're uploaded to Artifact Registry. It identifies vulnerabilities in OS packages (Ubuntu, Debian, Alpine) and application language packages (Go, Java, Python, Node.js). The service continuously monitors scanned images for new vulnerabilities, updating metadata multiple times daily as fresh CVE data arrives from sources like the National Vulnerability Database.

2. **Binary Authorization** - This service provides deploy-time enforcement of security policies for GKE, Cloud Run, and Google Distributed Cloud. Binary Authorization uses attestations (cryptographic signatures) to verify that containers were built by approved CI/CD systems, are compliant with vulnerability signing policies, and meet criteria for environment promotion. This prevents compromised or unauthorized container images from being deployed to production.

The combination of these two services creates a comprehensive defense against supply chain attacks by ensuring that:
- All container images are scanned for known vulnerabilities before deployment
- Only approved, signed containers that pass security policies can be deployed to GKE
- The entire CI/CD pipeline is protected from model tampering and unauthorized deployments

This approach directly addresses the question's concern about "attacks exploiting ML model supply chains" by securing the development and deployment pipeline where ML models stored in Artifact Registry are deployed to GKE.

### Why Other Options Are Wrong

- **B:** While sanitizing training data and using IAM are security best practices, they don't specifically address the **supply chain security** concern mentioned in the question. Data poisoning attacks target model training integrity, not the deployment pipeline. IAM controls are fundamental but don't prevent compromised container images from being deployed.

- **C:** Limiting external dependencies is a good general security practice, but it doesn't provide active protection against supply chain attacks. Key rotation for data access addresses data security, not the deployment pipeline security that's the focus of the question. This option lacks the automated scanning and enforcement mechanisms needed to detect and prevent malicious containers.

- **D:** This option contains technical errors - the question states the system deploys to GKE, not Cloud Run. Additionally, firewall rules and IDS focus on runtime network security, not supply chain security. These controls don't address vulnerabilities in container images or prevent unauthorized deployments during the CI/CD pipeline.

### References

- [Binary Authorization overview](https://docs.cloud.google.com/binary-authorization/docs/overview)
- [Container scanning overview](https://docs.cloud.google.com/artifact-analysis/docs/container-scanning-overview)
- [Securing deployments - Artifact Registry](https://docs.cloud.google.com/artifact-registry/docs/secure-deployments)
- [Software supply chain security - Artifact Registry](https://docs.cloud.google.com/artifact-registry/docs/software-supply-chain-security)
