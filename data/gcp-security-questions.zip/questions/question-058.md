# Question 058

**Source:** https://www.examtopics.com/discussions/google/view/30235-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC peering, network segmentation, transitive routing, cross-organization peering

---

## Question

Which two security characteristics are related to the use of VPC peering to connect two VPC networks? (Choose two.)
## Choices

- **A.** Central management of routes, firewalls, and VPNs for peered networks
- **B.** Non-transitive peered networks; where only directly peered networks can communicate Most Voted
- **C.** Ability to peer networks that belong to different Google Cloud organizations Most Voted
- **D.** Firewall rules that can be created with a tag from one peered network to another peered network
- **E.** Ability to share specific subnets across peered networks

---

## Community

**Most Voted:** BC


**Votes:** BC: 54% | BD: 38% | CE: 8% (13 total)


**Top Comments:**

- (18 upvotes) Ans should be BC https://cloud.google.com/vpc/docs/vpc-peering#key_properties

- (5 upvotes) agree BC

- (3 upvotes) Agree with BC

---

## Answer

**Correct:** B, C

**Confidence:** high

### Explanation

**B (Non-transitive peering)** is correct. VPC Network Peering explicitly does not support transitive routing. As documented, if VPC networks net-a and net-b are peered, and net-a and net-c are peered, there is no connectivity between net-b and net-c unless they are directly peered. This non-transitive property is a fundamental security characteristic that prevents unintended network exposure and maintains explicit control over which networks can communicate.

**C (Cross-organization peering)** is correct. VPC Network Peering supports connecting VPC networks across different Google Cloud organizations, enabling secure collaboration between separate organizational entities while maintaining administrative independence. The documentation confirms that peering works "whether or not they belong to the same project or the same organization."

### Why Other Options Are Wrong

- **A:** VPC Network Peering does not provide central management of routes, firewalls, or VPNs. Peered networks "remain administratively separate" - each VPC network maintains its own distributed firewall policies, routes, and VPN configurations. There is no unified control plane for managing these resources across peered networks.

- **D:** Network tags in firewall rules do not work across peered networks. The documentation explicitly states that "Firewall rules whose targets are defined using network tags are only resolved to instances in the firewall rule's VPC network." Even if both peered networks use the same tag name, the tags remain isolated to their respective VPC networks and cannot target instances in the peered network.

- **E:** VPC Network Peering does not support selective subnet sharing. When networks are peered, subnet routes are automatically exchanged based on the peering configuration (all private IPv4 subnet routes are always exchanged). You cannot choose to share only specific subnets - the routing is all-or-nothing based on IP address type, not individual subnet selection.

### References

- [VPC Network Peering](https://docs.cloud.google.com/vpc/docs/vpc-peering)
- [Best practices and reference architectures for VPC design](https://docs.cloud.google.com/architecture/best-practices-vpc-design)
