# Question 014

**Source:** https://www.examtopics.com/discussions/google/view/16979-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** IAM, organization administrator, permissions management, auditing, organization resource

---

## Question

A business unit at a multinational corporation signs up for GCP and starts moving workloads into GCP. The business unit creates a Cloud Identity domain with an organizational resource that has hundreds of projects. Your team becomes aware of this and wants to take over managing permissions and auditing the domain resources. Which type of access should your team grant to meet this requirement?
## Choices

- **A.** Organization Administrator Most Voted
- **B.** Security Reviewer
- **C.** Organization Role Administrator
- **D.** Organization Policy Administrator

---

## Community

**Most Voted:** A


**Votes:** A: 86% | C: 14% (7 total)


**Top Comments:**

- (30 upvotes) C. After carefully review this link: https://cloud.google.com/iam/docs/understanding-roles my opinion is based on 'the least privilege' practice, that future domain shall not get granted automatically

- (12 upvotes) "If you have an organization associated with your Google Cloud account, the Organization Role Administrator role enables you to administer all custom roles in your organization", it can not be C

- (6 upvotes) IAM - not IAP - typo

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The Organization Administrator role (roles/resourcemanager.organizationAdmin) is the correct choice because it provides both capabilities required: **managing permissions** and **auditing**.

Key capabilities of Organization Administrator:
- **Manage IAM policies**: Has the `resourcemanager.organizations.setIamPolicy` permission, allowing it to grant and revoke IAM roles across the organization
- **View all projects**: Can view and list all projects in the organization resource, even those they don't have direct access to
- **Audit capabilities**: Includes all `getIamPolicy` permissions needed to review and audit IAM configurations across the organization hierarchy
- **Manage Essential Contacts**: Can configure notification contacts for the organization
- **Day-to-day operations**: Designed specifically for managing organization operations without requiring super admin privileges

This role provides the comprehensive access needed to "take over managing permissions and auditing" across hundreds of projects in the organization resource.

### Why Other Options Are Wrong

- **B. Security Reviewer** - This role (roles/iam.securityReviewer) only provides read-only access with `getIamPolicy` permissions for all resource types. While it can audit IAM policies, it **cannot manage permissions** (no setIamPolicy permission). It only fulfills half the requirement.

- **C. Organization Role Administrator** - This is not a standard Google Cloud IAM role. There is no predefined role called "Organization Role Administrator" in the Google Cloud IAM role hierarchy.

- **D. Organization Policy Administrator** - This role (roles/orgpolicy.policyAdmin) manages organization policies and constraints (defining what restrictions to place on resource configuration), not IAM permissions. It controls **what can be configured** through organization policies, but does not manage **who has access** through IAM roles.

### References

- [Access control for organization resources with IAM](https://docs.cloud.google.com/resource-manager/docs/access-control-org)
- [IAM roles and permissions index](https://docs.cloud.google.com/iam/docs/roles-permissions)
- [Manage access to projects, folders, and organizations](https://docs.cloud.google.com/iam/docs/granting-changing-revoking-access)
