# Question 027

**Source:** https://www.examtopics.com/discussions/google/view/27114-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** resource hierarchy, organization, folders, business units, IAM permissions

---

## Question

A customer's company has multiple business units. Each business unit operates independently, and each has their own engineering group. Your team wants visibility into all projects created within the company and wants to organize their Google Cloud Platform (GCP) projects based on different business units. Each business unit also requires separate sets of IAM permissions. Which strategy should you use to meet these needs?
## Choices

- **A.** Create an organization node, and assign folders for each business unit. Most Voted
- **B.** Establish standalone projects for each business unit, using gmail.com accounts.
- **C.** Assign GCP resources in a project, with a label identifying which business unit owns the resource.
- **D.** Assign GCP resources in a VPC for each business unit to separate network access.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (1 total)


**Top Comments:**

- (18 upvotes) A is the right ans - resource manager

- (3 upvotes) Correct Answer: A

- (1 upvotes) Ans - A

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Creating an organization node with folders for each business unit is the correct and recommended approach for this scenario because it addresses all three requirements:

1. **Central visibility**: The organization node provides a single root container where administrators can view and manage all projects across the company. This ensures centralized governance while maintaining the resource hierarchy structure.

2. **Organizing by business unit**: Folders provide the optimal grouping mechanism for business units. As stated in Google Cloud's documentation, folders "can be used to model different legal entities, departments, and teams within a company." Each business unit gets its own folder, which can contain multiple projects and even sub-folders for further organization.

3. **Separate IAM permissions**: Folders act as policy inheritance points. IAM roles granted on a folder resource are automatically inherited by all project and folder resources within that folder. This allows each business unit to have distinct sets of permissions without managing them individually on each project. For example, you can assign the Folder Admin role to business unit leaders, who can then manage their own resources independently.

The resource hierarchy (Organization → Folders → Projects → Resources) mirrors the organizational structure and provides both isolation and inheritance - business units can operate independently while the organization maintains oversight and consistent policies.

### Why Other Options Are Wrong

- **B:** Standalone projects using gmail.com accounts is an anti-pattern that lacks centralized visibility and control. Without an organization node, projects belong to individual users rather than the company, creating "shadow projects" and administrative challenges. When employees leave, their projects could be deleted. This approach provides no hierarchical organization and makes centralized policy enforcement impossible.

- **C:** Using labels to identify resource ownership is insufficient for this use case. Labels are metadata tags useful for billing allocation, resource grouping in queries, or organizational tracking, but they do not provide IAM permission separation or project-level organization. You cannot apply different IAM policies based on labels, and this approach fails to provide the hierarchical structure needed for managing multiple business units with independent permissions.

- **D:** Using VPCs for business unit separation focuses only on network isolation and does not address the broader requirements. VPCs are networking constructs that don't provide visibility into all projects, don't organize projects hierarchically, and don't solve the IAM permission management challenge across business units. Additionally, multiple business units could exist within the same project using different VPCs, which doesn't provide the organizational clarity or access control needed.

### References

- [Resource hierarchy | Resource Manager Documentation](https://docs.cloud.google.com/resource-manager/docs/cloud-platform-resource-hierarchy)
- [IAM overview | Identity and Access Management Documentation](https://docs.cloud.google.com/iam/docs/overview)
- [Decide a resource hierarchy for your Google Cloud landing zone](https://docs.cloud.google.com/architecture/landing-zones/decide-resource-hierarchy)
