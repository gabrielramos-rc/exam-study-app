# Question 158

**Source:** https://www.examtopics.com/discussions/google/view/80816-exam-professional-cloud-security-engineer-topic-1-question/

---

## Question

You are deploying a web application hosted on Compute Engine. A business requirement mandates that application logs are preserved for 12 years and data is kept within European boundaries. You want to implement a storage solution that minimizes overhead and is cost-effective. What should you do?

## Choices

- **A.** Create a Cloud Storage bucket to store your logs in the EUROPE-WEST1 region. Modify your application code to ship logs directly to your bucket for increased efficiency.
- **B.** Configure your Compute Engine instances to use the Google Cloud's operations suite Cloud Logging agent to send application logs to a custom log bucket in the EUROPE-WEST1 region with a custom retention of 12 years.
- **C.** Use a Pub/Sub topic to forward your application logs to a Cloud Storage bucket in the EUROPE-WEST1 region.
- **D.** Configure a custom retention policy of 12 years on your Google Cloud's operations suite log bucket in the EUROPE-WEST1 region.

---

## Community

**Most Voted:** A


**Votes:** A: 46% | B: 44% | C: 10% (48 total)


**Top Comments:**

- (14 upvotes) Correct. Tested and can verify this. Between A and C. and I would choose A.

- (10 upvotes) Seems there is a limitation of retention period for the Google Log Buckets. So A is the correct answer https://cloud.google.com/logging/docs/buckets#create_bucket Optional: To set a custom retention p

- (5 upvotes) A: Google recommand to avoid developping new code while it propose service for that =&gt; incorrect B: seem to reponse for this needs =&gt; correct C: Pub/sub is not using for forwarding log, it is an

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is correct because it leverages Cloud Logging's routing infrastructure while meeting all requirements:

1. **12-Year Retention Requirement**: Cloud Logging custom log buckets have a maximum retention period of 3650 days (approximately 10 years), which is insufficient for the 12-year requirement. Cloud Storage has no such limitation and can retain logs indefinitely.

2. **Minimal Overhead**: Using the Cloud Logging agent with a log sink to Pub/Sub allows the application to continue using standard logging practices. The agent automatically collects and forwards logs to Cloud Logging, which then routes them through Pub/Sub to Cloud Storage. This is a managed solution requiring minimal operational overhead.

3. **European Data Residency**: By creating the Cloud Storage bucket in EUROPE-WEST1, logs remain within European boundaries, satisfying compliance requirements.

4. **Cost-Effectiveness**: Cloud Storage, especially with lifecycle policies to transition to Coldline or Archive storage classes, is more cost-effective for 12-year retention than keeping logs in Cloud Logging buckets (which charge retention fees beyond the default 30-day period).

5. **Standard Architecture Pattern**: Using Pub/Sub as an intermediary for log routing to Cloud Storage is a documented Google Cloud pattern that provides flexibility and decoupling between log collection and storage.

### Why Other Options Are Wrong

- **A.** While this technically works, modifying application code to ship logs directly to Cloud Storage bypasses Cloud Logging entirely, which increases overhead and complexity. You lose benefits like centralized log management, automatic metadata enrichment, and standardized logging. This violates the "minimizes overhead" requirement as developers must implement custom logging logic.

- **B.** This option is technically impossible. Cloud Logging custom log buckets have a maximum retention period of 3650 days (10 years), not 12 years. The documentation explicitly states: "you can configure Cloud Logging to retain your logs between 1 day and 3650 days." A 12-year (4380 days) retention policy cannot be configured.

- **D.** Similar to option B, this is technically impossible. You cannot configure a 12-year retention policy on any Cloud Logging log bucket (default, required, or custom). The maximum retention period is 3650 days (approximately 10 years).

### References

- [Configure log buckets - Cloud Logging](https://cloud.google.com/logging/docs/buckets)
- [Quotas and limits - Cloud Logging](https://cloud.google.com/logging/quotas)
- [Route log entries - Cloud Logging](https://cloud.google.com/logging/docs/routing/overview)
- [View logs routed to Cloud Storage](https://cloud.google.com/logging/docs/export/storage)
- [Regionalize your logs - Cloud Logging](https://cloud.google.com/logging/docs/regionalized-logs)
- [Keep your logs data compliant with regional log buckets](https://cloud.google.com/blog/products/operations/keep-your-logs-data-compliant-with-regional-log-buckets)
