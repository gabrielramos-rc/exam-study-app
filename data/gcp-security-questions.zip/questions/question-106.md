# Question 106

**Source:** https://www.examtopics.com/discussions/google/view/84628-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** folders, resource hierarchy, IAM, Google Cloud Directory Sync, groups

---

## Question

You work for a large organization where each business unit has thousands of users. You need to delegate management of access control permissions to each business unit. You have the following requirements: ✑ Each business unit manages access controls for their own projects. ✑ Each business unit manages access control permissions at scale. ✑ Business units cannot access other business units' projects. ✑ Users lose their access if they move to a different business unit or leave the company. ✑ Users and access control permissions are managed by the on-premises directory service. What should you do? (Choose two.)
## Choices

- **A.** Use VPC Service Controls to create perimeters around each business unit's project.
- **B.** Organize projects in folders, and assign permissions to Google groups at the folder level. Most Voted
- **C.** Group business units based on Organization Units (OUs) and manage permissions based on OUs
- **D.** Create a project naming convention, and use Google's IAM Conditions to manage access based on the prefix of project names.
- **E.** Use Google Cloud Directory Sync to synchronize users and group memberships in Cloud Identity. Most Voted

---

## Community

**Most Voted:** BE


**Votes:** BE: 100% (8 total)


**Top Comments:**

- (5 upvotes) I will take B &amp; E. Makes sense for the OUs to have their own folders and respective projects under their folders. This will make each OU independent from one another in terms of environments, and 

- (5 upvotes) Ans are : B &amp; E

- (2 upvotes) Agreed…B &amp; E

---

## Answer

**Correct:** B, E

**Confidence:** high

### Explanation

The correct solution combines **B (folders with group-based permissions)** and **E (Google Cloud Directory Sync)** to meet all requirements:

**Option B - Organize projects in folders with group-based IAM:**
- Folders provide hierarchical organization where each business unit gets its own folder containing their projects
- IAM permissions assigned at the folder level automatically inherit to all projects within that folder
- This enables delegation at scale - business unit admins get Folder Admin or other roles on their folder, granting control over all contained projects
- Folder boundaries provide natural isolation - permissions granted on one folder don't affect projects in other folders
- As Google's documentation states: "Folder resources allow delegation of administration rights, so for example, each head of a department can be granted full ownership of all Google Cloud resources that belong to their departments"

**Option E - Google Cloud Directory Sync (GCDS):**
- Synchronizes users and groups from on-premises Active Directory/LDAP to Cloud Identity
- Provides one-way sync ensuring on-premises directory remains the authoritative source
- When users are removed from groups in AD (due to departure or transfer), those changes automatically sync to Cloud Identity
- Group memberships in Cloud Identity reflect the current state of the on-premises directory
- Enables the "users lose their access if they move to a different business unit" requirement through automated group membership management

Together, these solutions create a scalable, delegated access control model where:
1. On-premises directory manages who is in which business unit (via groups)
2. GCDS keeps Cloud Identity synchronized with those groups
3. Each business unit's folder has IAM bindings to their respective groups
4. Business unit admins manage their own folder's permissions without cross-contamination

### Why Other Options Are Wrong

- **A:** VPC Service Controls create security perimeters around services and data, not access control delegation. They prevent data exfiltration but don't address IAM delegation, user lifecycle management, or on-premises directory integration. Wrong tool for this use case.

- **C:** Organization Units (OUs) are an Active Directory concept, not a Google Cloud IAM feature. While you might organize users in OUs on-premises, Google Cloud doesn't have native OU-based permission management. You must use folders for resource hierarchy and groups for identity management.

- **D:** Using project naming conventions with IAM Conditions is overly complex, fragile, and doesn't scale well. IAM Conditions can filter based on resource attributes, but managing permissions based on name prefixes creates maintenance overhead, is error-prone, and doesn't provide the clear administrative boundaries that folders offer. This approach also doesn't integrate with on-premises directory services for user lifecycle management.

### References

- [Access control for folders with IAM](https://docs.cloud.google.com/resource-manager/docs/access-control-folders)
- [Resource hierarchy](https://docs.cloud.google.com/resource-manager/docs/cloud-platform-resource-hierarchy)
- [Active Directory user account provisioning](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-synchronizing-user-accounts)
- [Using resource hierarchy for access control](https://docs.cloud.google.com/iam/docs/resource-hierarchy-access-control)
