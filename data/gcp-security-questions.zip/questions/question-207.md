# Question 207

**Source:** https://www.examtopics.com/discussions/google/view/117281-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Cloud NAT, Private Google Access, organizational policy, VM external IP

---

## Question

Your DevOps team uses Packer to build Compute Engine images by using this process: 1. Create an ephemeral Compute Engine VM. 2. Copy a binary from a Cloud Storage bucket to the VM's file system. 3. Update the VM's package manager. 4. Install external packages from the internet onto the VM. Your security team just enabled the organizational policy, constraints/ compute.vmExternalIpAccess, to restrict the usage of public IP Addresses on VMs. In response, your DevOps team updated their scripts to remove public IP addresses on the Compute Engine VMs; however, the build pipeline is failing due to connectivity issues. What should you do? (Choose two.)
## Choices

- **A.** Provision an HTTP load balancer with the VM in an unmanaged instance group to allow inbound connections from the internet to your VM.
- **B.** Provision a Cloud NAT instance in the same VPC and region as the Compute Engine VM. Most Voted
- **C.** Enable Private Google Access on the subnet that the Compute Engine VM is deployed within. Most Voted
- **D.** Update the VPC routes to allow traffic to and from the internet.
- **E.** Provision a Cloud VPN tunnel in the same VPC and region as the Compute Engine VM.

---

## Community

**Most Voted:** BC


**Votes:** BC: 100% (10 total)


**Top Comments:**

- (3 upvotes) BC looks good

- (3 upvotes) BC I think Cloud NAT to update em private access to cloud storage access

- (2 upvotes) B &amp; C make sense

---

## Answer

**Correct:** B, C

**Confidence:** high

### Explanation

The Packer build process requires two distinct types of connectivity:

1. **Access to Cloud Storage** (step 2: copying binaries) - This requires **Private Google Access (Option C)**. When enabled on a subnet, Private Google Access allows VMs with only internal IP addresses to reach the external IP addresses of Google APIs and services, including Cloud Storage. According to Google Cloud documentation, "VM instances that only have internal IP addresses can use Private Google Access. They can reach the external IP addresses of Google APIs and services."

2. **Access to internet package repositories** (step 4: installing external packages) - This requires **Cloud NAT (Option B)**. Cloud NAT enables VMs without external IP addresses to access the internet by performing source network address translation (SNAT). As stated in the documentation, "VMs without external IP addresses can access destinations on the internet" when a Cloud NAT gateway is configured. This is essential for downloading software packages from external repositories.

Together, these two solutions address the connectivity failures caused by removing public IP addresses from the VMs. Cloud NAT handles general internet access, while Private Google Access specifically handles communication with Google Cloud services.

### Why Other Options Are Wrong

- **A:** An HTTP load balancer provides *inbound* connectivity from the internet to your VMs, not *outbound* connectivity. The Packer build process needs to reach external resources (Cloud Storage and package repositories), not receive inbound connections. Additionally, load balancers add unnecessary complexity and cost for this use case.

- **D:** Simply updating VPC routes is insufficient. Without either external IP addresses or Cloud NAT, VMs with only internal IPs cannot route traffic to the internet, regardless of route configuration. Routes define paths, but Cloud NAT is required to perform the address translation that makes internet connectivity possible.

- **E:** Cloud VPN establishes secure tunnels to on-premises networks or other VPCs, but doesn't provide general internet access for VMs. VPN is designed for hybrid connectivity scenarios, not for accessing public internet resources or Google Cloud APIs.

### References

- [Cloud NAT overview](https://docs.cloud.google.com/nat/docs/overview)
- [Private Google Access](https://docs.cloud.google.com/vpc/docs/private-google-access)
- [Configure Private Google Access](https://docs.cloud.google.com/vpc/docs/configure-private-google-access)
