# Question 071

**Source:** https://www.examtopics.com/discussions/google/view/30364-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** service account, IAM roles, least privilege, Compute Viewer

---

## Question

You will create a new Service Account that should be able to list the Compute Engine instances in the project. You want to follow Google-recommended practices. What should you do?
## Choices

- **A.** Create an Instance Template, and allow the Service Account Read Only access for the Compute Engine Access Scope.
- **B.** Create a custom role with the permission compute.instances.list and grant the Service Account this role. Most Voted
- **C.** Give the Service Account the role of Compute Viewer, and use the new Service Account for all instances.
- **D.** Give the Service Account the role of Project Viewer, and use the new Service Account for all instances.

---

## Community

**Most Voted:** B


**Votes:** B: 90% | C: 10% (20 total)


**Top Comments:**

- (16 upvotes) B is right

- (7 upvotes) Key here is "and grant the Service Account this role.". C and D are giving this role to ALL instances which is overly permissive. A is wrong. Only choice is B

- (5 upvotes) B. Create a custom role with the permission compute.instances.list and grant the Service Account this role: This follows the principle of least privilege by granting only the specific permission neede

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Creating a custom role with only the `compute.instances.list` permission is the correct answer because it best follows the **principle of least privilege**, which is the cornerstone of Google-recommended practices for service accounts.

The requirement is narrow and specific: "list the Compute Engine instances in the project." This requires exactly ONE permission: `compute.instances.list`. A custom role grants precisely this permission and nothing more.

The Compute Viewer role (`roles/compute.viewer`) would grant read access to ALL Compute Engine resources - not just instances, but also disks, networks, images, snapshots, firewalls, and more. This violates least privilege by providing far more access than needed.

Google's best practices prioritize:
1. **Grant only the minimum permissions required** - this is the primary principle
2. Use predefined roles when they match requirements - but Compute Viewer far exceeds this requirement
3. Create custom roles when predefined roles are too broad

### Why Other Options Are Wrong

- **A:** Access scopes are a legacy mechanism for controlling service account permissions on VM instances. Google explicitly recommends against relying on access scopes and instead recommends using IAM roles. Additionally, an Instance Template is not relevant to granting IAM permissions to a service account.

- **C:** Compute Viewer (`roles/compute.viewer`) grants read-only access to ALL Compute Engine resources (instances, disks, networks, images, snapshots, etc.), not just instance listing. This violates least privilege by granting many unnecessary permissions. The phrase "use the new Service Account for all instances" is also confusing and doesn't relate to the IAM requirement.

- **D:** Project Viewer (`roles/viewer`) grants read-only access to ALL resources across the entire project, not just Compute Engine. This is even more permissive than Compute Viewer and severely violates least privilege.

### References

- [Best practices for using service accounts securely](https://cloud.google.com/iam/docs/best-practices-service-accounts)
- [Understanding custom roles](https://cloud.google.com/iam/docs/understanding-custom-roles)
- [Compute Engine IAM roles and permissions](https://cloud.google.com/compute/docs/access/iam)
