# Question 211

**Source:** https://www.examtopics.com/discussions/google/view/117315-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** GDPR, data residency, data sovereignty, Assured Workloads, organization policy, personnel controls

---

## Question

Your organization wants to be compliant with the General Data Protection Regulation (GDPR) on Google Cloud. You must implement data residency and operational sovereignty in the EU. What should you do? (Choose two.)
## Choices

- **A.** Limit the physical location of a new resource with the Organization Policy Service "resource locations constraint." Most Voted
- **B.** Use Cloud IDS to get east-west and north-south traffic visibility in the EU to monitor intra-VPC and inter-VPC communication.
- **C.** Limit Google personnel access based on predefined attributes such as their citizenship or geographic location by using Key Access Justifications. Most Voted
- **D.** Use identity federation to limit access to Google Cloud resources from non-EU entities.
- **E.** Use VPC Flow Logs to monitor intra-VPC and inter-VPC traffic in the EU.

---

## Community

**Most Voted:** AC


**Votes:** AC: 89% | AD: 11% (18 total)


**Top Comments:**

- (9 upvotes) A &amp; C https://cloud.google.com/assured-workloads/key-access-justifications/docs/assured-workloads

- (4 upvotes) C is incorrect. Key Access Justifications can be used to limit access to specific keys, but they do not prevent Google personnel from accessing other data in your Google Cloud environment. A and D are

- (2 upvotes) To be compliant with GDPR on Google Cloud and implement data residency and operational sovereignty in the EU, you can take the following two actions: A. Limit the physical location of a new resource w

---

## Answer

**Correct:** A, C

**Confidence:** high

### Explanation

For GDPR compliance requiring data residency and operational sovereignty in the EU, you need to implement two types of controls:

**Option A (Resource Locations Constraint)** addresses **data residency** by restricting where data can be stored. The Organization Policy Service resource locations constraint allows you to restrict the physical location of new resources at the organization, project, or folder level. This ensures that all data remains within EU regions, which is a fundamental requirement for GDPR compliance and data residency.

**Option C (Personnel Controls)** addresses **operational sovereignty** by limiting which Google personnel can access your data. While the question mentions "Key Access Justifications," the actual feature that limits Google personnel access based on citizenship or geographic location is **Assured Workloads personnel controls**. These controls, available with specific EU control packages (like EU Data Boundary and Support), ensure that support access is restricted to EU personnel based in the EU. This provides operational sovereignty by preventing non-EU Google staff from accessing your workloads.

Note: Key Access Justifications actually provides transparency and approval workflows for key access requests, not personnel citizenship/location restrictions. However, option C correctly identifies the need for personnel controls based on citizenship and geographic location, which is a valid requirement for operational sovereignty in GDPR contexts.

### Why Other Options Are Wrong

- **B (Cloud IDS):** Cloud IDS is an intrusion detection system that provides network traffic visibility for security monitoring. While useful for security operations, it does not implement data residency or operational sovereignty controls. It's a monitoring tool, not a compliance control.

- **D (Identity federation):** Identity federation controls which external users can access Google Cloud resources based on their identity provider. This addresses user authentication and authorization but does not control where data is stored (residency) or restrict Google personnel access (sovereignty). It's about customer user access, not data location or Google staff access.

- **E (VPC Flow Logs):** VPC Flow Logs capture network traffic metadata for monitoring and troubleshooting. Like Cloud IDS, this is a monitoring and visibility tool, not a control mechanism for data residency or operational sovereignty. Logging traffic does not prevent data from being stored outside the EU or restrict Google personnel access.

### References

- [Data residency | Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/data-residency)
- [Overview of Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/overview)
- [Control packages | Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/control-packages)
- [Meet regulatory, compliance, and privacy needs](https://docs.cloud.google.com/architecture/framework/security/meet-regulatory-compliance-and-privacy-needs)
