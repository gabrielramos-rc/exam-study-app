# Question 276

**Source:** https://www.examtopics.com/discussions/google/view/147070-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC network, network isolation, VPC peering, hub-and-spoke, on-premises connectivity

---

## Question

You are creating a secure network architecture. You must fully isolate development and production environments, and prevent any network traffic between the two environments. The network team requires that there is only one central entry point to the cloud network from the on-premises environment. What should you do?
## Choices

- **A.** Create one Virtual Private Cloud (VPC) network per environment. Add the on-premises entry point to the production VPC. Peer the VPCs with each other and create firewall rules to prevent traffic.
- **B.** Create one shared Virtual Private Cloud (VPC) network and use it as the entry point to the cloud network. Create separate subnets per environment. Create firewall rules to prevent traffic.
- **C.** Create one Virtual Private Cloud (VPC) network per environment. Create a VPC Service Controls perimeter per environment and add one environment VPC to each.
- **D.** Create one Virtual Private Cloud (VPC) network per environment. Create one additional VPC for the entry point to the cloud network. Peer the entry point VPC with the environment VPCs. Most Voted

---

## Community

**Most Voted:** D


**Votes:** C: 17% | D: 83% (6 total)


**Top Comments:**

- (2 upvotes) It's D

- (1 upvotes) D satisfies all requirements

- (1 upvotes) d is correct?

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D implements the **hub-and-spoke network architecture**, which is the Google Cloud recommended pattern for this exact scenario. According to Google Cloud documentation, this topology uses "a central routing VPC network that contains shared services" and serves as "the sole entry point to the cloud from the enterprise's on-premises network."

In this design:
- **Each environment (dev, prod) gets its own VPC** (spoke networks) - providing complete isolation
- **One additional VPC serves as the hub** - the central entry point from on-premises
- **VPC peering connects hub to spokes** - each spoke peers only with the hub, not with each other
- **Non-transitive peering provides isolation** - VPC Network Peering is non-transitive, meaning development and production spoke VPCs cannot communicate with each other even though both are peered to the hub

The documentation explicitly states: "VPC Network Peering connections are not transitive. In this architecture, the on-premises and workload VPC networks can exchange traffic with the routing network, but not with each other." This inherent property of VPC peering provides the required isolation without relying on firewall rules.

The hub VPC would contain the Cloud VPN or Cloud Interconnect connection to on-premises, satisfying the requirement for a single central entry point.

### Why Other Options Are Wrong

- **A:** Peering development and production VPCs directly violates the isolation requirement. While firewall rules could block traffic, this creates a less secure architecture because you're relying on configuration (firewall rules) rather than network design (non-transitive peering). Additionally, connecting on-premises to only the production VPC doesn't provide a neutral central entry point - it biases the architecture toward production and makes the development environment dependent on production infrastructure.

- **B:** Using a shared VPC with separate subnets does not provide full network isolation. Subnets within the same VPC can communicate with each other by default. While firewall rules can block this traffic, you're still within a single security boundary. This violates the principle of defense in depth and doesn't achieve "fully isolate" as required. Subnets are meant for segmentation within an environment, not between environments.

- **C:** VPC Service Controls create security perimeters around Google Cloud services (like Cloud Storage, BigQuery) to prevent data exfiltration, not network isolation between VPCs. Service Controls do not control network traffic between VPCs or provide on-premises connectivity. They operate at the API/service level, not the network level. This option doesn't address the requirement for a central entry point from on-premises.

### References

- [Hub-and-spoke network architecture](https://docs.cloud.google.com/architecture/deploy-hub-spoke-vpc-network-topology)
- [Decide the network design for your Google Cloud landing zone](https://docs.cloud.google.com/architecture/landing-zones/decide-network-design)
- [Best practices and reference architectures for VPC design](https://docs.cloud.google.com/architecture/best-practices-vpc-design)
