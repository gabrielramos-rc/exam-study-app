# Question 338

**Source:** https://www.examtopics.com/discussions/google/view/311191-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** GKE security, organization policy, auto-upgrade, patch management, node pool security

---

## Question

Your organization is planning to deploy a large number of Google Kubernetes Engine (GKE) clusters to run business applications in different folders and projects. You must ensure that all GKE nodes always run the latest release to minimize vulnerability risk and administrative effort. What should you do?
## Choices

- **A.** After creating clusters, use the Google Cloud console gcloud container node-pools describe NODE_POOL_NAME --cluster=CLUSTER_NAME command. Examine the upgradeSettings and UpdateInfo output.
- **B.** Create a custom organization policy constraint resource.management.autoUpgrade == true with an action type of ALLOW at the organization level before deployment. Most Voted
- **C.** Create a new node pool with the newer version for each cluster. Migrate the workload. Eliminate the outdated node pool.
- **D.** Manually run the Google Cloud console gcloud container clusters upgrade CLUSTER_NAME--node-pool=NODE_POOL_NAME --cluster-version VERSION command on newly created clusters regularly.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (1 total)

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Creating a custom organization policy constraint with `resource.management.autoUpgrade == true` and action type `ALLOW` at the organization level is the most effective solution to ensure all GKE nodes always run the latest release with minimal administrative effort. This approach:

1. **Enforces auto-upgrade at scale**: The organization policy applies automatically to all GKE clusters created across all folders and projects within the organization, ensuring compliance for the "large number of clusters" mentioned in the scenario.

2. **Prevents non-compliant configurations**: The constraint with `ALLOW` action type requires that all node pools must have `autoUpgrade` enabled. Any attempt to create or update a node pool without auto-upgrade enabled will be blocked by the organization policy.

3. **Reduces administrative overhead**: Once set at the organization level, no per-cluster or per-project configuration is needed. New clusters automatically inherit the requirement, and existing clusters must comply.

4. **Minimizes vulnerability risk**: With auto-upgrades enforced, all node pools automatically receive the latest patches and security updates when GKE selects versions for auto-upgrade, maintaining security posture across the entire organization.

The policy is defined as a custom constraint for the `container.googleapis.com/NodePool` resource type and can be enforced using CEL (Common Expression Language) conditions. After implementation, the policy takes effect within 15 minutes and ensures all future node pool creations and updates comply with the auto-upgrade requirement.

### Why Other Options Are Wrong

- **A:** Simply examining upgrade settings after cluster creation is a monitoring/verification action, not a preventive control. This doesn't ensure that auto-upgrade is enabled or enforce it across all clusters. It provides visibility but doesn't solve the problem of minimizing administrative effort or ensuring compliance.

- **C:** Creating new node pools and migrating workloads is a manual upgrade strategy that requires significant administrative effort for each cluster. With a "large number of GKE clusters," this approach is operationally expensive and doesn't minimize administrative effort as required. This is the traditional blue/green upgrade approach, useful for controlled migrations but not for automated ongoing maintenance.

- **D:** Manually running upgrade commands regularly is the most labor-intensive option and directly contradicts the requirement to minimize administrative effort. This approach requires continuous manual intervention, scheduling, and coordination across all clusters in different folders and projects. It's error-prone and doesn't scale well.

### References

- [Restrict actions on GKE resources using custom organization policies](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/custom-org-policies)
- [Auto-upgrading nodes | Google Kubernetes Engine (GKE)](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/node-auto-upgrades)
- [Creating and managing custom constraints | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/organization-policy/creating-managing-custom-constraints)
