# Question 322

**Source:** https://www.examtopics.com/discussions/google/view/306212-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, user provisioning, unmanaged accounts, consumer accounts

---

## Question

You are responsible for managing identities in your company’s Google Cloud organization. Employees are frequently using your organization's corporate domain name to create unmanaged Google accounts. You want to implement a practical and efficient solution to prevent employees from completing this action in the future. What should you do?
## Choices

- **A.** Create a Google Cloud identity for all users in your organization. Ensure that new users are added automatically. Most Voted
- **B.** Implement an automated process that scans all identities in your organization and disables any unmanaged accounts.
- **C.** Register a new domain for your Google Cloud resources. Move all existing identities and resources to this domain.
- **D.** Switch your corporate email system to another domain to avoid using the same domain for Google Cloud identities and corporate emails.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (2 total)


**Top Comments:**

- (1 upvotes) A is correct.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The correct solution is to create Cloud Identity accounts for all users in the organization and ensure new users are automatically provisioned. This is the **proactive provisioning** approach recommended by Google Cloud documentation for preventing unmanaged (consumer) Google accounts.

When you proactively create a managed user account in Cloud Identity or Google Workspace with a corporate email address (e.g., alice@example.com), any subsequent attempts by employees to create consumer Google accounts using that same email address will fail. The system blocks conflicting registrations because the email is already associated with a managed organizational identity.

Key technical details:
- **Prevention mechanism**: Once a Cloud Identity user exists, the email cannot be reused for a personal Google account
- **Automation**: Using Directory Sync (GCDS) or automated provisioning ensures new employees get Cloud Identity accounts immediately
- **Centralized management**: All identities remain under organizational control with SSO, password policies, and security controls applied
- **Best practice**: This is explicitly stated as the preferred approach to prevent the security risks of unmanaged accounts bearing corporate email addresses

### Why Other Options Are Wrong

- **B:** This is a reactive approach that only addresses existing unmanaged accounts but doesn't prevent future account creation. The question asks to "prevent employees from completing this action in the future," making this solution insufficient and inefficient.

- **C:** Registering a new domain and migrating all resources is unnecessarily disruptive, expensive, and doesn't solve the root problem. Employees could still create unmanaged accounts with the new domain if proactive provisioning isn't implemented.

- **D:** Switching the corporate email domain is an extreme measure that creates massive operational disruption. It's neither practical nor efficient, and Google Cloud documentation specifically supports using the same domain for Cloud Identity and corporate email when properly configured.

### References

- [Evict consumer accounts - Google Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/evicting-consumer-accounts)
- [Sanitize Gmail accounts - Google Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/sanitizing-gmail-accounts)
