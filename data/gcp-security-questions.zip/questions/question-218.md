# Question 218

**Source:** https://www.examtopics.com/discussions/google/view/117320-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Managing authentication
**Tags:** session management, session timeout, authentication, Google Workspace, 2-step verification

---

## Question

Your organization uses Google Workspace Enterprise Edition for authentication. You are concerned about employees leaving their laptops unattended for extended periods of time after authenticating into Google Cloud. You must prevent malicious people from using an employee's unattended laptop to modify their environment. What should you do?
## Choices

- **A.** Create a policy that requires employees to not leave their sessions open for long durations.
- **B.** Review and disable unnecessary Google Cloud APIs.
- **C.** Require strong passwords and 2SV through a security token or Google authenticator.
- **D.** Set the session length timeout for Google Cloud services to a shorter duration. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (6 total)


**Top Comments:**

- (3 upvotes) D shoud be fine

- (2 upvotes) D is the correct.

- (1 upvotes) "extended periods of time" is the key phrase here

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The correct solution is to set the session length timeout for Google Cloud services to a shorter duration. This is a technical control that directly addresses the risk of unattended laptops by automatically invalidating authentication sessions after a specified period of inactivity.

When using Google Workspace Enterprise Edition for authentication, administrators can configure session duration policies through the Google Admin Console. These session controls can be applied to Google Cloud services to ensure that:

1. Sessions automatically expire after a defined timeout period
2. Users are required to re-authenticate when the session expires
3. Unattended laptops cannot be used indefinitely to access Google Cloud resources

This approach provides defense-in-depth by implementing a time-based security control that limits the window of opportunity for unauthorized access. Session timeout policies are a fundamental security best practice for preventing unauthorized use of authenticated sessions, particularly in scenarios where physical device security cannot be guaranteed.

For Google Workspace customers, session length controls can be configured through Access Context Manager or through Google Workspace session management settings, which apply to all Google Cloud services accessed via Workspace authentication.

### Why Other Options Are Wrong

- **A:** Creating a policy that requires employees to not leave sessions open is purely administrative and relies entirely on user compliance with no technical enforcement. This does not actually prevent malicious actors from using unattended laptops - it only documents what employees should do. Policies alone without technical controls are insufficient for security.

- **B:** Reviewing and disabling unnecessary Google Cloud APIs does not address the session security concern. While reducing API attack surface is a good general security practice, it does nothing to prevent someone from using an already-authenticated session on an unattended laptop to perform malicious actions through the enabled APIs.

- **C:** Requiring strong passwords and 2-step verification (2SV) improves initial authentication security but does not address the core problem of unattended laptops with active sessions. Once a user has successfully authenticated with 2SV and leaves their laptop unattended, a malicious actor can use that active session without needing to provide credentials or complete 2SV again.

### References

- [Access Context Manager Overview](https://docs.cloud.google.com/access-context-manager/docs/overview)
- [Google Workspace Admin Help - Session Control](https://support.google.com/a/answer/7576830)
- [Cloud Identity and Access Management Best Practices](https://cloud.google.com/iam/docs/best-practices-for-securing-service-accounts)
