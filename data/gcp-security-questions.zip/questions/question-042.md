# Question 042

**Source:** https://www.examtopics.com/discussions/google/view/17846-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** container security, GKE security, image hardening, attack surface minimization

---

## Question

A DevOps team will create a new container to run on Google Kubernetes Engine. As the application will be internet-facing, they want to minimize the attack surface of the container. What should they do?
## Choices

- **A.** Use Cloud Build to build the container images.
- **B.** Build small containers using small base images. Most Voted
- **C.** Delete non-used versions from Container Registry.
- **D.** Use a Continuous Delivery tool to deploy the application.

---

## Community

**Most Voted:** B


**Votes:** B: 67% | C: 33% (18 total)


**Top Comments:**

- (31 upvotes) I agree

- (3 upvotes) Answer is B, because this GCP exam, the GCP docs are always source of truth even though you might not be agree with them occasionally but even if you are not agree you need to choose the answer propos

- (3 upvotes) the only answer that will really reduce attack surface while exposing apps to internet is B, small containers (e.g. single web page?)

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Building small containers using small base images is the most effective way to minimize the attack surface of a container. According to Google Cloud documentation on building leaner containers, using minimal base images (such as Alpine Linux-based images or distroless images) reduces attack surface by including only the necessary runtime dependencies and excluding unnecessary components, tools, and binaries that could potentially be exploited.

The documentation specifically recommends separating build-time concerns from runtime requirements. For example, using lightweight alternatives like "openjdk:8-jre-alpine" which is "incredibly lean" rather than full images with development tools. Minimal base images inherently reduce attack surface by containing fewer packages, no shell, no package managers, and only essential runtime dependencies - all common attack vectors.

This approach directly addresses the security concern: smaller images mean fewer installed packages, fewer potential vulnerabilities, and a reduced attack surface for internet-facing applications running on GKE.

### Why Other Options Are Wrong

- **A:** While Cloud Build is a great tool for building container images, it's a build platform/service, not a security measure. You can build both secure and insecure containers with Cloud Build - it doesn't inherently minimize attack surface. The tool used to build doesn't determine the security posture of the resulting container.

- **C:** Deleting old/unused container versions from Container Registry is good housekeeping for reducing storage costs and preventing accidental deployment of outdated images, but it does nothing to minimize the attack surface of the containers actually running in production. This is a registry management task, not a container security hardening measure.

- **D:** Using a Continuous Delivery tool helps with deployment automation and consistency, but like Cloud Build, it's a deployment mechanism, not a security control. CD tools don't inherently reduce attack surface - they just automate the deployment of whatever containers you build (secure or not).

### References

- [Building leaner containers](https://docs.cloud.google.com/build/docs/optimize-builds/building-leaner-containers)
- [Base images](https://docs.cloud.google.com/software-supply-chain-security/docs/base-images)
- [Harden your cluster's security](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/hardening-your-cluster)
