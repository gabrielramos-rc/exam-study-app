# Question 318

**Source:** https://www.examtopics.com/discussions/google/view/150190-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** encryption, client-side encryption, Cloud KMS, Cloud HSM, CMEK, CSEK, data protection

---

## Question

Your organization must store highly sensitive data within Google Cloud. You need to design a solution that provides the strongest level of security and control. What should you do?
## Choices

- **A.** Use Cloud Storage with customer-supplied encryption keys (CSEK), VPC Service Controls for network isolation, and Cloud DLP for data inspection.
- **B.** Use Cloud Storage with customer-managed encryption keys (CMEK), Cloud DLP for data classification, and Secret Manager for storing API access tokens.
- **C.** Use Cloud Storage with client-side encryption, Cloud KMS for key management, and Cloud HSM for cryptographic operations. Most Voted
- **D.** Use Cloud Storage with server-side encryption, BigQuery with column-level encryption, and IAM roles for access control.

---

## Community

**Most Voted:** C


**Votes:** B: 14% | C: 86% (7 total)


**Top Comments:**

- (2 upvotes) Answer C

- (1 upvotes) A more suitable option would involve using Cloud HSMs in conjunction with other strong security measures such as CMEKs and Cloud DLP.

- (1 upvotes) Highly Secure etc = HSM

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Client-side encryption provides the **strongest level of security and control** for highly sensitive data in Google Cloud. According to Google Cloud documentation, client-side encryption offers "the highest level of control" because encryption occurs before data reaches Google's servers, ensuring Google has no possible access to unencrypted data.

Option C combines three key security components:

1. **Client-side encryption**: Data is encrypted on the client before upload, providing maximum control since Google never sees the unencrypted data
2. **Cloud KMS for key management**: Provides centralized key management, auditing, rotation, and access controls for encryption keys
3. **Cloud HSM for cryptographic operations**: Uses FIPS 140-2 Level 3 certified hardware security modules for cryptographic operations, providing the highest level of hardware-backed key protection

Cloud HSM uses Cloud KMS as its front end, allowing you to leverage Cloud KMS features while ensuring all cryptographic operations using HSM keys are performed inside the hardware security module boundary. The key material never leaves the HSM protection boundary, providing the strongest cryptographic guarantees.

This combination ensures that:
- Encryption happens client-side (maximum control)
- Keys are managed in a centralized, auditable system (Cloud KMS)
- Cryptographic operations use FIPS 140-2 Level 3 certified hardware (Cloud HSM)
- Google has zero access to unencrypted data or key material

### Why Other Options Are Wrong

- **A:** Customer-supplied encryption keys (CSEK) is server-side encryption where you provide keys with each request. While CSEK provides good control (keys are not stored by Google), it's still server-side encryption, meaning Google performs the encryption/decryption. This provides less control than client-side encryption.

- **B:** Customer-managed encryption keys (CMEK) is server-side encryption where keys are stored in Cloud KMS. While CMEK provides good key management capabilities, it's still server-side encryption with less control than client-side encryption. The documentation states CMEK "balances compliance needs with practical key management" but doesn't provide the strongest level of control.

- **D:** Server-side encryption with Google-managed keys (default encryption) provides the least customer control. While it satisfies many compliance requirements, Google manages all aspects of encryption and you have no control over the keys. This is the weakest option for organizations requiring the "strongest level of security and control."

### References

- [Data encryption options - Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption)
- [Cloud HSM - Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/hsm)
- [Cloud Key Management Service overview](https://docs.cloud.google.com/kms/docs/key-management-service)
