# Question 209

**Source:** https://www.examtopics.com/discussions/google/view/117282-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Binary Authorization, GKE security, container security, attestation, trusted images

---

## Question

Your organization is transitioning to Google Cloud. You want to ensure that only trusted container images are deployed on Google Kubernetes Engine (GKE) clusters in a project. The containers must be deployed from a centrally managed Container Registry and signed by a trusted authority. What should you do? (Choose two.)
## Choices

- **A.** Enable Container Threat Detection in the Security Command Center (SCC) for the project.
- **B.** Configure the trusted image organization policy constraint for the project.
- **C.** Create a custom organization policy constraint to enforce Binary Authorization for Google Kubernetes Engine (GKE). Most Voted
- **D.** Enable PodSecurity standards, and set them to Restricted.
- **E.** Configure the Binary Authorization policy with respective attestations for the project. Most Voted

---

## Community

**Most Voted:** CE


**Votes:** BE: 48% | CE: 52% (21 total)


**Top Comments:**

- (4 upvotes) BE are correct!

- (4 upvotes) Options A, C, and D are not directly related to ensuring the use of trusted container images from a centrally managed Container Registry and signed by a trusted authority: A. Enabling Container Threat

- (3 upvotes) it's an org policy constraint it applies to all kings of images

---

## Answer

**Correct:** C, E

**Confidence:** high

### Explanation

To ensure only trusted, signed container images are deployed on GKE, you need Binary Authorization, which requires two key components:

**Option E - Binary Authorization Policy with Attestations:** This is the core mechanism that enforces deployment controls. The Binary Authorization policy defines admission rules that specify which attestations are required before a container image can be deployed. Attestations are cryptographic signatures created by trusted authorities (attestors) that certify an image has passed specific verification processes (e.g., built by an approved CI/CD pipeline, passed vulnerability scanning). During deployment, Binary Authorization verifies these signatures using Cloud KMS or PGP keys, blocking any images that lack the required attestations.

**Option C - Organization Policy to Enforce Binary Authorization:** While the wording mentions "custom" organization policy, you need to enforce Binary Authorization at the project or organization level to ensure it applies to all GKE clusters. Google Cloud provides the managed organization policy constraint `constraints/container.managed.enableBinaryAuthorization` which requires Binary Authorization to be enabled when creating or updating GKE clusters. This ensures the security control cannot be bypassed and applies consistently across the project.

Together, these two options create a complete solution: option C ensures Binary Authorization is enabled on all GKE clusters (enforcement layer), while option E provides the actual policy and attestation mechanism that verifies signatures and blocks untrusted images (verification layer).

### Why Other Options Are Wrong

- **A:** Container Threat Detection in SCC identifies runtime threats and vulnerabilities in running containers, but it doesn't prevent deployment of untrusted images in the first place. It's a detective control, not a preventive one for deployment-time image verification.

- **B:** The `constraints/compute.trustedImageProjects` organization policy constraint applies to Compute Engine VM boot disk images, not to container images in GKE. It restricts which projects can be used as sources for VM disk images, which is unrelated to container image verification and signing.

- **D:** PodSecurity standards enforce security controls on pod specifications (like preventing privileged containers or host network access), but they don't verify image signatures or control which container registries can be used. They address pod configuration security, not image trust and provenance.

### References

- [Binary Authorization Overview](https://docs.cloud.google.com/binary-authorization/docs/overview)
- [Binary Authorization Policy YAML Reference](https://docs.cloud.google.com/binary-authorization/docs/policy-yaml-reference)
- [Organization Policy Constraints](https://docs.cloud.google.com/resource-manager/docs/organization-policy/org-policy-constraints)
