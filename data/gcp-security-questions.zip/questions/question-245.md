# Question 245

**Source:** https://www.examtopics.com/discussions/google/view/146883-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Private Google Access, VPC, private subnet, Compute Engine, Cloud Storage

---

## Question

You have placed several Compute Engine instances in a private subnet. You want to allow these instances to access Google Cloud services, like Cloud Storage, without traversing the internet. What should you do?
## Choices

- **A.** Enable Private Google Access for the private subnet. Most Voted
- **B.** Configure Private Service Connect for the private subnet's Virtual Private Cloud (VPC) and allocate an IP range for the Compute Engine instances.
- **C.** Reserve and assign static external IP addresses for the Compute Engine instances.
- **D.** Create a Cloud NAT gateway for the region where the private subnet is configured.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (2 total)


**Top Comments:**

- (2 upvotes) New exam questions !

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Private Google Access is specifically designed for this exact scenario. It allows VM instances that only have internal (private) IP addresses to reach the external IP addresses of Google APIs and services without traversing the public internet.

When you enable Private Google Access on a subnet:
- VMs without external IP addresses in that subnet can access Google Cloud services (Cloud Storage, BigQuery, etc.)
- Traffic stays within Google's network infrastructure, never touching the internet
- It's configured at the subnet level using a simple on/off toggle
- No additional infrastructure or IP allocation is required

The configuration is straightforward - you simply enable Private Google Access for the subnet in the VPC network settings, either through the Console or using gcloud:
```
gcloud compute networks subnets update SUBNET_NAME \
    --region=REGION \
    --enable-private-ip-google-access
```

### Why Other Options Are Wrong

- **B:** Private Service Connect (PSC) is used for accessing services using private endpoints within your VPC, typically for third-party services or Google services that require dedicated endpoints. It's more complex than needed for basic Google Cloud service access and requires additional IP range allocation. Private Google Access is the simpler, purpose-built solution for this use case.

- **C:** Assigning static external IP addresses defeats the entire purpose of having a private subnet. This would expose the instances to the internet and allow traffic to traverse the public internet, which is exactly what the question wants to avoid. This is the opposite of the required solution.

- **D:** Cloud NAT is designed for instances to initiate outbound connections to the internet (not Google Cloud services). While Cloud NAT could technically allow access to Google services, it's unnecessary overhead because it routes traffic through the internet. Private Google Access is the more direct, secure, and cost-effective solution that keeps traffic within Google's internal network.

### References

- [Configure Private Google Access](https://docs.cloud.google.com/vpc/docs/configure-private-google-access)
- [Private Google Access Overview](https://docs.cloud.google.com/vpc/docs/private-google-access)
- [Private access options for services](https://docs.cloud.google.com/vpc/docs/private-access-options)
