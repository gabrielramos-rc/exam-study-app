# Question 299

**Source:** https://www.examtopics.com/discussions/google/view/148654-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** projects, VPC, network isolation, security boundaries, VPC Service Controls

---

## Question

You manage multiple internal-only applications that are hosted within different Google Cloud projects. You are deploying a new application that requires external internet access. To maintain security, you want to clearly separate this new application from internal systems. Your solution must have effective security isolation for the new externally-facing application. What should you do?
## Choices

- **A.** Deploy the application within the same project as an internal application. Use a Shared VPC model to manage network configurations.
- **B.** Place the application in the same project as an existing internal application, and adjust firewall rules to allow external traffic.
- **C.** Create a VPC Service Controls perimeter, and place the new application's project within that perimeter.
- **D.** Create a new project for the application, and use VPC Network Peering to access necessary resources in the internal projects. Most Voted

---

## Community

**Most Voted:** D


**Votes:** C: 35% | D: 65% (17 total)


**Top Comments:**

- (5 upvotes) Indeed. AND the Q clearly states 'effective security isolation'. This is VPC SCs

- (2 upvotes) D. is the most effective solution because creating a new, dedicated project provides the strongest possible security boundary and isolation at the IAM, resource, and billing levels. Using VPC Network 

- (2 upvotes) Answer is D, because that way you have complete isolation as required in the question. Explanation for C: C. Use VPC Service Controls (VPC-SC) is useful for protecting data from being exfiltrated, but

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Creating a new project for the externally-facing application (Option D) provides the strongest security isolation because **projects represent trust boundaries in Google Cloud**. According to Google Cloud's resource hierarchy best practices, projects serve as the base-level organizing entity where "services within the same project have a default level of trust," and "IAM roles granted at the project level are inherited by resources within that project."

For applications with different security requirements—especially when separating internal-only systems from externally-facing applications—Google Cloud documentation explicitly recommends using separate projects. As stated in the VPC design best practices: "Create VPC networks in different projects for independent IAM controls" and "Isolate sensitive data in its own VPC network."

By placing the new application in its own project:
1. **Project-level IAM isolation**: Completely separate identity and access management controls prevent accidental permission inheritance
2. **Network isolation**: The new project gets its own VPC network by default, forming a security boundary
3. **Independent security policies**: Organization policies, firewall rules, and security controls can be configured independently
4. **Controlled connectivity**: VPC Network Peering allows selective access to only necessary resources in internal projects while maintaining separation

VPC Network Peering provides secure, private connectivity between the new application's VPC and internal project VPCs without exposing traffic to the internet, while maintaining the isolation boundary.

### Why Other Options Are Wrong

- **A:** Deploying within the same project as an internal application contradicts the fundamental requirement for "effective security isolation." Projects are trust boundaries, and placing externally-facing and internal applications in the same project means they share IAM permissions, service accounts, and default trust relationships. Shared VPC is a network-level construct that doesn't provide project-level security isolation.

- **B:** Placing the application in the same project with just firewall rule adjustments is the weakest isolation approach. This violates the principle of using projects as trust boundaries. Firewall rules alone cannot prevent IAM permission inheritance, service account access, or other project-level security risks. This approach directly contradicts Google's recommendation to "use separate projects for applications with different security requirements."

- **C:** VPC Service Controls creates a data perimeter to prevent data exfiltration and control API access to Google Cloud services—it's designed for protecting sensitive data within a perimeter, not for isolating externally-facing applications from internal ones. Placing the external application within a service perimeter would actually restrict its ability to access external internet resources, which contradicts the requirement that the application "requires external internet access." VPC-SC is complementary to project isolation but not a substitute for it.

### References

- [Resource hierarchy - Projects as trust boundaries](https://docs.cloud.google.com/resource-manager/docs/cloud-platform-resource-hierarchy)
- [Decide a resource hierarchy for your Google Cloud landing zone](https://docs.cloud.google.com/architecture/landing-zones/decide-resource-hierarchy)
- [Best practices for VPC design - Network isolation](https://docs.cloud.google.com/architecture/best-practices-vpc-design)
- [Using resource hierarchy for access control](https://docs.cloud.google.com/iam/docs/resource-hierarchy-access-control)
