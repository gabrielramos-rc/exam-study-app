# Question 142

**Source:** https://www.examtopics.com/discussions/google/view/80426-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Managing authentication
**Tags:** 2-step verification, phishing protection, Titan Security Keys, FIDO U2F

---

## Question

You have noticed an increased number of phishing attacks across your enterprise user accounts. You want to implement the Google 2-Step Verification (2SV) option that uses a cryptographic signature to authenticate a user and verify the URL of the login page. Which Google 2SV option should you use?
## Choices

- **A.** Titan Security Keys Most Voted
- **B.** Google prompt
- **C.** Google Authenticator app
- **D.** Cloud HSM keys

---

## Community

**Most Voted:** A


**Votes:** A: 100% (13 total)


**Top Comments:**

- (7 upvotes) A is the answer. https://cloud.google.com/titan-security-key Security keys use public key cryptography to verify a user’s identity and URL of the login page ensuring attackers can’t access your accoun

- (5 upvotes) A is the right ans

- (3 upvotes) A. Titan Security Keys

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Titan Security Keys are the correct answer because they implement the FIDO U2F/FIDO2 protocol, which specifically uses cryptographic signatures to authenticate users and verify the URL of the login page - exactly as described in the question.

The FIDO U2F protocol provides phishing protection through a mechanism called "origin binding." When a user authenticates:

1. The browser automatically includes the actual origin (domain/URL) of the login page in the client data
2. The security key signs this challenge along with the origin information using its private cryptographic key
3. The server verifies the signature, which proves both the user's possession of the physical key AND that they're on the legitimate login page
4. This origin cannot be spoofed or modified by JavaScript, even on a phishing site

This cryptographic approach makes Titan Security Keys phishing-resistant because:
- The private key never leaves the physical device and cannot be stolen or shared
- The signature is unique and bound to the specific domain being accessed
- A phishing site on a different domain will produce a different signature that fails verification
- Unlike passwords or OTP codes, there's no credential that can be tricked out of the user

Google's documentation explicitly recommends Titan Security Keys as a phishing-resistant mechanism for multi-factor authentication across Google Cloud and Workspace environments.

### Why Other Options Are Wrong

- **B. Google prompt:** While convenient, Google prompts (push notifications to your phone) are susceptible to prompt fatigue attacks and MFA bombing. They don't use cryptographic signatures or verify the login URL - they simply ask "Was this you?" which users can approve on phishing sites.

- **C. Google Authenticator app:** This generates time-based one-time passwords (TOTP) that are not cryptographically bound to the login URL. A user can be tricked into entering the 6-digit code on a phishing site, which the attacker can then use on the real site within the time window. It doesn't verify the URL of the login page.

- **D. Cloud HSM keys:** Cloud HSM (Hardware Security Module) is used for managing encryption keys in Google Cloud infrastructure, not for user authentication or 2-Step Verification. It's a key management service for applications and data encryption, not an end-user authentication method.

### References

- [Titan Security Key Help - About Titan Security Keys](https://support.google.com/titansecuritykey/answer/9115487)
- [Use a security key for 2-Step Verification](https://support.google.com/accounts/answer/6103523)
- [Best practices for protecting against cryptocurrency mining attacks](https://docs.cloud.google.com/architecture/security/bps-for-protecting-against-crytocurrency-attacks)
- [Mitigate ransomware attacks using Google Cloud](https://docs.cloud.google.com/architecture/security/mitigating-ransomware-attacks)
- [FIDO2 vs U2F: Key Differences](https://frontegg.com/blog/fido2-vs-u2f)
- [Phishing-Resistant MFA: Why FIDO2 and WebAuthn Are the Gold Standard](https://terrazone.io/phishing-resistant-mfa-fido2-webauthn/)
