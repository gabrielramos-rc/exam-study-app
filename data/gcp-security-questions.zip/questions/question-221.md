# Question 221

**Source:** https://www.examtopics.com/discussions/google/view/117338-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, policy constraints, hierarchy inheritance, external IP addresses

---

## Question

You define central security controls in your Google Cloud environment. For one of the folders in your organization, you set an organizational policy to deny the assignment of external IP addresses to VMs. Two days later, you receive an alert about a new VM with an external IP address under that folder. What could have caused this alert?
## Choices

- **A.** The VM was created with a static external IP address that was reserved in the project before the organizational policy rule was set.
- **B.** The organizational policy constraint wasn't properly enforced and is running in "dry run" mode.
- **C.** A project level, the organizational policy control has been overwritten with an "allow" value. Most Voted
- **D.** The policy constraint on the folder level does not have any effect because of an "allow" value for that constraint on the organizational level.

---

## Community

**Most Voted:** C


**Votes:** A: 40% | B: 10% | C: 47% | D: 3% (30 total)


**Top Comments:**

- (4 upvotes) This scenario happens when "inheritFromParent = true". If "inheritFromParent = false", the "reconciling_policy_conflicts" rule will not work.

- (3 upvotes) "under that folder"...

- (3 upvotes) A. Even if IP created after org policy was set it wont allow to use it B. we can preview the org policy function using dry run (Preview mode) in this policy won't deny the usage, but it will notify. C

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

A project-level organizational policy can override a folder-level policy by using the "Replace" option (setting `inheritFromParent = false`). This is a standard mechanism in Google Cloud's organization policy hierarchy that allows administrators to exempt specific projects from restrictive policies set at higher levels (folder or organization).

When a project sets its own organizational policy with `inheritFromParent = false`, it completely supersedes the parent's policy rather than merging with it. In this scenario, if a project under the folder created a policy that allows external IP addresses with the Replace option, it would override the folder's deny policy, permitting VMs in that project to have external IP addresses.

This design allows for flexibility in the resource hierarchy—while you can set restrictive policies at the folder level for general security, individual projects can opt out when they have legitimate business needs. The organization policy documentation explicitly states: "To allow those operations, you must create organization policies that override the parent policy."

### Why Other Options Are Wrong

- **A:** Organization policies are not enforced retroactively. The documentation states: "You cannot apply the constraint retroactively. All instances that have external IP addresses before you enable the policy retain their external IP addresses." However, in this question, the VM was created TWO DAYS AFTER the policy was set, so it would be subject to the policy. A reserved static IP address alone doesn't bypass an active organizational policy constraint.

- **B:** Google Cloud organizational policies don't have a "dry run" mode. They are either enforced or not enforced. While some features in Google Cloud offer dry run capabilities (like firewall rules testing), organizational policy constraints are binary—they're either active and enforced or they're not set.

- **D:** This describes the wrong direction of hierarchy override. When evaluating organization policies, deny values always take precedence during policy reconciliation. If an organization-level policy had an "allow" value and a folder-level policy had a "deny" value, the deny would take effect at the folder and below. Additionally, the question states that the folder policy was set to deny, so this doesn't explain why a VM would have an external IP address.

### References

- [Understanding hierarchy evaluation](https://docs.cloud.google.com/resource-manager/docs/organization-policy/understanding-hierarchy)
- [Organization policy constraints](https://docs.cloud.google.com/resource-manager/docs/organization-policy/org-policy-constraints)
- [Creating and managing organization policies](https://docs.cloud.google.com/resource-manager/docs/organization-policy/creating-managing-policies)
