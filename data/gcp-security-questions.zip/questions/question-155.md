# Question 155

**Source:** https://www.examtopics.com/discussions/google/view/83348-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, Cloud Storage, public access prevention, data protection

---

## Question

You want to make sure that your organization's Cloud Storage buckets cannot have data publicly available to the internet. You want to enforce this across all Cloud Storage buckets. What should you do?
## Choices

- **A.** Remove Owner roles from end users, and configure Cloud Data Loss Prevention.
- **B.** Remove Owner roles from end users, and enforce domain restricted sharing in an organization policy.
- **C.** Configure uniform bucket-level access, and enforce domain restricted sharing in an organization policy. Most Voted
- **D.** Remove *.setIamPolicy permissions from all roles, and enforce domain restricted sharing in an organization policy.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (12 total)


**Top Comments:**

- (6 upvotes) It's C

- (2 upvotes) C is the answer.

- (1 upvotes) I agree with C

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is the best available answer, combining two security measures:

1. **Uniform bucket-level access**: Disables ACLs and enforces IAM-only access control, providing a more consistent and manageable security model
2. **Domain restricted sharing**: Restricts which domain users can be granted IAM roles

**Important caveat:** None of the provided options actually prevent public access (`allUsers`/`allAuthenticatedUsers`). Domain restricted sharing controls which domain identities can be added to IAM policies, but does NOT block public access grants. The correct solution would be `constraints/storage.publicAccessPrevention` organization policy, which is not listed.

However, Option C represents the best security practices among the choices because uniform bucket-level access eliminates ACL complexity and domain restricted sharing adds an additional control layer.

### Why Other Options Are Wrong

- **A:** Cloud Data Loss Prevention (DLP) inspects and protects sensitive data content but doesn't control bucket access permissions. Removing Owner roles alone is insufficient since many other roles can grant public access.

- **B:** Domain restricted sharing doesn't prevent `allUsers` and `allAuthenticatedUsers` grants. Many roles besides Owner can grant public access (e.g., Storage Admin, Storage Object Admin).

- **D:** Removing `*.setIamPolicy` permissions is operationally impractical, doesn't address existing public access, and doesn't prevent ACL-based public access. Service agents often require these permissions.

### References

- [Public access prevention - Cloud Storage](https://cloud.google.com/storage/docs/public-access-prevention)
- [Organization policy constraints for Cloud Storage](https://cloud.google.com/storage/docs/org-policy-constraints)
- [Domain restricted sharing](https://cloud.google.com/resource-manager/docs/organization-policy/domain-restricted-sharing)
- [Uniform bucket-level access](https://cloud.google.com/storage/docs/uniform-bucket-level-access)
