# Question 277

**Source:** https://www.examtopics.com/discussions/google/view/147071-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Managing authentication
**Tags:** Cloud Identity, password policy, Admin console, authentication, enforcement

---

## Question

You work for a large organization that is using Cloud Identity as the identity provider (IdP) on Google Cloud. Your InfoSec team has mandated the enforcement of a strong password with a length between 12 and 16 characters for all users. After configuring this requirement, users are still able to access the Google Cloud console with passwords that are less than 12 characters. You need to fix this problem within the Admin console. What should you do?
## Choices

- **A.** Review each user's password configuration and reset existing passwords.
- **B.** Review the organization password management setting and select Enforce password policy at the next sign-in. Most Voted
- **C.** Review each user's password configuration and select Enforce strong password.
- **D.** Review the organization password management setting and select Enforce strong password.

---

## Community

**Most Voted:** B


**Votes:** B: 79% | D: 21% (14 total)


**Top Comments:**

- (7 upvotes) B. is the correct solution because simply changing the password policy does not affect users who are already logged in or whose passwords were set before the policy change. Selecting "Enforce password

- (3 upvotes) B is correct.

- (2 upvotes) According to the question, strong password policy is already enforced and we only need to fix the ones that still use short passwords, therefore option D is best.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

When a new password policy is configured in Cloud Identity, it only applies to new passwords or password changes by default. Existing users who already have passwords that don't meet the new requirements can continue to use them until they voluntarily change their passwords. This is why users are still able to access the Google Cloud console with passwords less than 12 characters even after the policy was configured.

The **"Enforce password policy at next sign-in"** option in the organization password management settings forces all existing users to change their password to comply with the new policy requirements the next time they sign in. Without this option enabled, users with non-compliant passwords can continue accessing Google services indefinitely.

The correct configuration in the Admin console is:
1. Navigate to **Security > Authentication > Password management**
2. Select the appropriate organizational unit
3. Configure the password strength and length requirements (already done in this scenario)
4. **Check the "Enforce password policy at next sign-in" box** to force existing users to update their passwords

This is an organization-level setting that must be applied to make the policy effective for all existing users, not a per-user configuration.

### Why Other Options Are Wrong

- **A:** Manually reviewing and resetting each user's password is unnecessarily time-consuming and operationally inefficient. It also doesn't enforce the policy automatically - it just resets passwords once. The "Enforce password policy at next sign-in" option is designed specifically to handle this at scale for all users.

- **C:** There is no per-user "Enforce strong password" setting. Password policies are configured at the organizational unit level, not individually for each user. Additionally, this doesn't address the core issue that existing passwords aren't being forced to comply with the new policy.

- **D:** While "Enforce strong password" is a necessary setting to enable the password strength requirements, this was already configured (as stated in the question - "After configuring this requirement"). The problem is that this setting alone doesn't force existing users with weak passwords to change them. You need the additional "Enforce password policy at next sign-in" option to apply the policy retroactively to existing users.

### References

- [Enforce and monitor password requirements for users - Cloud Identity Help](https://support.google.com/cloudidentity/answer/139399?hl=en)
