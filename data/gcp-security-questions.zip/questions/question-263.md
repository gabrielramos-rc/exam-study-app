# Question 263

**Source:** https://www.examtopics.com/discussions/google/view/147057-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** image hardening, VM hardening, patch management, security automation, custom images

---

## Question

Your organization relies heavily on virtual machines (VMs) in Compute Engine. Due to team growth and resource demands, VM sprawl is becoming problematic. Maintaining consistent security hardening and timely package updates poses an increasing challenge. You need to centralize VM image management and automate the enforcement of security baselines throughout the virtual machine lifecycle. What should you do?
## Choices

- **A.** Use VM Manager to automatically distribute and apply patches to YMs across your projects. Integrate VM Manager with hardened, organization-standard VM images stored in a central repository. Most Voted
- **B.** Configure the sole-tenancy feature in Compute Engine for all projects. Set up custom organization policies in Policy Controller to restrict the operating systems and image sources that teams are allowed to use.
- **C.** Create a Cloud Build trigger to build a pipeline that generates hardened VM images. Run vulnerability scans in the pipeline, and store images with passing scans in a registry. Use instance templates pointing to this registry.
- **D.** Activate Security Command Center Enterprise. Use VM discovery and posture management features to monitor hardening state and trigger automatic responses upon detection of issues.

---

## Community

**Most Voted:** A


**Votes:** A: 54% | C: 46% (13 total)


**Top Comments:**

- (4 upvotes) A is the correct answer ,VM Manager allows you to centrally manage and automate patching, configuration management, and compliance enforcement for VMs. By integrating with hardened VM images stored in

- (3 upvotes) Explanation: VM sprawl and security hardening challenges necessitate a robust solution for centralized VM image management and automation of security baselines. Implementing a pipeline to create, vali

- (3 upvotes) I think it's C.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C aligns with Google Cloud's recommended best practices for centralized VM image management and security baseline enforcement. According to the [Image Management Best Practices](https://docs.cloud.google.com/compute/docs/images/image-management-best-practices) documentation, organizations should implement **image baking** - creating customized images with security configurations pre-built, rather than relying on post-deployment configuration. The documentation specifically recommends using tools like Packer or Cloud Build to make "image creation more reproducible, auditable, configurable, and reliable."

This approach provides several key benefits:
- **Centralized control**: All teams use hardened images from a single registry
- **Security baseline enforcement**: Vulnerability scanning in the pipeline prevents non-compliant images from being published
- **VM sprawl prevention**: Instance templates ensure consistent deployment from approved images
- **Lifecycle management**: Automated build pipelines enable version control and deprecation policies

The documentation emphasizes establishing centralized image creation projects with controlled access and using image families to manage versions throughout the VM lifecycle. This directly addresses the requirements of centralizing image management and automating security baseline enforcement.

### Why Other Options Are Wrong

- **A:** VM Manager is designed for **patch management** of existing VMs, not for centralizing image management or preventing VM sprawl. While it can distribute patches across projects, it doesn't control which base images teams use or enforce security baselines at the image creation stage. The documentation shows VM Manager handles OS patch management service for scheduled patches, but doesn't address image lifecycle management or preventing teams from creating VMs from various sources.

- **B:** Sole-tenancy is a **hardware isolation** feature for compliance requirements (running VMs on dedicated physical servers), not an image management solution. Policy Controller is designed for Kubernetes policy enforcement, not Compute Engine. This option doesn't provide any centralized image registry, automated hardening pipeline, or vulnerability scanning capabilities.

- **D:** Security Command Center Enterprise is a **monitoring and detection** tool that can identify security issues after VMs are deployed, but it's reactive rather than proactive. It doesn't prevent VM sprawl, centralize image management, or enforce security baselines during VM creation. While it can discover VMs and assess their posture, it doesn't provide the automated image building and vulnerability scanning pipeline needed to solve the root problem.

### References

- [Image Management Best Practices](https://docs.cloud.google.com/compute/docs/images/image-management-best-practices)
- [Create Custom Images](https://docs.cloud.google.com/compute/docs/images/create-custom)
- [About VM Manager](https://docs.cloud.google.com/compute/vm-manager/docs/patch)
