# Question 009

**Source:** https://www.examtopics.com/discussions/google/view/16543-exam-professional-cloud-security-engineer-topic-1-question-9/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Logging, alerting policies, log-based metrics, security incidents

---

## Question

A company has been running their application on Compute Engine. A bug in the application allowed a malicious user to repeatedly execute a script that results in the Compute Engine instance crashing. Although the bug has been fixed, you want to get notified in case this hack re-occurs. What should you do?
## Choices

- **A.** Create an Alerting Policy in Stackdriver using a Process Health condition, checking that the number of executions of the script remains below the desired threshold. Enable notifications. Most Voted
- **B.** Create an Alerting Policy in Stackdriver using the CPU usage metric. Set the threshold to 80% to be notified when the CPU usage goes above this 80%.
- **C.** Log every execution of the script to Stackdriver Logging. Create a User-defined metric in Stackdriver Logging on the logs, and create a Stackdriver Dashboard displaying the metric.
- **D.** Log every execution of the script to Stackdriver Logging. Configure BigQuery as a log sink, and create a BigQuery scheduled query to count the number of executions in a specific timeframe.

---

## Community

**Most Voted:** A


**Votes:** A: 75% | B: 25% (12 total)


**Top Comments:**

- (31 upvotes) I agree it should be A

- (11 upvotes) Notification is only mentioned in A. So if customer wants to get notified then A is the correct answer.

- (7 upvotes) It's not necessary that running a malicious script multiple times will affect CPU usage. And, CPU usage can occur during usual normal workloads. A

---

## Answer

**Correct:** A (with important caveat - see explanation)

**Confidence:** medium

### Explanation

While option A is marked as "Most Voted" and mentions the right approach conceptually, there's a technical issue with the terminology. Google Cloud Monitoring does have **Process Health conditions**, but they monitor whether processes are running (counting active processes), not counting script executions over time. According to the documentation, Process Health "can notify you if the number of processes that match a pattern crosses a threshold" - useful for detecting when a process stops running, not for counting executions.

**However**, the underlying principle in option A is correct: you need to create a log-based metric and an alerting policy with notifications. The proper implementation would be:

1. **Log every script execution** to Cloud Logging (as mentioned in options C and D)
2. **Create a log-based metric** (user-defined metric) that counts matching log entries
3. **Create an alerting policy** on that metric with a threshold
4. **Enable notification channels** to receive alerts

This approach allows you to:
- Track the frequency of script executions in real-time
- Set thresholds for abnormal execution patterns
- Get immediate notifications when the threshold is exceeded
- Take action before the system crashes

### Why Other Options Are Wrong

- **B:** CPU usage monitoring is too generic and reactive. By the time CPU hits 80%, the malicious script may already be executing. This doesn't detect the root cause (script execution) and could generate false positives from legitimate high CPU usage. It also doesn't provide sufficient lead time to prevent crashes.

- **C:** Creating a dashboard only provides visualization but **no alerting or notifications**. You would need to actively monitor the dashboard to detect the issue, which defeats the purpose of automated detection. Dashboards are for investigation, not incident response.

- **D:** Using BigQuery with scheduled queries introduces significant delays (queries run on a schedule, not in real-time) and adds unnecessary complexity. By the time the scheduled query runs and detects the issue, the damage may already be done. This approach lacks the real-time alerting capabilities needed for security incident response.

### References

- [Configure notifications for log-based metrics](https://docs.cloud.google.com/logging/docs/logs-based-metrics/charts-and-alerts)
- [Log-based metrics overview](https://docs.cloud.google.com/logging/docs/logs-based-metrics)
- [Sample policies in JSON - Process Health](https://docs.cloud.google.com/monitoring/alerts/policies-in-json)
