# Question 111

**Source:** https://www.examtopics.com/discussions/google/view/74828-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** VPC Flow Logs, network monitoring, anomaly detection, Packet Mirroring

---

## Question

Your company requires the security and network engineering teams to identify all network anomalies within and across VPCs, internal traffic from VMs to VMs, traffic between end locations on the internet and VMs, and traffic between VMs to Google Cloud services in production. Which method should you use?
## Choices

- **A.** Define an organization policy constraint.
- **B.** Configure packet mirroring policies. Most Voted
- **C.** Enable VPC Flow Logs on the subnet.
- **D.** Monitor and analyze Cloud Audit Logs.

---

## Community

**Most Voted:** B


**Votes:** B: 68% | C: 32% (22 total)


**Top Comments:**

- (13 upvotes) B should be the answer. For detecting network anomalies, you need to have payload and header data as well to be effective. Besides C is saying to enable VPC flow logs on a subnet which won't serve our

- (8 upvotes) Backet mirroring policies allow you to mirror all traffic passing through a specific network interface or VPC route to a designated destination (e.g., another VM, a Cloud Storage bucket). This capture

- (5 upvotes) B is the answer. https://cloud.google.com/vpc/docs/packet-mirroring#enterprise_security Security and network engineering teams must ensure that they are catching all anomalies and threats that might i

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

VPC Flow Logs is the correct solution for identifying all network anomalies across the traffic types specified in the question. VPC Flow Logs is specifically designed for network monitoring and traffic analysis, capturing:

- **VM-to-VM traffic**: Flow logs are reported from both requesting and responding VMs in the same VPC network when both subnets have Flow Logs enabled
- **Internet traffic**: For flows that traverse the internet between a VM and an external endpoint, flow logs capture egress flows (from the VPC VM source) and ingress flows (to the VPC VM destination)
- **Traffic to Google Cloud services**: VPC Flow Logs covers all traffic that affects a VM, including connections to Google Cloud APIs and services

The documentation states that VPC Flow Logs supports three key use cases that align with the requirement:
1. **Network monitoring**: Monitor throughput and diagnose network issues to understand traffic changes
2. **Security forensics**: Examine communication patterns between IP addresses and identify potentially compromised systems through flow analysis
3. **Cost optimization**: Analyze usage patterns including inter-regional traffic and geographic destinations

VPC Flow Logs provides comprehensive visibility across and within VPCs with minimal overhead through sampling and aggregation. Security and network engineering teams can query the logs using Cloud Logging or export them to BigQuery for analysis using Flow Analyzer, which enables 5-tuple traffic analysis (source IP, destination IP, source port, destination port, and protocol) without requiring complex SQL queries.

### Why Other Options Are Wrong

- **A (Organization policy constraint):** Organization policies define constraints on resource configuration (like restricting external IP addresses or specifying allowed regions), but they do not monitor or detect network traffic or anomalies. They are preventive controls, not detective controls.

- **B (Packet Mirroring):** While Packet Mirroring can be used for security monitoring, it is designed for deep packet inspection and forensic analysis, not routine anomaly detection across all VPCs. Packet Mirroring copies all packets (including payloads) to collector destinations, requiring third-party appliances or additional analysis tools. This approach is resource-intensive, consumes additional bandwidth, and incurs higher costs compared to Flow Logs. It's typically used when you need to "complete a comprehensive inspection of suspicious flows" rather than for ongoing network-wide anomaly detection.

- **D (Cloud Audit Logs):** Cloud Audit Logs records administrative activities and data access operations (API calls), not network traffic flows. Audit Logs capture who did what, where, and when regarding GCP resource management, but they do not capture VM-to-VM traffic, internet traffic patterns, or network flows between VMs and Google Cloud services.

### References

- [VPC Flow Logs Overview](https://docs.cloud.google.com/vpc/docs/flow-logs)
- [Flow Analyzer Overview](https://docs.cloud.google.com/network-intelligence-center/docs/flow-analyzer/overview)
- [Packet Mirroring](https://docs.cloud.google.com/vpc/docs/packet-mirroring)
