# Question 247

**Source:** https://www.examtopics.com/discussions/google/view/146999-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Identity-Aware Proxy, IAP, Cloud Run, Application Load Balancer, authentication, SSO

---

## Question

You run a web application on top of Cloud Run that is exposed to the internet with an Application Load Balancer. You want to ensure that only privileged users from your organization can access the application. The proposed solution must support browser access with single sign-on. What should you do?
## Choices

- **A.** Change Cloud Run configuration to require authentication. Assign the role of Cloud Run Invoker to the group of privileged users.
- **B.** Create a group of privileged users in Cloud Identity. Assign the role of Cloud Run User to the group directly on the Cloud Run service.
- **C.** Change the Ingress Control configuration of Cloud Run to internal and create firewall rules to allow only access from known IP addresses.
- **D.** Activate Identity-Aware Proxy (IAP) on the Application Load Balancer backend. Assign the role of IAP-secured Web App User to the group of privileged users. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (4 total)


**Top Comments:**

- (2 upvotes) should be D

- (1 upvotes) I think it's D.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Identity-Aware Proxy (IAP) on the Application Load Balancer backend is the correct solution for browser-based authentication with SSO for Cloud Run services. IAP provides:

1. **Browser-based authentication**: IAP uses a Google-managed OAuth client to authenticate users directly in their browser, supporting organizational SSO and single sign-on workflows
2. **Application Load Balancer integration**: When Cloud Run is behind an ALB, enabling IAP on the load balancer backend service creates a security layer that intercepts all HTTPS requests before they reach Cloud Run
3. **Proper IAM role**: The "IAP-secured Web App User" role grants authenticated users access to IAP-protected resources behind the load balancer
4. **Dual authentication**: Both IAP and Cloud Run IAM checks are performed - IAP checks first for user authentication, then uses its service account to authenticate to Cloud Run's IAM layer

The authentication flow works as follows: User browser → IAP authentication (OAuth/SSO) → Load Balancer → IAP service account authenticates to Cloud Run → Cloud Run service.

### Why Other Options Are Wrong

- **A:** Cloud Run's native authentication (requiring the Cloud Run Invoker role) does not support browser-based SSO. It requires JWT tokens or gcloud credentials, making it unsuitable for direct browser access. Users would need to authenticate via command-line tools rather than through a web browser with SSO.

- **B:** The "Cloud Run User" role does not exist in Google Cloud IAM. The correct roles for Cloud Run are "Cloud Run Invoker" (for invoking services) and "Cloud Run Admin" (for managing services). Even if using the correct role, native Cloud Run authentication doesn't provide browser-based SSO capabilities.

- **C:** Restricting ingress to internal-only and using firewall rules based on IP addresses does not provide authentication or SSO. This approach only provides network-level access control, not user identity verification. Users from unknown IP addresses (like remote workers or mobile devices) would be blocked, and there's no SSO integration.

### References

- [Enabling IAP for Cloud Run | Identity-Aware Proxy](https://docs.cloud.google.com/iap/docs/enabling-cloud-run)
- [Identity-Aware Proxy overview](https://docs.cloud.google.com/iap/docs/concepts-overview)
- [Configure IAP for Cloud Run](https://docs.cloud.google.com/run/docs/securing/identity-aware-proxy-cloud-run)
