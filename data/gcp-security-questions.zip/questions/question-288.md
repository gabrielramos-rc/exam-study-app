# Question 288

**Source:** https://www.examtopics.com/discussions/google/view/147082-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Identity Platform, CIAM, Workforce Identity Federation, customer identity, corporate identity

---

## Question

Your organization is developing an application that will have both corporate and public end-users. You want to centrally manage those customers' identities and authorizations. Corporate end users must access the application by using their corporate user and domain name. What should you do?
## Choices

- **A.** Add the corporate and public end-user domains to domain restricted sharing on the organization.
- **B.** Federate the customers' identity provider (IdP) with Workforce Identity Federation in your application's project.
- **C.** Do nothing. Google Workspace identities will allow you to filter personal accounts and disable their access.
- **D.** Use a customer identity and access management tool (CIAM) like Identity Platform. Most Voted

---

## Community

**Most Voted:** D


**Votes:** B: 25% | D: 75% (12 total)


**Top Comments:**

- (3 upvotes) Obviously it's D. - Identity Platform : A customer identity and access management (CIAM) platform that lets users sign in to your applications and services. This is ideal for users who want to be thei

- (3 upvotes) B is correct - By federating your customers' IdP with WIF, you can provide a seamless authentication experience for your users while maintaining control over identity and access management in your Goo

- (3 upvotes) I think it's B.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Identity Platform is the correct solution for this scenario because it is specifically designed as a Customer Identity and Access Management (CIAM) platform that enables you to centrally manage identities for both corporate and public end-users accessing your applications.

The key requirements in this scenario are:
1. **Both corporate AND public end-users** need to access the same application
2. **Centralized identity management** for all users
3. **Corporate users** must authenticate using their corporate credentials and domain

Identity Platform supports this by:
- Allowing multiple identity providers (IdPs) to be configured simultaneously
- Supporting enterprise IdP integration via SAML or OIDC for corporate users (allowing them to sign in with their corporate credentials)
- Supporting public user sign-ups via email/password, social logins (Google, Facebook, Apple), and other authentication methods
- Providing a unified authentication system where both user types access the same application with appropriate authorization controls

This is the textbook use case for CIAM: managing external customer identities (public users) alongside corporate customer identities (corporate users) for accessing a customer-facing application. Identity Platform can federate with the corporate IdP to allow corporate users to sign in with their corporate domain credentials while simultaneously managing public user registrations.

### Why Other Options Are Wrong

- **A:** Domain restricted sharing is an organizational policy control that restricts resource sharing to specific domains. It doesn't provide identity management or authentication capabilities for application end-users. This controls who can share Google Cloud resources, not who can access your application.

- **B:** Workforce Identity Federation is designed for managing **internal workforce access** (employees and partners accessing Google Cloud resources and corporate systems), not for managing customer access to applications. The documentation explicitly states that Workforce Identity Federation "aggregates human users" for workforce scenarios, whereas this question requires managing external customers/end-users. Using Workforce Identity Federation for customer-facing applications is a fundamental misuse of the service.

- **C:** Google Workspace identities are for managing organizational users within a Google Workspace domain (employees, not customers). This option doesn't provide any identity management solution for public end-users, and it incorrectly assumes that Google Workspace can serve as a CIAM solution, which it cannot. Google Workspace is for internal organizational identity, not customer identity management.

### References

- [Identity management products and features](https://docs.cloud.google.com/docs/authentication/identity-products)
- [Overview of identity and access management](https://docs.cloud.google.com/architecture/identity)
