# Question 219

**Source:** https://www.examtopics.com/discussions/google/view/117340-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** encryption, CMEK, Cloud EKM, Key Access Justifications, key lifecycle

---

## Question

You are migrating an on-premises data warehouse to BigQuery, Cloud SQL, and Cloud Storage. You need to configure security services in the data warehouse. Your company compliance policies mandate that the data warehouse must:
- Protect data at rest with full lifecycle management on cryptographic keys.
- Implement a separate key management provider from data management.
- Provide visibility into all encryption key requests.

What services should be included in the data warehouse implementation? (Choose two.)

## Choices

- **A.** Customer-managed encryption keys
- **B.** Customer-Supplied Encryption Keys
- **C.** Key Access Justifications Most Voted
- **D.** Access Transparency and Approval
- **E.** Cloud External Key Manager Most Voted

---

## Community

**Most Voted:** CE


**Votes:** AE: 25% | CE: 75% (24 total)


**Top Comments:**

- (5 upvotes) Implement a separate key management provider from data management - so the key must be outside of the GCP - E Provide visibility into all encryption key requests. - this can be supported by - C

- (5 upvotes) AE looks correct, many people in the comments explained why, take a note.

- (4 upvotes) I think this is BE. They mention that they want the data and the keys to be in separate locations. So that would mean CSEK. And that is handled by External Key Manager. So BE.

---

## Answer

**Correct:** C, E

**Confidence:** high

### Explanation

The compliance requirements specify three key criteria:

1. **Protect data at rest with full lifecycle management on cryptographic keys**: Cloud External Key Manager (Cloud EKM) enables this by allowing organizations to use external key management systems (such as Fortanix, Futurex, or Thales) that provide complete lifecycle management capabilities including key creation, rotation, revocation, and destruction.

2. **Implement a separate key management provider from data management**: Cloud EKM explicitly provides this separation by keeping the key material entirely outside of Google Cloud infrastructure. The external key material "never leaves your EKM and it is never shared with Google." This creates a clear architectural separation where keys are managed in your external system while data resides in Google Cloud services (BigQuery, Cloud SQL, Cloud Storage).

3. **Provide visibility into all encryption key requests**: Key Access Justifications provides this capability by generating justification codes for every cryptographic operation involving Cloud KMS keys. It "enables you to view the reason for each Cloud EKM request" and allows you to "approve or deny key access requests depending on the provided justification code." These justifications are logged in Cloud KMS audit logs, providing complete visibility into when and why encryption keys are accessed.

Cloud EKM works with all three services mentioned (BigQuery, Cloud SQL, and Cloud Storage), and when combined with Key Access Justifications, satisfies all three compliance requirements. The external key manager handles lifecycle operations, maintains separation from Google's data management infrastructure, and Key Access Justifications provides the audit trail for all key access requests.

### Why Other Options Are Wrong

- **A (Customer-managed encryption keys):** CMEK alone provides lifecycle management and works with the required services, but it doesn't provide separation from Google Cloud (keys are still stored in Cloud KMS, which is a Google service). It also doesn't inherently provide visibility into key requests without Key Access Justifications. While CMEK is part of the solution when using EKM, the question asks for separate key management provider, which specifically points to EKM.

- **B (Customer-Supplied Encryption Keys):** CSEK has limited service support (primarily Cloud Storage and Compute Engine), doesn't work with BigQuery or Cloud SQL, and requires customers to manage and supply keys with each request. It lacks the lifecycle management capabilities and audit visibility required by the compliance policies.

- **D (Access Transparency and Approval):** These services provide visibility into Google personnel access to customer data and allow approval workflows for support access, but they don't address encryption key lifecycle management or the separation of key management from data management. They focus on administrative access transparency rather than cryptographic key request visibility.

### References

- [Cloud External Key Manager (Cloud EKM)](https://docs.cloud.google.com/kms/docs/ekm)
- [Key Access Justifications Overview](https://docs.cloud.google.com/assured-workloads/key-access-justifications/docs/overview)
- [Introduction to Key Access Justifications](https://docs.cloud.google.com/assured-workloads/access-transparency/docs/key-access-justifications)
- [Customer-managed encryption keys (CMEK)](https://docs.cloud.google.com/kms/docs/cmek)
- [BigQuery Customer-Managed Encryption Keys](https://docs.cloud.google.com/bigquery/docs/customer-managed-encryption)
- [Cloud SQL CMEK for MySQL](https://docs.cloud.google.com/sql/docs/mysql/cmek)
