# Question 008

**Source:** https://www.examtopics.com/discussions/google/view/15922-exam-professional-cloud-security-engineer-topic-1-question-8/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Identity-Aware Proxy, IAP, JWT, authentication, Compute Engine

---

## Question

A customer implements Cloud Identity-Aware Proxy for their ERP system hosted on Compute Engine. Their security team wants to add a security layer so that the ERP systems only accept traffic from Cloud Identity-Aware Proxy. What should the customer do to meet these requirements?
## Choices

- **A.** Make sure that the ERP system can validate the JWT assertion in the HTTP requests. Most Voted
- **B.** Make sure that the ERP system can validate the identity headers in the HTTP requests.
- **C.** Make sure that the ERP system can validate the x-forwarded-for headers in the HTTP requests.
- **D.** Make sure that the ERP system can validate the user's unique identifier headers in the HTTP requests.

---

## Community

**Most Voted:** A


**Votes:** A: 67% | B: 33% (6 total)


**Top Comments:**

- (21 upvotes) Use Cryptographic Verification If there is a risk of IAP being turned off or bypassed, your app can check to make sure the identity information it receives is valid. This uses a third web request head

- (15 upvotes) Answer is A.

- (3 upvotes) Agree A makes more sense

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Cloud Identity-Aware Proxy (IAP) adds a cryptographically signed JWT (JSON Web Token) to every authenticated request in the `X-Goog-IAP-JWT-Assertion` HTTP header. To ensure that the ERP system only accepts traffic from IAP and prevents requests from bypassing IAP, the backend application must validate this JWT assertion.

The validation process involves:
1. **Verifying the JWT signature** using IAP's public certificates (fetched from `https://www.gstatic.com/iap/verify/public_key`)
2. **Validating the issuer claim** to confirm it's `https://cloud.google.com/iap`
3. **Checking the audience claim** matches the expected resource format for Compute Engine: `/projects/{PROJECT_NUMBER}/global/backendServices/{BACKEND_SERVICE_ID}`
4. **Verifying token validity** (expiration and issuance timestamps)
5. **Extracting identity claims** (subject and email) from the validated token

This cryptographic validation ensures that the request authentically came from IAP and wasn't forged or bypassed, as only requests that pass through IAP will have a valid signed JWT. This is the security layer that prevents direct access to the ERP system.

### Why Other Options Are Wrong

- **B:** While IAP does add identity headers like `X-Goog-Authenticated-User-Email` and `X-Goog-Authenticated-User-Id`, these are plain text headers that can be easily forged if someone bypasses IAP and sends requests directly to the backend. They provide no cryptographic proof of authentication.

- **C:** The `X-Forwarded-For` header contains the original client IP address but provides no authentication or authorization information. It can be easily spoofed and doesn't prove the request came through IAP. This header is used for identifying client IPs, not for security validation.

- **D:** User unique identifier headers (like `X-Goog-Authenticated-User-Id`) are plain text and not cryptographically signed. Like option B, these can be forged and don't provide the necessary security layer to ensure traffic originates from IAP.

### References

- [Securing your app with signed headers | Identity-Aware Proxy](https://docs.cloud.google.com/iap/docs/samples/iap-validate-jwt)
- [Getting the user's identity | Identity-Aware Proxy](https://docs.cloud.google.com/iap/docs/identity-howto)
