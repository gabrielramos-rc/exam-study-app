# Question 125

**Source:** https://www.examtopics.com/discussions/google/view/75975-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Binary Authorization, container security, vulnerability scanning, CI/CD, GKE, attestation

---

## Question

You are setting up a CI/CD pipeline to deploy containerized applications to your production clusters on Google Kubernetes Engine (GKE). You need to prevent containers with known vulnerabilities from being deployed. You have the following requirements for your solution: Must be cloud-native - ✑ Must be cost-efficient ✑ Minimize operational overhead How should you accomplish this? (Choose two.)

## Choices

- **A.** Create a Cloud Build pipeline that will monitor changes to your container templates in a Cloud Source Repositories repository. Add a step to analyze Container Analysis results before allowing the build to continue. Most Voted
- **B.** Use a Cloud Function triggered by log events in Google Cloud's operations suite to automatically scan your container images in Container Registry.
- **C.** Use a cron job on a Compute Engine instance to scan your existing repositories for known vulnerabilities and raise an alert if a non-compliant container image is found.
- **D.** Deploy Jenkins on GKE and configure a CI/CD pipeline to deploy your containers to Container Registry. Add a step to validate your container images before deploying your container to the cluster.
- **E.** In your CI/CD pipeline, add an attestation on your container image when no vulnerabilities have been found. Use a Binary Authorization policy to block deployments of containers with no attestation in your cluster. Most Voted

---

## Community

**Most Voted:** AE


**Votes:** AE: 100% (15 total)


**Top Comments:**

- (9 upvotes) A. Create a Cloud Build pipeline that will monitor changes to your container templates in a Cloud Source Repositories repository. Add a step to analyze Container Analysis results before allowing the b

- (4 upvotes) Agreed

- (2 upvotes) AE is the answer. https://cloud.google.com/container-analysis/docs/container-analysis Container Analysis is a service that provides vulnerability scanning and metadata storage for containers. The scan

---

## Answer

**Correct:** A, E

**Confidence:** high

### Explanation

This question requires a cloud-native, cost-efficient solution with minimal operational overhead to prevent vulnerable containers from being deployed to GKE. The correct approach combines automated vulnerability scanning with attestation-based deployment control:

**Option A** leverages **Container Analysis** (now part of Artifact Analysis), which automatically scans container images when they're uploaded to Artifact Registry/Container Registry. Container Analysis continuously monitors images for new vulnerabilities with updates received multiple times daily. By integrating this into a Cloud Build pipeline that monitors Cloud Source Repositories, you can analyze the scan results before allowing builds to proceed. This is cloud-native (fully managed Google Cloud service), cost-efficient (automatic scanning is included), and requires minimal operational overhead (no infrastructure to manage).

**Option E** implements **Binary Authorization with attestations**, which is the Google Cloud-native approach for deployment policy enforcement. The recommended pattern is to create attestations in your CI/CD pipeline when vulnerability scans show no issues above acceptable thresholds, then configure a Binary Authorization policy that requires these attestations before allowing deployments to your GKE cluster. This prevents any container without a valid attestation (including those with known vulnerabilities) from being deployed. Binary Authorization is a fully managed service that integrates natively with GKE, requires no infrastructure maintenance, and provides a robust security gate.

Together, these solutions create a comprehensive security pipeline: Container Analysis scans for vulnerabilities → CI/CD creates attestations for clean images → Binary Authorization enforces attestation requirements at deployment time.

### Why Other Options Are Wrong

- **B:** Using a Cloud Function triggered by log events to scan containers is reactive rather than proactive, adds unnecessary complexity and operational overhead (managing Cloud Functions, log filters, and scanning triggers), and doesn't provide the deployment enforcement mechanism needed to block vulnerable containers from reaching the cluster.

- **C:** Running a cron job on a Compute Engine instance violates all three requirements: not cloud-native (requires managing VM infrastructure), not cost-efficient (paying for a continuously running VM), and creates significant operational overhead (maintaining the VM, cron jobs, scanning scripts, and alert mechanisms). This approach also only detects issues after the fact rather than preventing deployment.

- **D:** Deploying and managing Jenkins on GKE introduces substantial operational overhead (maintaining Jenkins infrastructure, plugins, updates, and availability), is not the most cost-efficient solution (consumes cluster resources), and is not cloud-native compared to using Google Cloud's managed CI/CD services like Cloud Build with Container Analysis and Binary Authorization.

### References

- [Container scanning overview | Artifact Analysis](https://docs.cloud.google.com/artifact-analysis/docs/container-scanning-overview)
- [Safeguard deployments | Software supply chain security](https://docs.cloud.google.com/software-supply-chain-security/docs/safeguard-deploys)
- [Use the vulnerability check | Binary Authorization](https://docs.cloud.google.com/binary-authorization/docs/cv-vulnerability-check)
- [Artifact analysis and vulnerability scanning | Artifact Registry](https://docs.cloud.google.com/artifact-registry/docs/analysis)
