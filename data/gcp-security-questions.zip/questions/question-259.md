# Question 259

**Source:** https://www.examtopics.com/discussions/google/view/147053-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** BigQuery, PII, data masking, column-level security, Sensitive Data Protection

---

## Question

Your team maintains 1PB of sensitive data within BigOuery that contains personally identifiable information (PII). You need to provide access to this dataset to another team within your organization for analysis purposes. You must share the BigQuery dataset with the other team while protecting the PII. What should you do?
## Choices

- **A.** Utilize BigQuery's row-level access policies to mask PII columns based on the other team's user identities. Most Voted
- **B.** Export the BigQuery dataset to Cloud Storage. Create a VPC Service Control perimeter and allow only their team's project access to the bucket.
- **C.** Implement data pseudonymization techniques to replace the PII fields with non-identifiable values. Grant the other team access to the pseudonymized dataset.
- **D.** Create a filtered copy of the dataset and replace the sensitive data with hash values in a separate project. Grant the other team access to this new project.

---

## Community

**Most Voted:** A


**Votes:** A: 62% | C: 38% (13 total)


**Top Comments:**

- (2 upvotes) https://cloud.google.com/blog/products/identity-security/how-to-use-google-cloud-to-find-and-protect-pii https://cloud.google.com/sensitive-data-protection/docs/dlp-bigquery

- (2 upvotes) Sorry: A: I disagree with answer C. Row-level security allows you to filter data and enable access to specific rows in a table, based on eligible user conditions. Row-level security allows a data owne

- (2 upvotes) yes, "replace" the original data is wrong. we need somewhere to keep the true copy of data. If copy to another target and then replace the PII then it is OK. But saying 1PB data, it is time consuming 

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is correct because implementing data pseudonymization techniques is the proper approach for protecting PII while maintaining data utility for analysis. BigQuery provides native column-level data masking capabilities that allow you to:

1. **Create data policies** with masking rules (SHA256 hashing, nullification, or custom routines) applied to specific columns
2. **Apply policy tags** to PII columns in your table schema
3. **Grant BigQuery Masked Reader role** to the other team, allowing them to query the dataset and receive pseudonymized/masked values for PII columns
4. **Maintain data utility** by preserving data structure and relationships while obscuring sensitive values

This approach allows the other team to access and analyze the dataset directly in BigQuery without exposing the actual PII. They can still perform analytics on the dataset while the PII fields are automatically masked based on their permissions. The data masking is applied at query time, meaning the original data remains intact and unmodified in the table.

As a best practice, you should assign the BigQuery Masked Reader role at the data policy level to avoid granting excessive permissions. Users with the Data Catalog Fine-Grained Reader role on the policy tags can see unmasked data, while users with only the Masked Reader role see masked data.

### Why Other Options Are Wrong

- **A:** Row-level access policies control which **rows** users can access, not which **columns** are masked. Row-level security filters entire rows based on conditions, but does not obscure PII within the columns themselves. This option confuses row-level security (for row filtering) with column-level data masking (for PII protection). The question specifically requires masking PII columns, not filtering rows.

- **B:** Exporting to Cloud Storage and using VPC Service Controls only provides network perimeter protection but does not mask the PII data itself. The other team would still have access to the unprotected PII values in the exported files. VPC Service Controls prevent data exfiltration across perimeter boundaries but do not provide data masking or de-identification capabilities.

- **D:** Creating a filtered copy with hash values in a separate project introduces operational overhead, data duplication, storage costs, and synchronization challenges. You would need to maintain two copies of a 1PB dataset and ensure the hashed copy stays current with the source. This is inefficient when BigQuery provides native column-level masking that works on the original dataset without duplication.

### References

- [Mask column data | BigQuery](https://docs.cloud.google.com/bigquery/docs/column-data-masking)
- [Introduction to data masking | BigQuery](https://cloud.google.com/bigquery/docs/column-data-masking-intro)
