# Question 047

**Source:** https://www.examtopics.com/discussions/google/view/21472-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** load balancer, HTTPS, SSL, TLS, encryption in transit

---

## Question

A large e-retailer is moving to Google Cloud Platform with its ecommerce website. The company wants to ensure payment information is encrypted between the customer's browser and GCP when the customers checkout online. What should they do?
## Choices

- **A.** Configure an SSL Certificate on an L7 Load Balancer and require encryption. Most Voted
- **B.** Configure an SSL Certificate on a Network TCP Load Balancer and require encryption.
- **C.** Configure the firewall to allow inbound traffic on port 443, and block all other inbound traffic.
- **D.** Configure the firewall to allow outbound traffic on port 443, and block all other outbound traffic.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (2 total)


**Top Comments:**

- (11 upvotes) Selected Answer: A

- (3 upvotes) A is the correct one. the question is to see if you understand difference between Layer 7 vs Layer 4 protocols.

- (2 upvotes) A is right

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

An **L7 (Layer 7) Load Balancer** (External Application Load Balancer) is the correct solution for encrypting HTTPS traffic between customer browsers and GCP. This is a proxy-based load balancer that:

- Operates at the application layer and understands HTTP/HTTPS protocols
- Performs SSL/TLS termination, decrypting traffic from clients using SSL certificates
- Can route traffic based on URL paths, hostnames, headers, and cookies
- Supports both Google-managed and self-managed SSL certificates
- Provides the target HTTPS proxy that holds the SSL certificate for encrypting traffic between the client and GCP

For an ecommerce website handling payment information, the External Application Load Balancer ensures end-to-end encryption from the customer's browser to Google Cloud by terminating SSL/TLS connections and re-encrypting traffic to backends within the VPC (Google automatically encrypts traffic between Google Front Ends and backends).

### Why Other Options Are Wrong

- **B:** Network TCP Load Balancer operates at Layer 4 (transport layer) and is designed for non-HTTP protocols requiring TCP/UDP passthrough with high throughput and low latency. While it can handle SSL passthrough, it's not designed for web application HTTPS termination and routing like an L7 load balancer. For a web application, L7 is the standard choice.

- **C:** Simply allowing inbound traffic on port 443 through the firewall does not provide encryption. Firewalls control what traffic is allowed, but they don't encrypt data. You still need an SSL/TLS certificate configured on a load balancer to actually encrypt the HTTPS connection. This is necessary but insufficient.

- **D:** Configuring outbound traffic rules is irrelevant to encrypting incoming customer connections. This addresses traffic leaving GCP, not incoming HTTPS connections from customers browsing the ecommerce website. The question specifically asks about browser-to-GCP encryption for checkout.

### References

- [SSL certificates overview | Cloud Load Balancing](https://docs.cloud.google.com/load-balancing/docs/ssl-certificates)
- [External Application Load Balancer overview](https://docs.cloud.google.com/load-balancing/docs/https)
