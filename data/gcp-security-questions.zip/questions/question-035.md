# Question 035

**Source:** https://www.examtopics.com/discussions/google/view/17523-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** PCI DSS, compliance, scope reduction, project separation, cardholder data environment

---

## Question

You are a member of the security team at an organization. Your team has a single GCP project with credit card payment processing systems alongside web applications and data processing systems. You want to reduce the scope of systems subject to PCI audit standards. What should you do?
## Choices

- **A.** Use multi-factor authentication for admin access to the web application.
- **B.** Use only applications certified compliant with PA-DSS.
- **C.** Move the cardholder data environment into a separate GCP project. Most Voted
- **D.** Use VPN for all connections between your office and cloud environments.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (2 total)


**Top Comments:**

- (22 upvotes) answer is C

- (4 upvotes) Definitely C

- (2 upvotes) C is the answer.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Moving the cardholder data environment (CDE) into a separate GCP project is the most effective strategy to reduce PCI DSS compliance scope. According to Google Cloud's architecture guidance, project isolation is a fundamental method for limiting PCI assessment scope because:

1. **IAM Boundary**: Projects function as IAM enforcement boundaries, allowing you to restrict user access to only the resources that handle cardholder data
2. **Folder-level Isolation**: All PCI-scoped resources can be grouped within a dedicated folder, creating a logical boundary where only designated users access in-scope components
3. **Connected Systems Exclusion**: By properly isolating the CDE in a separate project, unrelated infrastructure (web applications and data processing systems) cannot be considered "connected-to" or "security-impacting" systems—the key criteria determining inclusion in PCI assessments

Google Cloud documentation explicitly recommends this approach: "All projects that are in PCI scope are grouped within a single folder to isolate at the folder level." This architectural separation, combined with VPC Service Controls and network segmentation, minimizes the set of systems subject to audit requirements.

### Why Other Options Are Wrong

- **A:** Multi-factor authentication for admin access improves security but doesn't reduce the scope of systems subject to PCI audit. It's a security control that should be implemented regardless, but it doesn't isolate the CDE from other systems.

- **B:** Using PA-DSS certified applications helps with compliance but doesn't reduce the audit scope. When payment applications coexist with non-payment systems in the same project, all connected systems remain in scope regardless of application certification.

- **D:** VPN connections for office-to-cloud traffic improve security by encrypting communications, but this doesn't address the fundamental issue of scope reduction. The VPN would still connect to a mixed environment where cardholder data processing systems and non-payment systems share the same project boundary.

### References

- [Limiting scope of compliance for PCI environments in Google Cloud](https://docs.cloud.google.com/architecture/limiting-compliance-scope-pci-environments-google-cloud)
- [PCI DSS compliance in GCP](https://docs.cloud.google.com/architecture/pci-dss-compliance-in-gcp)
