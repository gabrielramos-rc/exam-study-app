# Question 237

**Source:** https://www.examtopics.com/discussions/google/view/126776-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** Cloud EKM, External Key Manager, CMEK, Cloud KMS, HSM, BigQuery encryption

---

## Question

Your organization wants full control of the keys used to encrypt data at rest in their Google Cloud environments. Keys must be generated and stored outside of Google and integrate with many Google Services including BigQuery. What should you do?
## Choices

- **A.** Use customer-supplied encryption keys (CSEK) with keys generated on trusted external systems. Provide the raw CSEK as part of the API call.
- **B.** Create a KMS key that is stored on a Google managed FIPS 140-2 level 3 Hardware Security Module (HSM). Manage the Identity and Access Management (IAM) permissions settings, and set up the key rotation period.
- **C.** Use Cloud External Key Management (EKM) that integrates with an external Hardware Security Module (HSM) system from supported vendors. Most Voted
- **D.** Create a Cloud Key Management Service (KMS) key with imported key material. Wrap the key for protection during import. Import the key generated on a trusted system in Cloud KMS.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (6 total)


**Top Comments:**

- (1 upvotes) Use Cloud External Key Management (EKM) that integrates with an external Hardware Security Module (HSM) system from supported vendors

- (1 upvotes) agree with c

- (1 upvotes) C. -Full Key Control: Cloud EKM allows you to leverage an external HSM, providing complete control over key generation and storage outside of Google's infrastructure. This satisfies your organization'

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Cloud External Key Manager (EKM) is the correct solution because it meets all the requirements:

1. **Keys stored outside Google**: With Cloud EKM, the external key material "never leaves your external key management system and it is never shared with Google." Keys remain in your supported external HSM (from partners like Fortanix, Futurex, or Thales).

2. **Full control**: You maintain complete control over key location, distribution, and access. You can revoke Google Cloud's access to the keys at any time through your external key manager.

3. **Integration with BigQuery and many Google services**: Cloud EKM integrates with all CMEK-compatible services including BigQuery, Cloud Storage, Compute Engine, Cloud SQL, Cloud Run, Spanner, and many others. Google Cloud communicates directly with the external key management partner for each encryption/decryption request.

4. **Keys generated externally**: Keys are generated and managed in your external HSM system, not by Google Cloud.

### Why Other Options Are Wrong

- **A:** CSEK is not supported by BigQuery. The documentation explicitly states: "BigQuery and BigLake tables don't support Customer-Supplied Encryption Keys (CSEK)." CSEK is only available for specific services like Compute Engine persistent disks. Additionally, CSEK requires providing the raw key with each API call, which is operationally complex.

- **B:** While this provides FIPS 140-2 Level 3 HSM protection, the key is still stored on a Google-managed HSM within Google Cloud. This does not meet the requirement for keys to be "generated and stored outside of Google." The organization wants external key storage, not Google-managed HSMs.

- **D:** Imported key material in Cloud KMS does not meet the requirement for keys to remain outside Google. Once imported, the key material becomes part of Cloud KMS infrastructure and is stored within Google Cloud (albeit encrypted). The requirement specifies keys must be "stored outside of Google," not just generated outside.

### References

- [Cloud External Key Manager Overview](https://docs.cloud.google.com/kms/docs/ekm)
- [BigQuery Encryption at Rest](https://docs.cloud.google.com/bigquery/docs/encryption-at-rest)
- [Customer-Managed Encryption Keys for BigQuery](https://docs.cloud.google.com/bigquery/docs/customer-managed-encryption)
