# Question 085

**Source:** https://www.examtopics.com/discussions/google/view/32131-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** GCDS, Google Cloud Directory Sync, LDAP, security groups, one-way sync

---

## Question

You are the Security Admin in your company. You want to synchronize all security groups that have an email address from your LDAP directory in Cloud IAM. What should you do?
## Choices

- **A.** Configure Google Cloud Directory Sync to sync security groups using LDAP search rules that have ג€user email addressג€ as the attribute to facilitate one-way sync. Most Voted
- **B.** Configure Google Cloud Directory Sync to sync security groups using LDAP search rules that have ג€user email addressג€ as the attribute to facilitate bidirectional sync.
- **C.** Use a management tool to sync the subset based on the email address attribute. Create a group in the Google domain. A group created in a Google domain will automatically have an explicit Google Cloud Identity and Access Management (IAM) role.
- **D.** Use a management tool to sync the subset based on group object class attribute. Create a group in the Google domain. A group created in a Google domain will automatically have an explicit Google Cloud Identity and Access Management (IAM) role.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (13 total)


**Top Comments:**

- (11 upvotes) GCDS allow sync ldap users in one way. A is correct

- (5 upvotes) A is correct

- (3 upvotes) A. Configure Google Cloud Directory Sync to sync security groups using LDAP search rules that have “user email address” as the attribute to facilitate one-way sync.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Google Cloud Directory Sync (GCDS) is specifically designed to synchronize users, groups, and shared contacts from an LDAP directory (including Active Directory) to Google Cloud Identity and Google Workspace. The correct approach is to configure GCDS with LDAP search rules that filter for groups with email addresses, using **one-way synchronization**.

Key aspects of the correct answer:

1. **LDAP Search Rules with Email Attribute**: GCDS allows you to configure LDAP search rules to filter which groups to sync. For security groups that have an email address, you would use the `mail` attribute in the search filter (e.g., `(&(objectCategory=group)(mail=*))`). This ensures only groups with email addresses are synchronized.

2. **One-Way Sync**: GCDS performs **one-way synchronization only** - from your LDAP directory to Google Cloud Identity. Data flows from your on-premises LDAP server to Google, and your LDAP server data is never updated or altered by GCDS. This is a fundamental design principle that maintains your LDAP directory as the authoritative source.

3. **Security Group Requirements**: For security groups to sync correctly with GCDS, each group must have a unique email address defined on the group object. Security groups in Active Directory are typically not mail-enabled by default, so administrators often need to manually assign email addresses to security groups before they can be synchronized.

4. **IAM Integration**: Once synchronized to Cloud Identity, these groups can then be used in Cloud IAM policies to grant permissions across Google Cloud resources.

### Why Other Options Are Wrong

- **B:** GCDS does **not support bidirectional sync**. It only provides one-way synchronization from LDAP to Google Cloud Identity. Attempting to configure bidirectional sync is not possible with GCDS and would be architecturally incorrect, as Google does not modify your LDAP directory data.

- **C:** This option is vague and incorrect. Groups created in the Google domain do **not** automatically receive explicit IAM roles - roles must be explicitly granted through IAM policies. Additionally, the statement about using "a management tool" is too generic when GCDS is the specific, purpose-built tool for this scenario.

- **D:** Using "group object class attribute" as the filter would sync all groups regardless of whether they have email addresses. The question specifically asks to sync only groups **that have an email address**, which requires filtering by the email/mail attribute, not the object class. Additionally, the false claim about automatic IAM role assignment makes this incorrect.

### References

- [About Google Cloud Directory Sync - Google Workspace Admin Help](https://support.google.com/a/answer/106368?hl=en)
- [Sync groups from your LDAP or Active Directory server](https://support.google.com/a/answer/167105?hl=en)
- [GCDS FAQ - Google Workspace Admin Help](https://support.google.com/a/answer/7177266?hl=en)
- [Google Cloud Directory Sync examples](https://cloud.google.com/community/tutorials/gcds-use-cases-common-and-complex)
