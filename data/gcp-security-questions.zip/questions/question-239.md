# Question 239

**Source:** https://www.examtopics.com/discussions/google/view/126778-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** hierarchical firewall policy, folder level, egress control, VPC network, Cloud NGFW

---

## Question

You control network traffic for a folder in your Google Cloud environment. Your folder includes multiple projects and Virtual Private Cloud (VPC) networks. You want to enforce on the folder level that egress connections are limited only to IP range 10.58.5.0/24 and only from the VPC network “dev-vpc”. You want to minimize implementation and maintenance effort. What should you do?
## Choices

- **A.** 1. Leave the network configuration of the VMs in scope unchanged. 2. Create a new project including a new VPC network "new-vpc". 3. Deploy a network appliance in "new-vpc" to filter access requests and only allow egress connections from "dev-vpc" to 10.58.5.0/24.
- **B.** 1. Leave the network configuration of the VMs in scope unchanged. 2. Enable Cloud NAT for "dev-vpc" and restrict the target range in Cloud NAT to 10.58.5.0/24.
- **C.** 1. Attach external IP addresses to the VMs in scope. 2. Define and apply a hierarchical firewall policy on folder level to deny all egress connections and to allow egress to IP range 10.58.5.0/24 from network dev-vpc. Most Voted
- **D.** 1. Attach external IP addresses to the VMs in scope. 2. Configure a VPC Firewall rule in "dev-vpc" that allows egress connectivity to IP range 10.58.5.0/24 for all source addresses in this network.

---

## Community

**Most Voted:** C


**Votes:** B: 38% | C: 62% (16 total)


**Top Comments:**

- (4 upvotes) hmm this is a tricky one. between B and C i am leaning more towards C but only because of the wording in the Q itself, specifically 'enforce on the folder level'. For me all options are pants but I fe

- (3 upvotes) But mentioned IP range is internal, so why we need External IP ? In my opinion all answers are bad

- (3 upvotes) NAT can be used to route internal traffic to other VPCs also. Cloud NAT lets certain resources in Google Cloud create outbound connections to the internet or to other Virtual Private Cloud (VPC) netwo

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is correct because it uses hierarchical firewall policies at the folder level, which is the most appropriate mechanism for enforcing network security controls across multiple projects and VPC networks within a folder. Here's why this is the optimal solution:

1. **Folder-level enforcement**: Hierarchical firewall policies can be created with a folder as their parent resource. Once associated with a folder, the firewall policy's rules apply to all resources in VPC networks within projects of that folder, providing centralized control.

2. **VPC network targeting**: Hierarchical firewall rules support a "Target networks" field that allows you to specify which VPC networks a rule applies to. This enables you to create a rule that allows egress traffic specifically from "dev-vpc" to the IP range 10.58.5.0/24, while denying egress from all other VPCs in the folder.

3. **Minimal maintenance**: This approach centralizes policy management at the folder level rather than requiring configuration in each individual project or VPC network. Changes to the policy are made once and automatically apply to all resources in scope.

4. **Deny-all with selective allow pattern**: The solution implements security best practices by creating a deny-all egress rule (destination 0.0.0.0/0) and then selectively allowing traffic from dev-vpc to the specific IP range using rule priorities and the "Go to next" action for allowed traffic.

Note: While the option mentions attaching external IP addresses, hierarchical firewall policies control egress traffic regardless of whether VMs have external IPs. The policy enforces rules based on VPC network membership and destination IP ranges.

### Why Other Options Are Wrong

- **A:** Deploying a network appliance to filter traffic is significantly more complex and requires ongoing maintenance of the appliance itself (patching, scaling, high availability). This violates the requirement to minimize implementation and maintenance effort. It also introduces a single point of failure and additional network hops.

- **B:** Cloud NAT is designed for enabling outbound internet connectivity for VMs without external IP addresses, not for enforcing security policies. Cloud NAT does not provide the capability to restrict egress based on source VPC network or enforce folder-level policies across multiple projects. It cannot enforce that ONLY dev-vpc can reach the destination IP range while blocking other VPCs.

- **D:** VPC firewall rules are applied at the VPC network level, not at the folder level. This approach would only control traffic within dev-vpc but would not enforce folder-level restrictions preventing other VPC networks from accessing the IP range. It fails to meet the requirement of folder-level enforcement across multiple projects and VPC networks.

### References

- [Hierarchical firewall policies overview](https://docs.cloud.google.com/firewall/docs/firewall-policies)
- [Use hierarchical firewall policies and rules](https://docs.cloud.google.com/firewall/docs/using-firewall-policies)
- [Configure hierarchical firewall policy to allow egress from specific VPC](https://docs.cloud.google.com/firewall/docs/quickstarts/configure-hfwpolicy-allow-egress-vpc)
- [Firewall policy rules details](https://docs.cloud.google.com/firewall/docs/firewall-policies-rule-details)
