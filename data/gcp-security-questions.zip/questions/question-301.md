# Question 301

**Source:** https://www.examtopics.com/discussions/google/view/148656-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** IAM, separation of duties, custom roles, least privilege, firewall permissions

---

## Question

Your organization is implementing separation of duties in a Google Cloud project. A group of developers must deploy new code, but cannot have permission to change network firewall rules. What should you do?
## Choices

- **A.** Assign the network administrator IAM role to all developers. Tell developers not to change firewall settings.
- **B.** Use Access Context Manager to create conditions that allow only authorized administrators to change firewall rules based on attributes such as IP address or device security posture.
- **C.** Create and assign two custom IAM roles. Assign the deployer role to control Compute Engine and deployment-related permissions. Assign the network administrator role to manage firewall permissions. Most Voted
- **D.** Grant the editor IAM role to the developer group. Explicitly negate any firewall modification permissions by using IAM deny policies.

---

## Community

**Most Voted:** C


**Votes:** C: 67% | D: 33% (3 total)


**Top Comments:**

- (1 upvotes) D. is the most robust and explicit solution for enforcing separation of duties. While granting the Editor role is overly permissive, pairing it with an IAM Deny policy creates an unbreakable security 

- (1 upvotes) It's C.

- (1 upvotes) C - Custom Roles: Creating custom IAM roles allows you to define granular permissions, ensuring that developers only have the necessary access to deploy new code. Separation of Duties: By assigning th

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is the correct approach for implementing separation of duties. Creating two distinct custom IAM roles allows you to precisely control which permissions each group receives:

1. **Deployer Role (Custom)**: Contains only the permissions developers need for deployment (e.g., `compute.instances.create`, `compute.instances.update`, `compute.instances.start`, etc.) while explicitly excluding firewall-related permissions like `compute.firewalls.create`, `compute.firewalls.update`, or `compute.firewalls.delete`.

2. **Network Administrator Role (Custom or Predefined)**: Assigned only to authorized administrators who need to manage firewall rules. Google provides a predefined `roles/compute.securityAdmin` role that grants permissions to manage firewall rules and SSL certificates.

This approach follows the principle of least privilege by granting only the specific permissions required for each role. Custom roles can contain up to 3,000 permissions and should be carefully scoped to bundle only the permissions needed for specific job functions. The documentation emphasizes that separation of duties is accomplished by assigning different IAM roles to different accounts, and custom roles help enforce this by ensuring principals have only the permissions they need.

### Why Other Options Are Wrong

- **A:** Assigning the Network Administrator role to developers directly violates separation of duties. Relying on verbal instructions ("Tell developers not to change firewall settings") is not a technical control and provides no enforcement mechanism. This approach grants the permission but hopes users won't misuse it, which is contrary to security best practices.

- **B:** Access Context Manager is designed for context-aware access based on attributes like IP address, device security posture, or geographic location. It controls access to resources based on contextual conditions, not for managing which permissions a user has. ACM doesn't prevent users with firewall permissions from making changes; it only restricts where/when they can access resources. This is the wrong tool for separating permissions.

- **D:** While IAM deny policies can explicitly block certain permissions, granting the Editor role first is over-permissive. The Editor role (`roles/editor`) provides broad write access across most Google Cloud services. Using deny policies to carve out exceptions violates the principle of least privilege—you should start with minimal permissions and add only what's needed, not grant broad access and then try to block specific actions. Additionally, deny policies add complexity and are harder to audit than properly scoped custom roles.

### References

- [Create and manage custom roles](https://docs.cloud.google.com/iam/docs/creating-custom-roles)
- [Compute Engine IAM roles and permissions](https://docs.cloud.google.com/compute/docs/access/iam)
- [IAM roles overview](https://docs.cloud.google.com/iam/docs/roles-overview)
