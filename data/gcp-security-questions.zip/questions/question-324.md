# Question 324

**Source:** https://www.examtopics.com/discussions/google/view/306215-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, resource locations, data residency, compliance, EU restrictions

---

## Question

Your organization has a workload that is regulated by European laws. You must restrict the creation of resources outside of the EU for this specific workload. You must find an effective way to implement this security control without disrupting the other global applications. What should you do?
## Choices

- **A.** Create a Cloud Function triggered at asset creation that detects and deletes resources outside of the EU.
- **B.** Create all your workload's assets in a regional subnet in the EU in one project or folder.
- **C.** Segment your workload in the EU in one project or folder by using VPC Service Controls.
- **D.** Implement an organization policy that only allows the EU as the location for your workload's project or folder. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (1 total)

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The correct solution is to implement an organization policy with the `gcp.resourceLocations` constraint set to only allow EU locations for the specific workload's project or folder. This approach provides:

**Proactive enforcement:** The organization policy prevents resource creation in non-EU regions at the API level, blocking requests before resources are created. The constraint uses the value group `in:eu-locations` which includes all EU regions and automatically expands as Google adds new EU locations.

**Granular scope:** Organization policies can be applied at the organization, folder, or project level. By applying it specifically to the workload's project or folder, you isolate the restriction to only the regulated workload without impacting other global applications in your organization.

**Automatic enforcement:** Once configured, the policy automatically enforces location restrictions across all supported Google Cloud services for that scope, including Compute Engine, Cloud Storage, BigQuery, and more. Users attempting to create resources outside the EU will receive an error message.

**Non-retroactive:** The policy only affects newly created resources, so existing global resources continue to function normally.

This is the most effective and scalable approach for regulatory compliance requiring data residency controls.

### Why Other Options Are Wrong

- **A:** Creating a Cloud Function to detect and delete resources is reactive rather than proactive. Resources would be created first (potentially violating compliance), then detected and deleted afterward. This creates a compliance gap, generates audit issues, and could disrupt applications that briefly used the resources. Additionally, this requires custom code maintenance and doesn't prevent the violation from occurring.

- **B:** Simply creating assets in a regional subnet doesn't prevent users from accidentally or intentionally creating resources in other regions. There's no enforcement mechanism - this relies entirely on manual procedures and human discipline, which is insufficient for regulatory compliance. Regional subnets also don't apply to many Google Cloud services beyond networking.

- **C:** VPC Service Controls is designed for creating security perimeters to prevent data exfiltration and restrict API access to Google Cloud services. While powerful for boundary protection, it doesn't control the geographic location where resources are created. VPC Service Controls focuses on "who can access what" rather than "where resources can be created."

### References

- [Restricting Resource Locations](https://docs.cloud.google.com/resource-manager/docs/organization-policy/defining-locations)
- [Resource Locations Supported Services](https://docs.cloud.google.com/resource-manager/docs/organization-policy/defining-locations-supported-services)
