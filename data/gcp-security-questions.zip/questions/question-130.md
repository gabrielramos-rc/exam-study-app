# Question 130

**Source:** https://www.examtopics.com/discussions/google/view/74836-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Cloud Armor, WAF, load balancer, security policy, DDoS

---

## Question

You plan to use a Google Cloud Armor policy to prevent common attacks such as cross-site scripting (XSS) and SQL injection (SQLi) from reaching your web application's backend. What are two requirements for using Google Cloud Armor security policies? (Choose two.)
## Choices

- **A.** The load balancer must be an external SSL proxy load balancer.
- **B.** Google Cloud Armor Policy rules can only match on Layer 7 (L7) attributes.
- **C.** The load balancer must use the Premium Network Service Tier.
- **D.** The backend service's load balancing scheme must be EXTERNAL. Most Voted
- **E.** The load balancer must be an external HTTP(S) load balancer. Most Voted

---

## Community

**Most Voted:** DE


**Votes:** BE: 8% | DE: 92% (13 total)


**Top Comments:**

- (5 upvotes) Not true....Security policy overview bookmark_border Google Cloud Armor security policies protect your application by providing Layer 7 filtering and by scrubbing incoming requests for common web atta

- (3 upvotes) Security policy for A does not block XSS and SQLi which is at layer 7. https://cloud.google.com/armor/docs/security-policy-overview#policy-types

- (3 upvotes) Google Cloud Armor security policies are sets of rules that match on attributes from Layer 3 to Layer 7 to protect externally facing applications or services. Each rule is evaluated with respect to in

---

## Answer

**Correct:** D, E

**Confidence:** high

### Explanation

The two requirements for using Google Cloud Armor security policies to protect against XSS and SQLi attacks are:

**D. The backend service's load balancing scheme must be EXTERNAL** - According to the official documentation, Cloud Armor security policies require the backend service to use an EXTERNAL, EXTERNAL_MANAGED, or INTERNAL_MANAGED load balancing scheme. For the context of protecting web applications from XSS and SQLi (which are external threats), the load balancing scheme must be EXTERNAL to allow Cloud Armor to inspect and filter incoming traffic at the Google Cloud edge before it reaches your backend services.

**E. The load balancer must be an external HTTP(S) load balancer** - Cloud Armor's advanced security features, particularly the preconfigured WAF rules for XSS and SQLi protection, are specifically designed for Application Load Balancers. The documentation explicitly states that Cloud Armor security policies are available for "all external Application Load Balancers (including classic Application Load Balancers)". For web application protection against Layer 7 attacks like XSS and SQLi, an external HTTP(S) load balancer (Application Load Balancer) is the appropriate choice as it operates at Layer 7 where these attacks occur.

### Why Other Options Are Wrong

- **A:** While Cloud Armor does support external proxy Network Load Balancers (TCP/SSL), these are not the primary or recommended load balancer type for web application protection against XSS and SQLi. These are Layer 7 attacks that require HTTP(S) inspection, which is provided by Application Load Balancers (external HTTP(S) load balancers), not SSL proxy load balancers.

- **B:** This is incorrect. Cloud Armor policy rules can match on both Layer 7 (application layer) and Layer 3 (network layer) attributes. The documentation shows rules can match on IP addresses and IP ranges (Layer 3), geolocation, as well as Layer 7 attributes like request headers, cookies, URI paths, and request body content.

- **C:** This is false. The documentation explicitly states that "The load balancer can be in Premium Tier or Standard Tier," meaning Cloud Armor security policies work with both network service tiers. There is no requirement to use Premium Network Service Tier.

### References

- [Security policy overview | Google Cloud Armor](https://docs.cloud.google.com/armor/docs/security-policy-overview)
- [Configure Cloud Armor security policies](https://docs.cloud.google.com/armor/docs/configure-security-policies)
