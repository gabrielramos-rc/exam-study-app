# Question 104

**Source:** https://www.examtopics.com/discussions/google/view/84267-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** Access Transparency, Access Approval, Assured Workloads, Google employee access control

---

## Question

You are a security engineer at a finance company. Your organization plans to store data on Google Cloud, but your leadership team is worried about the security of their highly sensitive data. Specifically, your company is concerned about internal Google employees' ability to access your company's data on Google Cloud. What solution should you propose?
## Choices

- **A.** Use customer-managed encryption keys.
- **B.** Use Google's Identity and Access Management (IAM) service to manage access controls on Google Cloud.
- **C.** Enable Admin activity logs to monitor access to resources.
- **D.** Enable Access Transparency logs with Access Approval requests for Google employees. Most Voted

---

## Community

**Most Voted:** D


**Votes:** A: 13% | D: 87% (15 total)


**Top Comments:**

- (5 upvotes) D https://cloud.google.com/access-transparency https://cloud.google.com/cloud-provider-access-management/access-transparency/docs/overview

- (5 upvotes) To address your organization’s concerns about the security of highly sensitive data stored on Google Cloud, you can propose the following solution: D. Enable Access Transparency logs with Access Appro

- (3 upvotes) Answer D - but, for "highly sensitive data" CMEK seems to be reasonable option but much easiest way is to use Transparency Logs

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Access Transparency with Access Approval is the specific solution designed to address concerns about Google employees accessing customer data on Google Cloud. This combination provides both visibility and control:

**Access Transparency** logs record actions that Google personnel take when accessing customer data, providing complete visibility into when and why Google administrators access your resources. These logs are cryptographically signed to ensure integrity.

**Access Approval** adds a mandatory control layer by requiring your explicit approval before Google Cloud Customer Care or engineering teams can access your customer data. Each access request must include a valid business justification, and you can approve or deny these requests. Approvals can be revoked at any time, and if not approved within 14 days, requests are automatically dismissed.

Together, these services give enterprises direct control over Google personnel's access to customer data, which is exactly what the finance company needs to address their leadership's concerns. This solution is part of Google's Assured Workloads offering specifically designed for highly regulated industries like finance.

### Why Other Options Are Wrong

- **A:** Customer-managed encryption keys (CMEK) protect data at rest from unauthorized access by controlling encryption keys, but they don't prevent or control Google employees' administrative access to your resources. Google administrators with valid reasons may still need access to troubleshoot issues, and CMEK doesn't provide visibility or approval workflows for such access.

- **B:** IAM manages access controls for your organization's users and service accounts accessing Google Cloud resources. It does not control or restrict Google employees' administrative access to your data. IAM is for managing customer-side access, not Google personnel access.

- **C:** Admin activity logs monitor actions taken by members of your Google Cloud organization, not actions taken by Google personnel. These logs track customer administrative actions but provide no visibility into or control over Google employee access to your data.

### References

- [Overview of Access Approval | Google Cloud Documentation](https://docs.cloud.google.com/assured-workloads/access-approval/docs/overview)
- [Overview of Access Transparency | Google Cloud Documentation](https://docs.cloud.google.com/assured-workloads/access-transparency/docs/overview)
- [Introduction to Access Approval | Access Transparency | Google Cloud Documentation](https://docs.cloud.google.com/assured-workloads/access-transparency/docs/access-approval)
