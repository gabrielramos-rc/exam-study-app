# Question 267

**Source:** https://www.examtopics.com/discussions/google/view/147061-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** Access Approval, Cloud EKM, external HSM, custom signing key, compliance

---

## Question

Your organization operates in a highly regulated industry and needs to implement strict controls around temporary access to sensitive Google Cloud resources. You have been using Access Approval to manage this access, but your compliance team has mandated the use of a custom signing key. Additionally, they require that the key be stored in a hardware security module (HSM) located outside Google Cloud. You need to configure Access Approval to use a custom signing key that meets the compliance requirements. What should you do?
## Choices

- **A.** Create a new asymmetric signing key in Cloud Key Management System (Cloud KMS) using a supported algorithm and grant the Access Approval service account the IAM signerVerifier role on the key.
- **B.** Export your existing Access Approval signing key as a PEM file. Upload the file to your external HSM and reconfigure Access Approval to use the key from the HSM.
- **C.** Create a signing key in your external HSM. Integrate the HSM with Cloud External Key Manager (Cloud EKM) and make the key available within your project. Configure Access Approval to use this key. Most Voted
- **D.** Create a new asymmetric signing key in Cloud KMS and configure the key with a rotation period of 30 days. Add the corresponding public key to your external HSM.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (6 total)


**Top Comments:**

- (1 upvotes) https://cloud.google.com/assured-workloads/access-approval/docs/review-approve-access-requests-custom-keys#select-key

- (1 upvotes) Only option C fulfils the compliance requirement of custom signing key located outside google cloud.

- (1 upvotes) I think it's C.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Cloud External Key Manager (Cloud EKM) is specifically designed to enable the use of keys managed in external key management systems, including hardware security modules (HSMs) located outside Google Cloud. When you integrate your external HSM with Cloud EKM, the keys remain in your external system and are never cached or stored within Google Cloud, meeting the strict compliance requirement that keys must be stored in an external HSM.

Access Approval supports custom signing keys, and you can use either a Cloud KMS key or an externally-managed key via Cloud EKM. The workflow is:

1. Create a signing key in your external HSM
2. Set up an EKM connection with your external key manager, authorizing your service account to access the crypto space
3. Create external keys in Cloud KMS (which represent the keys in your external HSM)
4. Configure Access Approval to use the Cloud EKM key as its custom signing key
5. The Access Approval service account needs the Cloud KMS CryptoKey Signer/Verifier role

This approach satisfies both requirements: using a custom signing key for Access Approval AND storing that key in an external HSM as mandated by the compliance team.

### Why Other Options Are Wrong

- **A:** While this creates a custom signing key for Access Approval, the key is stored in Google Cloud's Cloud KMS, not in an external HSM. This does not meet the compliance requirement that the key must be stored in a hardware security module located outside Google Cloud.

- **B:** Access Approval does not support exporting its signing keys. Google-managed services do not allow you to export private keys for security reasons. Additionally, you cannot directly reconfigure Access Approval to use a key stored solely in an external HSM without the Cloud EKM integration layer.

- **D:** This approach still stores the key in Cloud KMS (within Google Cloud) and only stores the public key in the external HSM. The compliance requirement is that the signing key (private key) must be stored in the external HSM. Additionally, simply adding a public key to the HSM does not create the integration needed for Access Approval to use the external key.

### References

- [Quickstart: Review access requests using a custom signing key](https://docs.cloud.google.com/assured-workloads/access-approval/docs/review-approve-access-requests-custom-keys)
- [Cloud External Key Manager Overview](https://docs.cloud.google.com/kms/docs/ekm)
- [Access Approval Overview](https://docs.cloud.google.com/assured-workloads/access-approval/docs/overview)
