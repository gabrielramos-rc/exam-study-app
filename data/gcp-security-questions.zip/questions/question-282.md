# Question 282

**Source:** https://www.examtopics.com/discussions/google/view/147076-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Managing and monitoring security controls
**Tags:** Cloud Logging, log sink, log bucket, log routing

---

## Question

You have just created a new log bucket to replace the _Default log bucket. You want to route all log entries that are currently routed to the _Default log bucket to this new log bucket, in the most efficient manner. What should you do?
## Choices

- **A.** Create exclusion filters for the _Default sink to prevent it from receiving new logs. Create a user-defined sink, and select the new log bucket as the sink destination.
- **B.** Disable the _Default sink. Create a user-defined sink and select the new log bucket as the sink destination.
- **C.** Create a user-defined sink with inclusion filters copied from the _Default sink. Select the new log bucket as the sink destination.
- **D.** Edit the _Default sink, and select the new log bucket as the sink destination. Most Voted

---

## Community

**Most Voted:** D


**Votes:** C: 12% | D: 88% (8 total)


**Top Comments:**

- (4 upvotes) I think it's C.

- (2 upvotes) D is correct

- (2 upvotes) D is correct answer, you can change the log destination for existing sink without creating new sink. as per Gemini.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The most efficient way to route all log entries currently routed to the _Default log bucket to a new log bucket is to **edit the _Default sink and change its destination** to the new log bucket.

According to Google Cloud documentation, the _Default sink can be modified, including changing its destination. This approach is the simplest and most efficient because:

1. **Single configuration change**: You only need to edit one resource (the _Default sink) rather than creating additional sinks
2. **Preserves existing routing logic**: The _Default sink already has the correct filters to route the logs you want
3. **No additional complexity**: No need to manage multiple sinks or duplicate filter logic
4. **Immediate effect**: All logs matching the sink's filter will be routed to the new destination once the change is saved

The documentation explicitly states: "You can modify and disable the _Default log sink. For example, you can edit the _Default log sink and change the destination."

### Why Other Options Are Wrong

- **A:** Creating exclusion filters on the _Default sink and then creating a new user-defined sink is unnecessarily complex. It requires managing two sinks and duplicating routing logic, when you can simply change the destination of the existing _Default sink.

- **B:** Disabling the _Default sink and creating a new user-defined sink adds unnecessary complexity. You would need to recreate all the routing logic that already exists in the _Default sink. This is less efficient than simply modifying the existing sink.

- **C:** Creating a user-defined sink with inclusion filters copied from the _Default sink is redundant and inefficient. You would have two sinks routing the same logs, which wastes resources and adds management overhead. The _Default sink would still be routing logs to the old bucket unless you also disable or modify it.

### References

- [Route log entries | Cloud Logging](https://docs.cloud.google.com/logging/docs/routing/overview)
- [Configure log buckets | Cloud Logging](https://docs.cloud.google.com/logging/docs/buckets)
- [Regionalize your logs | Cloud Logging](https://docs.cloud.google.com/logging/docs/regionalized-logs)
