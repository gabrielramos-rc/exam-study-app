# Question 231

**Source:** https://www.examtopics.com/discussions/google/view/117337-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** Cloud EKM, Key Access Justifications, external key manager, encryption, regulatory compliance

---

## Question

You are migrating an application into the cloud. The application will need to read data from a Cloud Storage bucket. Due to local regulatory requirements, you need to hold the key material used for encryption fully under your control and you require a valid rationale for accessing the key material. What should you do?
## Choices

- **A.** Encrypt the data in the Cloud Storage bucket by using Customer Managed Encryption Keys. Configure an IAM deny policy for unauthorized groups.
- **B.** Generate a key in your on-premises environment to encrypt the data before you upload the data to the Cloud Storage bucket. Upload the key to the Cloud Key Management Service (KMS). Activate Key Access Justifications (KAJ) and have the external key system reject unauthorized accesses.
- **C.** Encrypt the data in the Cloud Storage bucket by using Customer Managed Encryption Keys backed by a Cloud Hardware Security Module (HSM). Enable data access logs.
- **D.** Generate a key in your on-premises environment and store it in a Hardware Security Module (HSM) that is managed on-premises. Use this key as an external key in the Cloud Key Management Service (KMS). Activate Key Access Justifications (KAJ) and set the external key system to reject unauthorized accesses. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (12 total)


**Top Comments:**

- (2 upvotes) D. Generate a key in your on-premises environment and store it in a Hardware Security Module (HSM) that is managed on-premises. Use this key as an external key in the Cloud Key Management Service (KMS

- (1 upvotes) External key - means: Cloud External Key Manager Access Justifications - it is part a Cloud External Key Manager

- (1 upvotes) "Provide justification for key usage" is your hint in this question. That leaves B or D. You can't upload custom keys to KMS. D.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D correctly addresses both regulatory requirements through Cloud External Key Manager (Cloud EKM) with Key Access Justifications:

1. **Full control over key material**: With Cloud EKM, the external key material is created and stored in your on-premises HSM. The documentation explicitly states: "The external key material of a Cloud EKM key is cryptographic material created and stored in your EKM. This material does not leave your EKM and it is never shared with Google." This ensures you maintain complete ownership and control of the encryption keys.

2. **Valid rationale for accessing keys**: Key Access Justifications (KAJ) directs Google systems to generate access justification codes for each cryptographic operation involving the enrolled Cloud KMS keys. When enabled, each request to access your encryption keys includes a justification code explaining why the access is needed (e.g., customer-initiated access, service operations, support requests).

3. **Rejecting unauthorized accesses**: Your external key management system can be configured with policies to approve or deny key access requests based on the provided justification codes. This gives you active control to reject accesses that don't align with your security policies.

4. **Regulatory compliance**: This architecture supports data sovereignty and regulatory compliance requirements by keeping sensitive key material entirely outside Google's infrastructure while still allowing encrypted data to be processed in Google Cloud.

The dual-layer encryption approach ensures that data encrypted using a Cloud EKM key cannot be decrypted without both the external key material (in your control) and the internal key material, providing defense in depth.

### Why Other Options Are Wrong

- **A:** Customer Managed Encryption Keys (CMEK) store the key material within Google Cloud's infrastructure (Cloud KMS), not fully under your control. While you manage the key through Cloud KMS, the cryptographic material resides in Google's systems. IAM deny policies control who can access the key but don't provide rationale for each access. This doesn't meet the requirement of holding key material "fully under your control."

- **B:** This option has a critical flaw: it suggests uploading the on-premises key to Cloud KMS, which defeats the purpose of maintaining full control over the key material. Once uploaded to Cloud KMS, the key material resides in Google's infrastructure, not your control. Additionally, the phrase "have the external key system reject unauthorized accesses" doesn't make sense if the key is uploaded to Cloud KMS (there is no external key system in this scenario). KAJ cannot be used effectively without Cloud EKM's external key architecture.

- **C:** CMEK backed by Cloud HSM provides enhanced security with FIPS 140-2 Level 3 validated hardware, but the key material still resides within Google Cloud's HSM infrastructure, not under your exclusive control. Data access logs provide audit trails for data access but don't provide rationale for key access requests, nor do they give you the ability to approve/deny key access based on justification codes. This doesn't meet the "fully under your control" requirement.

### References

- [Cloud External Key Manager Overview](https://docs.cloud.google.com/kms/docs/ekm)
- [Key Access Justifications Overview](https://docs.cloud.google.com/assured-workloads/key-access-justifications/docs/overview)
