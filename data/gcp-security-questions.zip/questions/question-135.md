# Question 135

**Source:** https://www.examtopics.com/discussions/google/view/81552-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** encryption at rest, Cloud KMS, key rotation, default encryption, CMEK

---

## Question

You need to implement an encryption-at-rest strategy that protects sensitive data and reduces key management complexity for non-sensitive data. Your solution has the following requirements: ✑ Schedule key rotation for sensitive data. ✑ Control which region the encryption keys for sensitive data are stored in. ✑ Minimize the latency to access encryption keys for both sensitive and non-sensitive data. What should you do?
## Choices

- **A.** Encrypt non-sensitive data and sensitive data with Cloud External Key Manager.
- **B.** Encrypt non-sensitive data and sensitive data with Cloud Key Management Service.
- **C.** Encrypt non-sensitive data with Google default encryption, and encrypt sensitive data with Cloud External Key Manager.
- **D.** Encrypt non-sensitive data with Google default encryption, and encrypt sensitive data with Cloud Key Management Service. Most Voted

---

## Community

**Most Voted:** D


**Votes:** B: 14% | D: 86% (29 total)


**Top Comments:**

- (12 upvotes) Sorry answer is B

- (6 upvotes) D- the ans refers to both types of data:sensitive and non sensitive

- (6 upvotes) And keep KMS to be complience with sensitive data strategy

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D correctly addresses all requirements by using a tiered encryption approach:

**For non-sensitive data - Google default encryption:**
- All data stored in Google Cloud is encrypted at rest by default using AES-256
- Google automatically manages and rotates encryption keys
- Zero key management complexity for the customer
- Minimal latency since keys are managed internally by Google's infrastructure
- No additional cost

**For sensitive data - Cloud Key Management Service (Cloud KMS):**
- Provides scheduled automatic key rotation capabilities (requirement 1)
- Allows you to specify regional key rings, ensuring encryption keys are stored in specific regions (requirement 2)
- Keys remain within Google Cloud infrastructure, ensuring minimal latency for encrypt/decrypt operations (requirement 3)
- Cloud KMS keys are customer-managed encryption keys (CMEK) that give you control over key lifecycle, rotation schedules, and audit logging
- Regional Cloud KMS keys must be in the same region or global location as the encrypted resources

This approach optimally balances security requirements with operational complexity by only applying CMEK to sensitive data that requires explicit key management, while leveraging default encryption for non-sensitive data.

### Why Other Options Are Wrong

- **A:** Using Cloud External Key Manager (EKM) for both sensitive and non-sensitive data maximizes key management complexity rather than reducing it. EKM also introduces significant latency concerns (150ms timeout requirement for external key system communication), violating the minimize latency requirement.

- **B:** Encrypting all data with Cloud KMS creates unnecessary key management complexity for non-sensitive data. While it meets the technical requirements for sensitive data, it fails the "reduce key management complexity for non-sensitive data" requirement since you must manage keys, rotation policies, and permissions for all data.

- **C:** Cloud EKM violates the latency minimization requirement. EKM stores keys in external key management systems outside Google Cloud, requiring network round-trips to external systems with a 150ms timeout constraint. This introduces significant latency compared to Cloud KMS keys stored within Google Cloud. EKM is designed for "hold-your-own-keys" (HYOK) requirements, which is excessive for this scenario.

### References

- [Cloud Key Management Service encryption](https://docs.cloud.google.com/docs/security/key-management-deep-dive)
- [Key rotation](https://docs.cloud.google.com/kms/docs/key-rotation)
- [Cloud External Key Manager](https://cloud.google.com/kms/docs/ekm)
- [EKM architectures and latency considerations](https://docs.cloud.google.com/kms/docs/ekm-architectures)
