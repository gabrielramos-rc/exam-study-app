# Question 120

**Source:** https://www.examtopics.com/discussions/google/view/74831-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, service perimeter, dry run mode, perimeter testing

---

## Question

You need to enable VPC Service Controls and allow changes to perimeters in existing environments without preventing access to resources. Which VPC Service Controls mode should you use?
## Choices

- **A.** Cloud Run
- **B.** Native
- **C.** Enforced
- **D.** Dry run Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (6 total)


**Top Comments:**

- (10 upvotes) Enforced mode is the default mode for service perimeters. When a service perimeter is enforced, requests that violate the perimeter policy, such as requests to restricted services from outside a perim

- (3 upvotes) D is correct

- (2 upvotes) D. Dry run

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Dry run mode is specifically designed for this exact scenario. According to Google Cloud documentation, dry run mode allows you to "understand the effect of enabling VPC Service Controls and changes to perimeters in existing environments" without blocking access. In dry run mode, requests that violate the perimeter policy are not denied, only logged. This enables you to:

- Test perimeter configuration changes before enforcement
- Monitor usage of services without preventing access to resources
- Determine the impact that changes to existing service perimeters will have
- Identify unexpected service usage patterns in your organization

The key behavior is that violations are logged but not blocked, allowing you to safely enable VPC Service Controls and make perimeter changes while maintaining full access to resources. This is a best practice recommended by Google before switching to enforced mode, as it reduces complexity and prevents service interruptions.

### Why Other Options Are Wrong

- **A. Cloud Run:** This is a Google Cloud serverless compute platform, not a VPC Service Controls mode. It's completely unrelated to service perimeter configuration.

- **B. Native:** This is not a valid VPC Service Controls mode. The only two modes for VPC Service Controls are "dry run" and "enforced."

- **C. Enforced:** This is the opposite of what's needed. Enforced mode actively blocks requests that violate the perimeter policy, which would prevent access to resources. While enforced mode is the ultimate goal for production security, it should only be used after validating the configuration in dry run mode.

### References

- [Dry run mode for service perimeters](https://docs.cloud.google.com/vpc-service-controls/docs/dry-run-mode)
- [Best practices for enabling VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/enable)
