# Question 140

**Source:** https://www.examtopics.com/discussions/google/view/79828-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** object lifecycle, retention policy, Cloud Storage, data protection, compliance

---

## Question

You work for an organization in a regulated industry that has strict data protection requirements. The organization backs up their data in the cloud. To comply with data privacy regulations, this data can only be stored for a specific length of time and must be deleted after this specific period. You want to automate the compliance with this regulation while minimizing storage costs. What should you do?
## Choices

- **A.** Store the data in a persistent disk, and delete the disk at expiration time.
- **B.** Store the data in a Cloud Bigtable table, and set an expiration time on the column families.
- **C.** Store the data in a BigQuery table, and set the table's expiration time.
- **D.** Store the data in a Cloud Storage bucket, and configure the bucket's Object Lifecycle Management feature. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (8 total)


**Top Comments:**

- (9 upvotes) It must be D. Big Query cost is high when compare to storage bucket.

- (4 upvotes) D. Store the data in a Cloud Storage bucket, and configure the bucket's Object Lifecycle Management feature.

- (3 upvotes) Answer D

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Cloud Storage with Object Lifecycle Management is the optimal solution for automated backup data retention compliance and cost minimization. Object Lifecycle Management allows you to define rules that automatically perform actions (such as deletion) on objects when they meet specific conditions, including age-based criteria. This directly addresses the requirement to delete data after a specific period.

Key advantages for this use case:

1. **Automated Compliance**: Lifecycle rules execute automatically when objects reach the specified age (Time-to-Live/TTL), ensuring data is deleted precisely when required without manual intervention. The system continuously evaluates objects against defined conditions.

2. **Cost Optimization**: Cloud Storage is the most cost-effective option for backup data storage. You can:
   - Start with Standard storage for frequently accessed backups
   - Use lifecycle policies to automatically transition objects to Nearline, Coldline, or Archive storage classes before deletion
   - The storage class transitions incur no retrieval fees or early deletion charges
   - Time spent in the original storage class counts toward minimum storage duration requirements for the new class

3. **Purpose-Built for Backups**: Cloud Storage is specifically designed for object storage and backups, offering:
   - High durability (99.999999999% for Standard storage)
   - Scalability without capacity planning
   - Multiple storage classes optimized for different access patterns
   - Built-in versioning and retention controls

4. **Regulatory Features**: Cloud Storage supports additional compliance requirements through:
   - Bucket Lock for enforcing retention policies
   - Object Retention Lock for per-object retention requirements
   - Audit logging for compliance tracking

### Why Other Options Are Wrong

- **A:** Persistent disks are block storage designed for VM instances, not backup storage. Manual deletion is not automated, violates the requirement for automation, and persistent disks are significantly more expensive than Cloud Storage. Additionally, disks must be attached to instances and have size limitations.

- **B:** Cloud Bigtable does support column family expiration (TTL), but Bigtable is a NoSQL database service optimized for high-throughput, low-latency workloads like IoT and time-series data. It's not designed for backup storage and is considerably more expensive than Cloud Storage. The operational complexity and cost make it inappropriate for this use case.

- **C:** While BigQuery does support table expiration for automatic deletion, BigQuery is a data warehouse designed for analytics workloads, not backup storage. It's optimized for querying large datasets, not storing static backup files. The pricing model (storage + query costs) makes it cost-ineffective for backups that don't require analytical processing. Additionally, BigQuery is better suited for structured data, whereas backups often include diverse file types.

### References

- [Object Lifecycle Management](https://docs.cloud.google.com/storage/docs/lifecycle)
- [Options for controlling data lifecycles](https://docs.cloud.google.com/storage/docs/control-data-lifecycles)
- [Manage tables - BigQuery](https://docs.cloud.google.com/bigquery/docs/managing-tables)
