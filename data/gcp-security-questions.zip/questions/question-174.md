# Question 174

**Source:** https://www.examtopics.com/discussions/google/view/80407-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Packet Mirroring, network inspection, deep packet inspection, SOC, Cloud IDS

---

## Question

You manage your organization's Security Operations Center (SOC). You currently monitor and detect network traffic anomalies in your VPCs based on network logs. However, you want to explore your environment using network payloads and headers. Which Google Cloud product should you use?
## Choices

- **A.** Cloud IDS
- **B.** VPC Service Controls logs
- **C.** VPC Flow Logs
- **D.** Google Cloud Armor
- **E.** Packet Mirroring Most Voted

---

## Community

**Most Voted:** E


**Votes:** A: 20% | E: 80% (20 total)


**Top Comments:**

- (10 upvotes) It should be A.. Cloud IDS inspects not only the IP header of the packet, but also the payload. https://cloud.google.com/blog/products/identity-security/how-google-cloud-ids-helps-detect-advanced-netw

- (8 upvotes) Both A and E would work, but in this case I believe Cloud IDS is a better fit as it is monitor and prevent network anomalies.

- (3 upvotes) E Packet Mirroring captures all traffic and packet data, including payloads and headers. The capture can be configured for both egress and ingress traffic, only ingress traffic, or only egress traffic

---

## Answer

**Correct:** E

**Confidence:** high

### Explanation

Packet Mirroring is the correct solution for exploring network payloads and headers. Unlike VPC Flow Logs which only capture metadata about network flows (source/destination IPs, ports, protocols, byte counts), Packet Mirroring captures complete packet data including payloads and headers. This enables deep packet inspection (DPI) required for comprehensive security analysis.

Packet Mirroring clones network traffic based on specified filtering criteria and can be configured to capture egress, ingress, or both directions of traffic. The mirrored traffic is encapsulated using Geneve and forwarded to collector instances (behind an internal load balancer) where security tools can perform detailed analysis. This is essential for Security Operations Centers (SOC) that need to:

- Detect intrusion signatures across multiple packets in a flow
- Perform deep packet inspection to identify protocol anomalies
- Conduct network forensics for compliance requirements (PCI DSS, etc.)
- Catch all anomalies and threats that sampling-based approaches might miss

The documentation explicitly states that Packet Mirroring "captures all traffic and packet data, including payloads and headers," making it the ideal tool when moving from flow log analysis to payload-level inspection.

### Why Other Options Are Wrong

- **A (Cloud IDS):** While Cloud IDS does provide intrusion detection, it actually uses Packet Mirroring under the hood to capture the traffic. You would still need to configure Packet Mirroring as the underlying mechanism. Additionally, Cloud IDS is focused on threat detection rather than general payload exploration for SOC analysis.

- **B (VPC Service Controls logs):** VPC Service Controls provides boundary security for Google Cloud services and generates logs about access attempts to protected resources. It does not capture network payloads or headers - it logs API access control decisions and perimeter violations.

- **C (VPC Flow Logs):** VPC Flow Logs only record metadata about network flows (5-tuple information, byte counts, packet counts) but explicitly do not include payload data or full headers. The question states the SOC is already using network logs for anomaly detection but wants to explore payloads and headers, which Flow Logs cannot provide.

- **D (Google Cloud Armor):** Cloud Armor is a DDoS protection and Web Application Firewall (WAF) service that protects applications behind load balancers. While it inspects traffic for security threats, it's designed for protection rather than exploration and analysis, and does not provide SOC teams with access to captured payloads for forensic analysis.

### References

- [Packet Mirroring Overview](https://docs.cloud.google.com/vpc/docs/packet-mirroring)
- [Out-of-band Integration Overview](https://docs.cloud.google.com/network-security-integration/docs/out-of-band/out-of-band-integration-overview)
