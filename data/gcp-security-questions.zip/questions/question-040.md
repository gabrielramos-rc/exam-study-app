# Question 040

**Source:** https://www.examtopics.com/discussions/google/view/80812-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** PCI DSS, compliance, shared responsibility, Customer Responsibility Matrix

---

## Question

You want to evaluate your organization's Google Cloud instance for PCI compliance. You need to identify Google's inherent controls. Which document should you review to find the information?
## Choices

- **A.** Google Cloud Platform: Customer Responsibility Matrix Most Voted
- **B.** PCI DSS Requirements and Security Assessment Procedures
- **C.** PCI SSC Cloud Computing Guidelines
- **D.** Product documentation for Compute Engine

---

## Community

**Most Voted:** A


**Votes:** A: 77% | B: 8% | C: 15% (13 total)


**Top Comments:**

- (3 upvotes) https://cloud.google.com/architecture/pci-dss-compliance-in-gcp B is correct answer

- (3 upvotes) It is B:: The PCI DSS Requirements and Security Assessment Procedures is the document that outlines the specific requirements for PCI compliance. It is created and maintained by the Payment Card Indus

- (3 upvotes) A. Google Cloud Platform: Customer Responsibility Matrix

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The **Google Cloud Platform: Customer Responsibility Matrix** (also called the PCI DSS Shared Responsibility Matrix) is the correct document to identify Google's inherent controls for PCI compliance. This matrix explicitly delineates which security controls and compliance obligations are managed by Google Cloud versus those that remain the customer's responsibility.

The Customer Responsibility Matrix serves multiple purposes:
- Clearly identifies Google's inherent controls and infrastructure security measures
- Shows which PCI DSS requirements are addressed by Google's infrastructure as a Level 1 service provider
- Helps customers understand inherited security controls (like default encryption and infrastructure controls) that they can provide as evidence to auditors
- Serves as a reference guide when conducting PCI DSS audits

This document is available through Google Cloud's Compliance Reports Manager and is specifically designed to help merchants pursue PCI DSS compliance by outlining the shared responsibility model.

### Why Other Options Are Wrong

- **B:** PCI DSS Requirements and Security Assessment Procedures is the official PCI Security Standards Council document that defines PCI DSS requirements for all organizations. While essential for understanding PCI requirements, it does not identify Google's specific inherent controls or responsibilities. This is a generic industry standard document, not Google-specific.

- **C:** PCI SSC Cloud Computing Guidelines is another PCI Security Standards Council document that provides general guidance on cloud computing for PCI compliance. Like option B, this is industry-wide guidance and does not detail Google Cloud's specific inherent controls or what Google manages on behalf of customers.

- **D:** Product documentation for Compute Engine covers technical specifications and features of a single Google Cloud product. While it may mention some security features, it does not provide a comprehensive view of Google's inherent controls across all services or map them to PCI DSS requirements. The Customer Responsibility Matrix provides this holistic view.

### References

- [PCI Data Security Standard compliance | Cloud Architecture Center](https://docs.cloud.google.com/architecture/pci-dss-compliance-in-gcp)
- [Shared responsibilities and shared fate on Google Cloud](https://docs.cloud.google.com/architecture/framework/security/shared-responsibility-shared-fate)
