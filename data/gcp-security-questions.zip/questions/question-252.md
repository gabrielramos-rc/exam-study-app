# Question 252

**Source:** https://www.examtopics.com/discussions/google/view/147046-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Data Loss Prevention, DLP, Sensitive Data Protection, PII, VPC Service Controls, data exfiltration

---

## Question

Your organization is migrating a sensitive data processing workflow from on-premises infrastructure to Google Cloud. This workflow involves the collection, storage, and analysis of customer information that includes personally identifiable information (PII). You need to design security measures to mitigate the risk of data exfiltration in this new cloud environment. What should you do?
## Choices

- **A.** Encrypt all sensitive data in transit and at rest. Establish secure communication channels by using TLS and HTTPS protocols.
- **B.** Implement a Cloud DLP solution to scan and identify sensitive information, and apply redaction or masking techniques to the PII. Integrate VPC SC with your network security controls to block potential data exfiltration attempts. Most Voted
- **C.** Restrict all outbound network traffic from cloud resources. Implement rigorous access controls and logging for all sensitive data and the systems that process the data.
- **D.** Rely on employee expertise to prevent accidental data exfiltration incidents.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (4 total)


**Top Comments:**

- (1 upvotes) b is just great all aroujnd

- (1 upvotes) I think it's B.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B provides the most comprehensive defense-in-depth approach specifically designed to mitigate data exfiltration risks for PII in Google Cloud. This solution combines two critical Google Cloud security services:

**Sensitive Data Protection (Cloud DLP)** addresses data exfiltration at the data layer by:
- Automatically discovering and classifying PII using 100+ built-in detectors
- Applying de-identification techniques like redaction, masking, and tokenization to remove or obfuscate sensitive data
- Preventing unauthorized access to raw PII by transforming data before it can be exfiltrated
- Creating de-identified copies of data that can be safely used for analytics without exposing actual PII

**VPC Service Controls** addresses data exfiltration at the network layer by:
- Creating security perimeters around Google Cloud resources containing sensitive data
- Preventing data from being copied to unauthorized resources outside the perimeter using service operations
- Blocking access to Google-managed services (Cloud Storage, BigQuery) from untrusted locations
- Providing context-aware access control based on identity, device, and network origin
- Working independently from IAM to provide an additional layer of boundary protection

This layered approach directly targets the question's requirement to "mitigate the risk of data exfiltration" by controlling both what data exists (de-identified PII via DLP) and where it can go (perimeter controls via VPC SC).

### Why Other Options Are Wrong

- **A:** While encryption at rest and in transit is essential for data protection, it does not prevent data exfiltration. Encrypted data can still be exfiltrated by authorized users with proper credentials or through compromised accounts. Encryption protects confidentiality during storage and transmission, but does not control data movement or access boundaries.

- **C:** Completely restricting all outbound network traffic is operationally impractical and overly restrictive. Cloud workloads typically need controlled egress for legitimate purposes (software updates, API calls, external services). This approach lacks the intelligence to distinguish between legitimate and malicious data movement, and would likely break normal business operations.

- **D:** Relying solely on employee expertise is not a technical control and provides no systematic protection against data exfiltration. Human error is a leading cause of data breaches, and this approach offers no defense against compromised credentials, malicious insiders, or accidental misconfigurations. Professional security engineering requires technical controls, not just training.

### References

- [Overview of VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/overview)
- [De-identifying sensitive data | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/deidentify-sensitive-data)
- [De-identification and re-identification of PII using Sensitive Data Protection](https://docs.cloud.google.com/architecture/de-identification-re-identification-pii-using-cloud-dlp)
- [Sensitive Data Protection overview](https://docs.cloud.google.com/sensitive-data-protection/docs/sensitive-data-protection-overview)
