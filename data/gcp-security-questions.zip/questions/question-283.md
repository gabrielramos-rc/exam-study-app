# Question 283

**Source:** https://www.examtopics.com/discussions/google/view/147077-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Security Command Center, Security Health Analytics, misconfigurations, compliance, detection

---

## Question

Your organization's use of the Google Cloud has grown substantially and there are many different groups using different cloud resources independently. You must identify common misconfigurations and compliance violations across the organization and track findings for remedial action in a dashboard. What should you do?
## Choices

- **A.** Create a filter set in Cloud Asset Inventory to identify service accounts with high privileges and IAM principals with Gmail domains.
- **B.** Scan and alert vulnerabilities and misconfigurations by using Secure Health Analytics detectors in Security Command Center Premium. Most Voted
- **C.** Set up filters on Cloud Audit Logs to flag log entries for specific, risky API calls, and display the calls in a Cloud Log Analytics dashboard.
- **D.** Alert and track emerging attacks detected in your environment by using Event Threat Detection detectors.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (4 total)


**Top Comments:**

- (1 upvotes) https://cloud.google.com/security-command-center/docs/concepts-security-health-analytics

- (1 upvotes) I think it's B.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Security Health Analytics in Security Command Center Premium is specifically designed to identify common misconfigurations and compliance violations across an organization. It is a managed service that automatically scans cloud environments for security issues and provides centralized dashboard visibility through the Security Command Center console.

Key capabilities that match the requirements:

- **Automated misconfiguration detection**: Security Health Analytics uses detectors to continuously scan Google Cloud resources (Compute Engine, GKE, Cloud Storage, Cloud SQL, IAM, Cloud KMS, Cloud DNS) for common misconfigurations and vulnerabilities
- **Compliance violation tracking**: The service maps detectors to numerous security frameworks including CIS Benchmarks, ISO 27001, NIST 800-53, PCI DSS, HIPAA, and SOC 2, allowing organizations to monitor compliance violations
- **Organization-wide visibility**: Works across the entire organization, scanning all projects and resources regardless of which teams manage them
- **Centralized dashboard**: Security Command Center provides a unified console to view, filter, and track findings for remedial action
- **Premium tier requirement**: Most Security Health Analytics detectors require the Premium or Enterprise tier, which provides the full detector suite and compliance control mappings

The service automatically generates findings for detected misconfigurations and compliance violations, making it easy to track remediation efforts across the organization.

### Why Other Options Are Wrong

- **A:** Cloud Asset Inventory is excellent for discovering and tracking assets, but it's primarily an asset management tool. While you can create filters to identify specific configurations (like high-privilege service accounts), it doesn't provide automated misconfiguration detection, compliance mapping, or a comprehensive security dashboard for tracking remediation actions across diverse security issues.

- **C:** Cloud Audit Logs with Log Analytics dashboards can flag specific API calls and display them, but this approach requires manual configuration of filters for each risky scenario you want to detect. It doesn't provide automated detection of common misconfigurations or compliance violations, and it lacks the comprehensive, security-focused dashboard designed for tracking remediation efforts across the organization.

- **D:** Event Threat Detection (ETD) is designed to detect emerging attacks and threats based on suspicious activity patterns (like crypto mining, data exfiltration, malware). While valuable for threat detection, it doesn't focus on identifying misconfigurations or compliance violations, which are the specific requirements in this question. ETD complements Security Health Analytics but doesn't replace its misconfiguration detection capabilities.

### References

- [Overview of Security Health Analytics](https://docs.cloud.google.com/security-command-center/docs/concepts-security-health-analytics)
- [Assess compliance without Compliance Manager](https://docs.cloud.google.com/security-command-center/docs/compliance-management)
- [Using Security Health Analytics](https://docs.cloud.google.com/security-command-center/docs/how-to-use-security-health-analytics)
