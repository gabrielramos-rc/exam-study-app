# Question 129

**Source:** https://www.examtopics.com/discussions/google/view/75444-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, domain restricted sharing, IAM, Google Workspace customer ID, external partner access

---

## Question

You are a security administrator at your company. Per Google-recommended best practices, you implemented the domain restricted sharing organization policy to allow only required domains to access your projects. An engineering team is now reporting that users at an external partner outside your organization domain cannot be granted access to the resources in a project. How should you make an exception for your partner's domain while following the stated best practices?
## Choices

- **A.** Turn off the domain restriction sharing organization policy. Set the policy value to "Allow All."
- **B.** Turn off the domain restricted sharing organization policy. Provide the external partners with the required permissions using Google's Identity and Access Management (IAM) service.
- **C.** Turn off the domain restricted sharing organization policy. Add each partner's Google Workspace customer ID to a Google group, add the Google group as an exception under the organization policy, and then turn the policy back on.
- **D.** Turn off the domain restricted sharing organization policy. Set the policy value to "Custom." Add each external partner's Cloud Identity or Google Workspace customer ID as an exception under the organization policy, and then turn the policy back on. Most Voted

---

## Community

**Most Voted:** D


**Votes:** C: 17% | D: 83% (30 total)


**Top Comments:**

- (13 upvotes) Agreed with your explanaiton

- (5 upvotes) I agree Ref: https://cloud.google.com/resource-manager/docs/organization-policy/restricting-domains#setting_the_organization_policy

- (3 upvotes) D. Turn off the domain restricted sharing organization policy. Set the policy value to "Custom." Add each external partner's Cloud Identity or Google Workspace customer ID as an exception under the or

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D follows Google's documented best practice for adding external partner exceptions to the domain restricted sharing organization policy. The correct procedure is to:

1. Disable the domain restricted sharing organization policy temporarily
2. Set the policy enforcement to "Custom" (replacing the default allowed values)
3. Add each external partner's Cloud Identity or Google Workspace customer ID (DIRECTORY_CUSTOMER_ID) directly to the allowed_values list
4. Re-enable the policy

According to Google Cloud documentation, when using the `iam.allowedPolicyMemberDomains` constraint, you specify an organization principal set or Google Workspace customer ID in the allowed values. The policy then allows only identities specified in the list to be granted roles. You can obtain the customer ID using `gcloud organizations list`, which returns the DIRECTORY_CUSTOMER_ID for each organization.

This approach maintains security by continuing to restrict sharing to specific trusted domains while adding controlled exceptions for approved external partners. Each partner organization is explicitly allowed by including their customer ID in the policy's allowed values.

### Why Other Options Are Wrong

- **A:** Setting the policy to "Allow All" completely removes domain restrictions and violates the requirement to follow best practices. This would allow sharing with any domain globally, creating significant security risks and defeating the purpose of the domain restriction policy.

- **B:** Simply turning off the policy and using IAM permissions does not address the root cause. The domain restriction policy is an organization-level constraint that prevents IAM permissions from being granted to principals outside allowed domains. Disabling it entirely without configuring proper exceptions leaves the organization without domain-level boundary controls.

- **C:** While Google Groups can be used for access management, they are not the documented mechanism for adding exceptions to the domain restricted sharing organization policy. The policy works at the principal/domain level by checking customer IDs, not by evaluating Google Group membership. Adding customer IDs to a Google Group does not create valid policy exceptions for this constraint.

### References

- [Domain restricted sharing | Resource Manager Documentation](https://docs.cloud.google.com/resource-manager/docs/organization-policy/domain-restricted-sharing)
- [Restricting identities by domain | Resource Manager Documentation](https://cloud.google.com/resource-manager/docs/organization-policy/restricting-domains)
