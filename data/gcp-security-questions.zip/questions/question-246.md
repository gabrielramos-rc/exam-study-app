# Question 246

**Source:** https://www.examtopics.com/discussions/google/view/146998-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Binary Authorization, vulnerability scanning, Cloud Run, container security, CVSS

---

## Question

Your organization relies heavily on Cloud Run for its containerized applications. You utilize Cloud Build for image creation, Artifact Registry for image storage, and Cloud Run for deployment. You must ensure that containers with vulnerabilities rated above a common vulnerability scoring system (CVSS) score of "medium" are not deployed to production. What should you do?
## Choices

- **A.** Implement vulnerability scanning as part of the Cloud Build process. If any medium or higher vulnerabilities are detected, manually rebuild the image with updated components.
- **B.** Perform manual vulnerability checks post-build, but before Cloud Run deployment. Implement a manual security-engineer-driven remediation process.
- **C.** Configure Binary Authorization on Cloud Run to enforce image signatures. Create policies to allow deployment only for images passing a defined vulnerability threshold. Most Voted
- **D.** Utilize a vulnerability scanner during the Cloud Build stage and set Artifact Registry permissions to block images containing vulnerabilities above "medium."

---

## Community

**Most Voted:** C


**Votes:** C: 100% (6 total)


**Top Comments:**

- (2 upvotes) I think it's C.

- (1 upvotes) The best solution is C. Configure Binary Authorization on Cloud Run to enforce image signatures. Create policies to allow deployment only for images passing a defined vulnerability threshold. Here's w

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Binary Authorization provides deploy-time security controls for Cloud Run that can automatically enforce vulnerability policies based on CVSS scores. By configuring Binary Authorization with vulnerability check policies, you can define thresholds using `maximumFixableSeverity` and `maximumUnfixableSeverity` parameters to prevent deployment of images with vulnerabilities exceeding "medium" severity.

This approach provides:
- **Automated enforcement**: Policies are enforced at deployment time without manual intervention
- **Integration with Artifact Analysis**: Automatically scans images in Artifact Registry for vulnerabilities
- **CVSS-based thresholds**: Configure specific severity levels (e.g., block "high" and "critical", allow "low" and "medium")
- **Continuous protection**: Every Cloud Run deployment is checked against the policy before execution
- **Attestation-based validation**: Combines vulnerability checks with signature validation for comprehensive security

Binary Authorization is the native GCP solution specifically designed for this use case, providing policy-driven enforcement that integrates seamlessly with Cloud Build, Artifact Registry, and Cloud Run.

### Why Other Options Are Wrong

- **A:** Manual rebuilding after detecting vulnerabilities is reactive and error-prone. It doesn't prevent deployment of vulnerable images - it only detects them after the build. There's no automated enforcement mechanism to block deployments, creating a security gap.

- **B:** Manual security-engineer-driven processes don't scale and introduce human error and delays. This approach lacks automation and cannot provide consistent, real-time enforcement. Every deployment would require manual review, making it impractical for production CI/CD pipelines.

- **D:** Artifact Registry permissions control who can push/pull images, not vulnerability-based deployment policies. There is no native Artifact Registry feature to "block images containing vulnerabilities" - it stores images but doesn't enforce deployment policies. This confuses storage permissions with deployment-time security controls.

### References

- [Use the vulnerability check | Binary Authorization](https://docs.cloud.google.com/binary-authorization/docs/cv-vulnerability-check)
- [Use Binary Authorization | Cloud Run](https://docs.cloud.google.com/run/docs/securing/binary-authorization)
- [Container scanning overview | Artifact Analysis](https://docs.cloud.google.com/artifact-analysis/docs/container-scanning-overview)
- [Safeguard deployments | Software Supply Chain Security](https://docs.cloud.google.com/software-supply-chain-security/docs/safeguard-deploys)
