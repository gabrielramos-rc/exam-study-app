# Question 286

**Source:** https://www.examtopics.com/discussions/google/view/147080-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, PII, de-identification, format-preserving encryption, credit card PAN, tokenization

---

## Question

Your application development team is releasing a new critical feature. To complete their final testing, they requested 10 thousand real transaction records. The new feature includes format checking on the primary account number (PAN) of a credit card. You must support the request and minimize the risk of unintended personally identifiable information (PII) exposure. What should you do?
## Choices

- **A.** Run the new application by using Confidential Computing to ensure PII and card PAN is encrypted in use.
- **B.** Scan and redact PII from the records by using the Cloud Data Loss Prevention API. Perform format-preserving encryption on the card PAN. Most Voted
- **C.** Encrypt the records by using Cloud Key Management Service to protect the PII and card PAN.
- **D.** Build a tool to replace the card PAN and PII fields with randomly generated values.

---

## Community

**Most Voted:** B


**Votes:** A: 25% | B: 75% (8 total)


**Top Comments:**

- (4 upvotes) A is correct. Redacting PII beats the purposed of using real transaction records

- (2 upvotes) B can preserving the format for testing purposes while ensuring that the actual data remains protected. But, A doesn't address the issue of storing or sharing PII securely for testing.

- (1 upvotes) https://cloud.google.com/architecture/de-identification-re-identification-pii-using-cloud-dlp https://cloud.google.com/blog/products/identity-security/taking-charge-of-your-data-using-cloud-dlp-to-de-

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B is the correct approach because it addresses both requirements optimally:

1. **Protects PII**: Cloud Data Loss Prevention API (now Sensitive Data Protection) can automatically scan and detect various types of PII in the transaction records and redact them, minimizing exposure risk.

2. **Enables Format Testing**: Format-preserving encryption (FPE) on the credit card PAN is crucial here. FPE using the FPE-FFX algorithm encrypts the PAN while maintaining the same length and character set (numeric). This means:
   - The encrypted PAN remains a valid-looking credit card number (same length, all digits)
   - The application's format checking functionality can still be tested
   - The actual PAN is protected and unreadable
   - The transformation is reversible if needed with the proper cryptographic key

3. **Best Practice for Testing**: Sensitive Data Protection has built-in support for detecting 12-19 digit PAN data and offers de-identification techniques specifically designed for testing scenarios where data utility must be preserved.

This combination provides the ideal balance: PII is removed/protected while the PAN structure is preserved for format validation testing.

### Why Other Options Are Wrong

- **A:** Confidential Computing encrypts data in memory during processing, which protects against memory attacks but doesn't help with the fundamental problem - the development team would still have access to real PII and PAN values in plaintext during testing. This doesn't minimize PII exposure to the testing team.

- **C:** Using Cloud KMS to encrypt the entire records would make them unusable for testing. The encrypted data would be in ciphertext form, and the application couldn't perform format checking on encrypted values. This defeats the purpose of providing test data.

- **D:** Random replacement might work for some fields, but it's not optimal because:
  - Building a custom tool introduces unnecessary complexity and potential security gaps
  - Random values don't guarantee referential integrity (same original value should map to same token)
  - Lacks the robust detection capabilities of Sensitive Data Protection
  - Not reversible if original data needs to be recovered
  - Google provides a purpose-built, well-tested service for exactly this use case

### References

- [Pseudonymization | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/pseudonymization)
- [De-identification and re-identification of PII in large-scale datasets](https://docs.cloud.google.com/architecture/de-identification-re-identification-pii-using-cloud-dlp)
- [Format-preserving encryption (FPE) | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/samples/dlp-deidentify-fpe)
