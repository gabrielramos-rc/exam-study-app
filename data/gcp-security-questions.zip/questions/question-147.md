# Question 147

**Source:** https://www.examtopics.com/discussions/google/view/80443-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Managing authentication
**Tags:** 2-step verification, MFA, backup codes, user account recovery, Google Admin console

---

## Question

You are responsible for managing your company's identities in Google Cloud. Your company enforces 2-Step Verification (2SV) for all users. You need to reset a user's access, but the user lost their second factor for 2SV. You want to minimize risk. What should you do?
## Choices

- **A.** On the Google Admin console, select the appropriate user account, and generate a backup code to allow the user to sign in. Ask the user to update their second factor. Most Voted
- **B.** On the Google Admin console, temporarily disable the 2SV requirements for all users. Ask the user to log in and add their new second factor to their account. Re-enable the 2SV requirement for all users.
- **C.** On the Google Admin console, select the appropriate user account, and temporarily disable 2SV for this account. Ask the user to update their second factor, and then re-enable 2SV for this account.
- **D.** On the Google Admin console, use a super administrator account to reset the user account's credentials. Ask the user to update their credentials after their first login.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (15 total)


**Top Comments:**

- (6 upvotes) .Agreed, On the Google Admin console, select the appropriate user account, and generate a backup code to allow the user to sign in. Ask the user to update their second factor.

- (4 upvotes) A. https://support.google.com/a/answer/9176734?hl=en

- (3 upvotes) Account Remains Protected by 2SV: Backup codes act as a temporary second factor, ensuring the account stays protected by 2SV even during the recovery process.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is the correct and recommended approach according to Google Workspace best practices. When a user loses their second factor for 2-Step Verification, administrators should generate backup verification codes to restore access while maintaining security:

**Process:**
1. Navigate to Admin console > Directory > Users
2. Select the specific user account
3. Click Security > 2-step verification
4. Click "Get Backup Verification Codes"
5. Securely send one backup code to the user (via IM or text)
6. User can sign in using their password and the backup code
7. Once signed in, user should immediately add a new second factor

This approach minimizes risk by:
- Maintaining 2SV enforcement throughout the process
- Only affecting the specific user who needs help
- Providing temporary, limited-use backup codes (not permanent access)
- Requiring the user to still have their password
- Allowing the user to immediately re-establish proper 2FA after login

Google documentation explicitly states: "You have the option of turning off 2SV for a locked-out user, but this isn't recommended. Instead, get a backup code for the user to allow them to sign in to their account."

### Why Other Options Are Wrong

- **B:** Temporarily disabling 2SV for ALL users creates massive security risk across the entire organization. This exposes every user account to potential compromise during the window when 2SV is disabled. This is completely unnecessary when the issue affects only one user and violates the principle of least privilege and minimizing attack surface.

- **C:** While this affects only the individual user (better than B), Google explicitly recommends against disabling 2SV even for individual users. This option is available but not recommended because it creates an unnecessary security window. If 2SV is enforced organization-wide, this option may be disabled entirely by policy. Backup codes provide the same recovery capability without compromising security.

- **D:** Resetting the user's credentials (password) does not solve the 2SV problem. The user would still need their second factor to complete authentication. This approach doesn't address the actual issue (lost second factor) and creates additional overhead by forcing an unnecessary password reset. The user already knows their password - they just need help with the second factor.

### References

- [Recover an account protected by 2-Step Verification - Google Workspace Admin Help](https://support.google.com/a/answer/9176734?hl=en)
- [Manage a user's security settings - Google Workspace Admin Help](https://support.google.com/a/answer/2537800?hl=en)
- [Deploy 2-Step Verification - Google Workspace Admin Help](https://support.google.com/a/answer/9176657?hl=en)
