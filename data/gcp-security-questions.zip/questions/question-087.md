# Question 087

**Source:** https://www.examtopics.com/discussions/google/view/34060-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC firewall rules, network segmentation, service accounts, network tags, ingress rules

---

## Question

You have an application where the frontend is deployed on a managed instance group in subnet A and the data layer is stored on a mysql Compute Engine virtual machine (VM) in subnet B on the same VPC. Subnet A and Subnet B hold several other Compute Engine VMs. You only want to allow the application frontend to access the data in the application's mysql instance on port 3306. What should you do?
## Choices

- **A.** Configure an ingress firewall rule that allows communication from the src IP range of subnet A to the tag "data-tag" that is applied to the mysql Compute Engine VM on port 3306.
- **B.** Configure an ingress firewall rule that allows communication from the frontend's unique service account to the unique service account of the mysql Compute Engine VM on port 3306. Most Voted
- **C.** Configure a network tag "fe-tag" to be applied to all instances in subnet A and a network tag "data-tag" to be applied to all instances in subnet B. Then configure an egress firewall rule that allows communication from Compute Engine VMs tagged with data-tag to destination Compute Engine VMs tagged fe- tag.
- **D.** Configure a network tag "fe-tag" to be applied to all instances in subnet A and a network tag "data-tag" to be applied to all instances in subnet B. Then configure an ingress firewall rule that allows communication from Compute Engine VMs tagged with fe-tag to destination Compute Engine VMs tagged with data-tag.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (10 total)


**Top Comments:**

- (11 upvotes) Agree with B

- (4 upvotes) why is it not a? a seems straight forward The link which Zuy01 provided for answer b states: For this reason, using a service account is the recommended method for production instances NOT running on 

- (4 upvotes) I agree (A), it is planned to limit a MySQL server in Compute Engine (IaaS) not in Cloud SQL (PaaS), so Networks Tags is the most common and recommended to use. Don't get confused with the services...

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B is the correct answer because it uses service accounts to provide the most granular and secure control for this specific use case. Using service accounts in firewall rules offers several advantages:

**Service Account-Based Firewall Rules:**
- Each VM can have a unique service account, providing instance-level granularity
- The ingress rule specifies both the source service account (frontend VMs) and target service account (MySQL VM)
- This ensures ONLY the frontend instances with the specific service account can access the MySQL instance on port 3306
- Service accounts are controlled via IAM roles and require stopping/restarting instances to change, providing more robust security than network tags
- Service accounts cannot be arbitrarily modified by any IAM principal with edit permissions

**Why This Approach is Optimal:**
- The question emphasizes that both subnets contain "several other Compute Engine VMs"
- The requirement is to allow ONLY the frontend application to access the MySQL instance
- Service accounts provide the most precise identification of which VMs should communicate
- An ingress rule is correct because we're controlling traffic TO the MySQL VM

### Why Other Options Are Wrong

- **A:** Using the source IP range of subnet A would allow ALL VMs in subnet A to access the MySQL instance, not just the frontend VMs. This violates the requirement to allow only the frontend application to access the database. Additionally, mixing IP ranges with network tags is less secure than service account-based rules.

- **C:** This uses an egress rule instead of an ingress rule. Egress rules control traffic leaving the source VM, but for database access control, you need an ingress rule on the MySQL VM to control what can connect TO it. Additionally, the rule direction is backwards (from data-tag to fe-tag), which would allow MySQL to initiate connections to frontend VMs, not the other way around. Also, applying tags to ALL instances in both subnets defeats the purpose of granular control.

- **D:** While this option correctly uses an ingress rule and has the tag direction correct (from fe-tag to data-tag), it applies tags to ALL instances in subnet A and ALL instances in subnet B. This means all VMs in subnet A would be able to access all VMs in subnet B, not just the frontend accessing the MySQL instance. This doesn't meet the requirement for granular control. Option B with service accounts is more secure and precise.

### References

- [VPC firewall rules](https://docs.cloud.google.com/firewall/docs/firewalls)
- [Use VPC firewall rules](https://docs.cloud.google.com/firewall/docs/using-firewalls)
