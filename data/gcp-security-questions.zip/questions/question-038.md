# Question 038

**Source:** https://www.examtopics.com/discussions/google/view/32120-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** CSEK, customer-supplied encryption keys, Cloud Storage, encryption, gsutil

---

## Question

A customer's internal security team must manage its own encryption keys for encrypting data on Cloud Storage and decides to use customer-supplied encryption keys (CSEK). How should the team complete this task?
## Choices

- **A.** Upload the encryption key to a Cloud Storage bucket, and then upload the object to the same bucket.
- **B.** Use the gsutil command line tool to upload the object to Cloud Storage, and specify the location of the encryption key. Most Voted
- **C.** Generate an encryption key in the Google Cloud Platform Console, and upload an object to Cloud Storage using the specified key.
- **D.** Encrypt the object, then use the gsutil command line tool or the Google Cloud Platform Console to upload the object to Cloud Storage.

---

## Community

**Most Voted:** B


**Votes:** B: 67% | D: 33% (15 total)


**Top Comments:**

- (15 upvotes) The fact is, both B &amp; D would work. I lean towards B because it allows you to manage the file using GCP tools later as long as you keep that key around. B is definitely incomplete though, as the b

- (7 upvotes) it mentions u cant use console for CSEK

- (2 upvotes) I have encrypt the object using 256 Encryption method, When I create a Bucket it gave me option of encryption as Google Managed Keys and Customer Managed keys but NO CSEK, I opted Google Managed as I 

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

When using customer-supplied encryption keys (CSEK) with Cloud Storage, you must use the **gsutil** command-line tool (or gcloud storage CLI) and provide the encryption key during the upload operation. The correct workflow is:

1. Generate a Base64-encoded AES-256 encryption key (managed by you, not Google)
2. Use gsutil with the encryption key parameter to upload the object
3. Google Cloud Storage encrypts the object using your supplied key during the upload process

The gsutil command uses flags like `--encryption-key` to specify your Base64-encoded AES-256 key. When you provide the key, Cloud Storage uses it to encrypt the object's data, CRC32C checksum, and MD5 hash. The key itself is never stored by Google - you must provide it for all subsequent read/write operations on that object.

Example command:
```bash
gcloud storage cp SOURCE_DATA gs://BUCKET_NAME/OBJECT_NAME --encryption-key=YOUR_ENCRYPTION_KEY
```

Or with gsutil:
```bash
gsutil -o "GSUtil:encryption_key=YOUR_BASE64_KEY" cp file.txt gs://bucket/
```

### Why Other Options Are Wrong

- **A:** **INCORRECT** - You should never upload encryption keys to Cloud Storage buckets. This defeats the entire purpose of customer-supplied keys and creates a major security vulnerability. The encryption key must be kept secure on your systems and provided during each operation, not stored in the cloud.

- **C:** **INCORRECT** - The Google Cloud Console cannot be used to upload objects with customer-supplied encryption keys (CSEK). The documentation explicitly states this limitation. Additionally, you cannot generate a CSEK in the console - you must generate and manage your own encryption keys outside of Google Cloud. If you wanted Google to generate and manage keys, you would use CMEK (Customer-Managed Encryption Keys) with Cloud KMS instead.

- **D:** **INCORRECT** - You do not pre-encrypt the object before uploading. With CSEK, you upload the unencrypted object and provide the encryption key to Cloud Storage, which handles the encryption process. Pre-encrypting the object would result in double encryption and prevent Cloud Storage from properly managing the encrypted data. Also, as mentioned, the Console cannot be used for CSEK uploads.

### References

- [Customer-supplied encryption keys | Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption/customer-supplied-keys)
- [Use customer-supplied encryption keys | Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption/using-customer-supplied-keys)
- [Data encryption options | Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption)
