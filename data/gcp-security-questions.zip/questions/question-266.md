# Question 266

**Source:** https://www.examtopics.com/discussions/google/view/147060-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** IAM, custom roles, least privilege, separation of duties, multi-project

---

## Question

Your organization is migrating a complex application to Google Cloud. The application has multiple internal components that interact with each other across several Google Cloud projects. Security is a major concern, and you must design an authorization scheme for administrators that aligns with the principles of least privilege and separation of duties. What should you do?
## Choices

- **A.** Identify the users who will migrate the application, revoke the default user roles and assign the users with purposely created custom roles. Most Voted
- **B.** Use multiple external identity providers (IdP) configured to use different SAML profiles and federate the IdPs for each application component.
- **C.** Configure multi-factor authentication (MFA) to enforce the use of physical tokens for all users who will migrate the application.
- **D.** No action needed. When a Google Cloud organization is created, the appropriate permissions are automatically assigned to all users in the domain.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (4 total)


**Top Comments:**

- (1 upvotes) a

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A correctly implements both least privilege and separation of duties principles for a complex multi-project application migration. Google Cloud IAM best practices explicitly recommend:

1. **Avoiding Default/Basic Roles**: The documentation states "Basic roles include thousands of permissions across all Google Cloud services. In production environments, do not grant basic roles unless there is no alternative." Default roles (Owner, Editor, Viewer) provide overly broad permissions that violate least privilege.

2. **Creating Custom Roles**: Custom roles enable enforcement of the principle of least privilege by granting only the minimum permissions required for specific migration tasks. The documentation emphasizes: "Custom roles help you enforce the principle of least privilege, because they help to ensure that the principals in your organization have only the permissions that they need."

3. **Separation of Duties**: By identifying specific users and assigning them purposely created custom roles, you can ensure no single administrator has all permissions needed to complete critical functions across the entire migration. This implements separation of duties effectively.

4. **Multi-Project Scenarios**: For complex applications spanning multiple projects, granting targeted permissions through custom roles allows fine-grained control over what each administrator can access in each project, maintaining security boundaries.

The approach in Option A directly addresses the requirement to "align with the principles of least privilege and separation of duties" by removing overly permissive default roles and replacing them with custom roles designed for specific migration responsibilities.

### Why Other Options Are Wrong

- **B:** Using multiple external identity providers with different SAML profiles is unnecessarily complex and doesn't directly address authorization (what users can do). This addresses authentication (who users are), not authorization. Separation of duties is about role segregation, not IdP segregation per component.

- **C:** Multi-factor authentication is an authentication security control that strengthens identity verification, but it doesn't implement least privilege or separation of duties. MFA prevents unauthorized access but doesn't control what authorized users can do once authenticated.

- **D:** This is completely incorrect. Google Cloud does NOT automatically assign appropriate permissions to all users in a domain when an organization is created. This would violate the principle of least privilege by giving everyone access. Administrators must explicitly configure IAM permissions following security best practices.

### References

- [Use IAM securely | Identity and Access Management (IAM)](https://docs.cloud.google.com/iam/docs/using-iam-securely)
- [Roles and permissions | Identity and Access Management (IAM)](https://docs.cloud.google.com/iam/docs/roles-overview)
- [Best practices for Privileged Access Manager](https://docs.cloud.google.com/iam/docs/pam-best-practices)
