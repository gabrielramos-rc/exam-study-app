# Question 194

**Source:** https://www.examtopics.com/discussions/google/view/117171-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, unmanaged accounts, transfer tool, identity synchronization, GCDS, reconciliation

---

## Question

You plan to synchronize identities to Cloud Identity from a third-party identity provider (IdP). You discovered that some employees used their corporate email address to set up consumer accounts to access Google services. You need to ensure that the organization has control over the configuration, security, and lifecycle of these consumer accounts. What should you do? (Choose two.)
## Choices

- **A.** Mandate that those corporate employees delete their unmanaged consumer accounts.
- **B.** Reconcile accounts that exist in Cloud Identity but not in the third-party IdP. Most Voted
- **C.** Evict the unmanaged consumer accounts in the third-party IdP before you sync identities.
- **D.** Use Google Cloud Directory Sync (GCDS) to migrate the unmanaged consumer accounts' emails as user aliases.
- **E.** Use the transfer tool to invite those corporate employees to transfer their unmanaged consumer accounts to the corporate domain.

---

## Community

**Most Voted:** B


**Votes:** B: 73% | E: 27% (15 total)


**Top Comments:**

- (4 upvotes) BE look like the correct answers

- (4 upvotes) E. https://support.google.com/a/answer/6178640?hl=en

- (3 upvotes) B &amp; E, To ensure control over the configuration, security, and lifecycle of consumer accounts created with corporate email addresses, you should reconcile accounts that exist in Cloud Identity but

---

## Answer

**Correct:** B, E

**Confidence:** high

### Explanation

When synchronizing identities from a third-party IdP to Cloud Identity, organizations must handle two distinct account management challenges:

**Option E - Transfer Tool for Unmanaged Consumer Accounts**: This is the primary Google-recommended method for managing unmanaged consumer accounts. When employees use corporate email addresses to create consumer accounts, the transfer tool for unmanaged users allows administrators to:
- Discover these accounts automatically (within 12 hours of domain verification)
- Send transfer requests to affected users
- Obtain user consent to convert consumer accounts to managed accounts
- Transfer all associated data to the organization's control

The migration requires user consent and preserves user data while bringing accounts under organizational security policies and lifecycle management. Google recommends processing transfers in batches, starting with approximately 10 users.

**Option B - Reconcile Accounts in Cloud Identity**: After synchronization begins, it's critical to reconcile accounts that exist in Cloud Identity but lack a matching identity in the third-party IdP. These orphaned managed accounts represent a security risk because they:
- Can become subject to inadvertent reuse and name squatting
- May represent former employees whose IdP records were deleted
- Could result from mismatches between Cloud Identity and the IdP

Reconciliation ensures identity consistency across systems and prevents security gaps in your identity management infrastructure.

### Why Other Options Are Wrong

- **A:** Mandating deletion of consumer accounts would result in data loss for users and is unnecessarily disruptive. The transfer tool preserves user data while achieving organizational control, making deletion an inferior approach compared to the supported migration path.

- **C:** Evicting unmanaged consumer accounts in the third-party IdP is incorrect on multiple levels. Unmanaged consumer accounts exist in Google's systems, not in the third-party IdP. Additionally, eviction would cause data loss rather than the desired migration to organizational control.

- **D:** GCDS (Google Cloud Directory Sync) does not have functionality to migrate unmanaged consumer accounts' emails as user aliases. GCDS synchronizes identities from an LDAP directory to Cloud Identity but doesn't handle the conversion of existing consumer accounts. The transfer tool is the proper mechanism for this specific use case.

### References

- [Migrate consumer accounts | Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/migrating-consumer-accounts)
- [Assess existing user accounts | Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/assessing-existing-user-accounts)
