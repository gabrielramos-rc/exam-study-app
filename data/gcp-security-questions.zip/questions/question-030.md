# Question 030

**Source:** https://www.examtopics.com/discussions/google/view/16998-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Security Command Center, Cloud Asset Inventory, asset monitoring, organization-level visibility

---

## Question

A company migrated their entire data/center to Google Cloud Platform. It is running thousands of instances across multiple projects managed by different departments. You want to have a historical record of what was running in Google Cloud Platform at any point in time. What should you do?
## Choices

- **A.** Use Resource Manager on the organization level.
- **B.** Use Forseti Security to automate inventory snapshots.
- **C.** Use Stackdriver to create a dashboard across all projects.
- **D.** Use Security Command Center to view all assets across the organization. Most Voted

---

## Community

**Most Voted:** D


**Votes:** A: 12% | B: 35% | D: 53% (17 total)


**Top Comments:**

- (13 upvotes) Forseti is outdated,no one uses it anymore

- (11 upvotes) Forseti Security Capabilities: Automated inventory collection across the entire organization Historical snapshots of all resources at scheduled intervals Cross-project visibility spanning multiple dep

- (6 upvotes) Outdated questions- you should use asset inventory now.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Security Command Center (SCC) is the correct solution for maintaining a historical record of assets running across an organization with thousands of instances in multiple projects. When activated at the organization level, SCC provides comprehensive visibility into all assets across the entire organization hierarchy.

The key technical reasons why SCC is the best choice:

1. **Leverages Cloud Asset Inventory**: SCC's asset list is provided by Cloud Asset Inventory, which maintains a 35-day historical record of create, update, and delete operations for all assets. The documentation states: "The list of assets is provided by Cloud Asset Inventory. In most cases, Cloud Asset Inventory updates the list within minutes after assets are created, modified, or removed in your Google Cloud environment."

2. **Organization-level visibility**: SCC can be activated at the organization level to view assets for the entire organization, with the ability to filter by specific projects, resource types, and locations. This directly addresses the requirement to track thousands of instances across multiple departments and projects.

3. **Change history tracking**: SCC provides a change history feature that allows you to compare snapshots of asset metadata between different points in time, enabling you to see exactly what was running at any historical point within the 35-day window.

4. **Centralized management**: Unlike managing individual projects, SCC provides a unified view across all projects without requiring separate configuration for each project or department.

### Why Other Options Are Wrong

- **A. Use Resource Manager on the organization level**: Resource Manager is designed for managing the organizational hierarchy (organizations, folders, projects) and their IAM policies, not for tracking asset inventory or historical resource states. It doesn't provide asset discovery or historical tracking capabilities.

- **B. Use Forseti Security to automate inventory snapshots**: Forseti Security is an open-source security toolkit that was previously popular but is now deprecated. Google recommends migrating to Security Command Center's built-in capabilities. Additionally, Forseti requires custom implementation and maintenance, whereas SCC is a native, fully-managed service.

- **C. Use Stackdriver to create a dashboard across all projects**: While Cloud Monitoring (formerly Stackdriver) can create dashboards showing metrics across projects, it's designed for operational monitoring and metrics visualization, not for asset inventory or historical resource tracking. It doesn't maintain a record of what resources existed at specific points in time.

### References

- [Cloud Asset Inventory Overview](https://docs.cloud.google.com/asset-inventory/docs/asset-inventory-overview)
- [Get Asset Histories - Cloud Asset Inventory](https://docs.cloud.google.com/asset-inventory/docs/get-asset-history)
- [Inspect Assets in Security Command Center](https://docs.cloud.google.com/security-command-center/docs/work-with-resources-in-the-console)
