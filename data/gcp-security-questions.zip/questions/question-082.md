# Question 082

**Source:** https://www.examtopics.com/discussions/google/view/30372-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Private Google Access, VPC, Cloud Storage, private connectivity

---

## Question

A customer wants to run a batch processing system on VMs and store the output files in a Cloud Storage bucket. The networking and security teams have decided that no VMs may reach the public internet. How should this be accomplished?
## Choices

- **A.** Create a firewall rule to block internet traffic from the VM.
- **B.** Provision a NAT Gateway to access the Cloud Storage API endpoint.
- **C.** Enable Private Google Access. Most Voted
- **D.** Mount a Cloud Storage bucket as a local filesystem on every VM.

---

## Community

**Most Voted:** C


**Votes:** A: 18% | B: 14% | C: 68% (22 total)


**Top Comments:**

- (15 upvotes) Private google access is enabled at subnet level not at VPC level.

- (7 upvotes) What if the VM is on-premise? The question never said it was in GCP? Would the answer not be 'B'?

- (3 upvotes) This has no effect and is meaningless if the VM has an external IP... You need to read the document: 'Private Google Access has no effect on instances that have external IP addresses. Instances with e

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Private Google Access is the correct solution for allowing VMs without external IP addresses to access Google APIs and services, including Cloud Storage. When enabled on a subnet, Private Google Access allows instances with only internal IP addresses to reach the external IP addresses of Google APIs and services while keeping all traffic within Google's network.

Key technical details:
- **Subnet-level configuration**: Private Google Access is enabled on a per-subnet basis in your VPC network
- **Internal IP only**: Only affects VMs that have internal IP addresses without external IPs
- **Routing**: Uses the default route (0.0.0.0/0) with next hop to the default internet gateway, but traffic remains within Google's network
- **No internet exposure**: VMs remain isolated from the public internet while accessing Cloud Storage APIs

This directly addresses the requirement: VMs can store output files in Cloud Storage buckets without any public internet connectivity.

### Why Other Options Are Wrong

- **A:** Creating a firewall rule to block internet traffic would prevent access to Cloud Storage APIs, as the VMs would have no way to communicate with Google services. Firewall rules alone don't provide a mechanism for private access to Google APIs.

- **B:** NAT Gateway (Cloud NAT) is used to provide outbound internet access for VMs without external IPs. However, this contradicts the security requirement that "no VMs may reach the public internet." NAT Gateway enables internet access, which is explicitly forbidden by the security policy.

- **D:** Cloud Storage cannot be mounted as a local filesystem natively on VMs. While third-party tools like Cloud Storage FUSE exist, this approach is more complex, has performance limitations, and is not the standard or recommended solution for VMs to access Cloud Storage. Additionally, it doesn't address the networking/security constraint properly.

### References

- [Private Google Access | Virtual Private Cloud | Google Cloud](https://docs.cloud.google.com/vpc/docs/private-google-access)
- [Private access options for services | Virtual Private Cloud | Google Cloud](https://cloud.google.com/vpc/docs/private-access-options)
- [Configure Private Google Access | Virtual Private Cloud | Google Cloud Documentation](https://docs.cloud.google.com/vpc/docs/configure-private-google-access)
