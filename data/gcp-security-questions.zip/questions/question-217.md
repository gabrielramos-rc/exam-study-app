# Question 217

**Source:** https://www.examtopics.com/discussions/google/view/117341-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Cloud Interconnect, HA VPN, hybrid connectivity, routing, default route

---

## Question

You are routing all your internet facing traffic from Google Cloud through your on-premises internet connection. You want to accomplish this goal securely and with the highest bandwidth possible. What should you do?
## Choices

- **A.** Create an HA VPN connection to Google Cloud. Replace the default 0.0.0.0/0 route.
- **B.** Create a routing VM in Compute Engine. Configure the default route with the VM as the next hop.
- **C.** Configure Cloud Interconnect with HA VPN. Replace the default 0.0.0.0/0 route to an on-premises destination.
- **D.** Configure Cloud Interconnect and route traffic through an on-premises firewall. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (6 total)


**Top Comments:**

- (4 upvotes) "Each HA VPN tunnel can support up to 3 gigabits per second (Gbps) for the sum of ingress and egress traffic. This is a limitation of HA VPN." https://cloud.google.com/network-connectivity/docs/vpn/qu

- (3 upvotes) Might be C, there is also "security" requirments: https://cloud.google.com/network-connectivity/docs/interconnect/concepts/ha-vpn-interconnect

- (2 upvotes) Option A (Creating an HA VPN connection) is suitable for setting up a VPN connection but may not provide the same high bandwidth as Cloud Interconnect. Additionally, replacing the default 0.0.0.0/0 ro

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Cloud Interconnect provides the highest bandwidth option for routing internet traffic from Google Cloud through on-premises infrastructure. Dedicated Interconnect supports 10-Gbps or 100-Gbps connections with a maximum total capacity of 200 Gbps (2 × 100-Gbps), while Partner Interconnect supports VLAN attachments from 50 Mbps to 50 Gbps. This is significantly higher than VPN connections.

You can replace the default 0.0.0.0/0 route in your VPC network to route internet-bound traffic through Cloud Interconnect to your on-premises firewall. The documentation confirms that "the system-generated default route can be removed or replaced" and you can create custom static routes or use dynamic routes (via BGP) to redirect traffic through VLAN attachments as the next hop.

By routing traffic through Cloud Interconnect to an on-premises firewall, you achieve:
- **Security**: Traffic flows through your corporate security controls and policies
- **Highest bandwidth**: Cloud Interconnect offers significantly higher throughput than VPN
- **Private connectivity**: Traffic doesn't traverse the public internet until it reaches your on-premises infrastructure

### Why Other Options Are Wrong

- **A:** HA VPN alone provides secure connectivity but has lower bandwidth compared to Cloud Interconnect. VPN tunnels typically support up to 3 Gbps per tunnel, which is far less than the 10-200 Gbps available with Cloud Interconnect. This doesn't meet the "highest bandwidth possible" requirement.

- **B:** Using a routing VM as a next hop introduces a single point of failure, doesn't provide the highest bandwidth, and adds unnecessary complexity and latency. The VM's network throughput would be limited by its instance type and would not match Cloud Interconnect's dedicated high-speed connections.

- **C:** This option unnecessarily combines Cloud Interconnect with HA VPN. While you can layer HA VPN over Cloud Interconnect for additional encryption if needed, this is not required to achieve the goal and adds complexity. Cloud Interconnect alone provides secure private connectivity without requiring VPN encryption, and adding VPN would reduce the effective bandwidth.

### References

- [Cloud Interconnect overview](https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/overview)
- [VPC Routes](https://docs.cloud.google.com/vpc/docs/routes)
