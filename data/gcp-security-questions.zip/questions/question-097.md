# Question 097

**Source:** https://www.examtopics.com/discussions/google/view/75709-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Managing authentication
**Tags:** SAML federation, Active Directory, password policy, 2-Step Verification, security keys, post-SSO verification

---

## Question

Your organization has implemented synchronization and SAML federation between Cloud Identity and Microsoft Active Directory. You want to reduce the risk of Google Cloud user accounts being compromised. What should you do?
## Choices

- **A.** Create a Cloud Identity password policy with strong password settings, and configure 2-Step Verification with security keys in the Google Admin console.
- **B.** Create a Cloud Identity password policy with strong password settings, and configure 2-Step Verification with verification codes via text or phone call in the Google Admin console.
- **C.** Create an Active Directory domain password policy with strong password settings, and configure post-SSO (single sign-on) 2-Step Verification with security keys in the Google Admin console. Most Voted
- **D.** Create an Active Directory domain password policy with strong password settings, and configure post-SSO (single sign-on) 2-Step Verification with verification codes via text or phone call in the Google Admin console.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (9 total)


**Top Comments:**

- (6 upvotes) user account doesnt need admin console access

- (4 upvotes) C：correct answer

- (4 upvotes) Answer = B

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

When using SAML federation between Cloud Identity and Active Directory, **Active Directory is the authoritative source for user credentials and password policies**. Google's best practices state that you should "designate your external IdP as the source of truth" and exclusively use it to manage users.

With SAML federation, passwords are **never synchronized to Cloud Identity**—authentication happens entirely at the Active Directory level. Therefore, password policies must be configured in Active Directory, not Cloud Identity.

For 2-Step Verification, Google strongly recommends **post-SSO 2-Step Verification with security keys** (phishing-resistant mechanisms like Titan Security Keys) because:

1. **Security keys are phishing-resistant**: Unlike SMS/phone verification codes (vulnerable to phishing, SIM swapping, and interception), physical security keys provide the strongest protection
2. **Post-SSO verification adds defense-in-depth**: Even if Active Directory enforces MFA, configuring post-SSO verification in Google Admin console provides an additional security layer
3. **Super admin protection**: Since super admins can bypass SSO, post-SSO 2-Step Verification ensures they're still protected when they authenticate directly to Cloud Identity
4. **IdP compromise protection**: If the external IdP becomes compromised, post-SSO verification provides a secondary verification layer

Option C correctly combines Active Directory password policy management with the most secure 2-Step Verification approach.

### Why Other Options Are Wrong

- **A:** Incorrect because password policies cannot be enforced in Cloud Identity when using SAML federation—passwords aren't synchronized to Cloud Identity, so Cloud Identity password policies wouldn't apply to federated users.
- **B:** Wrong for two reasons: (1) password policies should be in Active Directory, not Cloud Identity, and (2) verification codes via text/phone are less secure than security keys and vulnerable to phishing attacks.
- **D:** While Active Directory password policy is correct, SMS/phone-based verification codes are significantly less secure than security keys. Google specifically recommends "phishing-resistant mechanisms such as a Titan Security Key" for MFA.

### References

- [Best practices for federating Google Cloud with an external identity provider](https://docs.cloud.google.com/architecture/identity/best-practices-for-federating)
- [Single sign-on - Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/single-sign-on)
- [Active Directory single sign-on - Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-configuring-single-sign-on)
