# Question 151

**Source:** https://www.examtopics.com/discussions/google/view/82555-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** CMEK, crypto-shredding, Cloud KMS, encryption keys, PII deletion

---

## Question

Your privacy team uses crypto-shredding (deleting encryption keys) as a strategy to delete personally identifiable information (PII). You need to implement this practice on Google Cloud while still utilizing the majority of the platform's services and minimizing operational overhead. What should you do?
## Choices

- **A.** Use client-side encryption before sending data to Google Cloud, and delete encryption keys on-premises.
- **B.** Use Cloud External Key Manager to delete specific encryption keys.
- **C.** Use customer-managed encryption keys to delete specific encryption keys. Most Voted
- **D.** Use Google default encryption to delete specific encryption keys.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (20 total)


**Top Comments:**

- (11 upvotes) C is right

- (4 upvotes) C. Use customer-managed encryption keys to delete specific encryption keys.

- (2 upvotes) CMEK allows users to manage their keys on google without operation overhead of managing keys externally

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Customer-managed encryption keys (CMEK) in Cloud KMS is the optimal solution for implementing crypto-shredding on Google Cloud because it directly addresses all requirements:

**Crypto-shredding capability**: CMEK is specifically designed to support crypto-shredding. According to Google's documentation, one of the primary use cases for CMEK is to "selectively delete data protected by your keys in the case of off-boarding or to remediate security events (crypto-shredding)." When you disable or destroy a CMEK, the encrypted data becomes permanently inaccessible, effectively achieving data deletion without physical removal.

**Broad service support**: CMEK is supported by 80+ Google Cloud services, including BigQuery, Cloud Storage, Cloud SQL, Compute Engine, GKE, Cloud Run, Spanner, Firestore, Bigtable, and Vertex AI. This satisfies the requirement to "utilize the majority of the platform's services."

**Minimal operational overhead**: CMEK is a fully managed service within Cloud KMS. You don't need to maintain external infrastructure, manage dual systems, or coordinate between separate platforms. Key operations (creation, rotation, destruction) are all performed through Cloud KMS APIs and the Google Cloud Console with straightforward automation capabilities.

**Implementation**: When you need to crypto-shred PII, you simply destroy the specific CryptoKey version in Cloud KMS. The data encrypted with that key becomes immediately inaccessible across all services using it.

### Why Other Options Are Wrong

- **A:** Client-side encryption before sending data to Google Cloud requires significant operational overhead. You must manage encryption/decryption in every application, maintain on-premises key infrastructure, and handle key distribution. This approach also limits your ability to use many Google Cloud services that require access to unencrypted data for processing (like BigQuery analytics, Cloud SQL queries, or full-text search). The operational complexity contradicts the "minimizing operational overhead" requirement.

- **B:** Cloud External Key Manager (Cloud EKM) does support crypto-shredding, but it introduces substantial operational overhead. Cloud EKM requires you to maintain and manage an external key management system separate from Google Cloud, coordinate key operations between two systems, ensure high availability of the external key manager, and manage support contracts with external vendors. Google's documentation explicitly states that organizations bear full responsibility for external key availability and security, and "key version rotation or key version destruction operations need to be completed both directly in your EKM and in Cloud KMS." This dual-system management contradicts the requirement to minimize operational overhead.

- **D:** Google default encryption uses Google-managed encryption keys that are completely managed by Google. Customers have no control over these keys and cannot delete, disable, or destroy them. Google default encryption does not support crypto-shredding because you cannot selectively destroy encryption keys to render specific data inaccessible. This option cannot meet the fundamental requirement of the question.

### References

- [Customer-managed encryption keys (CMEK) | Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/cmek)
- [Best practices for using CMEKs | Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/cmek-best-practices)
- [Cloud External Key Manager | Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/ekm)
- [Destroy and restore key versions | Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/destroy-restore)
