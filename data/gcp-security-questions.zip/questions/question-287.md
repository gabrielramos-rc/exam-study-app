# Question 287

**Source:** https://www.examtopics.com/discussions/google/view/147081-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** Cloud EKM, External Key Manager, Key Access Justifications, Access Approval, CMEK, audit, compliance, regulatory

---

## Question

You work for a banking organization. You are migrating sensitive customer data to Google Cloud that is currently encrypted at rest while on-premises. There are strict regulatory requirements when moving sensitive data to the cloud. Independent of the cloud service provider, you must be able to audit key usage and be able to deny certain types of decrypt requests. You must choose an encryption strategy that will ensure robust security and compliance with the regulations. What should you do?
## Choices

- **A.** Utilize Google default encryption and Cloud IAM to keep the keys within your organization's control.
- **B.** Implement Cloud External Key Manager (Cloud EKM) with Access Approval, to integrate with your existing on-premises key management solution.
- **C.** Implement Cloud External Key Manager (Cloud EKM) with Key Access Justifications to integrate with your existing one premises key management solution. Most Voted
- **D.** Utilize customer-managed encryption keys (CMEK) created in a dedicated Google Compute Engine instance with Confidential Compute encryption, under your organization's control.

---

## Community

**Most Voted:** C


**Votes:** B: 30% | C: 70% (10 total)


**Top Comments:**

- (5 upvotes) Cloud External Key Manager (Cloud EKM) is the specific service that allows an organization to use encryption keys stored and managed in their own on-premises (or third-party) key management system, pr

- (3 upvotes) I think it's B.

- (2 upvotes) C does not offer the same level of access control as Access Approval, which is critical for denying unauthorized decrypt requests.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Cloud External Key Manager (Cloud EKM) with Key Access Justifications is the correct solution because it satisfies both critical regulatory requirements:

**1. Independent Control and Audit of Key Usage:**
Cloud EKM allows you to maintain cryptographic keys in your existing on-premises external key management system, completely outside Google's infrastructure. The external key material never leaves your key manager, giving you true independence from the cloud provider. You can enable audit logging in your external key manager to capture all access to and usage of your EKM keys, providing comprehensive audit trails that meet regulatory requirements.

**2. Ability to Deny Decrypt Requests:**
Key Access Justifications enables you to set policies on Cloud KMS keys that allow you to "view, approve, and deny key access requests depending on the provided justification code." This feature specifically addresses the requirement to deny certain types of decrypt requests. For select external key management partners, you can configure Key Access Justifications policies outside of Google Cloud to be exclusively enforced by the external key manager, providing granular control over which cryptographic operations are permitted based on justification reasons.

**Combined Architecture:**
Cloud EKM provides the external control and auditability, while Key Access Justifications adds the policy-based approval/denial mechanism. Data encrypted with Cloud EKM keys cannot be decrypted without both the external key material (in your control) and internal key material, and each decrypt request must pass your Key Access Justifications policy checks.

### Why Other Options Are Wrong

- **A:** Google default encryption uses Google-managed keys that remain under Google's control, not your organization's control. You cannot audit key usage independently or deny decrypt requests at the granular level required by the regulations. This does not provide the independence from the cloud provider that is explicitly required.

- **B:** While Cloud EKM provides external key control and audit capabilities, Access Approval is designed for authorizing Google personnel access to customer data, not for denying specific types of decrypt requests. Access Approval controls human access by Google staff, whereas the requirement is to control cryptographic decrypt operations. Key Access Justifications is the correct feature for policy-based control over decrypt requests.

- **D:** Customer-managed encryption keys (CMEK) stored in Cloud KMS are still managed within Google's infrastructure, not truly independent of the cloud provider. Additionally, creating CMEK in a Compute Engine instance is not a supported or secure architecture - CMEK keys should be created in Cloud KMS. This approach does not provide the external key control or ability to deny decrypt requests based on justification policies.

### References

- [Cloud External Key Manager Overview](https://docs.cloud.google.com/kms/docs/ekm)
- [Key Access Justifications Overview](https://docs.cloud.google.com/assured-workloads/key-access-justifications/docs/overview)
- [Introduction to Key Access Justifications](https://docs.cloud.google.com/assured-workloads/access-transparency/docs/key-access-justifications)
