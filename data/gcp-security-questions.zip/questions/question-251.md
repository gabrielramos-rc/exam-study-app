# Question 251

**Source:** https://www.examtopics.com/discussions/google/view/147045-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** Workload Identity Federation, service account, external identity provider, on-premises applications

---

## Question

Your organization has a centralized identity provider that is used to manage human and machine access. You want to leverage this existing identity management system to enable on-premises applications to access Google Cloud without hard coded credentials. What should you do?
## Choices

- **A.** Enable Secure Web Proxy. Create a proxy subnet for each region that Secure Web Proxy will be deployed. Deploy an SSL certificate to Certificate Manager. Create a Secure Web Proxy policy and rules that allow access to Google Cloud services.
- **B.** Enable Workforce Identity Federation. Create a workforce identity pool and specify the on-premises identity provider as a workforce identity pool provider. Create an attribute mapping to map the on-premises identity provider token to a Google STS token. Create an IAM binding that binds the required role(s) to the external identity by specifying the project ID, workload identity pool, and attribute that should be matched.
- **C.** Enable Identity-Aware Proxy (IAP). Configure IAP by specifying the groups and service accounts that should have access to the application. Grant these identities the IAP-secured web app user role.
- **D.** Enable Workload Identity Federation. Create a workload identity pool and specify the on-premises identity provider as a workload identity pool provider. Create an attribute mapping to map the on-premises identity provider token to a Google STS token. Create a service account with the necessary permissions for the workload. Grant the external identity the Workload Identity user role on the service account. Most Voted

---

## Community

**Most Voted:** D


**Votes:** B: 14% | D: 86% (14 total)


**Top Comments:**

- (5 upvotes) This is the best explanation if anyone still not sure.

- (4 upvotes) Im pretty sure its D

- (2 upvotes) Workload Identity Federation allows applications running outside of Google Cloud (like on-premises systems) to authenticate to Google Cloud services using tokens from an existing identity provider wit

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

**Workload Identity Federation** is the correct solution for enabling on-premises **applications** (workloads) to access Google Cloud without hard-coded credentials. The question specifically asks about "on-premises applications" which are machine/workload identities, not human users.

Option D follows the exact architecture for Workload Identity Federation:

1. **Create a workload identity pool** - An entity that manages external identities for workloads
2. **Configure identity provider** - Specify your on-premises IdP as a workload identity pool provider (supports OIDC, SAML, or Active Directory Federation Services)
3. **Create attribute mapping** - Maps your on-premises IdP token attributes to Google Security Token Service (STS) tokens (e.g., `google.subject=assertion.sub`)
4. **Create a service account** - With the necessary permissions for the workload to access Google Cloud resources
5. **Grant Workload Identity User role** (`roles/iam.workloadIdentityUser`) - Allows the external identity to impersonate the service account

This eliminates the need for service account keys (hard-coded credentials) and follows OAuth 2.0 token exchange. The application exchanges its on-premises credential for a federated token via STS, which then obtains short-lived OAuth 2.0 access tokens.

### Why Other Options Are Wrong

- **A:** Secure Web Proxy is for controlling egress traffic from VMs to the internet through a proxy, not for identity federation. It doesn't solve the authentication problem or eliminate hard-coded credentials.

- **B:** Workforce Identity Federation is designed for **human users** (workforce/employees), not for applications or machine identities. While it uses similar concepts (identity pools, providers, attribute mapping), it's the wrong type of federation for this use case. The question specifically mentions "on-premises applications" which are workloads, not people.

- **C:** Identity-Aware Proxy (IAP) is for controlling access to applications running on Google Cloud, not for enabling on-premises applications to authenticate to Google Cloud. IAP is a reverse proxy that enforces access control before requests reach your application. It doesn't provide a mechanism for external applications to authenticate without credentials.

### References

- [Workload Identity Federation](https://docs.cloud.google.com/iam/docs/workload-identity-federation)
- [Configure Workload Identity Federation with other identity providers](https://docs.cloud.google.com/iam/docs/workload-identity-federation-with-other-providers)
- [Best practices for using Workload Identity Federation](https://docs.cloud.google.com/iam/docs/best-practices-for-using-workload-identity-federation)
