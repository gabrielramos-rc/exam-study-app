# Question 228

**Source:** https://www.examtopics.com/discussions/google/view/117242-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** Cloud EKM, External Key Manager, Confidential VM, encryption in use, CMEK

---

## Question

You manage a mission-critical workload for your organization, which is in a highly regulated industry. The workload uses Compute Engine VMs to analyze and process the sensitive data after it is uploaded to Cloud Storage from the endpoint computers. Your compliance team has detected that this workload does not meet the data protection requirements for sensitive data. You need to meet these requirements:
- Manage the data encryption key (DEK) outside the Google Cloud boundary.
- Maintain full control of encryption keys through a third-party provider.
- Encrypt the sensitive data before uploading it to Cloud Storage.
- Decrypt the sensitive data during processing in the Compute Engine VMs.
- Encrypt the sensitive data in memory while in use in the Compute Engine VMs.

What should you do? (Choose two.)

## Choices

- **A.** Configure Customer Managed Encryption Keys to encrypt the sensitive data before it is uploaded to Cloud Storage, and decrypt the sensitive data after it is downloaded into your VMs.
- **B.** Configure Cloud External Key Manager to encrypt the sensitive data before it is uploaded to Cloud Storage, and decrypt the sensitive data after it is downloaded into your VMs. Most Voted
- **C.** Create Confidential VMs to access the sensitive data. Most Voted
- **D.** Migrate the Compute Engine VMs to Confidential VMs to access the sensitive data.
- **E.** Create a VPC Service Controls service perimeter across your existing Compute Engine VMs and Cloud Storage buckets.

---

## Community

**Most Voted:** BC


**Votes:** BC: 61% | BD: 39% (28 total)


**Top Comments:**

- (4 upvotes) I would go with BC as well

- (4 upvotes) C because Confidential VM does not support live migration.

- (3 upvotes) BC . Agree.

---

## Answer

**Correct:** B, D

**Confidence:** high

### Explanation

This question requires meeting five specific data protection requirements, which necessitate two complementary technologies:

**Option B - Cloud External Key Manager (Cloud EKM)** satisfies requirements 1-4:
- **Manage DEK outside Google Cloud boundary:** Cloud EKM stores encryption keys in a third-party external key management system. The keys reside on the external system and are never sent to Google.
- **Full control through third-party provider:** Cloud EKM integrates with external key management partners (like Thales, Fortanix, etc.), giving you complete control over key lifecycle and access policies from outside Google's infrastructure.
- **Encrypt before upload & decrypt during processing:** Using Cloud EKM with client-side encryption libraries (like Tink), you can encrypt data locally before uploading to Cloud Storage, then decrypt it when needed in the VMs using the same external keys.

**Option D - Migrate to Confidential VMs** satisfies requirement 5:
- **Encrypt data in memory while in use:** Confidential VMs use hardware-based memory encryption (AMD SEV, AMD SEV-SNP, or Intel TDX) to keep data encrypted in memory during processing. This provides encryption-in-use protection through a Trusted Execution Environment (TEE).
- Confidential VMs ensure that sensitive data remains encrypted even while being actively processed in VM memory, protecting against hypervisor-based attacks and memory access attempts.

Together, these two solutions provide defense-in-depth: Cloud EKM handles external key management and encryption at rest/in transit, while Confidential VMs handle encryption in use (memory).

### Why Other Options Are Wrong

- **A:** CMEK (Customer-Managed Encryption Keys) stores keys within Cloud KMS inside Google Cloud's boundary, not outside it as required. While CMEK provides key management control, it doesn't meet the requirement for managing keys "outside the Google Cloud boundary" through a third-party provider.

- **C:** "Create Confidential VMs" is incomplete phrasing. The question states you already have "Compute Engine VMs" - you need to migrate/convert them to Confidential VMs (option D), not create new separate ones. Also, this alone doesn't address the external key management requirements.

- **E:** VPC Service Controls creates security perimeters to prevent data exfiltration and control API access, but it doesn't provide encryption key management outside Google Cloud, client-side encryption capabilities, or memory encryption. It's a network boundary control, not an encryption solution.

### References

- [Cloud External Key Manager Overview](https://docs.cloud.google.com/kms/docs/ekm)
- [Confidential VM Overview](https://docs.cloud.google.com/confidential-computing/confidential-vm/docs/confidential-vm-overview)
- [Data Encryption Options for Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption)
- [Client-Side Encryption with Tink and Cloud KMS](https://docs.cloud.google.com/kms/docs/client-side-encryption)
