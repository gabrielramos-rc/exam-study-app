# Question 320

**Source:** https://www.examtopics.com/discussions/google/view/150192-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** service account, IAM bindings, Compute Engine, Cloud Storage, least privilege

---

## Question

You are developing an application that runs on a Compute Engine VM. The application needs to access data stored in Cloud Storage buckets in other Google Cloud projects. The required access to the buckets is variable. You need to provide access to these resources while following Google- recommended practices. What should you do?
## Choices

- **A.** Limit the VMs access to the Cloud Storage buckets by setting the relevant access scope of the VM.
- **B.** Create IAM bindings for the VM's service account and the required buckets that allow appropriate access to the data stored in the buckets. Most Voted
- **C.** Grant the VM's service account access to the required buckets by using domain-wide delegation.
- **D.** Create a group and assign IAM bindings to the group for each bucket that the application needs to access. Assign the VM's service account to the group.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (6 total)


**Top Comments:**

- (3 upvotes) Directly assigning IAM bindings to the VM's service account for each Cloud Storage bucket provides the most secure and flexible way to manage access to your data. This approach adheres to the principl

- (3 upvotes) Answer B

- (1 upvotes) well explained below

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Creating IAM bindings for the VM's service account directly on the required Cloud Storage buckets is the Google-recommended approach. This follows the principle of least privilege by granting only the necessary permissions to the specific resources that the application needs to access.

The recommended pattern involves:
1. Setting the `cloud-platform` access scope on the VM (to allow API access broadly)
2. Controlling actual permissions through granular IAM role bindings on individual buckets
3. Granting only the specific roles needed (e.g., `roles/storage.objectViewer` or `roles/storage.objectAdmin`)

This approach provides flexibility for "variable" access requirements because IAM roles can be modified as needed without recreating the VM instance. The documentation emphasizes that "both of these configurations must allow access before the application running on the instance can access a resource," but the security control should come from IAM bindings, not access scopes.

### Why Other Options Are Wrong

- **A:** Access scopes are a legacy mechanism and should not be used as the primary access control. Google recommends setting the broad `cloud-platform` scope and controlling access through IAM roles instead. Access scopes function as an on/off switch but lack the granularity needed for variable access requirements across multiple buckets.

- **C:** Domain-wide delegation is used for Google Workspace (formerly G Suite) domain-wide access, not for cross-project Cloud Storage access. This feature allows service accounts to impersonate users within a Workspace domain and is completely unrelated to the scenario described. It's also not a Google-recommended practice for this use case.

- **D:** While using groups for IAM management is a valid pattern for user accounts, service accounts cannot be added to groups in the same way. This approach adds unnecessary complexity without providing any benefit over direct IAM bindings. Service accounts should receive permissions directly or through service account impersonation.

### References

- [Service accounts | Compute Engine Documentation](https://docs.cloud.google.com/compute/docs/access/service-accounts)
- [Create a VM that uses a user-managed service account](https://docs.cloud.google.com/compute/docs/access/create-enable-service-accounts-for-instances)
- [Best practices for using service accounts securely](https://docs.cloud.google.com/iam/docs/best-practices-service-accounts)
