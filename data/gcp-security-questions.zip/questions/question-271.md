# Question 271

**Source:** https://www.examtopics.com/discussions/google/view/147065-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** log export, log sink, aggregated sink, external SIEM, Cloud Logging, Pub/Sub, Dataflow

---

## Question

You work for a multinational organization that has systems deployed across multiple cloud providers, including Google Cloud. Your organization maintains an extensive on-premises security information and event management (SIEM) system. New security compliance regulations require that relevant Google Cloud logs be integrated seamlessly with the existing SIEM to provide a unified view of security events. You need to implement a solution that exports Google Cloud logs to your on-premises SIEM by using a push-based, near real-time approach. You must prioritize fault tolerance, security, and auto scaling capabilities. In particular, you must ensure that if a log delivery fails, logs are re-sent. What should you do?
## Choices

- **A.** Create a Pub/Sub topic for log aggregation. Write a custom Python script on a Cloud Function Leverage the Cloud Logging API to periodically pull logs from Google Cloud and forward the logs to the SIEM. Schedule the Cloud Function to run twice per day.
- **B.** Collect all logs into an organization-level aggregated log sink and send the logs to a Pub/Sub topic. Implement a primary Dataflow pipeline that consumes logs from this Pub/Sub topic and delivers the logs to the SIEM. Implement a secondary Dataflow pipeline that replays failed messages. Most Voted
- **C.** Deploy a Cloud Logging sink with a filter that routes all logs directly to a syslog endpoint. The endpoint is based on a single Compute Engine hosted on Google Cloud that routes all logs to the on-premises SIEM. Implement a Cloud Function that triggers a retry action in case of failure.
- **D.** Utilize custom firewall rules to allow your SIEM to directly query Google Cloud logs. Implement a Cloud Function that notifies the SIEM of a failed delivery and triggers a retry action.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (6 total)


**Top Comments:**

- (1 upvotes) B - https://cloud.google.com/architecture/stream-logs-from-google-cloud-to-splunk

- (1 upvotes) B 100%.

- (1 upvotes) use pub/sub. A is wrong as it says that "periodically pull logs" - Not near real-time and need programing works.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B is the correct solution as it implements Google Cloud's recommended architecture for streaming logs from Google Cloud to on-premises SIEM systems using a push-based approach. This architecture is explicitly documented in Google's reference architecture for integrating Cloud Logging with third-party SIEM platforms like Splunk.

The solution provides all required capabilities:

**Push-based, near real-time delivery:** Cloud Logging routes log entries to Pub/Sub topics as soon as they are received, with 99% of log entries available in less than 60 seconds. Pub/Sub then pushes messages to the Dataflow streaming pipeline for immediate delivery.

**Fault tolerance with automatic retry:** The primary Dataflow pipeline automatically retries transient failures (timeouts, connection resets) with exponential backoff. For persistent failures, messages are routed to an unprocessed topic (dead-letter queue) where they are stored for investigation.

**Secondary pipeline for replay:** The secondary Dataflow pipeline (Pub/Sub to Pub/Sub) allows operators to replay failed messages after investigating and resolving the root cause. This ensures no log data is lost, even during extended outages.

**Auto-scaling:** Dataflow automatically scales worker instances based on the message volume in the Pub/Sub subscription, handling variable log volumes without manual intervention.

**Security:** The architecture supports storing credentials (like Splunk HEC tokens) in Secret Manager and using private IP addresses for Dataflow workers to prevent exposure to the public internet.

**Organization-level aggregation:** Using an organization-level aggregated log sink ensures logs from all projects within the organization are captured in a single unified stream, providing the required unified view across the multinational organization.

### Why Other Options Are Wrong

- **A:** This is a pull-based approach, not push-based as required. Running twice per day does not meet the near real-time requirement (logs would be delayed by hours). Cloud Functions have execution time limits that make them unsuitable for continuous log streaming. Periodic polling is inefficient and does not provide automatic retry capabilities for failed deliveries.

- **C:** Using a single Compute Engine instance creates a single point of failure and does not provide auto-scaling capabilities. This violates the fault tolerance requirement. Manual Cloud Function retry logic is complex to implement correctly and does not provide the same reliability as Dataflow's built-in retry mechanisms. Syslog endpoints are not the recommended integration method for modern SIEM platforms.

- **D:** Firewall rules do not provide a mechanism for SIEM systems to query Cloud Logging - this fundamentally misunderstands how Cloud Logging works. SIEMs cannot directly pull logs from Google Cloud in a push-based manner. This approach does not implement a push-based solution and would not work in practice.

### References

- [Stream logs from Google Cloud to Splunk](https://docs.cloud.google.com/architecture/stream-logs-from-google-cloud-to-splunk)
- [View logs routed to Pub/Sub](https://docs.cloud.google.com/logging/docs/export/pubsub)
- [Route logs to supported destinations](https://docs.cloud.google.com/logging/docs/export/configure_export_v2)
- [Pub/Sub to Splunk template](https://docs.cloud.google.com/dataflow/docs/guides/templates/provided/pubsub-to-splunk)
