# Question 029

**Source:** https://www.examtopics.com/discussions/google/view/16996-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** Shared VPC, IAM, subnet, Compute Network User, least privilege

---

## Question

Your team sets up a Shared VPC Network where project co-vpc-prod is the host project. Your team has configured the firewall rules, subnets, and VPN gateway on the host project. They need to enable Engineering Group A to attach a Compute Engine instance to only the 10.1.1.0/24 subnet. What should your team grant to Engineering Group A to meet this requirement?
## Choices

- **A.** Compute Network User Role at the host project level.
- **B.** Compute Network User Role at the subnet level. Most Voted
- **C.** Compute Shared VPC Admin Role at the host project level.
- **D.** Compute Shared VPC Admin Role at the service project level.

---

## Community

**Most Voted:** B


**Votes:** A: 31% | B: 69% (26 total)


**Top Comments:**

- (22 upvotes) A is right. Source: https://cloud.google.com/compute/docs/access/iam#compute.networkUser

- (4 upvotes) To enable Engineering Group A to attach a Compute Engine instance to only the 10.1.1.0/24 subnet in a Shared VPC setup, you should follow these steps: Grant the Compute Network User role at the servic

- (3 upvotes) The correct answer is B per least privilegd access rule

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Engineering Group A should be granted the **Compute Network User role at the subnet level** (`roles/compute.networkUser` on the specific 10.1.1.0/24 subnet). This approach follows the principle of least privilege by restricting the group's access to only the specific subnet they need, rather than all subnets in the host project.

In Shared VPC, the Compute Network User role can be granted at two scopes:
- **Project level**: Grants access to all current and future subnets in the host project
- **Subnet level**: Grants access only to specific subnets

Google Cloud documentation explicitly recommends granting the Compute Network User role at the subnet level as it "provides a more granular means to define Service Project Admins by granting them the `compute.networkUser` role for only some subnets in the host project." This subnet-level permission allows Engineering Group A to create Compute Engine instances that attach to the 10.1.1.0/24 subnet only, preventing them from accessing other subnets in the Shared VPC.

### Why Other Options Are Wrong

- **A:** Granting Compute Network User at the host project level would give Engineering Group A access to all current and future subnets in the host project, violating the requirement to restrict access to only the 10.1.1.0/24 subnet. This is excessive permission and does not follow least privilege.

- **C:** Compute Shared VPC Admin role at the host project level would grant far too much permission. This role is designed for administrators who manage the entire Shared VPC configuration, including attaching/detaching service projects, not for groups that simply need to deploy instances to a specific subnet.

- **D:** Compute Shared VPC Admin role at the service project level is also excessive and inappropriate. Service Project Admins need the Network User role (not Shared VPC Admin) to use shared subnets. The Shared VPC Admin role is for managing the Shared VPC infrastructure itself, not for deploying resources.

### References

- [Provision Shared VPC](https://docs.cloud.google.com/vpc/docs/provisioning-shared-vpc)
- [Shared VPC Overview](https://docs.cloud.google.com/vpc/docs/shared-vpc)
