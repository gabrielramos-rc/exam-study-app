# Question 235

**Source:** https://www.examtopics.com/discussions/google/view/126774-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** CMEK, Cloud KMS, Cloud Storage, HSM, encryption, key location

---

## Question

You are setting up a new Cloud Storage bucket in your environment that is encrypted with a customer managed encryption key (CMEK). The CMEK is stored in Cloud Key Management Service (KMS), in project “prj-a”, and the Cloud Storage bucket will use project “prj-b”. The key is backed by a Cloud Hardware Security Module (HSM) and resides in the region europe-west3. Your storage bucket will be located in the region europe-west1. When you create the bucket, you cannot access the key, and you need to troubleshoot why. What has caused the access issue?
## Choices

- **A.** A firewall rule prevents the key from being accessible.
- **B.** Cloud HSM does not support Cloud Storage.
- **C.** The CMEK is in a different project than the Cloud Storage bucket.
- **D.** The CMEK is in a different region than the Cloud Storage bucket. Most Voted

---

## Community

**Most Voted:** D


**Votes:** C: 12% | D: 88% (17 total)


**Top Comments:**

- (5 upvotes) https://cloud.google.com/kms/docs/cmek#when-use-cmek

- (4 upvotes) CMEK Project Mismatch: By default, CMEKs can only be accessed by services within the same GCP project where the key resides (prj-a in this case). Your Cloud Storage bucket is in a different project (p

- (2 upvotes) You must create the Cloud KMS key ring in the same location as the data you intend to encrypt. For example, if your bucket is located in US-EAST1, any key ring used for encrypting objects in that buck

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The issue is caused by the regional mismatch between the Cloud KMS key and the Cloud Storage bucket. According to Google Cloud documentation, **you must create the Cloud KMS key ring in the same location as the data you intend to encrypt**.

In this scenario:
- The CMEK is stored in Cloud KMS in region **europe-west3**
- The Cloud Storage bucket is located in region **europe-west1**

This violates the fundamental requirement for CMEK with Cloud Storage. When you attempt to create the bucket with this key, the operation fails because Cloud Storage cannot access a key from a different region to encrypt objects in the bucket.

The documentation explicitly states: "For example, if your bucket is located in `US-EAST1`, any key ring used for encrypting objects in that bucket must also be created in `US-EAST1`." The same principle applies to this europe-west scenario.

### Why Other Options Are Wrong

- **A:** Firewall rules do not control access to Cloud KMS keys. Cloud KMS is accessed through Google Cloud APIs over HTTPS, and key access is controlled through IAM permissions, not network firewall rules. The encryption/decryption operations happen within Google's infrastructure using the Cloud Storage service agent.

- **B:** Cloud HSM fully supports Cloud Storage encryption. Cloud Storage integrates with Cloud KMS for customer-managed encryption keys (CMEK), and those keys can be protected by either software-based protection or Cloud HSM (hardware security modules). The HSM backing is not the issue here.

- **C:** CMEKs can be in a different project than the Cloud Storage bucket. Cross-project CMEK usage is supported as long as the Cloud Storage service agent from the bucket's project has the appropriate IAM permissions (cloudkms.cryptoKeyEncrypterDecrypter role) on the key in the other project. The cross-project scenario (prj-a vs prj-b) is not the cause of the access issue.

### References

- [Customer-managed encryption keys | Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption/customer-managed-keys)
