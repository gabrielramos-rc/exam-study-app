# Question 059

**Source:** https://www.examtopics.com/discussions/google/view/30328-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** GKE, container security, patch management, vulnerability, rolling update

---

## Question

A patch for a vulnerability has been released, and a DevOps team needs to update their running containers in Google Kubernetes Engine (GKE). How should the DevOps team accomplish this?
## Choices

- **A.** Use Puppet or Chef to push out the patch to the running container.
- **B.** Verify that auto upgrade is enabled; if so, Google will upgrade the nodes in a GKE cluster.
- **C.** Update the application code or apply a patch, build a new image, and redeploy it. Most Voted
- **D.** Configure containers to automatically upgrade when the base image is available in Container Registry.

---

## Community

**Most Voted:** C


**Votes:** B: 25% | C: 75% (4 total)


**Top Comments:**

- (15 upvotes) Yes, C is correct

- (7 upvotes) https://cloud.google.com/kubernetes-engine/docs/resources/security-patching#how_vulnerabilities_are_patched

- (5 upvotes) The qeustion is asking about upgrading application code rather than GKE

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

GKE security follows a **shared responsibility model**. Google manages patches for the GKE control plane and node operating systems (Container-Optimized OS/Ubuntu), but **patching application containers is the customer's responsibility**.

The correct approach for patching vulnerabilities in your application containers is to:
1. **Update the application code or apply the security patch**
2. **Build a new container image** with the patched code
3. **Redeploy the new image** using rolling updates (via `kubectl set image`, `kubectl apply`, or the Cloud Console)

GKE's rolling update mechanism ensures zero downtime by incrementally replacing Pods with the new patched image while maintaining service availability. You can monitor the rollout with `kubectl rollout status` and perform rollbacks if needed with `kubectl rollout undo`.

This follows the immutable infrastructure principle - you don't patch running containers in place, you replace them with new images containing the fixes.

### Why Other Options Are Wrong

- **A:** Using Puppet or Chef to push patches to running containers violates the immutable infrastructure principle and container best practices. Containers should be treated as ephemeral and replaced, not modified in place. Changes made to running containers are lost when the container restarts.

- **B:** Auto-upgrade handles **GKE platform patches** (control plane, node OS, and Kubernetes components), not your application container patches. While enabling auto-upgrade is a best practice for maintaining the underlying GKE infrastructure, it does not patch vulnerabilities in your custom application containers. This is the customer's responsibility in the shared responsibility model.

- **D:** Containers do not automatically upgrade when base images are updated. There is no built-in mechanism in GKE or Container Registry that automatically monitors base image updates and redeploys workloads. You must explicitly rebuild your images with updated base layers and manually trigger redeployment through rolling updates.

### References

- [Updating applications in GKE](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/updating-apps)
- [GKE security patching](https://docs.cloud.google.com/kubernetes-engine/docs/resources/security-patching)
- [GKE shared responsibility model](https://docs.cloud.google.com/kubernetes-engine/docs/concepts/shared-responsibility)
