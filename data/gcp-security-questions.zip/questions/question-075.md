# Question 075

**Source:** https://www.examtopics.com/discussions/google/view/30367-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Identity-Aware Proxy, IAP, two-factor authentication, authentication, web application security

---

## Question

A customer wants to make it convenient for their mobile workforce to access a CRM web interface that is hosted on Google Cloud Platform (GCP). The CRM can only be accessed by someone on the corporate network. The customer wants to make it available over the internet. Your team requires an authentication layer in front of the application that supports two-factor authentication Which GCP product should the customer implement to meet these requirements?
## Choices

- **A.** Cloud Identity-Aware Proxy Most Voted
- **B.** Cloud Armor
- **C.** Cloud Endpoints
- **D.** Cloud VPN

---

## Community

**Most Voted:** A


**Votes:** A: 100% (11 total)


**Top Comments:**

- (20 upvotes) I agree and A is right

- (7 upvotes) Technically CloudVPN implementation means the app will not be available from Internet. So answer shall be A.

- (5 upvotes) Answer -A

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Cloud Identity-Aware Proxy (IAP) is the correct solution because it provides all the required capabilities:

1. **Authentication Layer**: IAP establishes a central authorization layer for applications accessed by HTTPS, verifying user identity before granting access to the application. It integrates with OAuth 2.0 and Google Accounts to authenticate users.

2. **Two-Factor Authentication Support**: IAP supports multi-factor authentication through its reauthentication capabilities. Administrators can configure IAP to require users to authenticate using "one of their enrolled second factors" (security keys or other enrolled second factors) when accessing protected applications. This can be enforced through reauthentication policies with customizable session durations.

3. **Internet Access for Corporate Applications**: IAP enables secure access to applications over the internet without requiring users to be on the corporate network. It uses an application-level access control model instead of relying on network-level firewalls, making it ideal for mobile workforces.

4. **Corporate Identity Integration**: IAP can integrate with corporate identity systems through Google Cloud Directory Sync (to sync with Active Directory/LDAP) or Workforce Identity Federation (to use external identity providers).

IAP creates a secure perimeter around the web application by verifying both identity and authorization via IAM roles (IAP-secured Web App User role) before allowing access, making corporate applications safely accessible over the internet while maintaining strong authentication requirements.

### Why Other Options Are Wrong

- **B. Cloud Armor**: Cloud Armor is a DDoS protection and Web Application Firewall (WAF) service that protects applications from attacks at the network edge. While it provides security policy enforcement, it does not provide authentication or identity verification capabilities. It focuses on protecting against malicious traffic, not authenticating legitimate users.

- **C. Cloud Endpoints**: Cloud Endpoints is an API management system for developing, deploying, and managing APIs. While it provides API authentication and monitoring, it is designed for API security rather than providing a general authentication layer for web applications. It doesn't provide the browser-based authentication flow with two-factor authentication needed for a web CRM interface.

- **D. Cloud VPN**: Cloud VPN provides encrypted connectivity between your on-premises network and Google Cloud VPC networks. While it would allow the mobile workforce to connect to the corporate network to access the CRM, it doesn't meet the requirement for "convenient" access or provide an authentication layer in front of the application. Users would need VPN client software and the authentication would be at the network level, not the application level. This is the traditional approach that IAP is designed to replace.

### References

- [Identity-Aware Proxy overview](https://docs.cloud.google.com/iap/docs/concepts-overview)
- [IAP reauthentication](https://docs.cloud.google.com/iap/docs/configuring-reauth)
