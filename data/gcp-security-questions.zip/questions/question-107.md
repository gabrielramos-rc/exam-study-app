# Question 107

**Source:** https://www.examtopics.com/discussions/google/view/74826-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Web Security Scanner, vulnerability scanning, XSS detection, application security, GKE security

---

## Question

Your organization recently deployed a new application on Google Kubernetes Engine. You need to deploy a solution to protect the application. The solution has the following requirements: ✑ Scans must run at least once per week ✑ Must be able to detect cross-site scripting vulnerabilities ✑ Must be able to authenticate using Google accounts Which solution should you use?
## Choices

- **A.** Google Cloud Armor
- **B.** Web Security Scanner Most Voted
- **C.** Security Health Analytics
- **D.** Container Threat Detection

---

## Community

**Most Voted:** B


**Votes:** B: 100% (6 total)


**Top Comments:**

- (14 upvotes) Yes, B is right

- (3 upvotes) Google Cloud Armor can prevent XSS attacks. It has preconfigured rules that can mitigate XSS, broken authentication, and SQL injection. Cloud Armor also has a custom rules language that includes multi

- (2 upvotes) B is the answer.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Web Security Scanner is the correct solution because it specifically meets all three requirements:

1. **Weekly scans**: Web Security Scanner's managed scans automatically run once per week to detect and scan public web endpoints. This satisfies the requirement for scans to run at least weekly.

2. **Cross-site scripting (XSS) detection**: Web Security Scanner explicitly detects multiple types of XSS vulnerabilities, including standard XSS, XSS Angular Callback, and XSS Error variants. It supports vulnerability categories in the OWASP Top Ten, which includes XSS as a primary web application security risk.

3. **Google account authentication**: Web Security Scanner supports Google account authentication for custom scans. You can create a test account in Gmail or Google Workspace and configure the scanner to authenticate using that account. This enables scanning of applications that require user login, though two-factor authentication is not supported.

Web Security Scanner is designed specifically for web application vulnerability scanning and integrates with Security Command Center to provide comprehensive security findings.

### Why Other Options Are Wrong

- **A. Google Cloud Armor**: Cloud Armor is a web application firewall (WAF) and DDoS protection service that protects applications from attacks in real-time. It does not perform vulnerability scanning, detect XSS vulnerabilities through testing, or require authentication to scan applications. It's a runtime protection service, not a vulnerability scanner.

- **C. Security Health Analytics**: This service detects security misconfigurations and vulnerabilities in Google Cloud resources (like overly permissive IAM policies, open firewall rules, or missing OS patches). It does not scan web applications for vulnerabilities like XSS, nor does it authenticate to applications or perform penetration testing.

- **D. Container Threat Detection**: This service detects runtime threats in GKE containers, such as cryptocurrency mining, reverse shell attempts, or suspicious binary execution. It monitors container behavior for threats but does not scan web applications for vulnerabilities like XSS, nor does it use Google account authentication to test application security.

### References

- [Overview of Web Security Scanner](https://docs.cloud.google.com/security-command-center/docs/concepts-web-security-scanner-overview)
- [Setting up custom scans using Web Security Scanner](https://docs.cloud.google.com/security-command-center/docs/how-to-web-security-scanner-custom-scans)
- [Remediating Web Security Scanner findings](https://docs.cloud.google.com/security-command-center/docs/how-to-remediate-web-security-scanner-findings)
