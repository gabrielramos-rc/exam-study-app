# Question 222

**Source:** https://www.examtopics.com/discussions/google/view/117329-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** Workload Identity Federation, service account, ADFS, Active Directory, impersonation, attribute conditions

---

## Question

Your company recently published a security policy to minimize the usage of service account keys. On-premises Windows-based applications are interacting with Google Cloud APIs. You need to implement Workload Identity Federation (WIF) with your identity provider on-premises. What should you do?
## Choices

- **A.** Set up a workload identity pool with your corporate Active Directory Federation Service (ADFS). Configure a rule to let principals in the pool impersonate the Google Cloud service account. Most Voted
- **B.** Set up a workload identity pool with your corporate Active Directory Federation Service (ADFS). Let all principals in the pool impersonate the Google Cloud service account.
- **C.** Set up a workload identity pool with an OpenID Connect (OIDC) service on the same machine. Configure a rule to let principals in the pool impersonate the Google Cloud service account.
- **D.** Set up a workload identity pool with an OpenID Connect (OIDC) service on the same machine. Let all principals in the pool impersonate the Google Cloud service account.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (14 total)


**Top Comments:**

- (5 upvotes) A. is the correct and most secure solution. Workload Identity Federation (WIF) is the right tool for connecting on-premises applications to Google Cloud APIs without service account keys. Setting up a

- (3 upvotes) Here's why option A is the preferred choice: Workload Identity Pool: Using your corporate ADFS for identity federation is a common and secure way to manage identities and access to Google Cloud resour

- (3 upvotes) A is correct, B is also correct, but it causes chaos.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is correct because it implements Workload Identity Federation with Active Directory Federation Services (ADFS) using security best practices. For on-premises Windows-based applications in an Active Directory environment, ADFS is the appropriate identity provider to integrate with Google Cloud. The key security requirement is to "configure a rule" (using attribute conditions or filters) to restrict which principals in the pool can impersonate the service account.

According to Google Cloud documentation, when setting up Workload Identity Federation with Active Directory, you should implement "Only identities matching the filter" restrictions using CEL expressions to limit which pool members can impersonate service accounts. This follows the principle of least privilege and ensures only authorized users or workloads can obtain Google Cloud credentials. The documentation explicitly states: "Filter by subject, group, or custom attributes rather than allowing unrestricted access."

The process works through token exchange chaining:
1. Windows workloads use their Active Directory Kerberos credentials
2. Exchange these for OIDC tokens or SAML assertions from ADFS
3. Use Workload Identity Federation to exchange these tokens for short-lived Security Token Service (STS) tokens
4. Optionally impersonate a service account (based on configured rules)

This approach eliminates the need for service account keys while maintaining security through attribute-based access control.

### Why Other Options Are Wrong

- **B:** Allowing ALL principals in the pool to impersonate the service account violates the principle of least privilege and security best practices. Google Cloud documentation recommends using attribute conditions to restrict access, not granting blanket impersonation permissions to all pool members. This creates an overly permissive security posture.

- **C:** Setting up OIDC service "on the same machine" is not the correct architecture for on-premises Active Directory environments. ADFS is the appropriate federation service for Active Directory, not a standalone OIDC service on individual machines. This approach doesn't leverage the existing Active Directory infrastructure and would require deploying and managing OIDC services on each machine.

- **D:** This option combines two problems: using OIDC on individual machines (incorrect for AD environments) AND allowing unrestricted impersonation (violates security best practices). This is the least secure and least architecturally appropriate option.

### References

- [Configure Workload Identity Federation with Active Directory](https://docs.cloud.google.com/iam/docs/workload-identity-federation-with-active-directory)
- [Workload Identity Federation Overview](https://docs.cloud.google.com/iam/docs/workload-identity-federation)
- [Best practices for using Workload Identity Federation](https://docs.cloud.google.com/iam/docs/best-practices-for-using-workload-identity-federation)
