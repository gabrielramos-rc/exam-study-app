# Question 225

**Source:** https://www.examtopics.com/discussions/google/view/117306-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** Cloud Storage, retention policy, bucket lock, compliance

---

## Question

Your organization's record data exists in Cloud Storage. You must retain all record data for at least seven years. This policy must be permanent. What should you do?
## Choices

- **A.** 1. Identify buckets with record data. 2. Apply a retention policy, and set it to retain for seven years. 3. Monitor the bucket by using log-based alerts to ensure that no modifications to the retention policy occurs.
- **B.** 1. Identify buckets with record data. 2. Apply a retention policy, and set it to retain for seven years. 3. Remove any Identity and Access Management (IAM) roles that contain the storage buckets update permission.
- **C.** 1. Identify buckets with record data. 2. Enable the bucket policy only to ensure that data is retained. 3. Enable bucket lock.
- **D.** 1. Identify buckets with record data. 2. Apply a retention policy and set it to retain for seven years. 3. Enable bucket lock. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (6 total)


**Top Comments:**

- (2 upvotes) D is the right choice https://cloud.google.com/storage/docs/bucket-lock

- (1 upvotes) If policy is not permanent the answer would have been A

- (1 upvotes) D. https://cloud.google.com/storage/docs/bucket-lock

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D is correct because it implements the proper sequence to create a permanent retention policy in Cloud Storage:

1. **Identify buckets with record data** - First step is to locate the buckets containing records that need protection
2. **Apply a retention policy and set it to retain for seven years** - This creates a retention policy that prevents objects from being deleted or replaced until they are at least 7 years old
3. **Enable bucket lock** - This is the critical step that makes the policy permanent and irreversible

Bucket Lock is specifically designed for this use case. Once you lock a bucket's retention policy, it becomes permanent and cannot be removed or reduced. According to Google Cloud documentation, "Locking a bucket is an irreversible action. Once you lock a bucket: You cannot remove the retention policy from the bucket. You cannot decrease the retention period for the policy." This ensures the policy requirement to be "permanent" is met.

The combination of retention policy + bucket lock provides compliance assurance for regulatory requirements such as FINRA, SEC, and CFTC that require immutable storage with guaranteed retention periods.

### Why Other Options Are Wrong

- **A:** Monitoring with log-based alerts is reactive and does not prevent modifications. An administrator with sufficient permissions could still modify or remove the retention policy before an alert triggers. This does not satisfy the "permanent" requirement.

- **B:** Removing IAM roles that contain storage.buckets.update permission is insufficient because: (1) permissions could be re-granted later, (2) this doesn't prevent someone with Owner or Organization Admin roles from modifying the policy, and (3) it doesn't provide the same irreversible guarantee as bucket lock. This approach relies on ongoing IAM management rather than a technical control.

- **C:** This option is incorrect because "bucket policy only" is not a Cloud Storage feature. The terminology is confused - Cloud Storage uses "retention policies" not "bucket policies only." Additionally, you cannot enable bucket lock without first setting a retention policy, so the sequence in this option is invalid.

### References

- [Use and lock retention policies | Cloud Storage](https://docs.cloud.google.com/storage/docs/using-bucket-lock)
- [Bucket Lock | Cloud Storage](https://docs.cloud.google.com/storage/docs/bucket-lock)
