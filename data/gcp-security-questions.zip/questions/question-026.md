# Question 026

**Source:** https://www.examtopics.com/discussions/google/view/32698-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** shared responsibility, SaaS, Google Workspace, G Suite, compliance

---

## Question

An organization is migrating from their current on-premises productivity software systems to G Suite. Some network security controls were in place that were mandated by a regulatory body in their region for their previous on-premises system. The organization's risk team wants to ensure that network security controls are maintained and effective in G Suite. A security architect supporting this migration has been asked to ensure that network security controls are in place as part of the new shared responsibility model between the organization and Google Cloud. What solution would help meet the requirements?
## Choices

- **A.** Ensure that firewall rules are in place to meet the required controls.
- **B.** Set up Cloud Armor to ensure that network security controls can be managed for G Suite.
- **C.** Network security is a built-in solution and Google's Cloud responsibility for SaaS products like G Suite. Most Voted
- **D.** Set up an array of Virtual Private Cloud (VPC) networks to control network security as mandated by the relevant regulation.

---

## Community

**Most Voted:** C


**Votes:** B: 33% | C: 67% (3 total)


**Top Comments:**

- (12 upvotes) C is right

- (7 upvotes) This thread suggests option "D" to be the only viable option. Now what ?? https://www.exam-answer.com/migrating-to-gsuite-network-security-controls

- (4 upvotes) Question is asking for Network security group, Hence i will go with Option A

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

For SaaS products like G Suite (now Google Workspace), network security controls are part of Google's responsibility in the shared responsibility model. According to Google Cloud's shared responsibility documentation, "In SaaS, we own the bulk of the security responsibilities." This explicitly includes the underlying network infrastructure and network security controls.

In the SaaS model, the cloud provider maintains responsibility for:
- Network infrastructure and security
- Platform security
- Application security
- Physical infrastructure

The customer's responsibilities in SaaS are limited to:
- Access controls (who can access the service)
- Data management (the data stored in the application)

Unlike IaaS offerings where customers manage firewall rules, VPCs, and other network controls, SaaS products like G Suite have network security built-in and managed by Google. The organization cannot and should not attempt to configure traditional network security controls (firewalls, VPCs, Cloud Armor) for a SaaS product, as these are not customer-configurable in the SaaS delivery model.

### Why Other Options Are Wrong

- **A:** Firewall rules are not customer-configurable for SaaS products like G Suite. Firewall rules apply to IaaS resources like Compute Engine VMs, not to SaaS applications. The organization has no ability to configure firewall rules for G Suite's underlying infrastructure.

- **B:** Cloud Armor is a DDoS protection and WAF service that applies to customer-managed load balancers and applications, not to Google's SaaS products. G Suite already has DDoS protection and security controls built-in as part of Google's responsibility. Customers cannot apply Cloud Armor to G Suite.

- **D:** VPC networks are for IaaS workloads where customers control the network infrastructure. G Suite is a SaaS product that runs on Google's infrastructure, not in customer-managed VPCs. Organizations cannot create VPC networks to control G Suite network security - this fundamentally misunderstands the SaaS delivery model.

### References

- [Shared responsibilities and shared fate on Google Cloud](https://docs.cloud.google.com/architecture/framework/security/shared-responsibility-shared-fate)
