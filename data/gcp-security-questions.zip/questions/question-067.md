# Question 067

**Source:** https://www.examtopics.com/discussions/google/view/30356-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, PII, Cloud Storage, Cloud Functions

---

## Question

A company is backing up application logs to a Cloud Storage bucket shared with both analysts and the administrator. Analysts should only have access to logs that do not contain any personally identifiable information (PII). Log files containing PII should be stored in another bucket that is only accessible by the administrator. What should you do?
## Choices

- **A.** Use Cloud Pub/Sub and Cloud Functions to trigger a Data Loss Prevention scan every time a file is uploaded to the shared bucket. If the scan detects PII, have the function move into a Cloud Storage bucket only accessible by the administrator. Most Voted
- **B.** Upload the logs to both the shared bucket and the bucket only accessible by the administrator. Create a job trigger using the Cloud Data Loss Prevention API. Configure the trigger to delete any files from the shared bucket that contain PII.
- **C.** On the bucket shared with both the analysts and the administrator, configure Object Lifecycle Management to delete objects that contain any PII.
- **D.** On the bucket shared with both the analysts and the administrator, configure a Cloud Storage Trigger that is only triggered when PII data is uploaded. Use Cloud Functions to capture the trigger and delete such files.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (6 total)


**Top Comments:**

- (17 upvotes) Answer A https://codelabs.developers.google.com/codelabs/cloud-storage-dlp-functions#0 https://www.youtube.com/watch?v=0TmO1f-Ox40

- (8 upvotes) A is answer

- (4 upvotes) Ans : A

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A implements the recommended event-driven architecture for automated PII detection and classification documented in Google Cloud's official tutorial "Automating the classification of data uploaded to Cloud Storage." This solution creates a quarantine and classification pipeline that:

1. Uses Cloud Storage Pub/Sub notifications to trigger a Cloud Function (`create_DLP_job`) when files are uploaded to the shared bucket
2. The Cloud Function invokes the Sensitive Data Protection (DLP) API to inspect files for PII (including FIRST_NAME, PHONE_NUMBER, EMAIL_ADDRESS, US_SOCIAL_SECURITY_NUMBER)
3. Based on the scan results, files are automatically moved to the appropriate bucket:
   - Files without PII remain accessible to analysts
   - Files containing PII are moved to the administrator-only bucket

This architecture is designed specifically for organizations dealing with "hundreds or thousands of files a day" where manual classification is impractical. The event-driven approach ensures every uploaded file is automatically scanned and properly segregated based on PII detection, maintaining separation of access without manual intervention.

### Why Other Options Are Wrong

- **B:** Uploading logs to both buckets defeats the purpose of protecting PII, as sensitive data would be exposed to analysts before being deleted. This creates a security window where unauthorized access could occur. Additionally, deleting files wastes storage and creates gaps in the audit trail.

- **C:** Object Lifecycle Management cannot detect or evaluate file content for PII. Lifecycle policies work on object metadata (age, storage class, creation date) not content inspection. There is no mechanism in lifecycle rules to analyze file contents for sensitive data.

- **D:** Cloud Storage triggers cannot detect "when PII data is uploaded" because PII detection requires content inspection by the DLP API. Storage triggers fire on events like object finalization, deletion, or metadata changes—they have no awareness of file contents. This option confuses the trigger mechanism with content analysis capabilities.

### References

- [Automating the classification of data uploaded to Cloud Storage](https://docs.cloud.google.com/sensitive-data-protection/docs/automating-classification-of-data-uploaded-to-cloud-storage)
- [Using Sensitive Data Protection with Cloud Storage](https://docs.cloud.google.com/sensitive-data-protection/docs/dlp-gcs)
- [Sensitive Data Protection overview](https://docs.cloud.google.com/sensitive-data-protection/docs/sensitive-data-protection-overview)
