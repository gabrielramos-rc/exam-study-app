# Question 329

**Source:** https://www.examtopics.com/discussions/google/view/305597-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Cloud Run, Cloud SQL, Cloud SQL Auth Proxy, private connectivity, cross-project

---

## Question

Your organization is implementing a new Python application that will be deployed on Cloud Run. The application needs to connect to a MySQL database that runs on Cloud SQL in a different project in your Google Cloud organization. You must secure the connection from the application to the Cloud SQL instance while minimizing management overhead. What should you do?
## Choices

- **A.** Use a public IP address for the Cloud SQL instance. Integrate the Cloud SQL Python Connector into your application code to connect to the Cloud SQL instance.
- **B.** Ensure that the Cloud SQL instance doesn't have a public IP address. Configure Cloud Run to use Cloud SQL Auth Proxy to connect to the Cloud SQL instance. Most Voted
- **C.** Ensure that the Cloud SQL instance doesn't have a public IP address. Enforce SSL/TLS. Require the use of a trusted client certificate to connect to the Cloud SQL instance.
- **D.** Ensure that the Cloud SQL instance doesn't have a public IP address. Configure the application's IP address as an authorized network to connect to the Cloud SQL instance.

---

## Community

**Most Voted:** B


**Votes:** A: 33% | B: 67% (6 total)


**Top Comments:**

- (2 upvotes) Documentation states: If you're using the Java, Python, or Go languages, then connect with the corresponding connector instead of with the Cloud SQL Auth proxy.

- (2 upvotes) B is correct

- (1 upvotes) The better way to secure connection to Cloud SQL is using Cloud SQL Auth Proxy A is wrong: Exposing your database to the public internet is a major security risk and is not a recommended practice.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud Run provides a built-in integration with Cloud SQL that uses the Cloud SQL Auth Proxy under the hood via Unix sockets. This is the recommended approach for securing connections from Cloud Run to Cloud SQL because it:

1. **Supports cross-project connections**: You can configure Cloud Run to connect to Cloud SQL instances in different projects by specifying the full instance connection name format `PROJECT-ID:REGION:INSTANCE-ID`
2. **Provides automatic encryption**: The Cloud SQL Auth Proxy automatically encrypts connections without requiring manual SSL/TLS certificate management
3. **Uses IAM-based authentication**: The Cloud Run service account is granted the Cloud SQL Client role, enabling secure authentication without embedding database credentials
4. **Minimizes management overhead**: You simply add the Cloud SQL connection in the Cloud Run configuration (via Console or gcloud), and the platform handles the proxy setup automatically through Unix sockets at `/cloudsql/INSTANCE_CONNECTION_NAME`
5. **Eliminates public IP exposure**: The connection works with private IP Cloud SQL instances, keeping database traffic within Google's private network

For cross-project scenarios, you must enable the Cloud SQL Admin API in both projects and grant the Cloud SQL Client IAM role to the Cloud Run service account in the project containing the Cloud SQL instance.

### Why Other Options Are Wrong

- **A:** Using a public IP exposes the database to the internet unnecessarily. While the Python Connector library can encrypt connections, it requires integrating additional code and doesn't minimize management overhead as much as the native Cloud Run integration. Public IPs also increase attack surface and don't align with security best practices.

- **C:** Manually managing SSL/TLS client certificates creates significant management overhead. You must download certificates, upload them to the container, store them securely (potentially using Secret Manager), and handle certificate rotation. This approach is the highest overhead option and contradicts the requirement to minimize management complexity.

- **D:** Cloud Run services don't have static IP addresses by default - they use dynamically assigned IPs. Configuring authorized networks would require using Cloud NAT with static IPs, adding complexity. Additionally, authorized networks only work with public IP instances, contradicting the requirement for private connectivity. This approach provides weak security compared to IAM-based authentication.

### References

- [Connect from Cloud Run to Cloud SQL](https://docs.cloud.google.com/sql/docs/mysql/connect-run)
- [Quickstart: Connect to Cloud SQL for MySQL from Cloud Run](https://docs.cloud.google.com/sql/docs/mysql/connect-instance-cloud-run)
