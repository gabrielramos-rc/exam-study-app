# Question 331

**Source:** https://www.examtopics.com/discussions/google/view/306213-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Binary Authorization, GKE security, container security, vulnerability scanning, CI/CD pipeline, attestation

---

## Question

Your organization uses a microservices architecture based on Google Kubernetes Engine (GKE). Recent security reviews recommend tighter controls around deployed container images to reduce potential vulnerabilities and maintain compliance. You need to implement an automated system by using managed services to ensure that only approved container images are deployed to the GKE clusters. What should you do?
## Choices

- **A.** Develop custom organization policies that restrict GKE cluster deployments to container images hosted within a specific Artifact Registry project where your approved images reside.
- **B.** Enforce Binary Authorization in your GKE clusters. Integrate container image vulnerability scanning into the CI/CD pipeline and require vulnerability scan results to be used for Binary Authorization policy decisions. Most Voted
- **C.** Automatically deploy new container images upon successful CI/CD builds by using Cloud Build triggers. Set up firewall rules to limit and control access to instances to mitigate malware injection.
- **D.** Build a system using third-party vulnerability databases and custom scripts to identify potential Common Vulnerabilities and Exposures (CVEs) in your container images. Prevent image deployment if the CVE impact score is beyond a specified threshold.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (2 total)


**Top Comments:**

- (1 upvotes) B is correct

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Binary Authorization is Google Cloud's managed service specifically designed to enforce deployment policies for container images on GKE. It implements software supply-chain security by preventing unauthorized container deployments through policy-based attestation verification.

The solution described in option B follows Google Cloud's recommended architecture:

1. **Binary Authorization enforcement**: Configured on GKE clusters to check policies at deployment time and either allow compliant images or block non-compliant ones
2. **Vulnerability scanning integration**: Artifact Analysis provides vulnerability information that integrates with Binary Authorization to control deployments
3. **CI/CD pipeline automation**: Cloud Build produces attestations and provenance that Binary Authorization uses for enforcement decisions
4. **Attestation-based control**: During the build process, attestations are created certifying that required activities (like vulnerability scanning) were completed. At deployment time, Binary Authorization uses attestors to verify these digital signatures before allowing deployment

This fully managed approach ensures only approved, vulnerability-scanned images reach production without requiring custom development or third-party tools.

### Why Other Options Are Wrong

- **A:** Organization policies cannot directly enforce container image approval based on vulnerability scans or attestations. They control which projects can be used but don't provide the granular, attestation-based control needed for verifying that images have passed security checks. This doesn't address the requirement for automated validation of approved images.

- **C:** This option only automates deployment after builds succeed but provides no security controls to verify image approval or vulnerability status. Firewall rules protect network access but do not validate container image security or prevent deployment of vulnerable containers. This violates the requirement to ensure only approved images are deployed.

- **D:** Building a custom system with third-party databases and scripts violates the requirement to use managed services. This approach creates maintenance overhead, requires custom development, and doesn't leverage Google Cloud's integrated Binary Authorization platform that already provides this functionality as a managed service.

### References

- [Binary Authorization overview](https://docs.cloud.google.com/binary-authorization/docs/overview)
- [Attestations overview](https://docs.cloud.google.com/binary-authorization/docs/attestations)
