# Question 134

**Source:** https://www.examtopics.com/discussions/google/view/75333-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Cloud Interconnect, restricted.googleapis.com, VPC Service Controls, Private Google Access, on-premises connectivity

---

## Question

You need to set up a Cloud interconnect connection between your company's on-premises data center and VPC host network. You want to make sure that on- premises applications can only access Google APIs over the Cloud Interconnect and not through the public internet. You are required to only use APIs that are supported by VPC Service Controls to mitigate against exfiltration risk to non-supported APIs. How should you configure the network?
## Choices

- **A.** Enable Private Google Access on the regional subnets and global dynamic routing mode.
- **B.** Set up a Private Service Connect endpoint IP address with the API bundle of "all-apis", which is advertised as a route over the Cloud interconnect connection.
- **C.** Use private.googleapis.com to access Google APIs using a set of IP addresses only routable from within Google Cloud, which are advertised as routes over the connection.
- **D.** Use restricted googleapis.com to access Google APIs using a set of IP addresses only routable from within Google Cloud, which are advertised as routes over the Cloud Interconnect connection. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (10 total)


**Top Comments:**

- (13 upvotes) Yes, It is D

- (3 upvotes) Ans: D Note: If you need to restrict users to just the Google APIs and services that support VPC Service Controls, use restricted.googleapis.com. https://cloud.google.com/vpc/docs/configure-private-go

- (2 upvotes) https://cloud.google.com/vpc/docs/configure-private-google-access-hybrid Choose restricted.googleapis.com when you only need access to Google APIs and services that are supported by VPC Service Contro

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The correct answer is **D** because `restricted.googleapis.com` provides the specific security requirements outlined in the question:

1. **VPC Service Controls Integration**: `restricted.googleapis.com` (IP range 199.36.153.4/30) is specifically designed to work with VPC Service Controls and **denies access to Google APIs and services that are not supported by VPC Service Controls**. This directly addresses the requirement to "only use APIs that are supported by VPC Service Controls to mitigate against exfiltration risk."

2. **Private Routing**: The restricted VIP uses IP addresses that are only routable from within Google Cloud's network. These routes can be advertised over Cloud Interconnect connections, ensuring that on-premises applications access Google APIs through the private connection, not the public internet.

3. **Data Exfiltration Mitigation**: According to Google Cloud documentation, restricted.googleapis.com "provides additional risk mitigation for data exfiltration" by limiting access to only VPC Service Controls-supported APIs, preventing potential data leakage to non-supported APIs.

4. **Cloud Interconnect Compatibility**: The restricted API routes can be announced to on-premises networks through Cloud Router's custom advertisement mode when using Cloud Interconnect, providing seamless private connectivity.

### Why Other Options Are Wrong

- **A**: Private Google Access is designed for VPC resources (not on-premises hosts) to access Google APIs without external IP addresses. It does not restrict access to only VPC Service Controls-supported APIs and does not provide the same data exfiltration protection. This option doesn't meet the requirement to "only use APIs that are supported by VPC Service Controls."

- **B**: Private Service Connect with "all-apis" bundle allows access to ALL Google APIs, which violates the requirement to "only use APIs that are supported by VPC Service Controls." The "all-apis" bundle does not provide the selective filtering needed to mitigate exfiltration risk to non-supported APIs.

- **C**: `private.googleapis.com` provides private access to Google APIs but does **not** integrate with VPC Service Controls and does **not** restrict access to only VPC Service Controls-supported APIs. It allows access to all Google APIs privately, failing to meet the data exfiltration mitigation requirement for non-supported APIs.

### References

- [Set up private connectivity to Google APIs and services | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/set-up-private-connectivity)
- [Private Google Access with VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/private-connectivity)
- [Overview of VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/overview)
