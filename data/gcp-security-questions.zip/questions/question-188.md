# Question 188

**Source:** https://www.examtopics.com/discussions/google/view/117224-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.3 - Ensuring security of workloads (for example, containers, VM)
**Tags:** container security, vulnerability scanning, Artifact Registry, GKE

---

## Question

A company is using Google Kubernetes Engine (GKE) with container images of a mission-critical application. The company wants to scan the images for known security issues and securely share the report with the security team without exposing them outside Google Cloud. What should you do?
## Choices

- **A.** 1. Enable Container Threat Detection in the Security Command Center Premium tier. 2. Upgrade all clusters that are not on a supported version of GKE to the latest possible GKE version. 3. View and share the results from the Security Command Center.
- **B.** 1. Use an open source tool in Cloud Build to scan the images. 2. Upload reports to publicly accessible buckets in Cloud Storage by using gsutil. 3. Share the scan report link with your security department.
- **C.** 1. Enable vulnerability scanning in the Artifact Registry settings. 2. Use Cloud Build to build the images. 3. Push the images to the Artifact Registry for automatic scanning. 4. View the reports in the Artifact Registry. Most Voted
- **D.** 1. Get a GitHub subscription. 2. Build the images in Cloud Build and store them in GitHub for automatic scanning. 3. Download the report from GitHub and share with the Security Team.

---

## Community

**Most Voted:** C


**Votes:** A: 22% | C: 78% (9 total)


**Top Comments:**

- (6 upvotes) Option A involves enabling Container Threat Detection in the Security Command Center Premium tier, upgrading clusters, and viewing and sharing results from the Security Command Center. While this opti

- (2 upvotes) i am going with option C all things considered like cost, time and all. option A sounds sound but to implement we need to update the tier and the security issues are already known so not worth it with

- (2 upvotes) https://cloud.google.com/security-command-center/docs/concepts-container-threat-detection-overview

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Artifact Registry provides built-in, automatic vulnerability scanning for container images that is the recommended Google Cloud-native solution for this use case. When you enable vulnerability scanning in Artifact Registry settings, the scanning process is triggered automatically every time you push a new image to Artifact Registry. The system scans for vulnerabilities in OS packages and application language packages (Python, Node.js, Java, Go), and the vulnerability information is continuously updated when new vulnerabilities are discovered.

This solution meets all requirements:
- **Scans images for known security issues**: Artifact Analysis automatically scans container images and detects vulnerabilities
- **Securely shares reports**: Results can be viewed directly in the Artifact Registry console within Google Cloud, keeping all data internal
- **No external exposure**: Everything stays within Google Cloud's secure environment
- **Integrated workflow**: Works seamlessly with Cloud Build and GKE deployment pipelines

The scanning is automatic, requires minimal configuration, and provides continuous monitoring with a default 30-day window that can be extended by pulling or pushing the image.

### Why Other Options Are Wrong

- **A:** Container Threat Detection in Security Command Center Premium focuses on runtime threat detection for running containers, not static image vulnerability scanning. It also requires upgrading clusters unnecessarily and is more expensive than the built-in Artifact Registry scanning. While SCC can aggregate vulnerability findings from Artifact Registry, enabling it as the primary scanning mechanism is not the most direct or cost-effective approach.

- **B:** Uploading reports to publicly accessible buckets directly violates the requirement to "securely share the report...without exposing them outside Google Cloud." Public buckets expose data to the internet. Additionally, using third-party open source tools adds maintenance overhead and complexity compared to the native Google Cloud solution.

- **D:** Storing images in GitHub moves them outside Google Cloud entirely, which contradicts the requirement to keep everything within Google Cloud. This also introduces unnecessary complexity, external dependencies, and potential security risks by managing images outside your GCP environment.

### References

- [Artifact analysis and vulnerability scanning | Artifact Registry](https://docs.cloud.google.com/artifact-registry/docs/analysis)
- [Container scanning overview | Artifact Analysis](https://docs.cloud.google.com/artifact-analysis/docs/container-scanning-overview)
- [Enable or disable automatic scanning | Artifact Analysis](https://docs.cloud.google.com/artifact-analysis/docs/enable-automatic-scanning)
