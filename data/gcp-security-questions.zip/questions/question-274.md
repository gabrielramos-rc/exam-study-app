# Question 274

**Source:** https://www.examtopics.com/discussions/google/view/147068-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, PII, healthcare data, compliance, data residency

---

## Question

Your EU-based organization stores both Personally Identifiable Information (PII) and non-PII data in Cloud Storage buckets across multiple Google Cloud regions. EU data privacy laws require that the PII data must not be stored outside of the EU. To help meet this compliance requirement, you want to detect if Cloud Storage buckets outside of the EU contain healthcare data. What should you do?
## Choices

- **A.** Create a Sensitive Data Protection job. Specify the infoType of data to be detected and run the job across all Google Cloud Storage buckets. Most Voted
- **B.** Create a log sink with a filter on resourceLocation.currentLocations. Trigger an alert if a log message appears with a non- EUcountry.
- **C.** Activate Security Command Center Premium. Use compliance monitoring to detect resources that do not follow the applicable healthcare regulation.
- **D.** Enforce the gcp.resourceLocations organization policy and add "EU" in a custom rule that only applies on resources with the tag "healthcare".

---

## Community

**Most Voted:** A


**Votes:** A: 75% | C: 25% (4 total)


**Top Comments:**

- (1 upvotes) Answer should be C. A - a data protection job just finds data that might contain PII. If you run it on all buckets in all regions, that won't confirm with the requirements of detecting buckets outside

- (1 upvotes) Definitely A

- (1 upvotes) Specifying the info Type of data to be detected allows to find storage buckets outside the EU that contain healthcare data.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Sensitive Data Protection (formerly Cloud DLP) is specifically designed to discover, classify, and protect sensitive data like PII and healthcare information across Google Cloud Storage buckets. To detect healthcare data in Cloud Storage buckets outside the EU, you should create a Sensitive Data Protection inspection job with the following capabilities:

1. **Organization-wide or folder-level scanning**: You can configure data profiling to scan Cloud Storage buckets across your entire organization or specific folders, covering multiple regions automatically.

2. **InfoType specification**: Sensitive Data Protection provides over 100 built-in infoType detectors, including healthcare-specific detectors (like medical record numbers, health insurance information, etc.) and general PII detectors. You specify which infoTypes to detect (healthcare data in this case).

3. **Multi-region support**: The service respects data residency by processing data in the region where it resides. You can use a global-region inspection template or create dedicated templates for each region. The service scans buckets across all regions and generates findings for each location.

4. **Discovery and profiling**: For scanning multiple buckets across the organization, Sensitive Data Protection's discovery service automatically profiles Cloud Storage data and identifies sensitive information. While data profiles are stored in the same region as the data (for residency compliance), you can export findings to BigQuery for a consolidated cross-region view.

5. **Automated detection**: Once configured, the job continuously scans for specified data types and provides detailed reports showing exactly which buckets contain healthcare data and their locations, allowing you to identify compliance violations (healthcare data stored outside EU).

This directly addresses the requirement to detect if Cloud Storage buckets outside of the EU contain healthcare data.

### Why Other Options Are Wrong

- **B:** Creating a log sink with filters on resourceLocation provides information about where resources are located, but it doesn't inspect the actual content of Cloud Storage buckets to determine if they contain healthcare data or PII. It only tells you where buckets exist, not what sensitive data they contain. This is a location monitoring solution, not a data classification solution.

- **C:** Security Command Center Premium provides compliance monitoring and security posture management, but it focuses on configuration compliance (whether resources follow security policies) rather than content inspection. SCC doesn't perform deep data scanning to detect specific types of sensitive data like healthcare information within Cloud Storage objects. It can show you which regions have resources, but not whether those resources contain healthcare data.

- **D:** The gcp.resourceLocations organization policy is a preventive control that restricts where new resources can be created. While useful for preventing future violations, it doesn't help you detect existing healthcare data that may already be stored in buckets outside the EU. It's a preventive control, not a detective control. Additionally, it doesn't inspect bucket contents to determine if they contain healthcare data—it only controls resource placement.

### References

- [Using Sensitive Data Protection with Cloud Storage](https://docs.cloud.google.com/sensitive-data-protection/docs/dlp-gcs)
- [Profile Cloud Storage data in an organization or folder](https://docs.cloud.google.com/sensitive-data-protection/docs/profile-org-folder-cloud-storage)
- [Sensitive Data Protection overview](https://docs.cloud.google.com/sensitive-data-protection/docs/sensitive-data-protection-overview)
- [Learn about your data through discovery and inspection](https://docs.cloud.google.com/sensitive-data-protection/docs/learn-about-your-data)
