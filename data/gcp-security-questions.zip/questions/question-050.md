# Question 050

**Source:** https://www.examtopics.com/discussions/google/view/25411-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** load balancer, SSL Proxy, TLS termination, Compute Engine

---

## Question

Your company has deployed an application on Compute Engine. The application is accessible by clients on port 587. You need to balance the load between the different instances running the application. The connection should be secured using TLS, and terminated by the Load Balancer. What type of Load Balancing should you use?
## Choices

- **A.** Network Load Balancing
- **B.** HTTP(S) Load Balancing
- **C.** TCP Proxy Load Balancing
- **D.** SSL Proxy Load Balancing Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (1 total)


**Top Comments:**

- (19 upvotes) Answer D https://cloud.google.com/load-balancing/docs/ssl - SSL Proxy Load Balancing is a reverse proxy load balancer that distributes SSL traffic coming from the internet to virtual machine (VM) inst

- (6 upvotes) We can use an HTTPS load balancer and change the backend services port to 587 .\| HTTPS load balacer will also work

- (2 upvotes) accessible by client on port 587 is the power word. Agree with D

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

SSL Proxy Load Balancing is the correct choice for this scenario because it provides TLS termination at the load balancer for non-HTTP(S) protocols on any port (1-65535), including port 587.

Key requirements satisfied by SSL Proxy Load Balancer:
- **TLS termination at the load balancer**: SSL Proxy load balancers terminate SSL/TLS connections from clients at the load balancing layer, then establish new connections to backend instances (either encrypted or unencrypted)
- **Port 587 support**: SSL Proxy supports all valid ports from 1-65535, making it suitable for port 587 (commonly used for SMTP submission with STARTTLS)
- **Global load balancing**: SSL Proxy is a global external proxy Network Load Balancer that can distribute traffic across multiple regions
- **Non-HTTP protocol**: Unlike HTTP(S) load balancing which is designed for HTTP/HTTPS traffic, SSL Proxy handles TCP traffic with TLS encryption

The load balancer manages SSL certificates, performs the TLS handshake with clients, and can then forward traffic to backends using either SSL (recommended) or TCP.

### Why Other Options Are Wrong

- **A. Network Load Balancing:** Network Load Balancing is a passthrough load balancer that does not terminate TLS connections. It operates at Layer 4 and simply forwards packets to backends without decrypting them, which doesn't meet the requirement for TLS termination at the load balancer.

- **B. HTTP(S) Load Balancing:** While HTTP(S) Load Balancing does terminate TLS, it is specifically designed for HTTP and HTTPS traffic (Layer 7). Port 587 is not an HTTP port, and HTTP(S) load balancers are intended for web applications, not general TCP protocols.

- **C. TCP Proxy Load Balancing:** TCP Proxy Load Balancing handles unencrypted TCP traffic. While it can proxy TCP connections, it does not provide TLS termination. It's designed for scenarios where SSL/TLS is handled by the backend instances or not required at all.

### References

- [Proxy Network Load Balancer overview](https://docs.cloud.google.com/load-balancing/docs/proxy-network-load-balancer)
- [Set up a global external proxy Network Load Balancer (SSL proxy)](https://docs.cloud.google.com/load-balancing/docs/tcp/set-up-global-ext-proxy-ssl)
- [External proxy Network Load Balancer overview](https://docs.cloud.google.com/load-balancing/docs/tcp)
