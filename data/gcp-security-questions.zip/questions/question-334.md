# Question 334

**Source:** https://www.examtopics.com/discussions/google/view/311199-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.3 - Securing AI workloads
**Tags:** Vertex AI, VPC Service Controls, Sensitive Data Protection, DLP API, Gemini, data exfiltration

---

## Question

Your organization is using AI to improve products through innovation. The developers want to use Gemini in Vertex AI on a project. You need to provide a secure Google Cloud environment to prevent and detect information leakages. What should you do?
## Choices

- **A.** Set up VPC Service Controls perimeters around the Vertex AI project. Enable Data Loss Prevention API for content inspection. Most Voted
- **B.** Grant the developers and AI engineers the Vertex AI User role. Monitor the audit trails with Cloud Logging.
- **C.** Deploy Model Armor to protect the Vertex AI endpoint. Review Security Command Center findings to detect information leakages.
- **D.** Implement a firewall rule that allows all traffic to and from the Vertex AI API endpoint.

---

## Community

**Most Voted:** A


**Votes:** A: 50% | C: 50% (2 total)


**Top Comments:**

- (1 upvotes) A. is the most effective and comprehensive solution for preventing and detecting data leakage. VPC Service Controls is the primary tool for preventing data exfiltration by creating a secure perimeter 

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A provides the most comprehensive security approach for preventing and detecting information leakage in Vertex AI:

**VPC Service Controls (VPC-SC)** creates a security perimeter around the Vertex AI project that prevents data exfiltration by:
- Blocking unauthorized access to ML artifacts (training data, models, inference requests/results, and Gemini models) from leaving the secure environment
- Automatically blocking public internet access to Vertex AI APIs once the perimeter is established
- Restricting outbound traffic from Vertex AI services to external third-party APIs and internet services
- Providing granular control over API access and explicitly restricting public internet exposure

**Data Loss Prevention API (Sensitive Data Protection)** complements VPC-SC by:
- Generating data profiles that reveal sensitivity and data risk levels of training data
- Detecting sensitive information types (infoTypes) like driver's license IDs and email addresses within training datasets
- Enabling content inspection for proactive detection of information leakage
- Integrating with Security Command Center to provide comprehensive security posture evaluation
- Supporting deep inspection capabilities when sensitive data is detected

This combination addresses both **prevention** (VPC-SC blocks exfiltration paths) and **detection** (DLP API identifies sensitive content), which is exactly what the question requires. According to Google Cloud documentation, VPC Service Controls specifically protects Gemini models from leaving the service perimeter, and DLP addresses "the critical risk of sensitive data leakage, in case the model has access to sensitive data."

### Why Other Options Are Wrong

- **B:** While granting appropriate IAM roles and monitoring audit logs are important security practices, they do not actively prevent data exfiltration or provide content-level inspection for sensitive information. Audit logs are reactive (detecting after the fact) rather than preventative, and IAM roles alone don't create the boundary controls needed to prevent information leakage.

- **C:** Model Armor is not a real Google Cloud service or product. This appears to be a fabricated option. While Security Command Center is a legitimate tool for security findings, it cannot prevent data exfiltration on its own without perimeter controls like VPC Service Controls in place.

- **D:** Implementing a firewall rule that allows all traffic to and from the Vertex AI API endpoint is the opposite of what's needed for security. This would expose the Vertex AI environment to the public internet and increase the risk of information leakage, rather than preventing it. Firewall rules should restrict traffic, not allow all traffic.

### References

- [VPC Service Controls with Vertex AI](https://docs.cloud.google.com/vertex-ai/docs/general/vpc-service-controls)
- [Sensitive data discovery for Vertex AI](https://docs.cloud.google.com/sensitive-data-protection/docs/discovery-for-vertex-ai)
- [Profile Vertex AI data in a single project](https://docs.cloud.google.com/sensitive-data-protection/docs/profile-project-vertex-ai)
- [Security controls for Vertex AI](https://docs.cloud.google.com/vertex-ai/docs/general/vertexai-security-controls)
