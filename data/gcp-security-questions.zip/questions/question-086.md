# Question 086

**Source:** https://www.examtopics.com/discussions/google/view/30376-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Audit Logs, admin activity logs, service account, security investigation

---

## Question

You are part of a security team investigating a compromised service account key. You need to audit which new resources were created by the service account. What should you do?
## Choices

- **A.** Query Data Access logs.
- **B.** Query Admin Activity logs. Most Voted
- **C.** Query Access Transparency logs.
- **D.** Query Stackdriver Monitoring Workspace.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (12 total)


**Top Comments:**

- (14 upvotes) Shouldn't it be A? The question is about which resources were created by the SA. B (Admin Activity logs) cannot view this. It is only for user's activity such as create, modify or delete a particular 

- (10 upvotes) B is right . Agree with your explanation

- (6 upvotes) Agree with B

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Admin Activity logs are the correct choice for auditing new resources created by a compromised service account. These logs automatically capture all "user-driven API calls or other actions that modify the configuration or metadata of resources," including resource creation operations such as:

- Creating VM instances
- Creating Cloud Storage buckets
- Creating databases or other GCP services
- Any configuration changes or metadata modifications

Admin Activity logs have several key advantages for security investigations:

1. **Always enabled**: They are automatically written and cannot be disabled, ensuring complete audit coverage
2. **No configuration required**: Unlike Data Access logs, they don't need to be explicitly enabled
3. **No additional cost**: They are stored in the _Required bucket at no charge
4. **Capture write operations**: They specifically track creation and modification actions

To investigate the compromised service account, you would filter Admin Activity logs using the service account's email address in the `protoPayload.authenticationInfo.principalEmail` field to see all resources it created.

### Why Other Options Are Wrong

- **A. Query Data Access logs**: Data Access logs track read operations (reading configuration or metadata of resources), not resource creation. They record when resources are accessed or read, not when they are created. Additionally, Data Access logs are disabled by default and would need to have been explicitly enabled before the compromise occurred.

- **C. Query Access Transparency logs**: Access Transparency logs record actions taken by Google personnel when accessing customer content for support purposes. They do not track actions taken by customer service accounts or users. These logs are only relevant for tracking Google employee access, not service account activity.

- **D. Query Stackdriver Monitoring Workspace**: Stackdriver Monitoring (now Cloud Monitoring) is used for metrics, performance monitoring, and alerting, not for auditing API calls or resource creation activities. It tracks resource utilization and health, not who created what resources.

### References

- [Cloud Audit Logs overview](https://docs.cloud.google.com/logging/docs/audit)
- [Identity and Access Management audit logging](https://docs.cloud.google.com/iam/docs/audit-logging)
