# Question 149

**Source:** https://www.examtopics.com/discussions/google/view/79833-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, service perimeter, access level, dry run mode

---

## Question

You want to update your existing VPC Service Controls perimeter with a new access level. You need to avoid breaking the existing perimeter with this change, and ensure the least disruptions to users while minimizing overhead. What should you do?
## Choices

- **A.** Create an exact replica of your existing perimeter. Add your new access level to the replica. Update the original perimeter after the access level has been vetted.
- **B.** Update your perimeter with a new access level that never matches. Update the new access level to match your desired state one condition at a time to avoid being overly permissive.
- **C.** Enable the dry run mode on your perimeter. Add your new access level to the perimeter configuration. Update the perimeter configuration after the access level has been vetted.
- **D.** Enable the dry run mode on your perimeter. Add your new access level to the perimeter dry run configuration. Update the perimeter configuration after the access level has been vetted. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (9 total)


**Top Comments:**

- (6 upvotes) D. Enable the dry run mode on your perimeter. Add your new access level to the perimeter dry run configuration. Update the perimeter configuration after the access level has been vetted.

- (5 upvotes) Answers are BOTH C&amp;D... The problem I have is that both answers say the same thing...why such a question.

- (1 upvotes) D seems to be correct. https://cloud.google.com/vpc-service-controls/docs/manage-dry-run-configurations#updating_a_dry_run_configuration

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The correct approach is to enable dry run mode on your perimeter and add your new access level to the perimeter's **dry run configuration** specifically. This is the officially documented method for safely testing perimeter changes without disrupting users.

According to Google Cloud documentation, while you can create a dry run configuration for a perimeter, access levels themselves do not have a dry run configuration. To test how a new or modified access level would affect your perimeter, you must:

1. Create the new access level as a regular access level resource
2. Enable dry run mode on your perimeter
3. Add the new access level to the perimeter's **dry run configuration** (not the enforced configuration)
4. Monitor logs to see what would be blocked if the dry run configuration were enforced
5. After vetting and confirming no issues, enforce the dry run configuration to replace the current enforced configuration

This workflow allows you to see the impact of the access level change through logging without actually denying any requests. Requests that violate the dry run configuration are logged but not denied, giving you visibility into potential disruptions before making changes permanent.

The key distinction is that you add the access level to the **dry run configuration** of the perimeter, not to the enforced configuration directly. This minimizes risk and overhead while ensuring no user disruption during testing.

### Why Other Options Are Wrong

- **A.** Creating a complete replica of the perimeter is unnecessary overhead and doesn't leverage the built-in dry run mode feature. This approach would be more complex to manage and doesn't follow Google Cloud best practices for testing perimeter changes.

- **B.** Adding an access level "that never matches" and updating it incrementally is not a documented pattern and creates unnecessary complexity. This approach is error-prone and doesn't provide the logging visibility that dry run mode offers. Additionally, modifying an existing access level affects all perimeters using it, which could be risky.

- **C.** This option incorrectly suggests adding the new access level to the perimeter configuration (the enforced configuration) rather than the dry run configuration. This would immediately enforce the new access level and could cause disruptions, defeating the purpose of testing. The whole point of dry run mode is to test changes in the dry run configuration before promoting them to the enforced configuration.

### References

- [Dry run mode for service perimeters | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/dry-run-mode)
- [Manage dry run configurations | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/manage-dry-run-configurations)
