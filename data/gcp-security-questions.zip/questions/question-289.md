# Question 289

**Source:** https://www.examtopics.com/discussions/google/view/147083-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** CMEK, CSEK, Cloud Storage, IAM, Audit Logs

---

## Question

You work for an organization that handles sensitive customer data. You must secure a series of Google Cloud Storage buckets housing this data and meet these requirements:
- Multiple teams need varying access levels (some read-only, some read-write).
- Data must be protected in storage and at rest.
- It's critical to track file changes and audit access for compliance purposes.
- For compliance purposes, the organization must have control over the encryption keys.

What should you do?

## Choices

- **A.** Create IAM groups for each team and manage permissions at the group level. Employ server-side encryption and Object Versioning by Google Cloud Storage. Configure cloud monitoring tools to alert on anomalous data access patterns.
- **B.** Set individual permissions for each team and apply access control lists (ACLs) to each bucket and file. Enforce TLS encryption for file transfers. Enable Object Versioning and Cloud Audit Logs for the storage buckets.
- **C.** Use predefined IAM roles tailored to each team's access needs, such as Storage Object Viewer and Storage Object User. Utilize customer-supplied encryption keys (CSEK) and enforce TLS encryption. Turn on both Object Versioning and Cloud Audit Logs for the storage buckets. Most Voted
- **D.** Assign IAM permissions for all teams at the object level. Implement third-party software to encrypt data at rest. Track data access by using network logs.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (7 total)


**Top Comments:**

- (3 upvotes) I agree. Only C satisfies all requirements above.

- (2 upvotes) I think it's C.

- (1 upvotes) This approach ensures that: Access Control: IAM roles are tailored to each team's needs, providing the principle of least privilege. Data Protection: Customer-supplied encryption keys (CSEK) give your

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C correctly addresses all four requirements with Google Cloud best practices:

1. **Multiple teams with varying access levels**: Predefined IAM roles like Storage Object Viewer (read-only) and Storage Object User (read-write) follow the principle of least privilege. IAM roles are the recommended approach for managing Cloud Storage access, as they can be granted at the project, bucket, or managed folder level for granular control.

2. **Control over encryption keys**: Customer-supplied encryption keys (CSEK) provide complete customer control over encryption keys. With CSEK, you provide your own AES-256 encryption key for each operation, and Google does not permanently store or manage your keys - they are purged from servers after each operation completes. This satisfies the compliance requirement for the organization to control encryption keys.

3. **Track file changes**: Object Versioning enables tracking of all changes to objects. When enabled, Cloud Storage maintains noncurrent versions of objects, allowing you to track the complete history of file changes and recover specific versions when needed.

4. **Audit access for compliance**: Cloud Audit Logs provides comprehensive tracking of "who did what, where, and when" for Cloud Storage operations. Admin Activity logs track configuration changes (bucket creation, IAM policy modifications), while Data Access logs (which must be explicitly enabled) track reads and writes to user data, meeting compliance audit requirements.

5. **TLS encryption**: Enforcing TLS (HTTPS) is mandatory when using CSEK and protects data in transit during read and write operations.

### Why Other Options Are Wrong

- **A:** While it uses IAM groups (a good practice) and Object Versioning, it relies on default Google-managed server-side encryption rather than customer-controlled encryption keys. The requirement explicitly states "the organization must have control over the encryption keys." Cloud monitoring alerts for anomalous patterns don't replace the comprehensive audit trail provided by Cloud Audit Logs.

- **B:** Uses ACLs instead of IAM roles. Google Cloud documentation states that IAM is the recommended method for access control, not ACLs. ACLs are a legacy access control system with limited capabilities. Setting individual permissions per team and managing ACLs at both bucket and file level creates unnecessary management overhead and doesn't follow the principle of least privilege through predefined roles. While it includes Object Versioning and Cloud Audit Logs, the access control approach is not best practice.

- **D:** Object-level IAM permissions create significant management overhead and complexity. Third-party encryption software is unnecessary when Google Cloud provides native encryption options (CSEK/CMEK) and introduces additional complexity, potential security vulnerabilities, and vendor dependencies. Network logs do not provide the comprehensive audit trail for data access that Cloud Audit Logs provides - they show network traffic but not the detailed "who accessed which object when" information required for compliance.

### References

- [Customer-supplied encryption keys | Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption/customer-supplied-keys)
- [Data encryption options | Cloud Storage](https://docs.cloud.google.com/storage/docs/encryption)
- [IAM roles for Cloud Storage](https://docs.cloud.google.com/storage/docs/access-control/iam-roles)
- [Access control best practices | Cloud Storage](https://docs.cloud.google.com/storage/docs/access-control/best-practices-access-control)
- [Cloud Audit Logs with Cloud Storage](https://docs.cloud.google.com/storage/docs/audit-logging)
- [Object Versioning | Cloud Storage](https://docs.cloud.google.com/storage/docs/object-versioning)
