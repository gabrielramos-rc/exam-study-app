# Question 139

**Source:** https://www.examtopics.com/discussions/google/view/84278-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, PII, Cloud Storage, Cloud Functions

---

## Question

You are backing up application logs to a shared Cloud Storage bucket that is accessible to both the administrator and analysts. Analysts should not have access to logs that contain any personally identifiable information (PII). Log files containing PII should be stored in another bucket that is only accessible to the administrator. What should you do?
## Choices

- **A.** Upload the logs to both the shared bucket and the bucket with PII that is only accessible to the administrator. Use the Cloud Data Loss Prevention API to create a job trigger. Configure the trigger to delete any files that contain PII from the shared bucket.
- **B.** On the shared bucket, configure Object Lifecycle Management to delete objects that contain PII.
- **C.** On the shared bucket, configure a Cloud Storage trigger that is only triggered when PII is uploaded. Use Cloud Functions to capture the trigger and delete the files that contain PII.
- **D.** Use Pub/Sub and Cloud Functions to trigger a Cloud Data Loss Prevention scan every time a file is uploaded to the administrator's bucket. If the scan does not detect PII, have the function move the objects into the shared Cloud Storage bucket. Most Voted

---

## Community

**Most Voted:** D


**Votes:** A: 17% | D: 83% (6 total)


**Top Comments:**

- (8 upvotes) Answer is D

- (7 upvotes) A is correct. A. Ensures that PII is always stored securely and then removes PII from the less secure location. D is incorrect because the approach is overly complex and inefficient. It requires unnec

- (3 upvotes) Answer is D

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D follows Google Cloud's recommended architecture pattern for automated PII detection and data segregation. The approach implements a "scan-before-share" model where:

1. **All logs are uploaded to the administrator's bucket first** - This ensures PII-containing files never reach the shared bucket where analysts have access
2. **Cloud Storage triggers a Cloud Function on upload** - Using Pub/Sub notifications when files are created in the admin bucket
3. **Sensitive Data Protection (DLP) scans each file** - The function triggers a DLP inspection job to detect PII using built-in infoType detectors
4. **Non-PII files are moved to the shared bucket** - Only files that pass the PII scan are promoted to the analyst-accessible bucket
5. **PII files remain in the admin-only bucket** - Files containing PII stay segregated with proper access controls

This architecture prevents analysts from ever accessing PII data, even temporarily. The documentation specifically mentions implementing "an automated data quarantine and classification system using Sensitive Data Protection, Cloud Storage, and Cloud Run functions" as a recommended pattern. By scanning before sharing rather than uploading and then deleting, you avoid the security risk of PII being exposed during the detection window.

### Why Other Options Are Wrong

- **A:** This approach uploads files to BOTH buckets simultaneously, meaning PII is exposed in the shared bucket until the job trigger runs and deletes it. This creates a security window where analysts could access PII. Additionally, DLP job triggers run on a schedule (periodic basis), not immediately on upload, extending this exposure window.

- **B:** Object Lifecycle Management cannot detect PII content. Lifecycle policies operate on metadata like age, creation date, storage class, or number of newer versions - not file contents. There is no way to configure lifecycle rules to inspect file contents for sensitive data.

- **C:** Cloud Storage triggers cannot be configured to fire "only when PII is uploaded." Storage triggers fire on object events (create, delete, archive) based on object metadata, not content. You cannot determine if PII exists without first scanning the file content with DLP, so this condition is impossible to implement.

### References

- [Using Sensitive Data Protection with Cloud Storage](https://docs.cloud.google.com/sensitive-data-protection/docs/dlp-gcs)
- [Inspecting Cloud Storage for sensitive data](https://docs.cloud.google.com/sensitive-data-protection/docs/inspecting-storage)
- [Jobs and job triggers - Sensitive Data Protection](https://cloud.google.com/sensitive-data-protection/docs/concepts-job-triggers)
