# Question 200

**Source:** https://www.examtopics.com/discussions/google/view/117238-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** CMEK, customer-managed encryption keys, organization policy, Cloud Storage

---

## Question

Your company must follow industry specific regulations. Therefore, you need to enforce customer-managed encryption keys (CMEK) for all new Cloud Storage resources in the organization called org1.

What command should you execute?

## Choices

- **A.** • organization poli-cy:constraints/gcp.restrictStorageNonCmekServices • binding at: org1 • policy type: allow • policy value: all supported services
- **B.** • organization policy: con-straints/gcp.restrictNonCmekServices • binding at: org1 • policy type: deny • policy value: storage.googleapis.com Most Voted
- **C.** • organization policy: con-straints/gcp.restrictStorageNonCmekServices • binding at: org1 • policy type: deny • policy value: storage.googleapis.com
- **D.** • organization policy: con-straints/gcp.restrictNonCmekServices • binding at: org1 • policy type: allow • policy value: storage.googleapis.com

---

## Community

**Most Voted:** B


**Votes:** B: 91% | D: 9% (11 total)


**Top Comments:**

- (2 upvotes) Policy Name: constraints/gcp.restrictNonCmekServices: This policy ensures that resources in specified Google Cloud services (e.g., Cloud Storage) cannot be created without enabling CMEK. It also preve

- (2 upvotes) https://cloud.google.com/kms/docs/cmek-org-policy#require-cmek

- (1 upvotes) B. Existing non-CMEK Google Cloud resources must be reconfigured or recreated manually to ensure enforcement. constraints/gcp.restrictNonCmekServices

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

The correct organization policy configuration to enforce CMEK for all new Cloud Storage resources is:
- **Constraint:** `constraints/gcp.restrictNonCmekServices`
- **Policy type:** Deny
- **Value:** `storage.googleapis.com`

This constraint requires that new and rewritten objects must be encrypted using customer-managed encryption keys (CMEK), and requires new buckets to set a Cloud KMS key as the default encryption key. When you configure this constraint with a "Deny" policy type and specify `storage.googleapis.com`, it blocks the creation of Cloud Storage resources unless CMEK protection is specified.

The constraint works by denying operations on services listed in the policy value unless those operations use CMEK. By setting it to deny `storage.googleapis.com`, you effectively require CMEK for all Cloud Storage operations within the organization.

### Why Other Options Are Wrong

- **A:** Uses an incorrect constraint name `constraints/gcp.restrictStorageNonCmekServices` (does not exist) and uses "allow" policy type with "all supported services" which would not enforce CMEK specifically for Storage.

- **C:** Uses an incorrect constraint name `constraints/gcp.restrictStorageNonCmekServices`. The correct constraint is `constraints/gcp.restrictNonCmekServices` (without "Storage" in the middle). While the policy type (deny) and value (storage.googleapis.com) are correct, the constraint name is wrong.

- **D:** Uses the correct constraint name but incorrect policy type. Using "allow" with `storage.googleapis.com` would permit non-CMEK operations on Storage, which is the opposite of what's required. The deny policy type is necessary to block non-CMEK operations.

### References

- [CMEK organization policies | Cloud KMS Documentation](https://docs.cloud.google.com/kms/docs/cmek-org-policy)
- [Organization policy constraints for Cloud Storage](https://docs.cloud.google.com/storage/docs/org-policy-constraints)
