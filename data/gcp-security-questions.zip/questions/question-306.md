# Question 306

**Source:** https://www.examtopics.com/discussions/google/view/148661-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Security Command Center, Security Health Analytics, Cloud KMS, key rotation, compliance monitoring

---

## Question

You must ensure that the keys used for at-rest encryption of your data are compliant with your organization's security controls. One security control mandates that keys get rotated every 90 days. You must implement an effective detection strategy to validate if keys are rotated as required. What should you do?
## Choices

- **A.** Analyze the crypto key versions of the keys by using data from Cloud Asset Inventory. If an active key is older than 90 days, send an alert message through your incident notification channel.
- **B.** Assess the keys in the Cloud Key Management Service by implementing code in Cloud Run. If a key is not rotated after 90 days, raise a finding in Security Command Center.
- **C.** Define a metric that checks for timely key updates by using Cloud Logging. If a key is not rotated after 90 days, send an alert message through your incident notification channel.
- **D.** Identify keys that have not been rotated by using Security Health Analytics. If a key is not rotated after 90 days, a finding in Security Command Center is raised. Most Voted

---

## Community

**Most Voted:** D


**Votes:** A: 23% | D: 77% (13 total)


**Top Comments:**

- (4 upvotes) VOTE A

- (3 upvotes) Why A is Correct: Cloud Asset Inventory: Cloud Asset Inventory offers a detailed view of cryptographic keys, including the age of each key version. By periodically analyzing this data, you can determi

- (2 upvotes) https://cloud.google.com/secret-manager/docs/analyze-resources?hl=es-419

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Security Health Analytics (SHA) in Security Command Center has a built-in detector specifically designed to monitor Cloud KMS key rotation compliance. The detector is called "KMS key not rotated" (API category: `KMS_KEY_NOT_ROTATED`) and automatically checks whether Cloud KMS encryption keys have rotation configured with a 90-day period.

This detector:
- Automatically scans Cloud KMS CryptoKey resources in real-time
- Examines resource metadata for the presence of `rotationPeriod` or `nextRotationTime` properties
- Generates findings in Security Command Center when keys lack proper rotation configuration
- Operates at the Premium tier with no custom code required
- Excludes asymmetric keys and keys with disabled/destroyed primary versions

This is the most effective detection strategy because it's a native, automated capability that requires no custom development or maintenance. The findings integrate directly with Security Command Center's incident response workflows.

### Why Other Options Are Wrong

- **A.** While Cloud Asset Inventory can track key metadata and analyze crypto key versions, this approach requires custom implementation of the detection logic, alert configuration, and ongoing maintenance. It's more complex than using the built-in SHA detector that provides this functionality out-of-the-box.

- **B.** Implementing custom code in Cloud Run to assess KMS keys introduces unnecessary complexity, operational overhead, and potential reliability issues. You would need to build, deploy, maintain, and secure the custom scanning application when Security Health Analytics already provides this capability natively.

- **C.** Cloud Logging doesn't inherently track key rotation schedules or automatically generate metrics for key age. You would need to create custom log-based metrics from KMS audit logs and build detection logic yourself. This is significantly more complex than using the purpose-built SHA detector designed specifically for this compliance check.

### References

- [Vulnerability findings - Security Command Center](https://docs.cloud.google.com/security-command-center/docs/concepts-vulnerabilities-findings)
- [Key rotation - Cloud KMS](https://docs.cloud.google.com/kms/docs/key-rotation)
