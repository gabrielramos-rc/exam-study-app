# Question 092

**Source:** https://www.examtopics.com/discussions/google/view/33956-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** XSS, Web Security Scanner, GKE security, vulnerability scanning, application security

---

## Question

You are on your company's development team. You noticed that your web application hosted in staging on GKE dynamically includes user data in web pages without first properly validating the inputted data. This could allow an attacker to execute gibberish commands and display arbitrary content in a victim user's browser in a production environment. How should you prevent and fix this vulnerability?
## Choices

- **A.** Use Cloud IAP based on IP address or end-user device attributes to prevent and fix the vulnerability.
- **B.** Set up an HTTPS load balancer, and then use Cloud Armor for the production environment to prevent the potential XSS attack.
- **C.** Use Web Security Scanner to validate the usage of an outdated library in the code, and then use a secured version of the included library.
- **D.** Use Web Security Scanner in staging to simulate an XSS injection attack, and then use a templating system that supports contextual auto-escaping. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (14 total)


**Top Comments:**

- (10 upvotes) Answer is D. There is mention about simulating in Web Security Scanner. "Web Security Scanner cross-site scripting (XSS) injection testing *simulates* an injection attack by inserting a benign test st

- (7 upvotes) Agree with D

- (5 upvotes) Answer is B. Web Security Scanner can look for XSS vulnerabilities but can't simulate XSS injection attack. https://cloud.google.com/armor/docs/rule-tuning#cross-site_scripting_xss

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D follows the correct approach to prevent and fix XSS vulnerabilities in GKE applications. The solution has two critical components:

1. **Detection in staging**: Web Security Scanner can scan GKE applications and specifically detects three types of XSS vulnerabilities (XSS, XSS Angular Callback, and XSS Error). Running it in staging allows you to identify XSS injection points before deploying to production. The scanner crawls the application, exercises user inputs and event handlers, and injects benign test strings to confirm if JavaScript can execute in user-editable fields.

2. **Proper remediation**: According to Google Cloud documentation, "The recommended fix is to escape all output and use a templating system that supports contextual auto-escaping." Contextual auto-escaping automatically applies the correct output encoding based on where the data appears (HTML, JavaScript, URL, etc.), preventing user input from being interpreted as executable code. This addresses the root cause - the application is dynamically including user data without proper validation.

This approach combines vulnerability detection with the documented best practice fix for XSS vulnerabilities.

### Why Other Options Are Wrong

- **A:** Cloud IAP provides identity-based access control but does not prevent or fix XSS vulnerabilities. IAP controls who can access the application but doesn't prevent malicious JavaScript injection in user-supplied data. XSS is an application-layer vulnerability that requires code-level fixes.

- **B:** While Cloud Armor provides WAF capabilities and can help mitigate XSS attacks in production, this is a compensating control, not a fix. The question asks to "prevent and fix" the vulnerability. Cloud Armor doesn't fix the underlying code issue - the application still improperly handles user input. Additionally, deploying defensive layers only in production while leaving staging vulnerable doesn't address the development workflow problem.

- **C:** While Web Security Scanner can detect outdated libraries, this misidentifies the problem. The question explicitly states the issue is "dynamically includes user data in web pages without first properly validating the inputted data" - this is an XSS vulnerability due to improper output encoding, not an outdated library issue. Simply updating libraries won't fix improper data handling in application code.

### References

- [Overview of Web Security Scanner](https://docs.cloud.google.com/security-command-center/docs/concepts-web-security-scanner-overview)
- [Remediating Web Security Scanner findings](https://docs.cloud.google.com/security-command-center/docs/how-to-remediate-web-security-scanner-findings)
