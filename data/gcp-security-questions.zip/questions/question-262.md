# Question 262

**Source:** https://www.examtopics.com/discussions/google/view/147056-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Cloud Armor, VPC firewall, Cloud IDS, web application security

---

## Question

Your organization hosts a sensitive web application in Google Cloud. To protect the web application, you've set up a virtual private cloud (VPC) with dedicated subnets for the application's frontend and backend components. You must implement security controls to restrict incoming traffic, protect against web-based attacks, and monitor internal traffic. What should you do?
## Choices

- **A.** Configure Cloud Firewall to permit allow-listed traffic only, deploy Google Cloud Armor with predefined rules for blocking common web attacks, and deploy Cloud Intrusion Detection System (IDS) to detect internal traffic anomalies. Most Voted
- **B.** Configure Google Cloud Armor to allow incoming connections, configure DNS Security Extensions (DNSSEC) on Cloud DNS to secure against common web attacks, and deploy Cloud Intrusion Detection System (Cloud IDS) to detect internal traffic anomalies.
- **C.** Configure Cloud Intrusion Detection System (Cloud IDS) to monitor incoming connections, deploy Identity-Aware Proxy (IAP) to block common web attacks, and deploy Google Cloud Armor to detect internal traffic anomalies.
- **D.** Configure Cloud DNS to secure incoming traffic, deploy Cloud Intrusion Detection System (Cloud IDS) to detect common web attacks, and deploy Google Cloud Armor to detect internal traffic anomalies.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (5 total)


**Top Comments:**

- (1 upvotes) Here's why: Cloud Firewall: By configuring the firewall to permit only allow-listed traffic, you can restrict incoming traffic to only trusted sources, enhancing security. Google Cloud Armor: This ser

- (1 upvotes) A is good.

- (1 upvotes) I think it's A.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A correctly implements all three security requirements with the appropriate Google Cloud services:

1. **Restrict incoming traffic**: VPC firewall rules configured to permit only allow-listed traffic provide network-level access control at the VPC level, allowing you to define which traffic is permitted to reach your application based on IP addresses, ports, and protocols.

2. **Protect against web-based attacks**: Google Cloud Armor is the correct service for defending web applications against Layer 7 threats. It provides DDoS protection and includes preconfigured WAF rules based on OWASP Core Rule Set that defend against common web attacks including SQL injection (SQLi), cross-site scripting (XSS), and other OWASP Top 10 vulnerabilities. Cloud Armor operates at the network edge, attached to backend services of load balancers.

3. **Monitor internal traffic**: Cloud IDS (Cloud Intrusion Detection System) is specifically designed to monitor network traffic for threat detection. Critically, Cloud IDS provides "full visibility into network traffic, including both north-south and east-west traffic," which enables monitoring of VM-to-VM communication within the VPC to detect lateral movement and internal traffic anomalies. It uses Packet Mirroring and Palo Alto Networks threat detection technologies.

This combination represents the defense-in-depth approach: firewall rules at the network perimeter, Cloud Armor for application-layer protection, and Cloud IDS for internal threat detection and monitoring.

### Why Other Options Are Wrong

- **B:** Misuses Google Cloud Armor by configuring it to "allow incoming connections" rather than using VPC firewall rules for traffic restriction. More critically, DNSSEC on Cloud DNS does not protect against web attacks—DNSSEC only validates DNS responses to prevent DNS spoofing and cache poisoning, not application-layer web vulnerabilities like XSS or SQLi.

- **C:** Completely reverses the roles of these services. Cloud IDS is designed for intrusion detection and monitoring (not access control), IAP is for identity-based access to applications (not blocking web attacks like XSS/SQLi), and Cloud Armor is for web application protection (not internal traffic monitoring). Cloud IDS cannot actively block traffic—it only detects and alerts on threats.

- **D:** Cloud DNS is a DNS hosting service and does not secure incoming traffic or provide perimeter controls. Cloud IDS detects threats through monitoring but does not "block" common web attacks—it only alerts. Cloud Armor is a web application firewall and DDoS protection service, not an internal traffic monitoring tool.

### References

- [Cloud Armor preconfigured WAF rules overview](https://docs.cloud.google.com/armor/docs/waf-rules)
- [Cloud Armor product overview](https://docs.cloud.google.com/armor/docs/cloud-armor-overview)
- [Cloud IDS overview](https://docs.cloud.google.com/intrusion-detection-system/docs/overview)
