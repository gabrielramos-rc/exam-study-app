# Question 089

**Source:** https://www.examtopics.com/discussions/google/view/32128-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** Cloud Storage, IAM, uniform bucket-level access, ACL, Cloud Audit Logs

---

## Question

You are the security admin of your company. You have 3,000 objects in your Cloud Storage bucket. You do not want to manage access to each object individually. You also do not want the uploader of an object to always have full control of the object. However, you want to use Cloud Audit Logs to manage access to your bucket. What should you do?
## Choices

- **A.** Set up an ACL with OWNER permission to a scope of allUsers.
- **B.** Set up an ACL with READER permission to a scope of allUsers.
- **C.** Set up a default bucket ACL and manage access for users using IAM.
- **D.** Set up Uniform bucket-level access on the Cloud Storage bucket and manage access for users using IAM. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (17 total)


**Top Comments:**

- (19 upvotes) D. Set up Uniform bucket-level access on the Cloud Storage bucket and manage access for users using IAM.

- (5 upvotes) Answer is D https://cloud.google.com/storage/docs/uniform-bucket-level-access#overview

- (5 upvotes) D is right

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Uniform bucket-level access is the correct solution because it addresses all the requirements:

1. **No individual object management**: Uniform bucket-level access disables ACLs entirely and relies exclusively on bucket-level IAM permissions. This eliminates the need to manage access to 3,000 individual objects.

2. **Removes uploader automatic control**: When uniform bucket-level access is enabled, "individual object ownership no longer exists; access that is granted from such ownership is revoked." This prevents uploaders from automatically having full control of objects they upload, which would normally occur with ACL-based permissions.

3. **Works seamlessly with Cloud Audit Logs**: Cloud Audit Logs is the recommended method for tracking access to Cloud Storage resources and works with both ACL and IAM-based access control. However, uniform bucket-level access provides a unified, simplified security model that makes audit logs easier to interpret.

4. **Security best practice**: Uniform bucket-level access "unifies and simplifies how you grant access to your Cloud Storage resources" and "prevents unintended data exposure from ACLs." It's required for advanced features like IAM Conditions, Workforce/Workload Identity Federation, and managed folders.

### Why Other Options Are Wrong

- **A:** Setting an ACL with OWNER permission to allUsers would make all objects publicly writable and give everyone full control—a critical security vulnerability. This doesn't address any of the requirements and creates a massive security risk.

- **B:** Setting an ACL with READER permission to allUsers makes all objects publicly readable. This doesn't prevent uploaders from having full control (they would still have OWNER permissions on objects they upload), doesn't simplify management, and creates security issues.

- **C:** Default bucket ACLs still use the ACL system, which means object uploaders retain ownership and full control of objects they create. This fails the requirement of not wanting "the uploader of an object to always have full control." Additionally, mixing ACLs with IAM creates complexity rather than simplifying access management.

### References

- [Uniform bucket-level access | Cloud Storage](https://docs.cloud.google.com/storage/docs/uniform-bucket-level-access)
- [Cloud Audit Logs with Cloud Storage](https://docs.cloud.google.com/storage/docs/audit-logging)
