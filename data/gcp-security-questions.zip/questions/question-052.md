# Question 052

**Source:** https://www.examtopics.com/discussions/google/view/30232-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** Project Creator, organization policy, IAM, projects, permissions inheritance

---

## Question

Your team needs to prevent users from creating projects in the organization. Only the DevOps team should be allowed to create projects on behalf of the requester. Which two tasks should your team perform to handle this request? (Choose two.)
## Choices

- **A.** Remove all users from the Project Creator role at the organizational level. Most Voted
- **B.** Create an Organization Policy constraint, and apply it at the organizational level.
- **C.** Grant the Project Editor role at the organizational level to a designated group of users.
- **D.** Add a designated group of users to the Project Creator role at the organizational level. Most Voted
- **E.** Grant the billing account creator role to the designated DevOps team.

---

## Community

**Most Voted:** AD


**Votes:** AC: 12% | AD: 88% (8 total)


**Top Comments:**

- (19 upvotes) E. I think that the billing account creator role is needed in this case. https://cloud.google.com/resource-manager/docs/default-access-control#removing-default-roles "After you designate your own Bill

- (4 upvotes) Seems to be AC When an organization resource is created, all users in your domain are granted the Billing Account Creator and Project Creator roles by default. As per the link https://cloud.google.com

- (4 upvotes) A &amp; D is the right answer.

---

## Answer

**Correct:** A, D

**Confidence:** high

### Explanation

To restrict project creation to only the DevOps team, you need to implement a two-step approach that removes broad permissions and grants them selectively:

**Option A - Remove all users from the Project Creator role at the organizational level** is essential because when an organization resource is created, all users in the domain are automatically granted the Project Creator role (`roles/resourcemanager.projectCreator`) and Billing Account Creator roles at the organization level by default. This ensures no disruption when the organization is first created. However, this means every user in the domain can create projects anywhere in the hierarchy due to permission inheritance. To restrict project creation, you must first remove this organization-wide permission grant.

**Option D - Add a designated group of users to the Project Creator role at the organizational level** is the second required step. After removing the broad permission in Option A, you need to grant the Project Creator role specifically to the DevOps team (or a designated group). The Project Creator role contains the `resourcemanager.projects.create` permission, which is required to create projects. By granting this role only to the DevOps team at the organization level, they gain the ability to create projects on behalf of requesters while all other users remain restricted.

### Why Other Options Are Wrong

- **B:** While organization policies are powerful controls, there is no standard organization policy constraint that directly prevents project creation. Project creation is controlled through IAM roles (specifically the Project Creator role), not organization policy constraints. Organization policy constraints are used for things like restricting resource locations, allowed services, domain restrictions, etc., but not for controlling who can create projects.

- **C:** The Project Editor role (`roles/editor`) is a primitive role that grants read/write permissions on resources within a project, but it does not include the `resourcemanager.projects.create` permission needed to create new projects. This role is for managing resources within existing projects, not for creating projects themselves.

- **E:** The Billing Account Creator role allows users to create billing accounts but does not grant the ability to create projects. While project creation requires an associated billing account, the Billing Account Creator role is separate from the Project Creator role and does not provide project creation permissions.

### References

- [Managing Default Organization Roles](https://docs.cloud.google.com/resource-manager/docs/creating-managing-organization)
- [Creating and Managing Projects](https://docs.cloud.google.com/resource-manager/docs/creating-managing-projects)
- [Organization Policy Service](https://docs.cloud.google.com/resource-manager/docs/organization-policy/overview)
