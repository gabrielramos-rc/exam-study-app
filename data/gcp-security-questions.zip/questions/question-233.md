# Question 233

**Source:** https://www.examtopics.com/discussions/google/view/126772-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** patch management, OS patch, VM Manager, security automation

---

## Question

You manage a fleet of virtual machines (VMs) in your organization. You have encountered issues with lack of patching in many VMs. You need to automate regular patching in your VMs and view the patch management data across multiple projects. What should you do? (Choose two.)
## Choices

- **A.** View patch management data in VM Manager by using OS patch management. Most Voted
- **B.** View patch management data in Artifact Registry.
- **C.** View patch management data in a Security Command Center dashboard.
- **D.** Deploy patches with Security Command Genter by using Rapid Vulnerability Detection.
- **E.** Deploy patches with VM Manager by using OS patch management. Most Voted

---

## Community

**Most Voted:** AE


**Votes:** AE: 77% | CE: 23% (13 total)


**Top Comments:**

- (3 upvotes) A and D https://cloud.google.com/compute/docs/os-patch-management

- (2 upvotes) Why Option A is Correct: VM Manager OS Patch Management: VM Manager provides a centralized view of patch status and compliance for all VMs across multiple projects. Patch management data includes deta

- (2 upvotes) . View patch management data in VM Manager by using OS patch management. Why? VM Manager's OS patch management feature provides a centralized view of patch compliance across your VMs, including multip

---

## Answer

**Correct:** A, E

**Confidence:** high

### Explanation

**VM Manager with OS patch management** is the correct Google Cloud service for both automating patch deployment and viewing patch management data across VMs.

**Option A** is correct because VM Manager provides a centralized **Patch dashboard** in the Google Cloud console where you can view patch compliance data across your VMs and multiple projects. The dashboard shows:
- Operating system overview with VM counts by OS type
- Patch compliance status categorized by severity (critical updates, security updates, other updates, up-to-date)
- Detailed patch job status and history
- Available updates for specific VM instances

**Option E** is correct because VM Manager's OS patch management feature enables you to **automate regular patching** through:
- **Patch deployments** with scheduled patch jobs (one-time or recurring schedules)
- Automatic patching at specified intervals
- Instance filters to patch multiple VMs simultaneously (up to 500 VMs per deployment)
- Integration with the OS Config agent that uses native OS utilities (yum, apt, Windows Update Agent) to apply patches

The OS Config API (VM Manager API) handles patch orchestration and can be managed through the Google Cloud console, gcloud CLI, or direct API calls. This provides a complete solution for both automating patch deployment and monitoring patch compliance across your VM fleet.

### Why Other Options Are Wrong

- **B:** Artifact Registry is a repository service for storing and managing build artifacts, container images, and language packages. It is not designed for patch management data or viewing VM patching status. It has no capabilities for displaying patch compliance information.

- **C:** Security Command Center provides security findings, vulnerability scanning results, and security posture monitoring, but it is not the primary interface for viewing detailed patch management data or patch job execution status. While SCC may detect vulnerabilities that require patches, VM Manager's Patch dashboard is the dedicated interface for viewing patch compliance and managing patch deployments.

- **D:** Security Command Center does not have a feature called "Rapid Vulnerability Detection" for deploying patches, and SCC in general is not a patch deployment tool. SCC is focused on security findings, threat detection, and vulnerability identification, not patch orchestration. The statement also contains a typo ("Genter" instead of "Center"), suggesting this is not a legitimate GCP feature.

### References

- [About Patch | VM Manager | Google Cloud](https://docs.cloud.google.com/compute/vm-manager/docs/patch)
- [Schedule patch jobs | VM Manager | Google Cloud](https://docs.cloud.google.com/compute/vm-manager/docs/patch/schedule-patch-jobs)
