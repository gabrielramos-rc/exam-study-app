# Question 034

**Source:** https://www.examtopics.com/discussions/google/view/32927-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** CMEK, Cloud KMS, key encryption key, Dataproc, persistent disk encryption

---

## Question

Your company is using Cloud Dataproc for its Spark and Hadoop jobs. You want to be able to create, rotate, and destroy symmetric encryption keys used for the persistent disks used by Cloud Dataproc. Keys can be stored in the cloud. What should you do?
## Choices

- **A.** Use the Cloud Key Management Service to manage the data encryption key (DEK).
- **B.** Use the Cloud Key Management Service to manage the key encryption key (KEK). Most Voted
- **C.** Use customer-supplied encryption keys to manage the data encryption key (DEK).
- **D.** Use customer-supplied encryption keys to manage the key encryption key (KEK).

---

## Community

**Most Voted:** B


**Votes:** A: 27% | B: 73% (15 total)


**Top Comments:**

- (25 upvotes) I agree but then should answer not be be C- customer supplied key?

- (5 upvotes) Correct answer is B, and A is wrong! envlope encryption is default mechanism in CMEK when used for Dataproc, please check this link: This PD and bucket data is encrypted using a Google-generated data 

- (4 upvotes) In my opinion it should be B. reference : https://cloud.google.com/kms/docs/envelope-encryption How to encrypt data using envelope encryption The process of encrypting data is to generate a DEK locall

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud Key Management Service (Cloud KMS) with Customer-Managed Encryption Keys (CMEK) is the correct solution for managing encryption keys for Dataproc persistent disks with the ability to create, rotate, and destroy keys stored in the cloud.

In Google Cloud's encryption architecture, there are two types of keys:
- **Data Encryption Key (DEK)**: The key that actually encrypts the data on disk
- **Key Encryption Key (KEK)**: The key that encrypts the DEK (envelope encryption)

When using CMEK with Dataproc:
- **Google manages the DEK**: Google automatically generates and manages the data encryption keys that encrypt the actual data on persistent disks
- **You manage the KEK**: Through Cloud KMS, you create, rotate, and destroy the key encryption keys that protect the DEKs

This envelope encryption approach allows you to have full control over key lifecycle operations (create, rotate, revoke/destroy) while Google handles the operational complexity of managing the actual data encryption keys. Cloud KMS keys can be stored in Google Cloud (using software or HSM protection levels) and support automatic or on-demand rotation.

The CMEK configuration is applied to Dataproc clusters using the `gcePdKmsKeyName` parameter to specify the Cloud KMS key resource ID for persistent disk encryption.

### Why Other Options Are Wrong

- **A:** Incorrect. You cannot directly manage the DEK through Cloud KMS. Google automatically manages the DEKs that encrypt data. With CMEK, you only control the KEK that encrypts/protects the DEK.

- **C:** Incorrect. Customer-Supplied Encryption Keys (CSEK) require you to supply and manage the keys yourself outside of Google Cloud. CSEKs must be provided with every API request and cannot be "stored in the cloud" as required by the question. Additionally, CSEKs don't have the same rotation and management capabilities as Cloud KMS.

- **D:** Incorrect. Customer-Supplied Encryption Keys (CSEK) are not stored in the cloud - you must manage and supply them with every request. This violates the requirement that "keys can be stored in the cloud." Additionally, with CSEKs you manage the DEK directly, not the KEK (there is no envelope encryption with CSEKs).

### References

- [Customer managed encryption keys (CMEK) - Dataproc Documentation](https://docs.cloud.google.com/dataproc/docs/concepts/configuring-clusters/customer-managed-encryption)
- [Customer-managed encryption keys (CMEK) - Cloud KMS Documentation](https://docs.cloud.google.com/kms/docs/cmek)
- [About disk encryption - Compute Engine Documentation](https://docs.cloud.google.com/compute/docs/disks/disk-encryption)
