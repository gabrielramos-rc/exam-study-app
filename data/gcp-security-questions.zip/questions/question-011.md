# Question 011

**Source:** https://www.examtopics.com/discussions/google/view/16101-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** DNSSEC, DNS Security Extensions, domain hijacking, man-in-the-middle attack, DNS spoofing, cache poisoning

---

## Question

A customer needs to prevent attackers from hijacking their domain/IP and redirecting users to a malicious site through a man-in-the-middle attack. Which solution should this customer use?
## Choices

- **A.** VPC Flow Logs
- **B.** Cloud Armor
- **C.** DNS Security Extensions Most Voted
- **D.** Cloud Identity-Aware Proxy

---

## Community

**Most Voted:** C


**Votes:** C: 100% (3 total)


**Top Comments:**

- (15 upvotes) C. Attackers can hijack this process of domain/IP lookup and redirect users to a malicious site through DNS hijacking and man-in-the-middle attacks. DNSSEC helps mitigate the risk of such attacks by c

- (5 upvotes) C is right

- (3 upvotes) Took the tesk today, only 5 question from this dump, the rest are new questions.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

DNS Security Extensions (DNSSEC) is the correct solution to prevent attackers from hijacking domains and redirecting users to malicious sites through man-in-the-middle attacks. DNSSEC authenticates responses to domain name lookups using digital signatures (RRSIG records), preventing attackers from manipulating or poisoning DNS responses.

When DNSSEC is enabled on Cloud DNS, Google Cloud automatically:
- Manages the creation and rotation of DNSSEC keys (DNSKEY records)
- Signs zone data with resource record digital signatures (RRSIG records)
- Provides cryptographic authentication of DNS responses

DNSSEC specifically protects against DNS spoofing and cache poisoning attacks, where attackers attempt to inject false DNS responses to redirect users to malicious servers. By verifying digital signatures on DNS responses, DNSSEC ensures that users are directed to the legitimate IP addresses for your domains, not attacker-controlled servers.

For full protection, DNSSEC requires:
1. Enabling DNSSEC in Cloud DNS for your zones
2. Creating DS records at your domain registrar to activate DNSSEC
3. Using a validating DNS resolver (like Google Public DNS) that verifies DNSSEC signatures

### Why Other Options Are Wrong

- **A. VPC Flow Logs:** VPC Flow Logs are used for network monitoring and troubleshooting by capturing information about IP traffic going to and from network interfaces. They do not prevent DNS hijacking or man-in-the-middle attacks; they only provide visibility into network traffic patterns after the fact.

- **B. Cloud Armor:** Cloud Armor is a web application firewall (WAF) and DDoS protection service that protects applications from layer 7 attacks, SQL injection, cross-site scripting, and volumetric attacks. While it provides important security protections, it does not prevent DNS-level attacks or domain hijacking through DNS spoofing.

- **D. Cloud Identity-Aware Proxy:** Identity-Aware Proxy (IAP) provides application-level access control by verifying user identity and request context before granting access to applications. It controls who can access applications but does not prevent DNS hijacking or authenticate DNS responses. IAP operates at a different layer than DNS security.

### References

- [DNS Security Extensions (DNSSEC) overview | Google Cloud Documentation](https://docs.cloud.google.com/dns/docs/dnssec)
- [Activate DNSSEC at your domain registrar](https://docs.cloud.google.com/dns/docs/registrars)
