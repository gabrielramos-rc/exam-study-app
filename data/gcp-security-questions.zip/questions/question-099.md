# Question 099

**Source:** https://www.examtopics.com/discussions/google/view/74823-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Secret Manager, sensitive configuration data, credentials storage, API keys storage

---

## Question

You are asked to recommend a solution to store and retrieve sensitive configuration data from an application that runs on Compute Engine. Which option should you recommend?
## Choices

- **A.** Cloud Key Management Service
- **B.** Compute Engine guest attributes
- **C.** Compute Engine custom metadata
- **D.** Secret Manager Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (13 total)


**Top Comments:**

- (13 upvotes) You need a secrets management solution https://cloud.google.com/secret-manager

- (5 upvotes) Sorry, this should be C

- (4 upvotes) Explanation: Secret Manager is the recommended solution for storing and retrieving sensitive configuration data in Google Cloud. It is purpose-built for managing sensitive information like API keys, p

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Secret Manager is the purpose-built service for storing and managing sensitive configuration data such as API keys, passwords, certificates, and credentials. It provides:

- **Secure storage**: Automatically encrypts all secrets at rest using AES-256-bit encryption and in transit
- **Access control**: Fine-grained IAM permissions to control who can access specific secrets
- **Versioning**: Maintains multiple versions of secrets for rollback capabilities
- **Audit logging**: Tracks all access to secrets for compliance and security monitoring
- **Programmatic access**: Native client libraries for applications to retrieve secrets at runtime

For applications running on Compute Engine, Secret Manager is the recommended solution because it separates sensitive data from application code and infrastructure configuration, following security best practices of never storing credentials in code, metadata, or file systems.

### Why Other Options Are Wrong

- **A. Cloud Key Management Service**: Cloud KMS is designed for managing cryptographic keys used for encryption/decryption operations, not for storing actual secret values like passwords or API keys. KMS keys are never extractable or viewable - they only perform cryptographic operations. While KMS can be used to encrypt secrets, Secret Manager is the appropriate service for actually storing and retrieving the sensitive configuration data itself.

- **B. Compute Engine guest attributes**: Guest attributes are a mechanism for the guest OS to communicate instance-level metadata to external systems. They are designed for operational data and status information, not for storing sensitive configuration data. They lack the security controls, encryption, versioning, and audit capabilities required for secrets management.

- **C. Compute Engine custom metadata**: Custom metadata is stored unencrypted and is visible to anyone with Compute Instance Admin or Compute Admin roles, and to the instance itself via the metadata server. Storing sensitive data in custom metadata violates security best practices because it lacks proper access controls, encryption at rest for the metadata values, versioning, and audit logging specific to secret access. The documentation explicitly warns against passing secrets through metadata.

### References

- [Secret Manager overview](https://docs.cloud.google.com/secret-manager/docs/overview)
- [Secret Manager best practices](https://docs.cloud.google.com/secret-manager/docs/best-practices)
