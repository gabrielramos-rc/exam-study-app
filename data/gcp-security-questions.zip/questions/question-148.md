# Question 148

**Source:** https://www.examtopics.com/discussions/google/view/80411-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Identity-Aware Proxy, IAP, access control, application security, centralized authorization

---

## Question

Which Google Cloud service should you use to enforce access control policies for applications and resources?
## Choices

- **A.** Identity-Aware Proxy Most Voted
- **B.** Cloud NAT
- **C.** Google Cloud Armor
- **D.** Shielded VMs

---

## Community

**Most Voted:** A


**Votes:** A: 100% (7 total)


**Top Comments:**

- (5 upvotes) A. Identity-Aware Proxy

- (2 upvotes) A. Identity-Aware Proxy

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Identity-Aware Proxy (IAP) is the correct service for enforcing access control policies for applications and resources. IAP is specifically designed to establish centralized authorization for applications accessed via HTTPS, implementing application-level access control instead of relying solely on network-level firewalls.

IAP enforces access control through a two-step process:
1. **Authentication**: Verifies user identity through OAuth 2.0 sign-in
2. **Authorization**: Checks that users have the required "IAP-secured Web App User" role before granting access

Key capabilities include:
- Centralized policy management across multiple applications and resources
- Fine-grained, group-based access controls (e.g., access for employees but not contractors)
- Support for App Engine, Cloud Run, Compute Engine, GKE, and on-premises applications
- Context-aware access using Access Context Manager for additional security layers based on IP address, device attributes, URL paths, and other contextual signals
- No VPN required - users access applications directly through their browser while IT teams centrally define and enforce policies

Each application or resource can have different access policies, allowing granular control at the project, service, version, or individual resource level.

### Why Other Options Are Wrong

- **B. Cloud NAT:** Cloud NAT provides outbound network address translation for VM instances without external IP addresses to access the internet. It does not enforce access control policies for applications - it's a networking service for egress traffic, not an access control mechanism.

- **C. Google Cloud Armor:** Cloud Armor is a web application firewall (WAF) and DDoS protection service that protects applications from network-based attacks using IP allowlists/blocklists, rate limiting, and security rules. While it provides security, it focuses on protecting against malicious traffic rather than enforcing identity-based access control policies for legitimate users.

- **D. Shielded VMs:** Shielded VMs provide verifiable integrity of VM instances through features like Secure Boot, vTPM, and integrity monitoring. They protect against rootkits and bootkits at the VM level but do not enforce application-level access control policies for users accessing applications.

### References

- [Identity-Aware Proxy overview](https://docs.cloud.google.com/iap/docs/concepts-overview)
- [Manage access to IAP-secured resources](https://docs.cloud.google.com/iap/docs/managing-access)
