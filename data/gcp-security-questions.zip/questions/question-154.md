# Question 154

**Source:** https://www.examtopics.com/discussions/google/view/80410-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Cloud NAT, outbound internet, VM without external IP, network address translation

---

## Question

Your company's cloud security policy dictates that VM instances should not have an external IP address. You need to identify the Google Cloud service that will allow VM instances without external IP addresses to connect to the internet to update the VMs. Which service should you use?
## Choices

- **A.** Identity Aware-Proxy
- **B.** Cloud NAT Most Voted
- **C.** TCP/UDP Load Balancing
- **D.** Cloud DNS

---

## Community

**Most Voted:** B


**Votes:** B: 100% (12 total)


**Top Comments:**

- (6 upvotes) Cloud NAT to control egress traffic.

- (2 upvotes) https://cloud.google.com/nat/docs/overview

- (1 upvotes) Cloud NAT is right B

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud NAT is the correct service for allowing VM instances without external IP addresses to connect to the internet. Cloud NAT is a managed, distributed network address translation (NAT) service that enables VMs in private subnets to make outbound connections to the internet while maintaining their security posture by not exposing them with external IPs.

When you configure Cloud NAT for a VPC network, it allocates a pool of external IP addresses and source ports that VMs can use for outbound connections. The service performs source NAT (SNAT) for outbound traffic and destination NAT (DNAT) for inbound responses to established connections. This allows VMs with only internal IP addresses to download updates, access external APIs, and reach other internet resources without requiring individual external IPs.

Cloud NAT is implemented as a distributed, software-defined managed service built into the Andromeda software that powers Google Cloud VPC networks. This makes it highly scalable and reliable without requiring proxy VMs or appliances. The documentation explicitly states: "you can reduce the need for individual VMs to each have external IP addresses" while still maintaining necessary internet connectivity for tasks like downloading software updates.

### Why Other Options Are Wrong

- **A. Identity Aware-Proxy:** IAP provides secure access TO resources, not FROM resources to the internet. IAP enables TCP forwarding and application access for administrators and users to reach internal resources without external IPs or VPNs, but it doesn't provide outbound internet connectivity for VMs.

- **C. TCP/UDP Load Balancing:** Load balancers distribute inbound traffic to backend instances and provide a single entry point for external clients. They don't enable outbound internet connectivity from private VMs. Load balancers are for receiving traffic, not initiating outbound connections.

- **D. Cloud DNS:** Cloud DNS is a managed domain name system service for resolving domain names to IP addresses. While DNS resolution is necessary for internet connectivity, it doesn't provide the network address translation required for VMs without external IPs to actually connect to internet destinations.

### References

- [Cloud NAT overview | Google Cloud Documentation](https://docs.cloud.google.com/nat/docs/overview)
- [Public NAT | Google Cloud Documentation](https://docs.cloud.google.com/nat/docs/public-nat)
