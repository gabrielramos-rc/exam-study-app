# Question 167

**Source:** https://www.examtopics.com/discussions/google/view/79801-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, VPC, organization, load balancer, resource hierarchy

---

## Question

You have the following resource hierarchy. There is an organization policy at each node in the hierarchy as shown. Which load balancer types are denied in VPC A? ![Question Image](../images/question-167-img1.jpg)

## Choices

- **A.** All load balancer types are denied in accordance with the global node's policy. Most Voted
- **B.** INTERNAL_TCP_UDP, INTERNAL_HTTP_HTTPS is denied in accordance with the folder's policy.
- **C.** EXTERNAL_TCP_PROXY, EXTERNAL_SSL_PROXY are denied in accordance with the project's policy.
- **D.** EXTERNAL_TCP_PROXY, EXTERNAL_SSL_PROXY, INTERNAL_TCP_UDP, and INTERNAL_HTTP_HTTPS are denied in accordance with the folder and project's policies.

---

## Community

**Most Voted:** A


**Votes:** A: 67% | C: 13% | D: 20% (30 total)


**Top Comments:**

- (14 upvotes) yes, It is A

- (5 upvotes) DENY values at a lower level override higher-level policies if they have more restrictive constraints, so answer cannot be A.

- (4 upvotes) This is correct

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

As shown in the diagram, there are three organization policies in the hierarchy:
- **Organization node**: `"allValues": "DENY"` (denies all load balancer types)
- **Folder 2**: `"deniedValues": ["INTERNAL_TCP_UDP", "INTERNAL_HTTP_HTTPS"]`
- **Project 2** (containing VPC A): `"deniedValues": ["EXTERNAL_TCP_PROXY", "EXTERNAL_SSL_PROXY"]`

For VPC A, which resides in Project 2, only **EXTERNAL_TCP_PROXY and EXTERNAL_SSL_PROXY** are denied because of how organization policy inheritance works by default.

When a child resource sets an organization policy without explicitly setting `inheritFromParent: true`, the child policy **replaces** the parent policy rather than merging with it. This is the default behavior for list-based constraints in Google Cloud Organization Policy.

Looking at the policies shown in the diagram, none of them explicitly include `inheritFromParent: true`. Therefore, the Project 2 policy completely overrides both the Folder 2 and Organization-level policies. Only the denials specified at the Project 2 level apply to resources within that project.

While the documentation for `constraints/compute.restrictLoadBalancerCreationForTypes` recommends setting `inheritFromParent: true` to ensure hierarchical enforcement, this is a recommendation, not the default behavior. Without this setting, standard organization policy inheritance rules apply, where child policies replace parent policies.

### Why Other Options Are Wrong

- **A:** Incorrect. The organization-level policy denying all load balancer types is overridden by the Project 2 policy. Child policies replace parent policies unless `inheritFromParent: true` is explicitly set.

- **B:** Incorrect. The Folder 2 policy is also overridden by the Project 2 policy. Even though Project 2 is a descendant of Folder 2, the project-level policy takes precedence and replaces the folder-level policy.

- **D:** Incorrect. This assumes that all policies in the hierarchy are automatically merged, which is not the default behavior. Merging only occurs when `inheritFromParent: true` is explicitly configured in the child policy. Without this setting, only the Project 2 policy applies.

### References

- [Organization policy constraints for Cloud Load Balancing](https://docs.cloud.google.com/load-balancing/docs/org-policy-constraints)
- [Understanding hierarchy evaluation](https://docs.cloud.google.com/resource-manager/docs/organization-policy/understanding-hierarchy)
- [Creating and managing organization policies](https://docs.cloud.google.com/resource-manager/docs/organization-policy/creating-managing-policies)
