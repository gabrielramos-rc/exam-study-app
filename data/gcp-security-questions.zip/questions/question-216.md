# Question 216

**Source:** https://www.examtopics.com/discussions/google/view/117319-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Security Command Center, SCC, compliance, CIS benchmark, mute findings, automation

---

## Question

Your organization wants to be continuously evaluated against CIS Google Cloud Computing Foundations Benchmark v1.3.0 (CIS Google Cloud Foundation 1.3). Some of the controls are irrelevant to your organization and must be disregarded in evaluation. You need to create an automated system or process to ensure that only the relevant controls are evaluated. What should you do?
## Choices

- **A.** Mark all security findings that are irrelevant with a tag and a value that indicates a security exception. Select all marked findings, and mute them on the console every time they appear. Activate Security Command Center (SCC) Premium.
- **B.** Activate Security Command Center (SCC) Premium. Create a rule to mute the security findings in SCC so they are not evaluated. Most Voted
- **C.** Download all findings from Security Command Center (SCC) to a CSV file. Mark the findings that are part of CIS Google Cloud Foundation 1.3 in the file. Ignore the entries that are irrelevant and out of scope for the company.
- **D.** Ask an external audit company to provide independent reports including needed CIS benchmarks. In the scope of the audit, clarify that some of the controls are not needed and must be disregarded.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (8 total)


**Top Comments:**

- (2 upvotes) Answer: B

- (2 upvotes) The right answer is B. please disregard the former

- (2 upvotes) https://cloud.google.com/security-command-center/docs/how-to-mute-findings

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Security Command Center (SCC) Premium provides automated compliance monitoring against CIS benchmarks, including CIS Google Cloud Computing Foundations Benchmark v1.3.0. To automatically exclude irrelevant controls from evaluation, you should create **mute rules** in SCC.

Mute rules are automated configurations that use filters to silence existing and future findings based on criteria you specify. When you create a mute rule:

1. **Automated operation**: The rule automatically applies to matching findings without manual intervention
2. **Continuous evaluation**: Both existing and future findings that match the filter criteria are muted (using dynamic mute rules)
3. **Compliance impact**: While muted findings still appear in compliance calculations for audit purposes, they are hidden from the default view and reduce alert fatigue
4. **Scalable approach**: You can create up to 1,000 mute rules per organization to handle various irrelevant controls

The correct implementation involves:
- Activating SCC Premium (required for advanced compliance features)
- Creating dynamic mute rules with filters targeting specific CIS benchmark controls that are irrelevant to your organization
- The rules automatically mute findings matching those controls, making the evaluation process focus only on relevant controls

This approach is automated, scalable, and the recommended best practice for managing compliance findings in Google Cloud.

### Why Other Options Are Wrong

- **A:** This is a manual approach requiring you to "mute them on the console every time they appear," which is not automated. The question explicitly requires an automated system, not a manual process. Additionally, tagging and repeatedly selecting findings is operationally inefficient.

- **C:** This is completely manual and offline. Downloading findings to CSV, manually marking them, and ignoring entries provides no automated evaluation system. This doesn't integrate with SCC's continuous monitoring and requires manual work for every new finding.

- **D:** Using an external audit company doesn't create an automated system within Google Cloud. This is an external, manual process that doesn't leverage SCC's built-in compliance monitoring capabilities. It also introduces delays and additional costs without addressing the requirement for continuous automated evaluation.

### References

- [Mute findings in Security Command Center](https://docs.cloud.google.com/security-command-center/docs/how-to-mute-findings)
- [Assess compliance without Compliance Manager](https://docs.cloud.google.com/security-command-center/docs/compliance-management)
- [Migrate from static to dynamic mute rules](https://docs.cloud.google.com/security-command-center/docs/dynamic-mute-migrate)
