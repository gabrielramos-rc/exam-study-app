# Question 068

**Source:** https://www.examtopics.com/discussions/google/view/30359-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, Directory Sync, GCDS, user deprovisioning, user lifecycle

---

## Question

A customer terminates an engineer and needs to make sure the engineer's Google account is automatically deprovisioned. What should the customer do?
## Choices

- **A.** Use the Cloud SDK with their directory service to remove their IAM permissions in Cloud Identity.
- **B.** Use the Cloud SDK with their directory service to provision and deprovision users from Cloud Identity.
- **C.** Configure Cloud Directory Sync with their directory service to provision and deprovision users from Cloud Identity. Most Voted
- **D.** Configure Cloud Directory Sync with their directory service to remove their IAM permissions in Cloud Identity.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (6 total)


**Top Comments:**

- (11 upvotes) Agree with C, there is no need of cloud SDK.

- (7 upvotes) Agree with C. "https://cloud.google.com/identity/solutions/automate-user-provisioning#cloud_identity_automated_provisioning" "Cloud Identity has a catalog of automated provisioning connectors, which a

- (2 upvotes) C. Configure Cloud Directory Sync with their directory service to provision and deprovision users from Cloud Identity.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Google Cloud Directory Sync (GCDS) is the recommended tool for automated user lifecycle management between an organization's directory service (such as Active Directory or LDAP) and Cloud Identity. GCDS handles both provisioning and deprovisioning automatically through scheduled synchronization.

When a user is removed or disabled in the source directory service (e.g., Active Directory), GCDS identifies users in Cloud Identity that lack corresponding matches in the directory during synchronization runs. The default behavior of GCDS is to automatically delete these unmatched users from Cloud Identity, ensuring that terminated employees are deprovisioned without manual intervention.

Key features of GCDS for deprovisioning:
- **Automated synchronization**: GCDS runs on a schedule (typically hourly) to continuously sync user changes
- **One-way sync**: Changes in the source directory (Active Directory) are replicated to Cloud Identity, ensuring the authoritative source controls access
- **Deletion policy**: GCDS automatically deletes or suspends users that no longer exist in the source directory
- **Safety mechanisms**: Built-in protections prevent accidental deletion of super admin accounts

This approach ensures that when an engineer is terminated and their account is disabled/removed from Active Directory, the deprovisioning automatically propagates to Cloud Identity on the next GCDS sync cycle.

### Why Other Options Are Wrong

- **A:** Removing IAM permissions doesn't deprovision the account itself - it only removes permissions. The user identity still exists in Cloud Identity. Additionally, manually using the Cloud SDK doesn't provide automation for ongoing user lifecycle management.

- **B:** While the Cloud SDK can be used to manage users programmatically, it requires custom scripting and automation logic. This is not the recommended or standard approach for integrating directory services with Cloud Identity. GCDS is the purpose-built tool for this use case.

- **D:** This option incorrectly describes GCDS functionality. GCDS provisions and deprovisions users (creates/deletes user accounts), not just IAM permissions. IAM permissions are managed separately through IAM policies and roles, not through GCDS.

### References

- [Active Directory user account provisioning](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-synchronizing-user-accounts)
- [Federate Google Cloud with Active Directory](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-introduction)
