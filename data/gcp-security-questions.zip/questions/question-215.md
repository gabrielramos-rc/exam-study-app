# Question 215

**Source:** https://www.examtopics.com/discussions/google/view/117342-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, groups, user management, membership restrictions

---

## Question

You are a Cloud Identity administrator for your organization. In your Google Cloud environment, groups are used to manage user permissions. Each application team has a dedicated group. Your team is responsible for creating these groups and the application teams can manage the team members on their own through the Google Cloud console. You must ensure that the application teams can only add users from within your organization to their groups. What should you do?
## Choices

- **A.** Change the configuration of the relevant groups in the Google Workspace Admin console to prevent external users from being added to the group. Most Voted
- **B.** Set an Identity and Access Management (IAM) policy that includes a condition that restricts group membership to user principals that belong to your organization.
- **C.** Define an Identity and Access Management (IAM) deny policy that denies the assignment of principals that are outside your organization to the groups in scope.
- **D.** Export the Cloud Identity logs to BigQuery. Configure an alert for external members added to groups. Have the alert trigger a Cloud Function instance that removes the external members from the group.

---

## Community

**Most Voted:** A


**Votes:** A: 68% | B: 20% | C: 12% (25 total)


**Top Comments:**

- (6 upvotes) Organization wide*

- (3 upvotes) To ensure that application teams can only add users from within your organization to their groups, you should use option B: B. Set an Identity and Access Management (IAM) policy that includes a condit

- (3 upvotes) https://support.google.com/a/answer/167097?hl=en&amp;sjid=9952232817978914605-AP

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The correct approach is to configure group settings in the Google Workspace Admin console to restrict group membership to only users within your organization. Cloud Identity groups have configurable access settings that control who can join groups, including options to:

- Restrict "Who can join" to only users from your organization's domain(s)
- Prevent external users from being added as members
- Control member management permissions while enforcing organizational boundaries

This is a native Cloud Identity group setting that proactively prevents external members from being added, while still allowing application teams to manage their own group membership within those constraints. The setting is applied at the group level in the Google Workspace Admin console (which manages Cloud Identity).

This approach is:
- **Preventive**: Stops external users from being added before it happens
- **Delegated**: Application teams can still manage members within policy constraints
- **Native**: Uses built-in Cloud Identity group access settings
- **Scalable**: Can be applied to multiple groups without custom code

### Why Other Options Are Wrong

- **B:** IAM policies control access to Google Cloud resources (like projects, buckets, VMs), not membership in Cloud Identity groups. IAM conditions cannot restrict who can be added to a group - they only control resource access permissions. This confuses resource access control with group membership management.

- **C:** IAM deny policies also control access to Google Cloud resources, not Cloud Identity group membership. Deny policies prevent principals from accessing resources but don't control the composition of groups themselves. This similarly confuses resource IAM with group membership controls.

- **D:** This is a reactive detection-and-remediation approach rather than a preventive control. It allows external members to be added temporarily, then removes them after the fact. This violates the principle of preventive security controls, creates audit gaps, could allow temporary unauthorized access, and requires maintaining custom Cloud Functions code when a native solution exists.

### References

- [Google Cloud Identity Groups Overview](https://docs.cloud.google.com/identity/docs/groups)
- [About group settings (Google Workspace Admin Help)](https://support.google.com/a/answer/167101)
- [Manage Cloud Identity groups](https://support.google.com/cloudidentity/answer/9400082)
