# Question 279

**Source:** https://www.examtopics.com/discussions/google/view/147073-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Private Google Access, hybrid connectivity, DNS configuration, on-premises, Artifact Registry

---

## Question

Your organization operates a hybrid cloud environment and has recently deployed a private Artifact Registry repository in Google Cloud. On-premises developers cannot resolve the Artifact Registry hostname and therefore cannot push or pull artifacts. You've verified the following:
- Connectivity to Google Cloud is established by Cloud VPN or Cloud Interconnect.
- No custom DNS configurations exist on-premises.
- There is no route to the internet from the on-premises network.

You need to identify the cause and enable the developers to push and pull artifacts. What is likely causing the issue and what should you do to fix the issue?

## Choices

- **A.** On-premises DNS servers lack the necessary records to resolve private Google API domains. Create DNS records for restricted.googleapis.com or private.googleapis.com pointing to Google's published IP ranges. Most Voted
- **B.** Developers must be granted the artifactregistry.writer IAM role. Grant the relevant developer group this role.
- **C.** Private Google Access is not enabled for the subnet hosting the Artifact Registry. Enable Private Google Access for the appropriate subnet.
- **D.** Artifact Registry requires external HTTP/HTTPS access. Create a new firewall rule allowing ingress traffic on ports 80 and 443 from the developer's IP ranges.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (9 total)


**Top Comments:**

- (4 upvotes) A is the right answer

- (2 upvotes) I think it's A.

- (1 upvotes) It's A i have done this before on customers organizations

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The issue is that on-premises DNS servers cannot resolve Artifact Registry hostnames (which use domains like `*.pkg.dev` and `*.googleapis.com`) because these domains normally resolve to public IP addresses on the internet. Since the on-premises network has no route to the internet and no custom DNS configuration, the on-premises DNS servers need specific DNS records to route these requests through the private connection (Cloud VPN or Interconnect) to Google's restricted or private VIP ranges.

To fix this, you need to create DNS records on the on-premises DNS servers:

**For private.googleapis.com (recommended):**
- Create an A record for `private.googleapis.com` pointing to: `199.36.153.8`, `199.36.153.9`, `199.36.153.10`, `199.36.153.11`
- Create a CNAME record for `*.googleapis.com` pointing to `private.googleapis.com`
- Create a DNS zone for `pkg.dev` with an A record pointing to the same IP addresses (for Artifact Registry endpoints like `us-central1-docker.pkg.dev`)

**For restricted.googleapis.com (if using VPC Service Controls):**
- Create an A record pointing to: `199.36.153.4`, `199.36.153.5`, `199.36.153.6`, `199.36.153.7`

This configuration allows on-premises clients to resolve Google API domains to Google's private VIP ranges, which are reachable through the Cloud VPN or Cloud Interconnect connection without requiring internet access.

### Why Other Options Are Wrong

- **B:** IAM permissions (artifactregistry.writer role) would cause authorization errors (403 Forbidden), not DNS resolution failures. The question explicitly states developers "cannot resolve the Artifact Registry hostname," which is a DNS issue, not an IAM issue.

- **C:** Private Google Access is a VPC subnet setting that allows VMs without external IP addresses to reach Google APIs. It does not apply to on-premises networks. On-premises networks access Google APIs through Cloud VPN/Interconnect using the appropriate DNS configuration, not Private Google Access.

- **D:** This is incorrect for multiple reasons: (1) Artifact Registry does not require external HTTP/HTTPS access when using private connectivity, (2) the issue is DNS resolution, not firewall blocking, (3) the firewall rule described is for ingress traffic when the issue is about outbound access from on-premises, and (4) the question states there is no route to the internet, so creating internet-bound firewall rules would not help.

### References

- [Configure Private Google Access for on-premises hosts](https://cloud.google.com/vpc/docs/configure-private-google-access-hybrid)
- [Configure restricted access for GKE private clusters - Artifact Registry](https://cloud.google.com/artifact-registry/docs/gke-private-clusters)
- [Best practices for Cloud DNS - Hybrid environments](https://cloud.google.com/dns/docs/best-practices)
