# Question 078

**Source:** https://www.examtopics.com/discussions/google/view/30369-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** super administrator, organization administrator, privileged roles, least privilege

---

## Question

Your team wants to limit users with administrative privileges at the organization level. Which two roles should your team restrict? (Choose two.)
## Choices

- **A.** Organization Administrator Most Voted
- **B.** Super Admin Most Voted
- **C.** GKE Cluster Admin
- **D.** Compute Admin
- **E.** Organization Role Viewer

---

## Community

**Most Voted:** AB


**Votes:** AB: 100% (4 total)


**Top Comments:**

- (14 upvotes) A. Organization Administrator B. Super Admin

- (4 upvotes) AB is correct

- (4 upvotes) There is no such role as "Super Admin". There is a Super Admin user. which has the "Owner" role to the how Organisation. Answer is probably A and D.

---

## Answer

**Correct:** A, B

**Confidence:** high

### Explanation

The two most powerful administrative roles at the organization level are:

1. **Super Admin (B)** - This is a Google Workspace or Cloud Identity role that has irrevocable Organization Administrator privileges. According to Google's best practices documentation, super admin accounts possess "a powerful set of permissions that are not necessary for use in the daily administration of your organization." Super admins have complete control over the organization resource, including identity and identity policies. Google recommends restricting these accounts and using them only for emergency recovery purposes, not day-to-day operations.

2. **Organization Administrator (A)** - This is a Google Cloud IAM role (`roles/resourcemanager.organizationAdmin`) that provides comprehensive access to manage IAM policies and organization policies for organizations, folders, and projects. The Organization Administrator can take full control of the organization resource and assign IAM roles to other users. This role has broad permissions across the entire resource hierarchy, including setIamPolicy capabilities.

Both roles should be restricted following the principle of least privilege. Google recommends that these highly privileged roles be used sparingly, with multi-factor authentication enforced, and assigned only to users who absolutely need organization-wide administrative control.

### Why Other Options Are Wrong

- **C. GKE Cluster Admin:** This is a service-specific role that provides administrative access to Google Kubernetes Engine clusters. While powerful within GKE, it operates at the project or cluster level, not the organization level. It does not grant organization-wide administrative privileges.

- **D. Compute Admin:** This is a service-specific role for managing Compute Engine resources. Like GKE Cluster Admin, it is scoped to specific services and projects, not the entire organization. It provides administrative control over compute resources but not organization-level IAM and policy management.

- **E. Organization Role Viewer:** This is a read-only role that allows viewing organization policies and roles but does not grant administrative privileges. It follows the principle of least privilege and is not a role that needs restriction in the same way as powerful administrative roles.

### References

- [Super administrator account best practices](https://docs.cloud.google.com/resource-manager/docs/super-admin-best-practices)
- [Access control for organization resources with IAM](https://docs.cloud.google.com/resource-manager/docs/access-control-org)
