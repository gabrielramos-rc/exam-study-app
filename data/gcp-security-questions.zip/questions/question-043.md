# Question 043

**Source:** https://www.examtopics.com/discussions/google/view/35256-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, Google Cloud Directory Sync, GCDS, Active Directory, LDAP, SSO, user provisioning

---

## Question

While migrating your organization's infrastructure to GCP, a large number of users will need to access GCP Console. The Identity Management team already has a well-established way to manage your users and want to keep using your existing Active Directory or LDAP server along with the existing SSO password. What should you do?
## Choices

- **A.** Manually synchronize the data in Google domain with your existing Active Directory or LDAP server.
- **B.** Use Google Cloud Directory Sync to synchronize the data in Google domain with your existing Active Directory or LDAP server. Most Voted
- **C.** Users sign in directly to the GCP Console using the credentials from your on-premises Kerberos compliant identity provider.
- **D.** Users sign in using OpenID (OIDC) compatible IdP, receive an authentication token, then use that token to log in to the GCP Console.

---

## Community

**Most Voted:** B


**Votes:** B: 91% | D: 9% (11 total)


**Top Comments:**

- (7 upvotes) Ans : B

- (5 upvotes) https://cloud.google.com/architecture/identity/federating-gcp-with-active-directory-configuring-single-sign-on

- (3 upvotes) B is correct answer here.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Google Cloud Directory Sync (GCDS) is the recommended and official Google-provided tool for synchronizing users and groups from existing Active Directory or LDAP servers to Cloud Identity or Google Workspace. This is the correct solution because:

1. **Official Google Tool**: GCDS is a free tool specifically designed for this purpose, communicating securely over SSL with Google Cloud
2. **One-Way Synchronization**: GCDS performs one-way provisioning from AD/LDAP to Google Cloud, ensuring Active Directory remains the authoritative source
3. **Password-Free Sync**: GCDS synchronizes user and group information but NOT passwords, maintaining AD as the sole credential manager
4. **Automated and Reliable**: Runs periodically to keep user data in sync, ensuring new users in AD are automatically available in Google Cloud
5. **SSO Integration**: Works seamlessly with SAML-based SSO (via AD FS or similar), where authentication is delegated back to Active Directory while Google Cloud handles authorization

The complete federation strategy involves two components:
- **GCDS** for user/group provisioning (syncing identities)
- **SAML SSO** (via AD FS) for authentication (verifying credentials)

This combination allows the organization to maintain their existing Active Directory infrastructure and SSO passwords while extending access to Google Cloud Console.

### Why Other Options Are Wrong

- **A:** Manual synchronization is not scalable, error-prone, and lacks automation. It would require continuous manual effort to keep user lists synchronized, making it impractical for "a large number of users" and violating operational best practices.

- **C:** Direct sign-in using Kerberos credentials is not how Google Cloud Console authentication works. While Kerberos can be part of the on-premises infrastructure, Google Cloud requires SAML-based SSO for delegated authentication. Users cannot directly use Kerberos credentials to access GCP Console.

- **D:** While OIDC is a valid authentication protocol, this option describes only the authentication flow without addressing the critical requirement of user provisioning. You still need to synchronize users from AD/LDAP to Cloud Identity first (which GCDS handles) before they can authenticate. Additionally, SAML (not OIDC) is the standard protocol for federating with Active Directory.

### References

- [Federate Google Cloud with Active Directory](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-introduction)
- [Active Directory User Account Provisioning](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-synchronizing-user-accounts)
- [Active Directory Single Sign-On](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-configuring-single-sign-on)
