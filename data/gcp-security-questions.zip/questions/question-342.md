# Question 342

**Source:** https://www.examtopics.com/discussions/google/view/311185-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Securing communications and establishing boundary protection
**Tags:** Cloud Interconnect, MACsec, HA VPN, hybrid connectivity, encryption

---

## Question

Your company is in a regulated industry that requires low overhead encryption using private connectivity from on-premises data centers to Google Cloud. You need to establish connectivity and ensure high availability across multiple regions. What should you do?
## Choices

- **A.** Set up two pairs of HA VPNs using IPSec from the data centers in multiple regions.
- **B.** Set up pairs of Cloud Interconnect connections to your data centers in multiple regions, and employ MACSec encryption. Most Voted
- **C.** Set up L2TP encryption over pairs of dedicated Cloud Interconnect connections from the data centers in multiple regions.
- **D.** Set up IPSec encryption over Partner Interconnect connections from your data centers in multiple regions.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (2 total)

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B correctly addresses all requirements: low overhead encryption, private connectivity, and high availability across multiple regions. MACSec (Media Access Control Security) provides Layer 2 encryption between your on-premises routers and Google's edge routers with minimal overhead. MACSec for Cloud Interconnect has no additional cost and operates at the data link layer, making it significantly more efficient than Layer 3 encryption protocols like IPSec.

For high availability across multiple regions, Google Cloud's 99.99% availability topology requires pairs of Cloud Interconnect connections deployed across at least two regions with Cloud Routers in each region. This configuration ensures that if a region-wide issue occurs, Google Cloud can reroute traffic through the other region. Each Cloud Router is attached to a pair of Dedicated Interconnect connections in different edge availability domains, and global dynamic routing must be enabled on the VPC network.

MACSec uses the IEEE 802.1AE standard with GCM-AES-256 or GCM-AES-256-XPN cipher suites, providing strong encryption with minimal performance impact. The encryption is applied at the physical link layer, protecting data between adjacent routers without the overhead of IPSec's tunneling, encapsulation, and additional headers.

### Why Other Options Are Wrong

- **A:** HA VPN uses IPSec encryption, which operates at Layer 3 and has significantly higher overhead than MACSec due to additional encapsulation, headers, and processing requirements. While HA VPN provides high availability and encryption, it does not meet the "low overhead encryption" requirement as efficiently as MACSec.

- **C:** L2TP (Layer 2 Tunneling Protocol) over Cloud Interconnect is not a standard or documented configuration for Google Cloud. L2TP is primarily used for VPN connections and would add unnecessary overhead and complexity. Google Cloud's recommended approach for low-overhead encryption on Interconnect is MACSec, not L2TP.

- **D:** While IPSec can be used over Partner Interconnect connections, it operates at Layer 3 and has higher overhead than MACSec. IPSec requires additional packet encapsulation, security headers (ESP/AH), and more CPU processing for encryption/decryption, making it less efficient than Layer 2 MACSec encryption for dedicated physical connections.

### References

- [MACsec for Cloud Interconnect overview](https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/macsec-overview)
- [Establish 99.99% availability for Dedicated Interconnect](https://docs.cloud.google.com/network-connectivity/docs/interconnect/tutorials/dedicated-creating-9999-availability)
- [Cloud Interconnect overview](https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/overview)
