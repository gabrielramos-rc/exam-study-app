# Question 297

**Source:** https://www.examtopics.com/discussions/google/view/148652-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, folders, hierarchy inheritance, policy templates, scale management

---

## Question

Your multinational organization is undergoing rapid expansion within Google Cloud. New teams and projects are added frequently. You are concerned about the potential for inconsistent security policy application and permission sprawl across the organization. You must enforce consistent standards while maintaining the autonomy of regional teams. You need to design a strategy to effectively manage IAM and organization policies at scale, ensuring security and administrative efficiency. What should you do?
## Choices

- **A.** Create detailed organization-wide policies for common scenarios. Instruct teams to apply the policies carefully at the project and resource level as needed.
- **B.** Delegate the creation of organization policies to regional teams. Centrally review these policies for compliance before deployment.
- **C.** Define a small set of essential organization policies. Supplement these policies with a library of optional policy templates for teams to leverage as needed.
- **D.** Use a hierarchical structure of folders. Implement template-based organization policies that cascade down, allowing limited customization by regional teams.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D is the correct approach for managing IAM and organization policies at scale while balancing centralized control with regional autonomy. Google Cloud's resource hierarchy is specifically designed to support this governance model through folders and policy inheritance.

Using a hierarchical folder structure with template-based organization policies provides several critical advantages:

1. **Automatic Policy Cascading**: When organization policies are set on a folder, "all descendants of that resource inherit the organization policy by default." This ensures consistent baseline security across all projects within that folder without manual application.

2. **Controlled Customization**: The inheritance mechanism supports `inheritFromParent` settings that allow regional teams to either merge their policies with parent policies or override them when necessary. This provides the balance between central governance and regional autonomy.

3. **Policy Reconciliation**: When multiple policies apply, the system follows clear rules - DENY values always take precedence during merges, ensuring security restrictions cascade properly while allowing teams to add additional controls.

4. **Scalability**: As new teams and projects are added, they automatically inherit the appropriate policies based on their folder placement, eliminating the inconsistent policy application problem mentioned in the scenario.

5. **Administrative Efficiency**: Central security teams can maintain baseline policies at organization or high-level folder nodes, while regional teams operate within those boundaries - reducing manual effort and permission sprawl.

This approach aligns with Google Cloud's documented best practices for enterprise-scale governance, where "folders act as a policy inheritance point for allow, deny, and organization policies" and enable organizations to "apply configurations at the folder level and then all resources within the folder inherit the policies."

### Why Other Options Are Wrong

- **A:** Manual instruction for teams to "apply policies carefully" at project and resource levels creates exactly the problem stated - inconsistent policy application. This approach is error-prone, doesn't scale, and provides no automated enforcement mechanism. It relies entirely on human compliance rather than technical controls.

- **B:** Delegating policy creation to regional teams with central review creates a bottleneck that doesn't scale. The review process becomes an administrative burden as the organization expands rapidly. Additionally, this approach is reactive rather than proactive - policies must be reviewed after creation rather than built within a structured framework.

- **C:** Providing optional policy templates as a library relies on teams voluntarily adopting them, which doesn't "enforce consistent standards" as required. Optional templates can be ignored or inconsistently applied, leading to the same policy sprawl and inconsistency problems. There's no inheritance mechanism ensuring baseline compliance.

### References

- [Understanding hierarchy evaluation | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/organization-policy/understanding-hierarchy)
- [Creating and managing organization policies | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/organization-policy/creating-managing-policies)
- [Resource hierarchy | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/cloud-platform-resource-hierarchy)
