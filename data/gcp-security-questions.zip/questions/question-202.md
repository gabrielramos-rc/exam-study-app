# Question 202

**Source:** https://www.examtopics.com/discussions/google/view/117278-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** hierarchical firewall, firewall policies, Security Command Center, organization policy, perimeter security

---

## Question

Your Google Cloud organization allows for administrative capabilities to be distributed to each team through provision of a Google Cloud project with Owner role (roles/owner). The organization contains thousands of Google Cloud projects. Security Command Center Premium has surfaced multiple OPEN_MYSQL_PORT findings. You are enforcing the guardrails and need to prevent these types of common misconfigurations. What should you do?
## Choices

- **A.** Create a hierarchical firewall policy configured at the organization to deny all connections from 0.0.0.0/0.
- **B.** Create a hierarchical firewall policy configured at the organization to allow connections only from internal IP ranges. Most Voted
- **C.** Create a Google Cloud Armor security policy to deny traffic from 0.0.0.0/0.
- **D.** Create a firewall rule for each virtual private cloud (VPC) to deny traffic from 0.0.0.0/0 with priority 0.

---

## Community

**Most Voted:** B


**Votes:** A: 26% | B: 74% (19 total)


**Top Comments:**

- (6 upvotes) Link in English: https://cloud.google.com/security-command-center/docs/how-to-remediate-security-health-analytics-findings#open_mysql_port

- (4 upvotes) Open MySQL port Category name in the API: OPEN_MYSQL_PORT Firewall rules that allow any IP address to connect to MySQL ports might expose your MySQL services to attackers. For more information, see VP

- (3 upvotes) B is good

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Creating a hierarchical firewall policy at the organization level to allow connections only from internal IP ranges is the best approach to prevent OPEN_MYSQL_PORT findings across thousands of projects. This solution addresses the core issue by:

1. **Enforcing organization-wide guardrails**: Hierarchical firewall policies applied at the organization level create centralized security controls that cannot be overridden by lower-level project owners. Even with Owner roles (roles/owner) at the project level, teams cannot bypass organization-level firewall policies.

2. **Preventing misconfigurations proactively**: By implementing an allow-list approach that permits only internal IP ranges, you establish a default-deny posture for external traffic. This prevents project teams from accidentally exposing MySQL (port 3306) or other services to the public internet (0.0.0.0/0).

3. **Scalability across thousands of projects**: A single hierarchical policy applies to all VPC networks across the organization hierarchy, eliminating the need to configure rules in each individual project or VPC.

4. **Principle of least privilege**: Allowing only internal IP ranges follows security best practices by restricting access to known, trusted sources while blocking all public internet access by default.

The hierarchical firewall policy framework ensures that lower-level rules cannot override higher-level policies, making this the most effective guardrail mechanism for preventing common misconfigurations like OPEN_MYSQL_PORT findings.

### Why Other Options Are Wrong

- **A:** While denying all connections from 0.0.0.0/0 at the organization level would prevent external access, it's too restrictive and uses a deny-all approach rather than an allow-list approach. This could block legitimate external traffic that might be needed for specific services. The allow-list approach in option B is more flexible and follows better security practices by explicitly defining what is permitted.

- **C:** Google Cloud Armor is designed for Layer 7 (HTTP/HTTPS) application-level security and DDoS protection for load balancers. It cannot protect MySQL port 3306 or other non-HTTP services. Cloud Armor security policies are not appropriate for controlling network-layer access to databases and infrastructure services.

- **D:** Creating individual firewall rules in each VPC across thousands of projects is not scalable and defeats the purpose of organization-wide guardrails. Project owners with Owner roles could modify or delete these VPC-level firewall rules, making this approach ineffective for preventing misconfigurations. Additionally, priority 0 is the highest priority, but VPC firewall rules can still be overridden by project administrators.

### References

- [Hierarchical firewall policies](https://docs.cloud.google.com/firewall/docs/firewall-policies)
- [Use hierarchical firewall policies and rules](https://docs.cloud.google.com/firewall/docs/using-firewall-policies)
- [Security Command Center overview](https://docs.cloud.google.com/security-command-center/docs/security-command-center-overview)
