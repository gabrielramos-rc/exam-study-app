# Question 193

**Source:** https://www.examtopics.com/discussions/google/view/117170-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, de-identification, PII, Cloud Storage

---

## Question

Your organization's Customers must scan and upload the contract and their driver license into a web portal in Cloud Storage. You must remove all personally identifiable information (PII) from files that are older than 12 months. Also, you must archive the anonymized files for retention purposes. What should you do?
## Choices

- **A.** Set a time to live (TTL) of 12 months for the files in the Cloud Storage bucket that removes PII and moves the files to the archive storage class.
- **B.** Create a Cloud Data loss Prevention (DLP) inspection job that de-identifies PII in files created more than 12 months ago and archives them to another Cloud Storage bucket. Delete the original files. Most Voted
- **C.** Configure the Autoclass feature of the Cloud Storage bucket to de-identify PII. Archive the files that are older than 12 months. Delete the original files.
- **D.** Schedule a Cloud Key Management Service (KMS) rotation period of 12 months for the encryption keys of the Cloud Storage files containing PII to de-identify them. Delete the original keys.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (7 total)


**Top Comments:**

- (6 upvotes) - Cloud DLP is specifically designed to detect and de-identify sensitive data like PII. You can configure an inspection job to target files older than 12 months and remove PII before archiving. - DLP 

- (2 upvotes) B is accurate

- (2 upvotes) I'll go with B

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud Data Loss Prevention (now called Sensitive Data Protection) is specifically designed to identify, classify, and de-identify PII in various data stores, including Cloud Storage. The service provides inspection jobs (DlpJob) that can scan Cloud Storage buckets for sensitive data and create de-identified copies of those files in a separate bucket.

The correct approach involves:

1. **Creating a DLP inspection job** configured with a StorageConfig object pointing to the source bucket
2. **Configuring an InspectConfig** to detect PII types (driver's license numbers, names, addresses, etc.)
3. **Enabling the de-identification action** within the inspection job to transform detected PII
4. **Specifying an output bucket** for de-identified copies (the archive location)
5. **Adding filters** to target only files older than 12 months
6. **Deleting original files** after successful de-identification to maintain only anonymized versions

Sensitive Data Protection supports over 200 built-in information type detectors for PII and can apply various de-identification techniques including redaction, masking, tokenization, and format-preserving encryption. The service creates a file structure in the output directory that mirrors the input directory structure.

### Why Other Options Are Wrong

- **A:** Cloud Storage TTL (Object Lifecycle Management) can delete or change storage classes based on age, but it cannot remove PII from files. TTL policies only manage object lifecycle, not content transformation. This option conflates lifecycle management with data de-identification, which are completely separate capabilities.

- **C:** Autoclass is a Cloud Storage feature that automatically transitions objects between storage classes (Standard, Nearline, Coldline, Archive) based on access patterns to optimize costs. It has no capability to de-identify PII or modify file contents. Autoclass only manages storage class transitions, not data transformation.

- **D:** Cloud KMS key rotation changes the cryptographic keys used to encrypt data but does not de-identify or remove PII from files. Rotating encryption keys simply re-encrypts the data with a new key while preserving the original content. The PII remains intact and readable when the data is decrypted. Key rotation is for cryptographic security, not data anonymization.

### References

- [Create de-identified copies of data stored in Cloud Storage using the API](https://docs.cloud.google.com/sensitive-data-protection/docs/deidentify-storage)
- [De-identification and re-identification of PII in large-scale datasets](https://docs.cloud.google.com/architecture/de-identification-re-identification-pii-using-cloud-dlp)
- [De-identification of sensitive Cloud Storage data](https://docs.cloud.google.com/sensitive-data-protection/docs/concepts-deidentify-storage)
