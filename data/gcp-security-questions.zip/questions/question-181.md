# Question 181

**Source:** https://www.examtopics.com/discussions/google/view/117080-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** patch management, VM Manager, OS patch, Cloud NAT, vulnerability management

---

## Question

Your organization operates Virtual Machines (VMs) with only private IPs in the Virtual Private Cloud (VPC) with internet access through Cloud NAT. Everyday, you must patch all VMs with critical OS updates and provide summary reports. What should you do?
## Choices

- **A.** Validate that the egress firewall rules allow any outgoing traffic. Log in to each VM and execute OS specific update commands. Configure the Cloud Scheduler job to update with critical patches daily for daily updates.
- **B.** Copy the latest patches to the Cloud Storage bucket. Log in to each VM, download the patches from the bucket, and install them.
- **C.** Assign public IPs to VMs. Validate that the egress firewall rules allow any outgoing traffic. Log in to each VM, and configure a daily cron job to enable for OS updates at night during low activity periods.
- **D.** Ensure that VM Manager is installed and running on the VMs. In the OS patch management service, configure the patch jobs to update with critical patches dally. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (9 total)


**Top Comments:**

- (3 upvotes) D vm doesn’t need ip public on cloud nat

- (2 upvotes) D is the correct

- (2 upvotes) A- validate egress firewall rules

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

VM Manager's OS patch management service is the native Google Cloud solution designed specifically for this scenario. It provides:

**Automated Patch Management:**
- Centralized patch job orchestration across all VMs
- Schedule patch jobs (one-time or recurring) to run daily with critical OS updates
- Supports both Windows and Linux distributions
- Uses OS-native utilities (yum, apt, Windows Update Agent) to apply patches

**Private IP Compatibility:**
- Works seamlessly with VMs that have only private IPs
- The OS Config agent on VMs accesses package repositories through Cloud NAT (as mentioned in the question)
- No public IP assignment required

**Reporting and Compliance:**
- Provides a Patch Dashboard showing compliance status organized by OS
- Categorized vulnerability reports with CVE mappings
- Individual VM patch status details
- Compliance backend periodically reads inventory data and cross-references with vulnerability sources

**Operational Efficiency:**
- No manual login to individual VMs required
- Can patch up to 500 VMs in a single patch deployment
- Maintenance windows and disruption budgets for controlled patching
- Cloud Monitoring integration for aggregate VM state tracking

The OS Config agent must be installed on VMs, and the OS Config API must be enabled to use this service.

### Why Other Options Are Wrong

- **A:** Manually logging into each VM is operationally inefficient and doesn't scale. Cloud Scheduler cannot directly execute OS-level patch commands on VMs. This approach lacks centralized reporting and compliance tracking capabilities.

- **B:** Manually downloading and installing patches from Cloud Storage is extremely inefficient and error-prone. This approach requires manual login to each VM, lacks automation, and doesn't leverage OS-native package management systems. It also provides no built-in reporting or compliance tracking.

- **C:** Assigning public IPs violates the stated requirement that VMs only have private IPs. Adding public IPs increases the attack surface unnecessarily when Cloud NAT already provides internet access. Using cron jobs lacks centralized management, reporting, and compliance visibility across the VM fleet.

### References

- [About Patch - VM Manager](https://docs.cloud.google.com/compute/vm-manager/docs/patch)
- [Manage patch jobs - VM Manager](https://docs.cloud.google.com/compute/vm-manager/docs/patch/manage-patch-jobs)
- [Schedule patch jobs - VM Manager](https://docs.cloud.google.com/compute/vm-manager/docs/patch/schedule-patch-jobs)
