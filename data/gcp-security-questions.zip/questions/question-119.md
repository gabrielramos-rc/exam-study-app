# Question 119

**Source:** https://www.examtopics.com/discussions/google/view/76027-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Identity-Aware Proxy, IAP TCP forwarding, bastion host, SSH access, perimeter security

---

## Question

You are a member of your company's security team. You have been asked to reduce your Linux bastion host external attack surface by removing all public IP addresses. Site Reliability Engineers (SREs) require access to the bastion host from public locations so they can access the internal VPC while off-site. How should you enable this access?
## Choices

- **A.** Implement Cloud VPN for the region where the bastion host lives.
- **B.** Implement OS Login with 2-step verification for the bastion host.
- **C.** Implement Identity-Aware Proxy TCP forwarding for the bastion host. Most Voted
- **D.** Implement Google Cloud Armor in front of the bastion host.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (12 total)


**Top Comments:**

- (6 upvotes) To enable access to the bastion host from public locations while reducing the Linux bastion host external attack surface by removing all public IP addresses, you should implement Identity-Aware Proxy 

- (3 upvotes) C is correct

- (2 upvotes) Correct. Ref.https://cloud.google.com/architecture/building-internet-connectivity-for-private-vms#configuring_iap_tunnels_for_interacting_with_instances

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Identity-Aware Proxy (IAP) TCP forwarding is the correct solution because it specifically enables SSH access to VM instances without requiring public IP addresses. According to Google Cloud documentation, "TCP forwarding with IAP doesn't require a public, routable IP address assigned to your resource. Instead, it uses internal IPs."

IAP TCP forwarding works by:
1. Creating a listening port on the local client that forwards traffic to the target instance
2. Wrapping all traffic from the client in HTTPS for secure transmission
3. Requiring users to pass authentication and authorization checks (based on IAM policies) before gaining access
4. Allowing SREs to connect from anywhere (public locations) without exposing the bastion host to the internet

This directly addresses the requirement to "reduce your Linux bastion host external attack surface by removing all public IP addresses" while still enabling SREs to "access the bastion host from public locations."

### Why Other Options Are Wrong

- **A:** Cloud VPN would provide connectivity between on-premises networks and Google Cloud, but it requires establishing a VPN gateway and doesn't address the specific need for individual SRE access from arbitrary public locations. VPN is designed for site-to-site connectivity, not individual user access from public locations.

- **B:** OS Login with 2-step verification enhances authentication security for SSH access, but it doesn't solve the fundamental problem of removing public IP addresses. The bastion host would still need a public IP address for SREs to connect from public locations. OS Login is a complementary security feature that should be used alongside IAP, not as a replacement for it.

- **D:** Google Cloud Armor is a web application firewall (WAF) and DDoS protection service designed for HTTP(S) load balancers. It cannot be placed "in front of" a bastion host to enable SSH access, and it doesn't eliminate the need for public IP addresses. Cloud Armor is for protecting web applications, not enabling SSH connectivity.

### References

- [TCP forwarding overview | Identity-Aware Proxy](https://docs.cloud.google.com/iap/docs/tcp-forwarding-overview)
- [Using IAP for TCP forwarding](https://docs.cloud.google.com/iap/docs/using-tcp-forwarding)
- [Connect to Linux VMs using Identity-Aware Proxy](https://docs.cloud.google.com/compute/docs/connect/ssh-using-iap)
