# Question 311

**Source:** https://www.examtopics.com/discussions/google/view/150183-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** Binary Authorization, attestation, vulnerability scanning, container security, CI/CD pipeline

---

## Question

Your organization is worried about recent news headlines regarding application vulnerabilities in production applications that have led to security breaches. You want to automatically scan your deployment pipeline for vulnerabilities and ensure only scanned and verified containers can run in the environment. What should you do?
## Choices

- **A.** Use Kubernetes role-based access control (RBAC) as the source of truth for cluster access by granting "container.clusters.get" to limited users. Restrict deployment access by allowing these users to generate a kubeconfig file containing the configuration access to the GKE cluster.
- **B.** Use gcloud artifacts docker images describe LOCATION-docker.pkg.dev/PROJECT_ID/REPOSITORY/IMAGE_ID@sha256:HASH --show-package-vulnerability in your CI/CD pipeline, and trigger a pipeline failure for critical vulnerabilities.
- **C.** Enforce the use of Cloud Code for development so users receive real-time security feedback on vulnerable libraries and dependencies before they check in their code.
- **D.** Enable Binary Authorization and create attestations of scans. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (4 total)


**Top Comments:**

- (2 upvotes) https://cloud.google.com/binary-authorization/docs/attestations D

- (2 upvotes) D: https://cloud.google.com/binary-authorization/docs/making-attestations?hl=es-419

- (2 upvotes) Answer D

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Binary Authorization with attestations is the correct solution for ensuring only scanned and verified containers can run in production. This service provides a complete enforcement mechanism that works as follows:

1. **Attestation Creation**: After a container image is built and scanned for vulnerabilities, an attestation is created to affirm that the vulnerability scan was performed. The attestation digitally signs the image's unique digest.

2. **Policy Enforcement**: Binary Authorization enforces deployment policies that require specific attestations before allowing container images to deploy to GKE or Cloud Run.

3. **Deployment-Time Verification**: When a deployment is attempted, Binary Authorization uses attestors (which contain cryptographic public keys) to verify the digital signatures in attestations. If all required attestations are verified, the image is allowed to deploy; otherwise, deployment is blocked.

4. **Automated Pipeline Integration**: This process integrates seamlessly with CI/CD pipelines - vulnerability scans run automatically, attestations are created for images that pass, and only attested images can reach production.

This approach shifts security verification from deployment-time to pre-deployment, ensuring that no unscanned or vulnerable containers can run while maintaining deployment speed.

### Why Other Options Are Wrong

- **A:** Kubernetes RBAC controls who can access the cluster and deploy workloads, but it doesn't verify that containers have been scanned for vulnerabilities or prevent vulnerable images from being deployed. RBAC is an access control mechanism, not a container verification system.

- **B:** While checking vulnerabilities in the CI/CD pipeline is good practice, this command only provides visibility into vulnerabilities. It doesn't enforce that containers are scanned or prevent unverified images from being deployed through other means. An image could still be deployed manually or through another pipeline that bypasses this check.

- **C:** Cloud Code provides real-time feedback during development, which is helpful for developers but happens too early in the lifecycle. It doesn't enforce that containers passing through the deployment pipeline have been scanned, and it can't prevent deployment of unscanned images. It's a development tool, not an enforcement mechanism.

### References

- [Attestations overview | Binary Authorization](https://docs.cloud.google.com/binary-authorization/docs/attestations)
- [Use the vulnerability check | Binary Authorization](https://docs.cloud.google.com/binary-authorization/docs/cv-vulnerability-check)
- [Securing deployments | Artifact Registry](https://docs.cloud.google.com/artifact-registry/docs/secure-deployments)
