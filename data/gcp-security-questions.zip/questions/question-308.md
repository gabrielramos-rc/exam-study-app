# Question 308

**Source:** https://www.examtopics.com/discussions/google/view/148663-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, PII, de-identification, transformation, data integrity

---

## Question

Your organization wants to publish yearly reports of your website usage analytics. You must ensure that no data with personally identifiable information (PII) is published by using the Cloud Data Loss Prevention (Cloud DLP) API. Data integrity must be preserved. What should you do?
## Choices

- **A.** Detect all PII in storage by using the Cloud DLP API. Create a cloud function to delete the PII.
- **B.** Discover and quarantine your PII data in your storage by using the Cloud DLP API.
- **C.** Discover and transform PII data in your reports by using the Cloud DLP API.
- **D.** Encrypt the PII from the report by using the Cloud DLP API.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is correct because Cloud DLP (now part of Sensitive Data Protection) provides **transformation methods** that de-identify PII while **preserving data integrity** for analytics purposes. The key requirement is to publish yearly analytics reports without PII while maintaining data utility.

Cloud DLP supports multiple transformation methods that preserve analytical value:

- **Format-Preserving Encryption (FPE-FFX)**: Replaces sensitive data with encrypted tokens that maintain the original length and character set
- **Deterministic encryption**: Creates consistent tokens that preserve referential integrity across datasets
- **Date shifting**: Maintains temporal relationships while obscuring exact dates
- **Bucketing/generalization**: Groups numerical data into ranges for statistical analysis
- **Cryptographic hashing**: Generates surrogate values that maintain data patterns

These transformations allow the analytics reports to remain useful for statistical analysis and trend identification while ensuring no actual PII is exposed. The data can still be aggregated, joined, and analyzed because the transformations preserve the structural and relational properties of the data.

### Why Other Options Are Wrong

- **A:** Deleting PII violates the requirement to "preserve data integrity." Deletion removes the data entirely, making the analytics incomplete and potentially useless. The reports would have gaps where PII existed, destroying their analytical value.

- **B:** Quarantining PII means isolating it from the rest of the data, which doesn't solve the problem of publishing reports. The PII would still exist but be separated, and the published reports would be incomplete. This doesn't enable publishing useful analytics while protecting PII.

- **D:** Simply encrypting PII without transformation doesn't work for published reports. The encrypted values would still appear in the reports as ciphertext, which provides no analytical value to report readers. Additionally, "encrypt" is ambiguous - if readers can't decrypt it, it's useless; if they can, the PII is exposed.

### References

- [De-identification and re-identification of PII in large-scale datasets using Sensitive Data Protection](https://docs.cloud.google.com/architecture/de-identification-re-identification-pii-using-cloud-dlp)
- [De-identifying sensitive data](https://docs.cloud.google.com/sensitive-data-protection/docs/deidentify-sensitive-data)
- [Transformation reference](https://docs.cloud.google.com/sensitive-data-protection/docs/transformations-reference)
