# Question 116

**Source:** https://www.examtopics.com/discussions/google/view/75402-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Logging, log sink, Cloud Storage, bucket ACL, fine-grained access

---

## Question

You are exporting application logs to Cloud Storage. You encounter an error message that the log sinks don't support uniform bucket-level access policies. How should you resolve this error?

## Choices

- **A.** Change the access control model for the bucket Most Voted
- **B.** Update your sink with the correct bucket destination.
- **C.** Add the roles/logging.logWriter Identity and Access Management (IAM) role to the bucket for the log sink identity.
- **D.** Add the roles/logging.bucketWriter Identity and Access Management (IAM) role to the bucket for the log sink identity.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (22 total)


**Top Comments:**

- (11 upvotes) Uniform Bucket-Level Access (UBLA) is a feature in Google Cloud Storage that allows you to use Identity and Access Management (IAM) to manage access to a bucket's content. When it is enabled, Access C

- (5 upvotes) To resolve the error message that the log sinks don’t support uniform bucket-level access policies when exporting application logs to Cloud Storage, you should change the access control model for the 

- (4 upvotes) Answer is (A). If bucket-level access policies are not supported, Fine-grained is being used. The recommended architecture is Uniform bucket-level access. Therefore, Change the access control model fo

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The error message explicitly states that "log sinks don't support uniform bucket-level access policies." This indicates that Cloud Logging requires the bucket to use **fine-grained access control** (which allows both IAM and ACLs) rather than uniform bucket-level access (which only allows IAM).

Cloud Storage offers two access control models:
1. **Uniform bucket-level access**: Uses only IAM permissions across all objects, disables ACLs
2. **Fine-grained access**: Allows both IAM and Access Control Lists (ACLs) to work in parallel

Cloud Logging sinks that export to Cloud Storage require fine-grained access control because they need to set ACL permissions on the log objects being written to the bucket. When uniform bucket-level access is enabled, ACLs are completely disabled, which prevents the logging service from functioning properly.

To resolve this error, you must **change the access control model from uniform to fine-grained** on the destination Cloud Storage bucket. This can be done by disabling uniform bucket-level access (if it was enabled within the last 90 days) to restore ACL support.

### Why Other Options Are Wrong

- **B:** Updating the sink destination won't help because the issue is with the bucket's access control configuration, not the sink configuration itself. The sink is already pointing to the correct bucket; the bucket just has the wrong access control model.

- **C:** The role `roles/logging.logWriter` doesn't exist in Google Cloud IAM. The correct role for log sinks writing to Cloud Storage is `roles/storage.objectCreator`, but adding IAM roles alone won't resolve the fundamental issue that the bucket has uniform bucket-level access enabled.

- **D:** The role `roles/logging.bucketWriter` doesn't exist in Google Cloud IAM. This is not a valid role. Even if the correct storage role were used, it wouldn't solve the access control model incompatibility.

### References

- [Overview of access control - Cloud Storage](https://docs.cloud.google.com/storage/docs/access-control)
- [Uniform bucket-level access - Cloud Storage](https://docs.cloud.google.com/storage/docs/uniform-bucket-level-access)
- [Route logs to supported destinations - Cloud Logging](https://docs.cloud.google.com/logging/docs/export/configure_export_v2)
