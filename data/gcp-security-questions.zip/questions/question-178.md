# Question 178

**Source:** https://www.examtopics.com/discussions/google/view/103569-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, format-preserving encryption, pseudonymization, de-identification

---

## Question

An organization wants to track how bonus compensations have changed over time to identify employee outliers and correct earning disparities. This task must be performed without exposing the sensitive compensation data for any individual and must be reversible to identify the outlier. Which Cloud Data Loss Prevention API technique should you use?
## Choices

- **A.** Cryptographic hashing
- **B.** Redaction
- **C.** Format-preserving encryption Most Voted
- **D.** Generalization

---

## Community

**Most Voted:** C


**Votes:** C: 81% | D: 19% (16 total)


**Top Comments:**

- (4 upvotes) D - right

- (3 upvotes) C is correct

- (3 upvotes) Answer D

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Format-preserving encryption (FPE) is the correct technique because it satisfies all three requirements of this use case:

1. **Tracking changes over time**: FPE uses deterministic encryption (specifically the FFX mode of operation), which means the same input value always produces the same encrypted output. This allows you to track how compensation values change over time by comparing encrypted values across different time periods without decrypting them.

2. **Protecting sensitive data**: FPE encrypts the compensation data, preventing exposure of individual sensitive values while maintaining data utility. The encrypted values can be used for analysis and comparison without revealing the actual compensation amounts.

3. **Reversibility to identify outliers**: FPE is a two-way transformation that can be reversed using the cryptographic key. When statistical analysis identifies an outlier in the encrypted dataset, authorized personnel can use the re-identification API with the same key to decrypt and reveal the specific employee's actual compensation data for corrective action.

FPE also preserves the format and character set of the original data, making it particularly useful for structured data like compensation tables where maintaining numeric formats aids in analysis.

### Why Other Options Are Wrong

- **A. Cryptographic hashing:** While hashing creates deterministic tokens that allow tracking patterns over time, it is a one-way transformation using HMAC-SHA-256 that cannot be reversed. This violates the requirement to "identify the outlier" by reversing the transformation to reveal the actual employee.

- **B. Redaction:** Redaction completely removes or masks sensitive data (replacing it with placeholder values like asterisks or blanks). This technique destroys the underlying values entirely, making it impossible to track changes over time or perform any meaningful statistical analysis to identify outliers.

- **D. Generalization:** Generalization replaces specific values with broader categories or ranges (e.g., replacing "$75,000" with "$50,000-$100,000"). While this protects privacy, it reduces data granularity too much to track individual changes over time, and the transformation is not reversible to identify specific outliers.

### References

- [Pseudonymization | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/pseudonymization)
- [De-identify table data with format-preserving encryption](https://docs.cloud.google.com/sensitive-data-protection/docs/samples/dlp-deidentify-table-fpe)
- [Re-identify content encrypted by FPE](https://docs.cloud.google.com/sensitive-data-protection/docs/samples/dlp-reidentify-fpe)
