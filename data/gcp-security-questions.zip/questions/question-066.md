# Question 066

**Source:** https://www.examtopics.com/discussions/google/view/30354-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** Cloud KMS, CMEK, KeyRing, IAM permissions, encryption at rest

---

## Question

You want data on Compute Engine disks to be encrypted at rest with keys managed by Cloud Key Management Service (KMS). Cloud Identity and Access Management (IAM) permissions to these keys must be managed in a grouped way because the permissions should be the same for all keys. What should you do?
## Choices

- **A.** Create a single KeyRing for all persistent disks and all Keys in this KeyRing. Manage the IAM permissions at the Key level.
- **B.** Create a single KeyRing for all persistent disks and all Keys in this KeyRing. Manage the IAM permissions at the KeyRing level. Most Voted
- **C.** Create a KeyRing per persistent disk, with each KeyRing containing a single Key. Manage the IAM permissions at the Key level.
- **D.** Create a KeyRing per persistent disk, with each KeyRing containing a single Key. Manage the IAM permissions at the KeyRing level.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (5 total)


**Top Comments:**

- (15 upvotes) B. Create a single KeyRing for all persistent disks and all Keys in this KeyRing. Manage the IAM permissions at the KeyRing level: This is efficient. By managing permissions at the KeyRing level, you'

- (3 upvotes) Answer-B

- (3 upvotes) Answer-B

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B is the correct approach because it aligns perfectly with the Cloud KMS resource hierarchy design and the requirement to manage permissions "in a grouped way" where "permissions should be the same for all keys."

**Why this is correct:**

1. **KeyRings are designed for grouping keys with identical IAM permissions**: According to Google Cloud documentation, "A key ring organizes keys in a specific Google Cloud location and lets you manage access control on groups of keys." This is exactly the use case described in the question.

2. **IAM inheritance from KeyRing to Keys**: When you grant IAM permissions at the KeyRing level, all keys within that KeyRing automatically inherit those permissions. As stated in the documentation, "a user who is granted the `cloudkms.admin` role on a key ring, they have the associated permissions on all the keys in that key ring."

3. **Operational efficiency**: Managing permissions at the KeyRing level means you only need to configure IAM once for the entire group of keys, rather than repeating the same permission grants on each individual key. This reduces administrative overhead and ensures consistency.

4. **Single KeyRing for all persistent disks**: Since all persistent disks need the same permissions (as stated in the question), placing all keys in a single KeyRing and managing permissions at that level is the most efficient approach.

### Why Other Options Are Wrong

- **A:** While creating a single KeyRing is correct, managing IAM permissions at the Key level defeats the purpose of using a KeyRing for grouping. You would have to separately configure the same permissions on each key, which is inefficient and error-prone when permissions should be identical across all keys.

- **C:** Creating a KeyRing per persistent disk with a single key means you lose the benefit of grouping keys together. You would still need to manage IAM at each individual key, which is operationally inefficient and doesn't satisfy the requirement to manage permissions "in a grouped way."

- **D:** While managing at the KeyRing level is correct, creating a separate KeyRing per persistent disk with single keys defeats the purpose. You would need to apply the same IAM permissions to multiple KeyRings instead of managing them once at a single KeyRing. This adds unnecessary complexity and administrative overhead.

### References

- [Cloud KMS IAM Permissions](https://docs.cloud.google.com/kms/docs/iam)
- [Cloud KMS Resource Hierarchy](https://docs.cloud.google.com/kms/docs/resource-hierarchy)
