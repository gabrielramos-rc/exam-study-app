# Question 115

**Source:** https://www.examtopics.com/discussions/google/view/75335-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** logging, IAM roles, audit logs, data access logs, Access Transparency, least privilege

---

## Question

The security operations team needs access to the security-related logs for all projects in their organization. They have the following requirements: ✑ Follow the least privilege model by having only view access to logs. ✑ Have access to Admin Activity logs. ✑ Have access to Data Access logs. ✑ Have access to Access Transparency logs. Which Identity and Access Management (IAM) role should the security operations team be granted?
## Choices

- **A.** roles/logging.privateLogViewer Most Voted
- **B.** roles/logging.admin
- **C.** roles/viewer
- **D.** roles/logging.viewer

---

## Community

**Most Voted:** A


**Votes:** A: 86% | D: 14% (14 total)


**Top Comments:**

- (18 upvotes) Ref: https://cloud.google.com/logging/docs/access-control

- (5 upvotes) You need roles/logging.privateLogViewer to view data access log and Access Transparency logs https://cloud.google.com/cloud-provider-access-management/access-transparency/docs/reading-logs#viewing-log

- (5 upvotes) For access to all logs in the _Required bucket, and access to the _Default view on the _Default bucket, grant the Logs Viewer (roles/logging.viewer) role. For access to all logs in the _Required and _

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The `roles/logging.privateLogViewer` (Private Logs Viewer) role is the correct choice because it is the only role that meets all three requirements while following the least privilege principle:

1. **View-only access**: It provides read-only access to logs without administrative permissions
2. **Admin Activity logs access**: Includes permissions to view Admin Activity audit logs stored in the _Required bucket
3. **Data Access logs access**: Critically, it includes the `logging.privateLogEntries.list` permission, which is required to access Data Access audit logs in the _Default bucket
4. **Access Transparency logs access**: Provides access to Access Transparency logs, which are considered private logs

The key distinguishing feature is that Private Logs Viewer extends the standard Logs Viewer role by adding access to sensitive audit logs, particularly Data Access logs, which are explicitly excluded from the regular Logs Viewer role for security reasons.

### Why Other Options Are Wrong

- **B (roles/logging.admin):** While this role would provide access to all required logs, it violates the least privilege principle by granting administrative permissions including the ability to create, modify, and delete log configurations, sinks, and buckets. The team only needs view access, not admin capabilities.

- **C (roles/viewer):** This is a basic viewer role at the project level that provides read-only access to most GCP resources, but it does not include the specific permissions needed to access Data Access audit logs. It lacks the `logging.privateLogEntries.list` permission required for viewing sensitive audit data.

- **D (roles/logging.viewer):** The Logs Viewer role provides access to Admin Activity and System Event logs but explicitly excludes Data Access audit logs. It lacks the `logging.privateLogEntries.list` permission, making it insufficient for the security team's requirements to access all three log types.

### References

- [Access control with IAM - Cloud Logging](https://docs.cloud.google.com/logging/docs/access-control)
- [Cloud Audit Logs overview](https://docs.cloud.google.com/logging/docs/audit)
