# Question 041

**Source:** https://www.examtopics.com/discussions/google/view/16482-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** object lifecycle, retention policy, PII, data deletion, Cloud Storage

---

## Question

Your company runs a website that will store PII on Google Cloud Platform. To comply with data privacy regulations, this data can only be stored for a specific amount of time and must be fully deleted after this specific period. Data that has not yet reached the time period should not be deleted. You want to automate the process of complying with this regulation. What should you do?
## Choices

- **A.** Store the data in a single Persistent Disk, and delete the disk at expiration time.
- **B.** Store the data in a single BigQuery table and set the appropriate table expiration time.
- **C.** Store the data in a single Cloud Storage bucket and configure the bucket's Time to Live. Most Voted
- **D.** Store the data in a single BigTable table and set an expiration time on the column families.

---

## Community

**Most Voted:** C


**Votes:** B: 10% | C: 80% | D: 10% (10 total)


**Top Comments:**

- (14 upvotes) Answer C is correct. The TTL is common use case of Cloud Storage life cycle management. Here is what GCP says: "To support common use cases like setting a Time to Live (TTL) for objects, retaining non

- (7 upvotes) This answer is still valid till 2024

- (4 upvotes) I believe B is correct. Setting a TTL of 14 days on the bucket via LifeCycle will not cause the bucket itself to be deleted after 14 days, instead it will cause each object uploaded to that bucket to 

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Cloud Storage with Object Lifecycle Management (commonly referred to as "Time to Live" or TTL) is the correct and standard solution for automatically deleting data after a specific retention period.

Google's own documentation explicitly describes this use case: *"To support common use cases like setting a Time to Live (TTL) for objects, retaining noncurrent versions of objects, or 'downgrading' storage classes..."*

How it works:
1. Each object in Cloud Storage has its own **creation timestamp**
2. Lifecycle rules with an **Age condition** delete objects individually when they reach the specified age
3. Objects that haven't reached the retention period remain untouched

For example, with a 30-day TTL:
- Object uploaded Jan 1 → deleted Jan 31
- Object uploaded Jan 15 → deleted Feb 14

This provides exactly what the question requires: automated, per-object deletion based on individual creation times.

### Why Other Options Are Wrong

- **A:** Persistent Disk deletion is manual and all-or-nothing. There's no built-in automatic deletion mechanism, and deleting the entire disk would delete ALL data regardless of when each record was created.

- **B:** BigQuery table expiration operates at the **table level only**. When a table expires, ALL rows are deleted simultaneously, regardless of when each row was inserted. This cannot satisfy the requirement that "data not yet at the retention period should not be deleted."

- **D:** While Bigtable's column family garbage collection does provide per-cell TTL, it's overkill for simple PII storage and deletion. Cloud Storage is the simpler, more common solution for this use case and is what the question's "Time to Live" terminology refers to.

### References

- [Object Lifecycle Management | Cloud Storage](https://cloud.google.com/storage/docs/lifecycle)
- [Lifecycle configuration examples](https://cloud.google.com/storage/docs/lifecycle-configurations)
- [Managing object lifecycles](https://cloud.google.com/storage/docs/managing-lifecycles)
