# Question 243

**Source:** https://www.examtopics.com/discussions/google/view/126783-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Identity-Aware Proxy, IAP, HTTP Load Balancer, authentication, authorization, Google credentials

---

## Question

An administrative application is running on a virtual machine (VM) in a managed group at port 5601 inside a Virtual Private Cloud (VPC) instance without access to the internet currently. You want to expose the web interface at port 5601 to users and enforce authentication and authorization Google credentials. What should you do?
## Choices

- **A.** Configure the bastion host with OS Login enabled and allow connection to port 5601 at VPC firewall. Log in to the bastion host from the Google Cloud console by using SSH-in-browser and then to the web application.
- **B.** Modify the VPC routing with the default route point to the default internet gateway. Modify the VPC Firewall rule to allow access from the internet 0.0.0.0/0 to port 5601 on the application instance.
- **C.** Configure Secure Shell Access (SSH) bastion host in a public network, and allow only the bastion host to connect to the application on port 5601. Use a bastion host as a jump host to connect to the application.
- **D.** Configure an HTTP Load Balancing instance that points to the managed group with Identity-Aware Proxy (IAP) protection with Google credentials. Modify the VPC firewall to allow access from IAP network range. Most Voted

---

## Community

**Most Voted:** D


**Votes:** B: 20% | D: 80% (5 total)


**Top Comments:**

- (2 upvotes) D is the answer

- (1 upvotes) The only viable option

- (1 upvotes) How B could enforce authentication and authorization Google credentials?

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Identity-Aware Proxy (IAP) with HTTP Load Balancer is the correct solution for exposing a web application with Google credential-based authentication and authorization. This approach provides:

1. **Authentication with Google Credentials**: IAP uses a Google-managed OAuth client to authenticate users. When IAP is enabled, it automatically creates an OAuth 2.0 client ID and secret, requiring login credentials for all connections to the load balancer.

2. **Authorization Control**: Only users granted the IAP-Secured Web App User role (`roles/iap.httpsResourceAccessor`) can access the application. This provides fine-grained, identity-based access control instead of network-level firewalls.

3. **Proper Firewall Configuration**: The firewall must allow traffic from the load balancer IP ranges (130.211.0.0/22 and 35.191.0.0/16), which include Google Cloud health checking systems and load balancer traffic. Without these firewall rules, the default deny ingress rule blocks incoming traffic to backend instances.

4. **No Direct Internet Exposure**: The VMs remain private within the VPC without direct internet access. All traffic flows through the load balancer and IAP, which acts as a security gateway performing authentication and authorization checks before forwarding requests.

### Why Other Options Are Wrong

- **A:** Using a bastion host with OS Login provides SSH access to VMs but doesn't expose the web application at port 5601 to end users. Users would need to SSH into the bastion and then manually connect to the application, which doesn't meet the requirement of exposing the web interface directly to users.

- **B:** Opening port 5601 to the entire internet (0.0.0.0/0) exposes the application without any authentication or authorization. This is a critical security vulnerability as anyone on the internet could access the administrative application. It violates security best practices and doesn't enforce Google credential-based access control.

- **C:** While a bastion host provides an additional security layer, it still requires users to SSH through the bastion to access the application. This doesn't directly expose the web interface to users and doesn't provide the seamless Google credential-based authentication and authorization required. It's an infrastructure access pattern, not a web application access pattern.

### References

- [Identity-Aware Proxy overview](https://docs.cloud.google.com/iap/docs/concepts-overview)
- [Enable IAP for Compute Engine](https://docs.cloud.google.com/iap/docs/enabling-compute-howto)
- [Setting up an external Application Load Balancer with IAP](https://docs.cloud.google.com/iap/docs/load-balancer-howto)
- [IAP Troubleshooting - Firewall Requirements](https://docs.cloud.google.com/iap/docs/faq)
