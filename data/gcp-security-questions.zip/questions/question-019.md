# Question 019

**Source:** https://www.examtopics.com/discussions/google/view/27108-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** envelope encryption, Cloud KMS, DEK, KEK, application layer encryption

---

## Question

You need to follow Google-recommended practices to leverage envelope encryption and encrypt data at the application layer. What should you do?
## Choices

- **A.** Generate a data encryption key (DEK) locally to encrypt the data, and generate a new key encryption key (KEK) in Cloud KMS to encrypt the DEK. Store both the encrypted data and the encrypted DEK. Most Voted
- **B.** Generate a data encryption key (DEK) locally to encrypt the data, and generate a new key encryption key (KEK) in Cloud KMS to encrypt the DEK. Store both the encrypted data and the KEK.
- **C.** Generate a new data encryption key (DEK) in Cloud KMS to encrypt the data, and generate a key encryption key (KEK) locally to encrypt the key. Store both the encrypted data and the encrypted DEK.
- **D.** Generate a new data encryption key (DEK) in Cloud KMS to encrypt the data, and generate a key encryption key (KEK) locally to encrypt the key. Store both the encrypted data and the KEK.

---

## Community

**Most Voted:** A


**Votes:** A: 80% | B: 20% (5 total)


**Top Comments:**

- (22 upvotes) Agree on A, spot on "KEK never leaves Cloud KMS"

- (3 upvotes) A is the correct answer as stated in google docs The process of encrypting data is to generate a DEK locally, encrypt data with the DEK, use a KEK to wrap the DEK, and then store the encrypted data an

- (2 upvotes) KMS is used for storing KEK in CSEK &amp; CMEK

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A follows Google's recommended practices for envelope encryption at the application layer. According to Google Cloud documentation:

1. **DEK Generation**: Data encryption keys (DEKs) should be generated locally (not in Cloud KMS) using strong cryptographic libraries like OpenSSL with 256-bit AES-GCM.

2. **KEK Management**: Key encryption keys (KEKs) should be created and stored in Cloud KMS as your central keystore. The KEK never leaves Cloud KMS.

3. **Storage Pattern**: You must store both the encrypted data AND the encrypted (wrapped) DEK together. The plaintext DEK should NEVER be stored.

This architecture allows for efficient encryption workflows: when you need to decrypt data, you retrieve both the encrypted data and the wrapped DEK, send the wrapped DEK to Cloud KMS for unwrapping, receive the plaintext DEK, use it to decrypt your data, then immediately discard the plaintext DEK. The KEK remains securely in Cloud KMS throughout this process.

### Why Other Options Are Wrong

- **B:** Incorrect because you should NOT store the KEK itself - the KEK remains in Cloud KMS and never leaves the service. Storing the KEK would defeat the security purpose of envelope encryption.

- **C:** Incorrect because DEKs should be generated locally (not in Cloud KMS), and KEKs should be generated in Cloud KMS (not locally). This option reverses the correct pattern.

- **D:** Incorrect on multiple counts: DEKs should be generated locally (not in Cloud KMS), KEKs should be in Cloud KMS (not locally), and you should store the encrypted DEK (not the KEK).

### References

- [Envelope encryption | Cloud KMS](https://docs.cloud.google.com/kms/docs/envelope-encryption)
- [Cloud KMS encryption deep dive](https://docs.cloud.google.com/docs/security/key-management-deep-dive)
