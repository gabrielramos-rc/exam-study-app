# Question 256

**Source:** https://www.examtopics.com/discussions/google/view/147050-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, service perimeter, ingress, egress, Cloud Storage

---

## Question

Your organization has two VPC Service Controls service perimeters, Perimeter-A and Perimeter-B, in Google Cloud. You want to allow data to be copied from a Cloud Storage bucket in Perimeter-A to another Cloud Storage bucket in Perimeter-B. You must minimize exfiltration risk, only allow required connections, and follow the principle of least privilege. What should you do?
## Choices

- **A.** Configure a perimeter bridge between Perimeter-A and Perimeter-B, and specify the Cloud Storage buckets as the resources involved.
- **B.** Configure a perimeter bridge between the projects hosting the Cloud Storage buckets in Perimeter-A and Perimeter-B.
- **C.** Configure an egress rule for the Cloud Storage bucket in Perimeter-A and a corresponding ingress rule in Perimeter-B. Most Voted
- **D.** Configure a bidirectional egress/ingress rule for the Cloud Storage buckets in Perimeter-A and Perimeter-B.

---

## Community

**Most Voted:** C


**Votes:** A: 45% | B: 5% | C: 50% (22 total)


**Top Comments:**

- (4 upvotes) I think it's B.

- (2 upvotes) While a perimeter bridge allows communication between two service perimeters, it may grant broader access than necessary and does not adhere to the principle of least privilege, as it could expose res

- (2 upvotes) Also, this is pretty similar to the example exposed in the documentation: https://cloud.google.com/vpc-service-controls/docs/share-across-perimeters#example_of_perimeter_bridges

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

The correct approach is to configure an **egress rule in Perimeter-A** and a **corresponding ingress rule in Perimeter-B**. This follows Google Cloud's recommended best practice for cross-perimeter data exchange. According to the official documentation, "Ingress and egress rules can replace and simplify use cases that previously required one or more perimeter bridges."

Key advantages of ingress/egress rules over perimeter bridges:

1. **Granular control**: You can specify exactly which Cloud Storage buckets are allowed to participate in the data transfer, rather than allowing all resources in entire projects to communicate
2. **Least privilege**: The rules can be scoped to specific resources, methods, identities, and network sources
3. **Unidirectional flow**: An egress rule from Perimeter-A allows data to flow out, while an ingress rule in Perimeter-B explicitly permits that data to enter - creating a controlled, one-way data path that minimizes exfiltration risk
4. **Modern approach**: Google Cloud documentation explicitly states that ingress/egress rules provide "more granular controls" and are the preferred method for secure data exchange

The documentation emphasizes: "Minimize exfiltration risk by constraining the exact service, methods, Google Cloud projects, VPC networks, and identities used to execute the data exchange."

### Why Other Options Are Wrong

- **A:** Perimeter bridges cannot specify individual Cloud Storage buckets as resources. Bridges operate at the project level, not the resource level. Additionally, you cannot directly target specific resources in a bridge configuration - resource-level control is achieved through IAM permissions, not bridge settings.

- **B:** While perimeter bridges do connect projects across perimeters, they provide bidirectional access to all services within those projects, which violates the principle of least privilege. This is overly broad compared to ingress/egress rules that can target specific buckets and methods. Google recommends using ingress/egress rules instead of bridges for better granular control.

- **D:** A bidirectional rule would allow data to flow in both directions between the perimeters, which is unnecessary for the stated requirement (copying from A to B only) and increases exfiltration risk. The unidirectional flow provided by separate egress (A) and ingress (B) rules better enforces the principle of least privilege.

### References

- [Ingress and egress rules | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/ingress-egress-rules)
- [Secure data exchange with ingress and egress rules](https://docs.cloud.google.com/vpc-service-controls/docs/secure-data-exchange)
- [Sharing across perimeters with bridges](https://docs.cloud.google.com/vpc-service-controls/docs/share-across-perimeters)
