# Question 254

**Source:** https://www.examtopics.com/discussions/google/view/147048-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** Workload Identity Federation, service account impersonation, short-lived credentials, multi-cloud

---

## Question

Your organization has applications that run in multiple clouds. The applications require access to a Google Cloud resource running in your project. You must use short-lived access credentials to maintain security across the clouds. What should you do?
## Choices

- **A.** Create a managed workload identity. Bind an attested identity to the Compute Engine workload.
- **B.** Create a service account key. Download the key to each application that requires access to the Google Cloud resource.
- **C.** Create a workload identity pool with a workload identity provider for each external cloud. Set up a service account and add an IAM binding for impersonation. Most Voted
- **D.** Create a VPC firewall rule for ingress traffic with an allowlist of the IP ranges of the external cloud applications.

---

## Community

**Most Voted:** C


**Votes:** A: 11% | C: 89% (9 total)


**Top Comments:**

- (4 upvotes) I think it's A.

- (2 upvotes) It's C

- (2 upvotes) C is the correct answer

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Workload Identity Federation is specifically designed for multi-cloud scenarios where external workloads (running in AWS, Azure, or other clouds) need to access Google Cloud resources using short-lived credentials. The solution requires:

1. **Workload identity pool**: A logical grouping that trusts external identity providers. You create one pool that can contain multiple providers.

2. **Workload identity provider**: A specific connection for each external cloud (e.g., one for AWS, one for Azure). This establishes trust between the external cloud's native authentication system and Google Cloud.

3. **Service account with IAM binding for impersonation**: External workloads authenticate with their native cloud credentials (AWS IAM roles, Azure managed identities), exchange them for Security Token Service (STS) tokens, and then impersonate a Google Cloud service account to obtain short-lived OAuth 2.0 access tokens.

This approach eliminates the security risks of managing long-lived service account keys and provides the required short-lived credentials (typically valid for 1 hour). The workloads can authenticate using their environment-specific credentials (AWS instance profiles, Azure managed identities) which are then exchanged for temporary Google Cloud credentials.

### Why Other Options Are Wrong

- **A:** "Managed workload identity" and "attested identity" refer to GKE Workload Identity or Compute Engine features for workloads *within* Google Cloud, not external multi-cloud workloads. This doesn't address applications running in other clouds.

- **B:** Service account keys are long-lived credentials (they don't expire unless rotated manually) and represent a significant security risk. The question explicitly requires "short-lived access credentials," and service account keys directly contradict this requirement. Google Cloud actively discourages using service account keys and recommends Workload Identity Federation instead.

- **D:** VPC firewall rules control network traffic based on IP addresses but don't provide authentication or authorization. They don't generate credentials (short-lived or otherwise) and wouldn't grant the applications access to Google Cloud APIs or resources. This is a network security control, not an identity/access management solution.

### References

- [Workload Identity Federation](https://docs.cloud.google.com/iam/docs/workload-identity-federation)
- [Configure Workload Identity Federation with AWS or Azure VMs](https://docs.cloud.google.com/iam/docs/workload-identity-federation-with-other-clouds)
- [Best practices for using Workload Identity Federation](https://docs.cloud.google.com/iam/docs/best-practices-for-using-workload-identity-federation)
