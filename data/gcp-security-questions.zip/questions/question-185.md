# Question 185

**Source:** https://www.examtopics.com/discussions/google/view/117156-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Configuring organization policies
**Tags:** organization policy, trusted images, compute.trustedImageProjects, image security

---

## Question

Your organization is moving virtual machines (VMs) to Google Cloud. You must ensure that operating system images that are used across your projects are trusted and meet your security requirements. What should you do?
## Choices

- **A.** Implement an organization policy to enforce that boot disks can only be created from images that come from the trusted image project. Most Voted
- **B.** Implement an organization policy constraint that enables the Shielded VM service on all projects to enforce the trusted image repository usage.
- **C.** Create a Cloud Function that is automatically triggered when a new virtual machine is created from the trusted image repository. Verify that the image is not deprecated.
- **D.** Automate a security scanner that verifies that no common vulnerabilities and exposures (CVEs) are present in your trusted image repository.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (9 total)


**Top Comments:**

- (4 upvotes) Is A correct?

- (2 upvotes) A is the correct.

- (2 upvotes) it's A A - https://cloud.google.com/compute/docs/images/restricting-image-access

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is correct because it directly implements the `compute.trustedImageProjects` organization policy constraint, which is the purpose-built mechanism for restricting which image projects users can access when creating persistent disks or boot disks. This constraint allows administrators to define an allowlist of specific image projects (e.g., `projects/debian-cloud`, `projects/cos-cloud`) from which boot disks can be created. By configuring this policy at the organization, folder, or project level, you ensure that only approved, trusted images meeting your security requirements can be used across all projects. The policy can be set to allow all images, deny all images, or specify custom projects using the format `projects/IMAGE_PROJECT`. This is the standard, scalable, and enforceable approach for controlling image usage across an organization.

### Why Other Options Are Wrong

- **B:** Shielded VM is a security feature that provides verifiable integrity through Secure Boot, vTPM, and integrity monitoring, but it does not enforce which image repository can be used. Enabling Shielded VM on all projects is a separate security control and doesn't restrict users from creating VMs from untrusted image sources. The constraint for Shielded VM (`compute.requireShieldedVm`) is different from the trusted image constraint.

- **C:** Creating a Cloud Function to verify images after VM creation is a reactive approach that doesn't prevent the creation of VMs from untrusted images. This is detective rather than preventive - by the time the function triggers, the VM has already been created from a potentially untrusted image. Additionally, checking only for deprecated images doesn't address the core requirement of ensuring images come from trusted sources.

- **D:** Automating a security scanner to check for CVEs in the trusted image repository is a good complementary practice but doesn't enforce that users can only use images from that repository. Users could still create VMs from other untrusted image sources. This is a validation control for your trusted repository but not an enforcement mechanism to prevent use of untrusted images.

### References

- [Setting up trusted image policies](https://docs.cloud.google.com/compute/docs/images/restricting-image-access)
- [Image management best practices](https://docs.cloud.google.com/compute/docs/images/image-management-best-practices)
