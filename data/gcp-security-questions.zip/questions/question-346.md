# Question 346

**Source:** https://www.examtopics.com/discussions/google/view/311180-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** service account, Compute Engine, Cloud Storage, least privilege, IAM roles

---

## Question

A batch job running on Compute Engine needs temporary write access to a Cloud Storage bucket. You want the batch job to use the minimum permissions necessary to complete the task. What should you do?
## Choices

- **A.** Create a service account with full Cloud Storage administrator permissions. Assign the service account to the Compute Engine instance.
- **B.** Create a service account and embed a long-lived service account key file that has write permissions specified directly in the batch job script.
- **C.** Create a service account with the storage.objectCreator role. Use service account impersonation in the batch job's code. Most Voted
- **D.** Grant the predefined storage.objectCreator role to the Compute Engine instance's default service account.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (1 total)

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D is correct because it follows Google Cloud best practices for service account security and the principle of least privilege:

1. **Uses the default service account**: Google recommends attaching service accounts directly to Compute Engine instances rather than using impersonation for workloads running in Google Cloud. The default service account is designed for this purpose.

2. **Minimum permissions with storage.objectCreator**: The `roles/storage.objectCreator` role grants only the permissions needed to create objects in Cloud Storage (`storage.objects.create`, `storage.multipartUploads.*`, etc.) without granting unnecessary permissions to view, delete, or overwrite existing objects. This is the minimum permission needed for "write access" in the context of creating new objects.

3. **No credential management required**: When a service account is attached to a Compute Engine instance, applications running on that instance automatically use the service account's credentials through the metadata server, eliminating the need for key files or impersonation logic.

4. **Temporary nature**: While the role grant is permanent on the service account, the access is effectively "temporary" to the batch job because it only has those permissions while running on that instance. The service account can be removed from the instance or the role can be revoked after the job completes.

### Why Other Options Are Wrong

- **A:** Creating a service account with "full Cloud Storage administrator permissions" violates the principle of least privilege. The `roles/storage.admin` role grants far more permissions than needed (delete buckets, modify bucket configurations, etc.) when the job only needs to write objects.

- **B:** Embedding long-lived service account key files directly in code is a significant security anti-pattern. Keys can be accidentally committed to source control, logged, or exposed. Google strongly recommends avoiding service account keys whenever possible and instead using workload identity or direct service account attachment.

- **C:** Service account impersonation adds unnecessary complexity when the workload is already running in Google Cloud. Best practices state: "If no, attach a service account to the resource" (rather than using impersonation) when running code in Google Cloud. Impersonation is primarily useful for cross-project access or when a user needs to temporarily assume a service account's identity. Additionally, creating a new service account when the default service account can be used with appropriate IAM roles is unnecessarily complex.

### References

- [Service accounts | Compute Engine Documentation](https://docs.cloud.google.com/compute/docs/access/service-accounts)
- [Best practices for using service accounts securely](https://docs.cloud.google.com/iam/docs/best-practices-service-accounts)
- [IAM roles for Cloud Storage](https://docs.cloud.google.com/storage/docs/access-control/iam-roles)
