# Question 108

**Source:** https://www.examtopics.com/discussions/google/view/75711-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Cloud Interconnect, Dedicated Interconnect, hybrid connectivity, bandwidth requirements

---

## Question

An organization is moving applications to Google Cloud while maintaining a few mission-critical applications on-premises. The organization must transfer the data at a bandwidth of at least 50 Gbps. What should they use to ensure secure continued connectivity between sites?
## Choices

- **A.** Dedicated Interconnect Most Voted
- **B.** Cloud Router
- **C.** Cloud VPN
- **D.** Partner Interconnect

---

## Community

**Most Voted:** A


**Votes:** A: 100% (3 total)


**Top Comments:**

- (8 upvotes) https://cloud.google.com/network-connectivity/docs/interconnect/concepts/overview For Partner Interconnect,, The maximum supported attachment size is 50 Gbps, but not all sizes might be available, dep

- (1 upvotes) A is right

- (1 upvotes) A. Dedicated Interconnect

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Dedicated Interconnect is the correct choice for this scenario requiring at least 50 Gbps of bandwidth for secure connectivity between on-premises and Google Cloud. Dedicated Interconnect provides:

- **High bandwidth capacity**: Supports 10 Gbps or 100 Gbps circuits with flexible VLAN attachment capacities from 50 Mbps to 50 Gbps per attachment
- **Scalability**: Can scale up to 8 x 10-Gbps (80 Gbps) circuits or 2 x 100-Gbps (200 Gbps) circuits, supporting up to 200 Gbps total bandwidth
- **Enterprise-grade secure connection**: Direct physical connection between your network and Google's network through a supported colocation facility
- **Cost-effective at scale**: More economical than purchasing equivalent bandwidth over the public internet for large data transfers

For the 50 Gbps requirement, you could use a single 100 Gbps circuit or multiple 10 Gbps circuits (e.g., 5 x 10 Gbps) with appropriate VLAN attachments. This provides both the required bandwidth and secure, reliable connectivity for mission-critical hybrid cloud operations.

### Why Other Options Are Wrong

- **B. Cloud Router:** Cloud Router is a software-defined router that enables dynamic route exchange using BGP between VPC networks and on-premises networks. It is not a connectivity solution itself - it works in conjunction with Cloud VPN or Cloud Interconnect to manage routing, but does not provide the actual network connection or bandwidth capacity.

- **C. Cloud VPN:** Cloud VPN cannot meet the 50 Gbps bandwidth requirement. Each HA VPN tunnel provides a maximum of 3 Gbps bandwidth. While you can create multiple tunnels to increase bandwidth, achieving 50 Gbps would require approximately 17 tunnels, which is impractical and not the intended use case. Cloud VPN is designed for lower bandwidth needs (typically under 10 Gbps with multiple tunnels).

- **D. Partner Interconnect:** Partner Interconnect has a maximum capacity of 50 Gbps per VLAN attachment. While this technically meets the "at least 50 Gbps" requirement, it operates at the exact minimum threshold with no headroom for growth or traffic bursts. Additionally, Partner Interconnect is typically used when organizations lack physical access to colocation facilities. For enterprise requirements of 50+ Gbps, Dedicated Interconnect is the standard recommendation as it offers higher maximum bandwidth (up to 200 Gbps), better scalability, and is more cost-effective at this scale.

### References

- [Cloud Interconnect overview](https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/overview)
- [Dedicated Interconnect overview](https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/dedicated-overview)
- [Choosing a Network Connectivity product](https://docs.cloud.google.com/network-connectivity/docs/how-to/choose-product)
- [Cloud VPN overview](https://docs.cloud.google.com/network-connectivity/docs/vpn/concepts/overview)
- [HA VPN topologies to increase bandwidth](https://docs.cloud.google.com/network-connectivity/docs/vpn/concepts/topologies-increase-bandwidth)
