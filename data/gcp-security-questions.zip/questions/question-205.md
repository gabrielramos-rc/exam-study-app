# Question 205

**Source:** https://www.examtopics.com/discussions/google/view/117303-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** Workload Identity Federation, service account impersonation, attribute mapping, spoofing prevention

---

## Question

You are running applications outside Google Cloud that need access to Google Cloud resources. You are using workload identity federation to grant external identities Identity and Access Management (IAM) roles to eliminate the maintenance and security burden associated with service account keys. You must protect against attempts to spoof another user's identity and gain unauthorized access to Google Cloud resources. What should you do? (Choose two.)
## Choices

- **A.** Enable data access logs for IAM APIs.
- **B.** Limit the number of external identities that can impersonate a service account.
- **C.** Use a dedicated project to manage workload identity pools and providers. Most Voted
- **D.** Use immutable attributes in attribute mappings. Most Voted
- **E.** Limit the resources that a service account can access.

---

## Community

**Most Voted:** CD


**Votes:** CD: 100% (14 total)


**Top Comments:**

- (8 upvotes) Agree, See https://cloud.google.com/iam/docs/best-practices-for-using-workload-identity-federation#protecting_against_spoofing_threats Because CD is in the list and E is not, preferred CD

- (2 upvotes) CD looks good to me

- (1 upvotes) C. protects against spoofing threats by centralizing and securing the management of identity pools and providers, making it harder for attackers to create or manipulate them. D. uses immutable attribu

---

## Answer

**Correct:** C, D

**Confidence:** high

### Explanation

**C. Use a dedicated project to manage workload identity pools and providers** - Google Cloud best practices explicitly recommend establishing a single dedicated project to manage all workload identity pools and providers. This provides centralized control and consistent configurations, making it easier to monitor and audit all federation configurations. You can enforce this discipline using the `constraints/iam.workloadIdentityPoolProviders` organizational policy constraint to prevent users from creating redundant or potentially insecure workload identity pool providers in other projects.

**D. Use immutable attributes in attribute mappings** - This is a critical security control to prevent spoofing attacks. Google Cloud documentation explicitly states: "Don't rely on attributes that aren't stable or authoritative" and recommends restricting attribute mappings to "attributes that can't be modified by the user, or can't be modified at all." Using immutable attributes (like account ID, sub claim, or tenant ID) prevents attackers from gaining unauthorized access by modifying user-controlled attributes in their external identity provider profile. Mutable attributes like display names, email addresses, or user-assigned groups could be changed by users to spoof other identities.

### Why Other Options Are Wrong

- **A. Enable data access logs for IAM APIs** - While this is a good practice for maintaining audit trails and is recommended in the best practices documentation, it is a detective control (helps you see what happened after an attack) rather than a preventive control. It does not actively protect against spoofing attempts; it only helps you detect them after they occur.

- **B. Limit the number of external identities that can impersonate a service account** - While limiting access is generally good practice, this option is too vague and doesn't address the specific risk of identity spoofing. The key issue is not the number of identities, but ensuring that attribute mappings use immutable attributes and that the right organizational structure is in place. You should grant access based on specific attribute conditions, not just limit numbers.

- **E. Limit the resources that a service account can access** - This is a general security best practice (principle of least privilege) but doesn't specifically protect against identity spoofing in Workload Identity Federation. Limiting service account permissions only reduces the blast radius after a successful spoofing attack; it doesn't prevent the spoofing itself. The question asks specifically about protecting against spoofing attempts.

### References

- [Best practices for using Workload Identity Federation](https://docs.cloud.google.com/iam/docs/best-practices-for-using-workload-identity-federation)
- [Workload Identity Federation Overview](https://docs.cloud.google.com/iam/docs/workload-identity-federation)
