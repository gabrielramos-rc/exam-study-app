# Question 144

**Source:** https://www.examtopics.com/discussions/google/view/81556-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** project migration, organization migration, VPC Service Controls, IAM inheritance, resource hierarchy

---

## Question

Your company's new CEO recently sold two of the company's divisions. Your Director asks you to help migrate the Google Cloud projects associated with those divisions to a new organization node. Which preparation steps are necessary before this migration occurs? (Choose two.)
## Choices

- **A.** Remove all project-level custom Identity and Access Management (IAM) roles.
- **B.** Disallow inheritance of organization policies.
- **C.** Identify inherited Identity and Access Management (IAM) roles on projects to be migrated. Most Voted
- **D.** Create a new folder for all projects to be migrated.
- **E.** Remove the specific migration projects from any VPC Service Controls perimeters and bridges. Most Voted

---

## Community

**Most Voted:** CE


**Votes:** AE: 4% | CD: 19% | CE: 53% | DE: 24% (75 total)


**Top Comments:**

- (11 upvotes) https://cloud.google.com/resource-manager/docs/project-migration#plan_policy When you migrate your project, it will no longer inherit the policies from its current place in the resource hierarchy, and

- (7 upvotes) IAM Role Inheritance: Projects inherit IAM roles from the organization or folder they belong to. When a project is moved to a new organization, these inherited roles are lost. Before migration, identi

- (4 upvotes) A, C https://cloud.google.com/resource-manager/docs/handle-special-cases

---

## Answer

**Correct:** C, E

**Confidence:** high

### Explanation

When migrating projects between organization nodes, two critical preparation steps are required:

**C. Identify inherited IAM roles on projects to be migrated** - This is essential because IAM policies are inherited through the resource hierarchy. When you migrate a project to a new organization, the inherited policies change. You need to identify which inherited roles exist at the current organization/folder level so you can understand the impact and ensure proper access is maintained at the destination. The documentation emphasizes creating a migration plan to "make sure that any potential impacts are mitigated during your project migration" and specifically notes that "changes in the resource hierarchy caused by a project migration can lead to changes in inherited policies, such as organization policies and Identity and Access Management (IAM) allow and deny policies."

**E. Remove projects from VPC Service Controls perimeters and bridges** - This is mandatory because **you cannot migrate a project that is protected by a VPC Service Controls security perimeter**. The documentation explicitly states this restriction. Projects must be removed from any service perimeter before migration can proceed. Even after removal, there is a propagation delay of several hours before the migration becomes possible. Attempting to migrate a project still in a perimeter will cause the migration to fail.

### Why Other Options Are Wrong

- **A. Remove all project-level custom IAM roles** - INCORRECT. Project-level custom roles do not need to be removed. The issue is with organization-level custom roles that don't transfer between organizations. Project-level policies remain attached after migration. Only organization-specific custom roles referenced in the project's IAM policies would cause a failed precondition error.

- **B. Disallow inheritance of organization policies** - INCORRECT. You don't disallow inheritance; instead, you need to configure specific organization policy constraints (`constraints/resourcemanager.allowedExportDestinations` on source and `constraints/resourcemanager.allowedImportSources` on destination) to permit the migration. Inheritance is a fundamental part of the resource hierarchy model.

- **D. Create a new folder for all projects to be migrated** - INCORRECT. This is not a required preparation step. Projects can be migrated directly to the organization node or to any folder within the destination organization. While creating a folder might be part of your organizational design, it's not a necessary prerequisite for the migration itself.

### References

- [Project migration checklist | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/project-migration-checklist)
- [Handle special cases | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/handle-special-cases)
- [Migrating projects between organization resources | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/project-migration)
