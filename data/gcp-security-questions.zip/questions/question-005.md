# Question 005

**Source:** https://www.examtopics.com/discussions/google/view/15919-exam-professional-cloud-security-engineer-topic-1-question-5/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** container security, image hardening, secure build, minimal images

---

## Question

When creating a secure container image, which two items should you incorporate into the build if possible? (Choose two.)
## Choices

- **A.** Ensure that the app does not run as PID 1.
- **B.** Package a single app as a container. Most Voted
- **C.** Remove any unnecessary tools not needed by the app. Most Voted
- **D.** Use public container images as a base image for the app.
- **E.** Use many container image layers to hide sensitive information.

---

## Community

**Most Voted:** BC


**Votes:** BC: 100% (5 total)


**Top Comments:**

- (14 upvotes) BC BC BC

- (3 upvotes) To add to my previous comment "A process running as PID 1 inside a container is treated specially by Linux: it ignores any signal with the default action. So, the process will not terminate on SIGINT 

- (2 upvotes) The answer is BC

---

## Answer

**Correct:** B, C

**Confidence:** high

### Explanation

The two correct answers for building secure container images are:

**B. Package a single app as a container** - This is a fundamental container best practice. Following the single-concern principle, each container should run one application or process. This approach:
- Simplifies dependency management and reduces conflicts
- Makes containers more modular and reusable
- Improves security by reducing the attack surface
- Facilitates easier troubleshooting and maintenance
- Enables better scaling and orchestration

**C. Remove any unnecessary tools not needed by the app** - This is a critical security practice known as minimizing the container image. Removing unnecessary tools:
- Reduces the attack surface by eliminating potential exploit vectors
- Decreases the number of vulnerabilities present in the image (fewer packages = fewer CVEs)
- Results in smaller image sizes, improving deployment speed
- Aligns with the principle of least privilege
- Is the core concept behind "distroless" container images maintained by Google

Google's Container-Optimized OS is "built, optimized, and hardened specifically for running containers" following these principles. The documentation emphasizes vulnerability scanning and secure build practices that include minimizing components.

### Why Other Options Are Wrong

- **A:** Running as PID 1 is actually normal and expected for containers. The main application process typically runs as PID 1 in a container namespace. While there are nuances around signal handling and zombie processes, avoiding PID 1 is not a security best practice. The security concern should be avoiding running as the root user, not avoiding PID 1.

- **D:** Using public container images as base images is generally discouraged from a security perspective. Public images may contain vulnerabilities, malware, or backdoors. Best practices recommend:
  - Using trusted, verified base images from known sources
  - Using minimal base images (like distroless or Alpine)
  - Scanning base images for vulnerabilities
  - Maintaining your own hardened base images when possible
  - Never blindly trusting public images without verification

- **E:** Using many image layers does not hide sensitive information and is counterproductive. More layers:
  - Increase image size and complexity
  - Do not provide security (all layers are accessible)
  - Can slow down image pull and build times
  - Best practices actually recommend minimizing the number of layers
  - Sensitive information should never be included in any layer (use Secret Manager instead)

### References

- [Set up security best practices - Cloud Workstations](https://docs.cloud.google.com/workstations/docs/set-up-security-best-practices)
- [Safeguard deployments - Software supply chain security](https://docs.cloud.google.com/software-supply-chain-security/docs/safeguard-deploys)
- [Harden your cluster's security - GKE](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/hardening-your-cluster)
- [GKE security overview](https://docs.cloud.google.com/kubernetes-engine/docs/concepts/security-overview)
