# Question 090

**Source:** https://www.examtopics.com/discussions/google/view/34062-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, service perimeter, data exfiltration, multiple projects

---

## Question

You are the security admin of your company. Your development team creates multiple GCP projects under the "implementation" folder for several dev, staging, and production workloads. You want to prevent data exfiltration by malicious insiders or compromised code by setting up a security perimeter. However, you do not want to restrict communication between the projects. What should you do?
## Choices

- **A.** Use a Shared VPC to enable communication between all projects, and use firewall rules to prevent data exfiltration.
- **B.** Create access levels in Access Context Manager to prevent data exfiltration, and use a shared VPC for communication between projects.
- **C.** Use an infrastructure-as-code software tool to set up a single service perimeter and to deploy a Cloud Function that monitors the "implementation" folder via Stackdriver and Cloud Pub/Sub. When the function notices that a new project is added to the folder, it executes Terraform to add the new project to the associated perimeter. Most Voted
- **D.** Use an infrastructure-as-code software tool to set up three different service perimeters for dev, staging, and prod and to deploy a Cloud Function that monitors the "implementation" folder via Stackdriver and Cloud Pub/Sub. When the function notices that a new project is added to the folder, it executes Terraform to add the new project to the respective perimeter.

---

## Community

**Most Voted:** C


**Votes:** B: 8% | C: 75% | D: 17% (12 total)


**Top Comments:**

- (17 upvotes) I think this is C. Communication between the project is necessary tied to VPC, but you need to include all projects under implementation folder in a single VPCSC

- (11 upvotes) B. Create access levels in Access Context Manager to prevent data exfiltration, and use a shared VPC for communication between projects. Explanation: Access Context Manager allows you to define access

- (5 upvotes) C. The keyword "prevent data exfiltration by malicious insiders or compromised code" is listed as the benefits of VPC service control https://cloud.google.com/vpc-service-controls/docs/overview#benefi

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

A single unified service perimeter is the correct and recommended approach for this scenario. According to Google Cloud documentation, "a single large perimeter, referred to as a common unified perimeter, provides the most effective protection against data exfiltration compared to using multiple, segmented perimeters."

Key reasons why Option C is correct:

1. **Prevents data exfiltration**: VPC Service Controls with a service perimeter protects Google Cloud services from unauthorized data access and data exfiltration by creating a security boundary around resources.

2. **Allows unrestricted internal communication**: All projects within a single service perimeter can freely communicate with each other's protected resources without additional configuration. This directly satisfies the requirement to "not restrict communication between the projects."

3. **Lower management overhead**: A single perimeter is significantly easier to manage and maintain compared to multiple perimeters with bridges or complex ingress/egress rules.

4. **Automation for new projects**: The Cloud Function automation ensures that new projects added to the "implementation" folder are automatically included in the perimeter, maintaining consistent security posture without manual intervention.

### Why Other Options Are Wrong

- **A:** Shared VPC and firewall rules do not provide adequate protection against data exfiltration. Firewall rules control network traffic at layers 3-4 but cannot prevent data exfiltration through API calls to Google Cloud services. VPC Service Controls is specifically designed to prevent data exfiltration by restricting which services can be accessed and from where.

- **B:** Access levels in Access Context Manager define conditions (IP addresses, device policy, identity) for accessing resources but are typically used as part of VPC Service Controls, not as a standalone solution. This option doesn't mention implementing service perimeters, which are the core mechanism for preventing data exfiltration. Additionally, Shared VPC alone doesn't prevent data exfiltration through service APIs.

- **D:** Creating three separate service perimeters for dev, staging, and prod goes against Google's best practice recommendations. Multiple perimeters would require configuring perimeter bridges or ingress/egress rules to allow communication between environments, adding significant complexity. The documentation explicitly states that a unified perimeter provides better protection and lower management overhead than segmented perimeters. The question requirements don't mandate isolation between dev/staging/prod environments.

### References

- [Design and architect service perimeters | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/architect-perimeters)
- [Overview of VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/overview)
- [Service perimeter details and configuration](https://cloud.google.com/vpc-service-controls/docs/service-perimeters)
