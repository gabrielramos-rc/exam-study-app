# Question 284

**Source:** https://www.examtopics.com/discussions/google/view/147078-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, Secret Manager, secrets, Security Command Center, Cloud Functions, environment variables

---

## Question

You are responsible for a set of Cloud Functions running on your organization's Google Cloud environment. During the last annual security review, secrets were identified in environment variables of some of these Cloud Functions. You must ensure that secrets are identified in a timely manner. What should you do?
## Choices

- **A.** Implement regular peer reviews to assess the environment variables and identify secrets in your Cloud Functions. Raise a security incident if secrets are discovered.
- **B.** Implement a Cloud Function that scans the environment variables multiple times a day, and creates a finding in Security Command Center if secrets are discovered.
- **C.** Use Sensitive Data Protection to scan the environment variables multiple times per day, and create a finding in Security Command Center if secrets are discovered. Most Voted
- **D.** Integrate dynamic application security testing into the CI/CD pipeline that scans the application code for the Cloud Functions. Fail the build process if secrets are discovered.

---

## Community

**Most Voted:** C


**Votes:** C: 67% | D: 33% (12 total)


**Top Comments:**

- (4 upvotes) I think it's D.

- (2 upvotes) (Dynamic application security testing): While this can help identify secrets in the code, it does not specifically address the secrets that may be present in environment variables

- (2 upvotes) I think C: To perform secrets discovery, you create a discovery scan configuration at the organization or project level. Within your selected scope, Sensitive Data Protection periodically scans Cloud 

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Sensitive Data Protection provides a native, automated solution specifically designed for detecting secrets in Cloud Functions environment variables. The service's secrets discovery feature periodically scans Cloud Run functions (both 1st and 2nd generation) and automatically detects credential types including passwords, authentication tokens, and Google Cloud credentials. When secrets are discovered, Sensitive Data Protection automatically generates a "Secrets in environment variables" vulnerability finding in Security Command Center, providing centralized security monitoring. This is a fully managed solution that requires minimal configuration - you simply enable secrets discovery at the project or organization level, and the service handles the continuous scanning and reporting without custom code or manual processes.

### Why Other Options Are Wrong

- **A:** Manual peer reviews are not timely or scalable. Annual reviews already missed the secrets, and regular peer reviews would still create significant delays between introduction and detection of secrets. This manual approach is error-prone and doesn't provide the continuous, automated monitoring required for effective security.

- **B:** Building a custom Cloud Function to scan environment variables is unnecessary when Google provides a native, managed solution. This approach would require custom development, maintenance, testing, and operational overhead. Additionally, you would need to handle the complexity of accessing and scanning other Cloud Functions' configurations securely, which presents its own security challenges.

- **D:** Dynamic application security testing (DAST) in the CI/CD pipeline scans running application code behavior, not environment variable configurations. DAST focuses on testing deployed applications from the outside to identify vulnerabilities, not detecting secrets stored in environment variables. Additionally, this only helps prevent new secrets from being deployed but doesn't address the requirement to identify existing secrets in currently running Cloud Functions in a timely manner.

### References

- [Report secrets in environment variables to Security Command Center](https://docs.cloud.google.com/sensitive-data-protection/docs/secrets-discovery)
- [Overview of sensitive data discovery](https://docs.cloud.google.com/sensitive-data-protection/docs/data-profiles)
