# Question 073

**Source:** https://www.examtopics.com/discussions/google/view/30366-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Cloud Storage, backup, disaster recovery, Cloud Interconnect, hybrid connectivity

---

## Question

An organization is starting to move its infrastructure from its on-premises environment to Google Cloud Platform (GCP). The first step the organization wants to take is to migrate its ongoing data backup and disaster recovery solutions to GCP. The organization's on-premises production environment is going to be the next phase for migration to GCP. Stable networking connectivity between the on-premises environment and GCP is also being implemented. Which GCP solution should the organization use?
## Choices

- **A.** BigQuery using a data pipeline job with continuous updates via Cloud VPN
- **B.** Cloud Storage using a scheduled task and gsutil via Cloud Interconnect Most Voted
- **C.** Compute Engines Virtual Machines using Persistent Disk via Cloud Interconnect
- **D.** Cloud Datastore using regularly scheduled batch upload jobs via Cloud VPN

---

## Community

**Most Voted:** B


**Votes:** B: 79% | C: 21% (14 total)


**Top Comments:**

- (11 upvotes) Data Backup to GCP, so B is correct

- (3 upvotes) https://cloud.google.com/architecture/dr-scenarios-for-data#back-up-to-cloud-storage-using-a-scheduled-task

- (3 upvotes) You would have been correct if the question had any RTO/RPO specifications. In absence of this question is assuming backup and restore as a DR strategy. So Option B Cloud Storage is the correct answer

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud Storage with scheduled tasks and gsutil (or gcloud storage) via Cloud Interconnect is the ideal solution for migrating backup and disaster recovery workloads from on-premises to GCP. This approach addresses all the organization's requirements:

**Cloud Storage as the backup target:**
- Cloud Storage is Google Cloud's primary object storage service specifically designed for backup and disaster recovery scenarios
- Provides automatic data mirroring across multiple locations with built-in redundancy
- Supports flexible storage classes for cost optimization (Standard, Nearline, Coldline, Archive)
- The `gcloud storage rsync` command enables efficient incremental backups when data changes are small relative to total volume

**Scheduled tasks with gsutil:**
- Allows automated, regular backups through cron jobs or similar scheduling mechanisms
- Simple implementation with gcloud CLI tools installed on on-premises systems
- Proven pattern recommended in Google Cloud's disaster recovery documentation

**Cloud Interconnect for connectivity:**
- Provides dedicated, stable, high-bandwidth connectivity between on-premises and GCP
- Essential for ongoing production backup operations with predictable performance
- Offers lower latency and higher throughput than VPN
- Better suited for "stable networking connectivity" requirement mentioned in the scenario
- Provides the reliable foundation needed for the next phase (production environment migration)

This solution is explicitly documented in Google Cloud's disaster recovery scenarios for data, where it states: "Create a scheduled task that runs a script or application to transfer the data to Cloud Storage."

### Why Other Options Are Wrong

- **A:** BigQuery is a data warehouse for analytics, not a backup/DR solution. It's designed for structured data analysis, not general-purpose backup storage. Using continuous data pipelines for backup is overly complex and not the recommended pattern for DR scenarios.

- **C:** Using Compute Engine VMs with Persistent Disk would require provisioning and managing compute instances just to store backup data. This adds unnecessary complexity, cost, and operational overhead. Persistent Disks are for active workloads, not backup storage archives.

- **D:** Cloud Datastore (now Firestore) is a NoSQL document database for application data, not a backup storage solution. Like BigQuery, it's designed for a specific use case (document storage and queries) rather than general backup/DR operations. It would require data restructuring and is not cost-effective for backup storage.

### References

- [Disaster recovery scenarios for data](https://docs.cloud.google.com/architecture/dr-scenarios-for-data)
- [Disaster recovery planning guide](https://docs.cloud.google.com/architecture/dr-scenarios-planning-guide)
- [Data protection, backup, and recovery options](https://docs.cloud.google.com/storage/docs/protection-backup-recovery-overview)
