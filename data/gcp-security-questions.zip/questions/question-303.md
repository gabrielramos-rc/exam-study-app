# Question 303

**Source:** https://www.examtopics.com/discussions/google/view/148658-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Cloud Armor, Application Load Balancer, IP deny-list, DDoS protection, WAF

---

## Question

There is a threat actor that is targeting organizations like yours. Attacks are always initiated from a known IP address range. You want to deny-list those IPs for your website, which is exposed to the internet through an Application Load Balancer. What should you do?
## Choices

- **A.** Create a Cloud Armor policy with a deny-rule for the known IP address range. Attach the policy to the backend of the Application Load Balancer.
- **B.** Activate Identity-Aware Proxy for the backend of the Application Load Balancer. Create a firewall rule that only allows traffic from the proxy to the application.
- **C.** Create a log sink with a filter containing the known IP address range. Trigger an alert that detects when the Application Load Balancer is accessed from those IPs.
- **D.** Create a Cloud Firewall policy with a deny-rule for the known IP address range. Associate the firewall policy to the Virtual Private Cloud with the application backend.

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Cloud Armor is specifically designed to protect Application Load Balancers from malicious traffic at Layer 3-7. To deny-list known malicious IP address ranges:

1. **Create a Cloud Armor security policy** with a deny rule matching the threat actor's IP ranges
2. **Attach the policy to the backend service** of the Application Load Balancer

Cloud Armor evaluates incoming requests before they reach your backend services, making it the ideal solution for blocking malicious IPs at the edge. The deny rule can match up to 10 IP address ranges in basic mode and specify deny actions (403, 404, or 502 responses).

Example using gcloud:
```bash
gcloud compute security-policies rules create 1000 \
    --security-policy my-policy \
    --src-ip-ranges "192.0.2.0/24" \
    --action "deny-403"
```

Then attach to the backend service:
```bash
gcloud compute backend-services update my-backend \
    --security-policy my-policy
```

This provides immediate protection at the Application Load Balancer level, preventing malicious traffic from consuming backend resources.

### Why Other Options Are Wrong

- **B.** Identity-Aware Proxy (IAP) is an authentication and authorization solution, not a network-level IP blocking mechanism. IAP provides identity-based access control for applications but does not offer IP deny-listing functionality. This adds unnecessary complexity and doesn't address the requirement to block specific IP ranges.

- **C.** Creating a log sink with alerts is a detective control (detection after the fact), not a preventive control. This approach only monitors and alerts when attacks occur but does not block the malicious traffic. The requirement is to deny-list the IPs, meaning actively prevent them from accessing the website.

- **D.** VPC firewall rules (Cloud Firewall policies) operate at the VPC network level and protect internal resources within the VPC. However, for Application Load Balancers exposed to the internet, the traffic is terminated at the load balancer edge before reaching the VPC. Cloud Armor policies attached to the load balancer backend are the correct mechanism for filtering external internet traffic. VPC firewall rules would not effectively block traffic already accepted by the load balancer.

### References

- [Security policy overview - Cloud Armor](https://docs.cloud.google.com/armor/docs/security-policy-overview)
- [Configure Cloud Armor security policies](https://docs.cloud.google.com/armor/docs/configure-security-policies)
- [Cloud Armor common use cases](https://docs.cloud.google.com/armor/docs/common-use-cases)
