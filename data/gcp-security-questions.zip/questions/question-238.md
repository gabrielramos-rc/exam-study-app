# Question 238

**Source:** https://www.examtopics.com/discussions/google/view/126777-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Managing authentication
**Tags:** 2FA, security key, phishing protection, FIDO U2F, person-in-the-middle

---

## Question

Your company is concerned about unauthorized parties gaining access to the Google Cloud environment by using a fake login page. You must implement a solution to protect against person-in-the-middle attacks. Which security measure should you use?
## Choices

- **A.** Security key Most Voted
- **B.** Google prompt
- **C.** Text message or phone call code
- **D.** Google Authenticator application

---

## Community

**Most Voted:** A


**Votes:** A: 86% | D: 14% (7 total)


**Top Comments:**

- (1 upvotes) To mitigate the risk of man-in-the-middle attacks and enhance the security of your Google Cloud environment, security keys provide the highest level of protection by using strong cryptographic methods

- (1 upvotes) - MFA: Google Authenticator is a MFA tool that generates unique, time-based one-time passcodes (OTP) on your mobile device. Even if an attacker steals your login credentials, they wouldn't have the va

- (1 upvotes) A. Security key

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Security keys (such as Titan Security Keys) provide the strongest protection against phishing and person-in-the-middle (MITM) attacks because they use **FIDO U2F/FIDO2 standards with cryptographic challenge-response authentication**. Here's why this is critical:

1. **Cryptographic Domain Binding**: Security keys create unique public-private key pairs for each service. During authentication, the key uses the website's domain as part of the cryptographic challenge. If a user is on a fake login page (phishing site), the domain won't match, and the authentication will fail - even if the user is tricked into trying to authenticate.

2. **No Secrets Transmitted**: The private key never leaves the security key device. Only cryptographic signatures are exchanged, making it impossible for an attacker to intercept credentials through a MITM attack.

3. **Google's Official Recommendation**: Google Cloud documentation explicitly states: "We recommend that you enforce 2-step verification for all user accounts in your organization with a phishing-resistant mechanism such as Titan Security Keys or other keys based on the phishing-resistant FIDO U2F (CTAP1) standards."

4. **Proven Track Record**: Google deployed mandatory security keys for all employees specifically to protect against sophisticated phishing attempts, replacing OTP-based second-factor authentication.

### Why Other Options Are Wrong

- **B (Google prompt):** While convenient, Google prompts are susceptible to "push fatigue" attacks and social engineering. An attacker with stolen credentials can trigger prompts hoping the user approves without verification. It doesn't provide cryptographic domain verification.

- **C (Text message or phone call code):** SMS/voice codes are the weakest 2FA method and highly vulnerable to MITM attacks through SIM swapping, SS7 protocol exploits, and phishing. The codes are simple numbers that can be intercepted or socially engineered from users.

- **D (Google Authenticator application):** TOTP codes from authenticator apps are better than SMS, but still vulnerable to phishing. If a user enters the TOTP code on a fake login page, the attacker can capture and use it immediately (before it expires) on the real site. Authenticator apps don't verify the domain they're authenticating to.

### References

- [Authentication and authorization - Security Foundations](https://docs.cloud.google.com/architecture/blueprints/security-foundations/authentication-authorization)
- [Handle compromised Google Cloud credentials](https://docs.cloud.google.com/docs/security/compromised-credentials)
- [FIDO2 And FIDO U2F Security Keys - Cryptnox](https://cryptnox.com/fido2-vs-fido-u2f-security-keys/)
- [Universal 2nd Factor - Wikipedia](https://en.wikipedia.org/wiki/Universal_2nd_Factor)
