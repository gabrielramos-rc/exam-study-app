# Question 163

**Source:** https://www.examtopics.com/discussions/google/view/84257-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC firewall rules, network segmentation, service account, firewall priority

---

## Question

You need to audit the network segmentation for your Google Cloud footprint. You currently operate Production and Non-Production infrastructure-as-a-service (IaaS) environments. All your VM instances are deployed without any service account customization. After observing the traffic in your custom network, you notice that all instances can communicate freely `" despite tag-based VPC firewall rules in place to segment traffic properly `" with a priority of 1000. What are the most likely reasons for this behavior?
## Choices

- **A.** All VM instances are missing the respective network tags. Most Voted
- **B.** All VM instances are residing in the same network subnet.
- **C.** All VM instances are configured with the same network route.
- **D.** A VPC firewall rule is allowing traffic between source/targets based on the same service account with priority 999. Most Voted
- **E.** A VPC firewall rule is allowing traffic between source/targets based on the same service account with priority 1001. 

---

## Community

**Most Voted:** AD


**Votes:** A: 6% | AD: 47% | C: 12% | D: 35% (17 total)


**Top Comments:**

- (5 upvotes) You are right, also, how is a rule with priority 1001 going to have priority over another rule with 1000?

- (5 upvotes) but only few tags r missing...so all vms shd not able to talk

- (4 upvotes) All VM instances are missing the respective network tags + A VPC firewall rule is allowing traffic between source/targets based on the same service account with priority 999

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The correct answer is **D** - a VPC firewall rule allowing traffic between source/targets based on the same service account with **priority 999**.

Here's why this is the root cause:

1. **All VMs share the same default service account**: When VMs are deployed "without any service account customization," they all use the Compute Engine default service account (`PROJECT_NUMBER-compute@developer.gserviceaccount.com`). This is a critical detail.

2. **Firewall priority hierarchy**: VPC firewall rules operate on priority where **lower numbers have higher priority**. A rule with priority 999 takes precedence over rules with priority 1000.

3. **Service account-based rule overrides tag-based rules**: The tag-based firewall rules (priority 1000) are being configured properly for segmentation. However, there's another firewall rule that filters by service account with priority 999, which has higher precedence. Since all VMs share the same default service account, this rule matches ALL instances and allows unrestricted communication between them.

4. **The rule is evaluated first**: When traffic flows between VMs, Google Cloud evaluates firewall rules in priority order. The priority 999 service account-based rule matches first and allows the traffic, so the priority 1000 tag-based rules are never evaluated (regardless of whether tags are present).

This is a common misconfiguration where administrators create service account-based rules without realizing that all default VMs share the same service account, effectively creating an allow-all rule that bypasses intended segmentation controls.

### Why Other Options Are Wrong

- **A:** While missing network tags would prevent tag-based rules from matching, this alone wouldn't explain why ALL instances can communicate freely. Without any matching allow rules, the implied deny rule would block traffic. The question states instances "can communicate freely," indicating an allow rule is actively permitting the traffic.

- **B:** Being in the same subnet doesn't automatically allow communication. VPC firewall rules still apply regardless of subnet placement. Even within the same subnet, the implied deny ingress rule would block traffic unless an allow rule permits it. Subnet placement alone doesn't override firewall rules.

- **C:** Network routes control where traffic is directed (routing paths), not whether traffic is permitted (firewall rules). Routes and firewall rules are separate mechanisms. Shared routes wouldn't cause firewall rules to be bypassed or explain why traffic is allowed despite segmentation rules.

- **E (priority 1001):** A rule with priority 1001 has LOWER priority than the tag-based rules at 1000. The tag-based rules would be evaluated first and would block the traffic (assuming proper tag configuration). A lower-priority rule at 1001 would never be reached and couldn't explain the observed behavior.

### References

- [VPC firewall rules - Google Cloud Documentation](https://docs.cloud.google.com/firewall/docs/firewalls)
- [Use VPC firewall rules - Google Cloud Documentation](https://docs.cloud.google.com/firewall/docs/using-firewalls)
- [Service accounts - Compute Engine Documentation](https://docs.cloud.google.com/compute/docs/access/service-accounts)
