# Question 015

**Source:** https://www.examtopics.com/discussions/google/view/27107-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** service account, Compute Engine, Cloud Storage, least privilege, IAM

---

## Question

An application running on a Compute Engine instance needs to read data from a Cloud Storage bucket. Your team does not allow Cloud Storage buckets to be globally readable and wants to ensure the principle of least privilege. Which option meets the requirement of your team?
## Choices

- **A.** Create a Cloud Storage ACL that allows read-only access from the Compute Engine instance's IP address and allows the application to read from the bucket without credentials.
- **B.** Use a service account with read-only access to the Cloud Storage bucket, and store the credentials to the service account in the config of the application on the Compute Engine instance.
- **C.** Use a service account with read-only access to the Cloud Storage bucket to retrieve the credentials from the instance metadata. Most Voted
- **D.** Encrypt the data in the Cloud Storage bucket using Cloud KMS, and allow the application to decrypt the data with the KMS key.

---

## Community

**Most Voted:** C


**Votes:** A: 14% | B: 9% | C: 77% (22 total)


**Top Comments:**

- (13 upvotes) Correct Answer is (B): If your application runs inside a Google Cloud environment that has a default service account, your application can retrieve the service account credentials to call Google Cloud

- (13 upvotes) Hello guys! Does anyone have the rest of the questions to share? :( I can't see the rest of the issues because of the subscription.

- (6 upvotes) Yes B is best possible option. This is something google also recommnd. https://cloud.google.com/storage/docs/authentication#libauth

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is the correct and recommended approach for Compute Engine instances to access Cloud Storage following the principle of least privilege. When you attach a service account to a Compute Engine instance, the instance automatically retrieves credentials from the instance metadata server. Applications running on the instance can use Application Default Credentials (ADC) to authenticate seamlessly without embedding secrets in code.

This approach implements least privilege by:
1. Creating a dedicated service account with only the required IAM role (e.g., `roles/storage.objectViewer` for read-only access)
2. Granting the service account minimal permissions to only the specific Cloud Storage bucket needed
3. Attaching this service account to the Compute Engine instance
4. The application automatically retrieves credentials from the metadata server without manual credential management

The instance metadata server provides a secure, automatic credential delivery mechanism that eliminates the need to store, distribute, or manage service account keys manually.

### Why Other Options Are Wrong

- **A:** IP-based ACLs on Cloud Storage buckets are not a secure authentication mechanism. IP addresses can be spoofed, change dynamically, or be shared by multiple instances. This approach doesn't authenticate the identity of the application and violates security best practices. Additionally, allowing access "without credentials" contradicts proper authentication requirements.

- **B:** Storing service account credentials (keys) in application configuration files is a security anti-pattern. It creates multiple risks: credentials can be accidentally committed to version control, exposed through logs, or compromised if the instance is breached. Google strongly recommends against creating and storing service account keys when alternatives like instance metadata exist.

- **D:** Encrypting data with Cloud KMS addresses data protection (encryption at rest), but doesn't solve the access control problem. The application still needs proper authentication to access the Cloud Storage bucket in the first place. This option confuses data encryption with access management and doesn't follow the principle of least privilege for bucket access.

### References

- [Service accounts | Compute Engine Documentation](https://docs.cloud.google.com/compute/docs/access/service-accounts)
- [Create a VM that uses a user-managed service account | Compute Engine Documentation](https://docs.cloud.google.com/compute/docs/access/create-enable-service-accounts-for-instances)
- [Best practices for using service accounts securely | IAM Documentation](https://docs.cloud.google.com/iam/docs/best-practices-service-accounts)
