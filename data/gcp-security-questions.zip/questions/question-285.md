# Question 285

**Source:** https://www.examtopics.com/discussions/google/view/147079-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Audit Logs, Security Command Center, Event Threat Detection, Security Health Analytics, IAM monitoring

---

## Question

Your organization 1s developing a new SaaS application on Google Cloud. Stringent compliance standards require visibility into privileged account activity, and potentially unauthorized changes and misconfigurations to the application's infrastructure. You need to monitor administrative actions, log changes to IAM roles and permissions, and be able to trace potentially unauthorized configuration changes. What should you do?
## Choices

- **A.** Create log sinks to Cloud Storage for long-term retention. Set up log-based alerts in Cloud Logging based on relevant log types. Enable VPC Flow Logs for network visibility.
- **B.** Deploy Cloud IDS and activate Firewall Rules Logging. Create a custom dashboard in Security Command Center to visualize potential intrusion attempts.
- **C.** Detect sensitive administrative actions by using Cloud Logging with custom filters. Enable VPC Flow Logs with BigQuery exports for rapid analysis of network traffic patterns.
- **D.** Enable Event Threat Detection and Security Health Analytics in Security Command Center. Set up detailed logging for IAM-related activity and relevant project resources by deploying Cloud Audit Logs. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (5 total)


**Top Comments:**

- (1 upvotes) https://cloud.google.com/security-command-center/docs/concepts-security-health-analytics

- (1 upvotes) misconfigurations = Security Health Analytics

- (1 upvotes) I think it's D.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D provides the comprehensive solution required for monitoring privileged account activity, IAM changes, and unauthorized configuration changes in a compliance environment:

**Cloud Audit Logs** form the foundation by capturing all administrative actions and IAM changes. Admin Activity audit logs are always enabled by default and cannot be disabled, ensuring you automatically capture user-driven API calls that modify resource configuration or metadata, including IAM role and permission changes. These logs answer "who did what, where, and when" in your cloud environment.

**Event Threat Detection** analyzes Cloud Audit Logs in near-real time to identify suspicious IAM activities using detection logic, proprietary threat intelligence, anomaly detection, and machine learning. It specifically detects:
- IAM Anomalous Grant activities (external members or service accounts receiving privileges)
- Privilege escalation when dormant service accounts receive sensitive roles
- Anomalous service account impersonation
- Sensitive roles granted to Google Groups with external members
- Service account key creation and metadata modifications
- Repeated permission denied errors indicating unauthorized access attempts

**Security Health Analytics** automatically detects common vulnerabilities, misconfigurations, and compliance violations across Google Cloud resources by monitoring Cloud Asset Inventory and receiving notifications of resource and IAM policy changes. This provides continuous compliance monitoring for infrastructure configuration.

Together, these services provide exactly what the question requires: visibility into privileged account activity, detection of unauthorized changes, tracing of configuration modifications, and compliance-grade monitoring of IAM-related activity.

### Why Other Options Are Wrong

- **A:** While log sinks and alerts are useful components, this option focuses on basic log retention and generic alerts. It doesn't provide the sophisticated threat detection capabilities needed to identify potentially unauthorized IAM changes and privilege escalation. VPC Flow Logs are for network traffic monitoring, not IAM activity or configuration changes, making this irrelevant to the requirements.

- **B:** Cloud IDS and Firewall Rules Logging are network security tools focused on intrusion detection at the network layer and monitoring traffic patterns. They don't monitor IAM activity, administrative actions, or configuration changes. This solution addresses the wrong security domain entirely - network intrusion vs. identity and access management.

- **C:** Custom filters in Cloud Logging provide basic monitoring but require manual configuration and don't leverage Google's built-in threat detection capabilities. VPC Flow Logs are again irrelevant for monitoring IAM changes and administrative actions. This approach lacks the automated threat intelligence and anomaly detection needed to identify sophisticated unauthorized activities.

### References

- [Cloud Audit Logs overview](https://docs.cloud.google.com/logging/docs/audit)
- [Overview of Event Threat Detection](https://docs.cloud.google.com/security-command-center/docs/concepts-event-threat-detection-overview)
- [Detection services - Security Command Center](https://docs.cloud.google.com/security-command-center/docs/concepts-security-sources)
