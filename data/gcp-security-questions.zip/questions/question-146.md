# Question 146

**Source:** https://www.examtopics.com/discussions/google/view/79832-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** service account key, organization policy, user-managed keys, key creation prevention

---

## Question

Your security team wants to reduce the risk of user-managed keys being mismanaged and compromised. To achieve this, you need to prevent developers from creating user-managed service account keys for projects in their organization. How should you enforce this?
## Choices

- **A.** Configure Secret Manager to manage service account keys.
- **B.** Enable an organization policy to disable service accounts from being created.
- **C.** Enable an organization policy to prevent service account keys from being created. Most Voted
- **D.** Remove the iam.serviceAccounts.getAccessToken permission from users.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (7 total)


**Top Comments:**

- (4 upvotes) Your answer represents Answer B: to Disable sevice account key creation

- (3 upvotes) C. https://cloud.google.com/iam/docs/best-practices-for-managing-service-account-keys "To prevent unnecessary usage of service account keys, use organization policy constraints: At the root of your or

- (2 upvotes) Yes, You are right Enable an organization policy to prevent service account keys from being created.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Google Cloud provides specific organization policy constraints designed to prevent the creation of user-managed service account keys. The constraint `iam.disableServiceAccountKeyCreation` (legacy) or `iam.managed.disableServiceAccountKeyCreation` (modern) can be enforced at the organization, folder, or project level to block developers from creating new external service account keys and Cloud Storage HMAC keys.

When this constraint is enabled, user-managed credentials cannot be created for service accounts in affected projects, even if users have the `iam.serviceAccountKeys.create` permission. This is a best practice recommendation from Google to reduce the risk of key mismanagement and compromise, as service account keys are long-lived credentials that pose security risks if not properly managed.

The constraint is non-retroactive (doesn't affect existing keys) but prevents all future key creation. Organizations created on or after May 3, 2024 have this constraint enforced by default. Google recommends using short-lived credentials through Workload Identity Federation or service account impersonation instead of user-managed keys.

### Why Other Options Are Wrong

- **A:** Secret Manager is designed to store and manage secrets (like API keys, passwords, certificates), not to prevent the creation of service account keys. While you could store service account keys in Secret Manager, this doesn't prevent developers from creating them in the first place.

- **B:** Disabling service account creation is far too restrictive and would prevent legitimate use of service accounts entirely. The requirement is specifically to prevent user-managed key creation, not to block service accounts themselves. Service accounts are essential for workload authentication.

- **D:** Removing `iam.serviceAccounts.getAccessToken` would prevent users from generating short-lived OAuth tokens for service accounts (which is actually a secure alternative to keys). This permission is used for service account impersonation and is unrelated to creating long-lived user-managed keys, which requires the `iam.serviceAccountKeys.create` permission.

### References

- [Restricting service account usage - Organization Policy](https://docs.cloud.google.com/resource-manager/docs/organization-policy/restricting-service-accounts)
- [Best practices for managing service account keys](https://docs.cloud.google.com/iam/docs/best-practices-for-managing-service-account-keys)
- [Use custom organization policies for service accounts and service account keys](https://docs.cloud.google.com/iam/docs/service-accounts-custom-constraints)
