# Question 122

**Source:** https://www.examtopics.com/discussions/google/view/75451-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC, firewall rules, service account, network segmentation, instance templates

---

## Question

Your organization acquired a new workload. The Web and Application (App) servers will be running on Compute Engine in a newly created custom VPC. You are responsible for configuring a secure network communication solution that meets the following requirements: ✑ Only allows communication between the Web and App tiers. ✑ Enforces consistent network security when autoscaling the Web and App tiers. ✑ Prevents Compute Engine Instance Admins from altering network traffic. What should you do?
## Choices

- **A.** 1. Configure all running Web and App servers with respective network tags. 2. Create an allow VPC firewall rule that specifies the target/source with respective network tags.
- **B.** 1. Configure all running Web and App servers with respective service accounts. 2. Create an allow VPC firewall rule that specifies the target/source with respective service accounts.
- **C.** 1. Re-deploy the Web and App servers with instance templates configured with respective network tags. 2. Create an allow VPC firewall rule that specifies the target/source with respective network tags.
- **D.** 1. Re-deploy the Web and App servers with instance templates configured with respective service accounts. 2. Create an allow VPC firewall rule that specifies the target/source with respective service accounts. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (15 total)


**Top Comments:**

- (15 upvotes) The requirement can be fulfilled by both network tags and service accounts. To update both compute instances will have to be stopped. That means options A and B are out. Option C is out because Comput

- (8 upvotes) It's D because of it's use of auto-scaling. If autoscaling wasn't part of the question, then B would have been suitable. It can't be network level tags because admins can change those.

- (3 upvotes) D. 1. Re-deploy the Web and App servers with instance templates configured with respective service accounts. 2. Create an allow VPC firewall rule that specifies the target/source with respective servi

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D correctly addresses all three requirements:

1. **Only allows communication between Web and App tiers**: VPC firewall rules with service accounts as source/target filters restrict traffic to only instances running with those specific service accounts. For example, you would create a rule allowing ingress from the Web service account to the App service account.

2. **Enforces consistent network security when autoscaling**: Instance templates ensure that all instances created by managed instance groups (MIGs) during autoscaling operations are automatically configured with the correct service account. This guarantees consistent firewall policy application regardless of scaling events.

3. **Prevents Compute Engine Instance Admins from altering network traffic**: Service accounts require IAM permissions to modify. Unlike network tags (which are instance metadata that can be changed by anyone with `compute.instances.setTags` permission), service accounts are identity objects managed through IAM. To change which service account an instance runs as, users need `iam.serviceAccounts.actAs` permission, which can be restricted from instance admins. This prevents instance administrators from bypassing firewall rules by simply changing tags.

The combination of instance templates (for consistency during autoscaling) and service accounts (for security enforcement) provides the most robust solution that meets all requirements.

### Why Other Options Are Wrong

- **A:** Configuring existing running instances with network tags doesn't provide consistency for autoscaling (no instance templates), and network tags can be modified by Compute Engine Instance Admins who have `compute.instances.setTags` permission, allowing them to bypass firewall restrictions.

- **B:** While service accounts provide the security benefit of preventing instance admins from altering network traffic, configuring existing running instances without instance templates fails to enforce consistent network security during autoscaling. New instances created by autoscalers would not automatically receive the correct service account configuration.

- **C:** Instance templates ensure autoscaling consistency, but network tags can be modified by Compute Engine Instance Admins with appropriate compute permissions, allowing them to circumvent firewall rules by adding or removing tags from instances.

### References

- [VPC firewall rules](https://docs.cloud.google.com/firewall/docs/firewalls)
- [Use VPC firewall rules - Filtering by service account vs. network tag](https://docs.cloud.google.com/firewall/docs/using-firewalls)
- [Instance groups documentation](https://docs.cloud.google.com/compute/docs/instance-groups)
- [Autoscaling groups of instances](https://docs.cloud.google.com/compute/docs/autoscaler)
