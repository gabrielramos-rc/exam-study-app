# Question 093

**Source:** https://www.examtopics.com/discussions/google/view/33958-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, service perimeter, Cloud Storage, data exfiltration prevention

---

## Question

You are part of a security team that wants to ensure that a Cloud Storage bucket in Project A can only be readable from Project B. You also want to ensure that data in the Cloud Storage bucket cannot be accessed from or copied to Cloud Storage buckets outside the network, even if the user has the correct credentials. What should you do?
## Choices

- **A.** Enable VPC Service Controls, create a perimeter with Project A and B, and include Cloud Storage service. Most Voted
- **B.** Enable Domain Restricted Sharing Organization Policy and Bucket Policy Only on the Cloud Storage bucket.
- **C.** Enable Private Access in Project A and B networks with strict firewall rules to allow communication between the networks.
- **D.** Enable VPC Peering between Project A and B networks with strict firewall rules to allow communication between the networks.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (7 total)


**Top Comments:**

- (20 upvotes) A is right

- (3 upvotes) https://cloud.google.com/vpc-service-controls/docs/overview#isolate

- (3 upvotes) Answer is most positively A. VPC service controls lets Security team create fine-grained Perimeter across projects within organization. -&gt; Security perimeter for API-Based services like Bigtable in

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

VPC Service Controls is the correct solution because it addresses both requirements simultaneously:

1. **Controlled access between Project A and B**: By creating a single service perimeter that includes both Project A and Project B with the Cloud Storage service, resources within the perimeter can communicate freely. The Cloud Storage bucket in Project A becomes accessible from Project B while remaining isolated from external resources.

2. **Prevention of data exfiltration even with valid credentials**: VPC Service Controls operates independently of IAM and creates security boundaries around Google Cloud resources. As the documentation states, "a service perimeter creates a security boundary around Google Cloud resources" that "prevents reading data from or copying data to a resource outside the perimeter." This means that even if a user has valid credentials, operations like `gcloud storage cp` to buckets outside the perimeter will fail.

The service perimeter provides defense-in-depth by preventing unauthorized data movement through "access from unauthorized networks using stolen credentials" - ensuring that compromised credentials alone cannot bypass perimeter restrictions if the request originates from outside the authorized perimeter.

### Why Other Options Are Wrong

- **B:** Domain Restricted Sharing Organization Policy controls which domains can access resources (preventing sharing with external organizations), and Bucket Policy Only disables ACLs in favor of IAM. However, neither prevents a user with valid credentials from copying data to other Cloud Storage buckets within the same organization or domain. This doesn't prevent data exfiltration to buckets in other projects within the allowed domain.

- **C:** Private Google Access enables VMs without external IP addresses to reach Google APIs and services. However, this is about network connectivity for Google services, not about creating security boundaries that prevent data exfiltration. Firewall rules control network traffic but cannot prevent authorized API calls to Cloud Storage buckets outside the intended projects.

- **D:** VPC Peering connects two VPC networks for communication between VMs. However, Cloud Storage is not a VPC resource - it's accessed via Google APIs regardless of VPC configuration. Firewall rules control network-level traffic between VMs but cannot restrict Cloud Storage API operations or prevent data exfiltration to buckets in other projects.

### References

- [Overview of VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/overview)
- [VPC Accessible Services](https://docs.cloud.google.com/vpc-service-controls/docs/vpc-accessible-services)
- [Secure Data Exchange](https://docs.cloud.google.com/vpc-service-controls/docs/secure-data-exchange)
