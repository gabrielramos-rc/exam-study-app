# Question 249

**Source:** https://www.examtopics.com/discussions/google/view/147001-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.3 - Securing AI workloads
**Tags:** AI security, shared responsibility model, managed AI service, IAM, monitoring

---

## Question

Your organization has an operational image classification model running on a managed AI service on Google Cloud. You are in a configuration review with stakeholders and must describe the security responsibilities for the image classification model. What should you do?
## Choices

- **A.** Explain that using platform-as-a-service (PaaS) transfers security concerns to Google. Describe the need for strict API usage limits to protect against unexpected usage and billing spikes.
- **B.** Explain the security aspects of the code that transforms user-uploaded images using Google's service. Define Cloud IAM for fine-grained access control within the development team.
- **C.** Explain Google's shared responsibility model. Focus the configuration review on Identity and Access Management (IAM) permissions, secure data upload/download procedures, and monitoring logs for any potential malicious activity. Most Voted
- **D.** Explain the development of custom network firewalls around the image classification service for deep intrusion detection and prevention. Describe vulnerability scanning tools for known vulnerabilities.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (5 total)


**Top Comments:**

- (2 upvotes) I think it's C.

- (1 upvotes) https://cloud.google.com/vertex-ai/docs/shared-responsibility

- (1 upvotes) The most appropriate approach is C.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C correctly describes the proper approach for explaining security responsibilities for a managed AI service by referencing Google's shared responsibility model. For managed/PaaS services, while Google is responsible for protecting the underlying infrastructure (hardware, firmware, kernel, OS, storage, network, and physical security), customers retain critical responsibilities including:

1. **IAM permissions**: Configuring proper identity and access controls to determine who can access the AI service and data
2. **Data security**: Implementing secure data upload/download procedures, as customers remain responsible for their data security
3. **Monitoring and detection**: Reviewing logs for potential malicious activity to detect security incidents

According to Google Cloud's shared responsibility documentation, for PaaS offerings customers "share responsibility with us for application-level controls and IAM management" and "remain responsible for your data security and client protection." This means that while Google secures the managed AI infrastructure, customers must properly configure access controls, protect their data, and monitor for threats.

For AI workloads specifically, the Well-Architected Framework emphasizes that customers should establish clear responsibility for the development, deployment, and outcomes of their AI systems and use Cloud Logging to log key events and decisions.

### Why Other Options Are Wrong

- **A:** Incorrect because using PaaS does **not** transfer all security concerns to Google. This fundamentally misunderstands the shared responsibility model. While Google manages infrastructure security, customers retain responsibility for application-level controls, IAM, data protection, and configuration. API usage limits are about cost control, not the primary security responsibility discussion needed.

- **B:** Too narrow in scope. While image transformation code security and IAM for the development team are valid concerns, this option misses the critical context of the shared responsibility model and other key areas like data security, monitoring, and secure procedures that should be discussed in a comprehensive configuration review with stakeholders.

- **D:** Inappropriate for managed services. Customers cannot develop "custom network firewalls around the image classification service" for a managed AI service—Google controls the infrastructure. Deep intrusion detection and prevention at the network level is Google's responsibility for the managed service infrastructure. This approach conflates IaaS responsibilities with PaaS realities.

### References

- [Shared responsibilities and shared fate on Google Cloud](https://docs.cloud.google.com/architecture/framework/security/shared-responsibility-shared-fate)
- [Use AI securely and responsibly](https://docs.cloud.google.com/architecture/framework/security/use-ai-securely-and-responsibly)
