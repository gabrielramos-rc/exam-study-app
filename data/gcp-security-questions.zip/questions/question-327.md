# Question 327

**Source:** https://www.examtopics.com/discussions/google/view/306216-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** Workload Identity, GKE, service account, authentication, Kubernetes

---

## Question

Your organization is migrating its primary web application from on-premises to Google Kubernetes Engine (GKE). You must advise the development team on how to grant their applications access to Google Cloud services from within GKE according to security recommended practices. What should you advise the development team to do?
## Choices

- **A.** Configure the GKE nodes to use the default Compute Engine service account.
- **B.** Enable Workload Identity for GKE. Assign a Kubernetes service account to the application and configure that Kubernetes service account to act as an Identity and Access Management (IAM) service account. Grant the required roles to the IAM service account. Most Voted
- **C.** Create a user-managed service account with only the roles required for the specific workload. Assign this service account to the GKE nodes.
- **D.** Create an application-specific IAM service account and generate a user-managed service account key for it. Inject the key to the workload by storing it as a Kubernetes secret within the same namespace as the application.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (2 total)


**Top Comments:**

- (1 upvotes) B is correct

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

**Option B is correct** because Workload Identity Federation for GKE is the recommended and most secure way to grant GKE applications access to Google Cloud services. This approach provides several critical security advantages:

1. **Fine-grained identity management**: Each application gets its own distinct identity through a Kubernetes ServiceAccount that is bound to an IAM service account, enabling precise access control at the workload level rather than the node level.

2. **No long-lived credentials**: Unlike service account keys, Workload Identity eliminates the need to store, distribute, or rotate static credentials. The GKE metadata server handles credential exchange automatically and transparently.

3. **Least privilege enforcement**: Permissions can be granted to specific Google Cloud resources that each application needs, following the principle of least privilege.

4. **Protection of sensitive metadata**: Workload Identity Federation for GKE enables the GKE metadata server, which filters requests to sensitive instance metadata fields, replacing the need for metadata concealment.

The configuration process follows security best practices:
- Enable Workload Identity Federation at the cluster level (always enabled in Autopilot)
- Create a Kubernetes ServiceAccount for the application
- Establish IAM allow policies that grant specific permissions to that ServiceAccount
- Annotate Pods to use the appropriate ServiceAccount

Google Cloud documentation explicitly states that "Workload Identity Federation for GKE is the recommended way to authenticate to Google Cloud APIs" and provides "more secure authentication workflow than alternatives like static token files."

### Why Other Options Are Wrong

- **A:** Using the default Compute Engine service account violates the principle of least privilege. All pods on the node would inherit the same permissions, providing no workload-level isolation. This is a security anti-pattern that grants overly broad access and makes it impossible to implement fine-grained access control.

- **C:** While using a user-managed service account is better than the default, assigning it to GKE nodes still grants permissions at the node level rather than the workload level. All pods on those nodes would share the same identity and permissions, which violates least privilege and doesn't provide application-specific access control.

- **D:** Generating and storing service account keys as Kubernetes secrets is explicitly discouraged by Google Cloud security best practices. This approach introduces significant security risks: keys are long-lived credentials that must be rotated, can be extracted from the cluster, and create a credential management burden. Google recommends avoiding service account keys whenever possible, and Workload Identity Federation eliminates the need for them entirely.

### References

- [About Workload Identity Federation for GKE](https://docs.cloud.google.com/kubernetes-engine/docs/concepts/workload-identity)
- [Authenticate to Google Cloud APIs from GKE workloads](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/workload-identity)
- [Harden your cluster's security](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/hardening-your-cluster)
- [Best practices for using service accounts securely](https://docs.cloud.google.com/iam/docs/best-practices-service-accounts)
