# Question 077

**Source:** https://www.examtopics.com/discussions/google/view/80687-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Logging, Audit Logs, BigQuery, service account, authentication validation

---

## Question

Last week, a company deployed a new App Engine application that writes logs to BigQuery. No other workloads are running in the project. You need to validate that all data written to BigQuery was done using the App Engine Default Service Account. What should you do?
## Choices

- **A.** 1. Use Cloud Logging and filter on BigQuery Insert Jobs. 2. Click on the email address in line with the App Engine Default Service Account in the authentication field. 3. Click Hide Matching Entries. 4. Make sure the resulting list is empty. Most Voted
- **B.** 1. Use Cloud Logging and filter on BigQuery Insert Jobs. 2. Click on the email address in line with the App Engine Default Service Account in the authentication field. 3. Click Show Matching Entries. 4. Make sure the resulting list is empty.
- **C.** 1. In BigQuery, select the related dataset. 2. Make sure that the App Engine Default Service Account is the only account that can write to the dataset.
- **D.** 1. Go to the Identity and Access Management (IAM) section of the project. 2. Validate that the App Engine Default Service Account is the only account that has a role that can write to BigQuery.

---

## Community

**Most Voted:** A


**Votes:** A: 72% | B: 24% | C: 4% (25 total)


**Top Comments:**

- (14 upvotes) Stackdriver is now Cloud Operations.

- (5 upvotes) Yes, but *hiding* log entries associated with App Engine Default Service Account will help *validate* that all data written to BigQuery was written by such service account. If we show only entries ass

- (4 upvotes) A is correct as last 2 are means of doing it rather than validating it

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The correct approach is to use Cloud Logging to filter on BigQuery Insert Jobs and validate that **only** the App Engine Default Service Account performed these operations. Here's why Option A works:

1. **Filter on BigQuery Insert Jobs**: In Cloud Logging, you filter for `protoPayload.methodName="google.cloud.bigquery.v2.JobService.InsertJob"` to find all BigQuery data insert operations.

2. **Click on the App Engine Default Service Account email**: When you view the logs, the `protoPayload.authenticationInfo.principalEmail` field shows which identity performed each operation. Clicking on the App Engine Default Service Account email creates a filter for that specific principal.

3. **Click "Hide Matching Entries"**: This is the key step. This action hides all log entries WHERE the principal IS the App Engine Default Service Account, showing you only entries from OTHER principals.

4. **Verify the list is empty**: If the resulting list is empty after hiding the App Engine service account entries, it proves that NO other accounts performed insert operations - only the App Engine Default Service Account did.

This is a validation-by-exclusion approach: you're confirming that when you hide the expected service account's actions, nothing remains (no unauthorized access).

### Why Other Options Are Wrong

- **B:** This reverses the logic. "Show Matching Entries" would display only entries FROM the App Engine service account, then checking if that list is empty would mean the App Engine account did NOT perform any operations - the opposite of what we want to validate.

- **C:** This checks IAM permissions on the dataset, which tells you who CAN write (authorization), not who DID write (actual activity). An account could have write permissions but never actually use them. This doesn't validate actual data access behavior.

- **D:** This checks IAM roles at the project level, which has the same problem as C - it shows who has permissions, not who actually performed the write operations. Also, multiple accounts could have BigQuery write roles for legitimate reasons (like admin access), but that doesn't mean they're writing data from the application.

### References

- [BigQuery Audit Logs Reference](https://docs.cloud.google.com/bigquery/docs/reference/auditlogs)
- [Cloud Logging Query Language](https://docs.cloud.google.com/logging/docs/view/logging-query-language)
