# Question 226

**Source:** https://www.examtopics.com/discussions/google/view/117323-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** Confidential Computing, Shielded VM, encryption in use, secure boot, vTPM, integrity monitoring

---

## Question

Your organization wants to protect all workloads that run on Compute Engine VM to ensure that the instances weren't compromised by boot-level or kernel-level malware. Also, you need to ensure that data in use on the VM cannot be read by the underlying host system by using a hardware-based solution. What should you do?
## Choices

- **A.** 1. Use Google Shielded VM including secure boot, Virtual Trusted Platform Module (vTPM), and integrity monitoring. 2. Create a Cloud Run function to check for the VM settings, generate metrics, and run the function regularly.
- **B.** 1. Activate Virtual Machine Threat Detection in Security Command Center (SCC) Premium. 2. Monitor the findings in SCC.
- **C.** 1. Use Google Shielded VM including secure boot, Virtual Trusted Platform Module (vTPM), and integrity monitoring. 2. Activate Confidential Computing. 3. Enforce these actions by using organization policies. Most Voted
- **D.** 1. Use secure hardened images from the Google Cloud Marketplace. 2. When deploying the images, activate the Confidential Computing option. 3. Enforce the use of the correct images and Confidential Computing by using organization policies.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (7 total)


**Top Comments:**

- (2 upvotes) C is the correct

- (1 upvotes) Confidential computing for data security in use.

- (1 upvotes) Confidential computing is about data in use not data at rest but C is the correct answer as there aren't any others that fit better

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C correctly addresses both requirements stated in the question:

1. **Protection against boot-level/kernel-level malware**: Shielded VM provides comprehensive protection through three key features:
   - **Secure Boot**: Verifies the digital signature of all boot components and stops the boot process if verification fails, preventing unsigned malware from loading
   - **Virtual Trusted Platform Module (vTPM)**: Provides hardware-based security for protecting keys and certificates used to authenticate system access
   - **Integrity Monitoring**: Uses Measured Boot to detect changes in the boot sequence, helping identify if malware has compromised the bootloader, kernel, or boot drivers

2. **Hardware-based protection for data in use**: Confidential Computing uses hardware-based memory encryption through Trusted Execution Environments (TEEs). As the documentation states, "Confidential Computing is the protection of data in-use using a hardware-based Trusted Execution Environment (TEE)." The processor keeps all data encrypted in memory, preventing the underlying host system (hypervisor) from reading it.

3. **Enforcement through Organization Policies**: This ensures all VMs in the organization are created with these security features enabled, providing consistent protection across all workloads.

These two technologies are complementary—Shielded VM protects the boot integrity and runtime measurements, while Confidential Computing encrypts memory to prevent data access by the host system.

### Why Other Options Are Wrong

- **A:** While this option correctly identifies Shielded VM features, it completely misses the requirement for protecting data in use. Cloud Run functions for monitoring VM settings do not provide hardware-based encryption of data in memory. This only addresses boot/kernel protection but not the memory encryption requirement.

- **B:** Virtual Machine Threat Detection in SCC Premium is a monitoring and detection service that identifies runtime threats. However, it does not provide the required protection mechanisms—it only detects threats after they occur. It neither prevents boot-level malware through secure boot mechanisms nor encrypts data in use with hardware-based solutions.

- **D:** While hardened images and Confidential Computing are good security practices, hardened images alone do not provide the same level of boot integrity protection as Shielded VM. Shielded VM's secure boot, vTPM, and integrity monitoring features specifically verify boot components at the hardware level, which is more robust than just using a hardened image. The question specifically asks to "ensure that instances weren't compromised by boot-level or kernel-level malware," which requires Shielded VM's hardware-based verification mechanisms.

### References

- [Shielded VM overview](https://docs.cloud.google.com/compute/shielded-vm/docs/shielded-vm)
- [Confidential Computing overview](https://docs.cloud.google.com/confidential-computing/docs/confidential-computing-overview)
- [Confidential VM overview](https://docs.cloud.google.com/confidential-computing/confidential-vm/docs/confidential-vm-overview)
- [Monitor Confidential VM integrity](https://docs.cloud.google.com/confidential-computing/confidential-vm/docs/monitor-integrity)
