# Question 056

**Source:** https://www.examtopics.com/discussions/google/view/29918-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** VPC peering, cross-organization, private connectivity, Compute Engine

---

## Question

A customer is collaborating with another company to build an application on Compute Engine. The customer is building the application tier in their GCP Organization, and the other company is building the storage tier in a different GCP Organization. This is a 3-tier web application. Communication between portions of the application must not traverse the public internet by any means. Which connectivity option should be implemented?
## Choices

- **A.** VPC peering Most Voted
- **B.** Cloud VPN
- **C.** Cloud Interconnect
- **D.** Shared VPC

---

## Community

**Most Voted:** A


**Votes:** A: 75% | C: 25% (4 total)


**Top Comments:**

- (17 upvotes) Key information being "Communication between portions of the application must not traverse the public internet by any means" leaves only option "C" as a valid one, as all other options rely on the pub

- (4 upvotes) A is the answer.

- (3 upvotes) Yes it Should be VPC Peering. https://cloud.google.com/vpc/docs/vpc-peering

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

VPC Network Peering is the correct solution for this cross-organization private connectivity scenario. According to Google Cloud documentation, VPC Network Peering "connects two Virtual Private Cloud (VPC) networks so that resources in each network can communicate with each other" and explicitly supports peering across different organizations: "Peered VPC networks can be in the same project, different projects of the same organization, or different projects of different organizations."

The key requirements are met:
- **Private connectivity**: VPC peering provides "internal IPv4 and IPv6 connectivity between pairs of VPC networks" without traversing the public internet
- **Cross-organization support**: Works between different GCP organizations while keeping networks administratively separate
- **Performance**: Traffic maintains "the same latency, throughput, and availability as traffic within the same VPC network"

This allows the customer's application tier in one organization to communicate privately with the partner company's storage tier in another organization over Google's internal network.

### Why Other Options Are Wrong

- **B (Cloud VPN):** While Cloud VPN provides encrypted connectivity and keeps traffic private, it's primarily designed for hybrid connectivity (connecting on-premises to cloud or cross-cloud). It adds unnecessary complexity and encryption overhead when both tiers are already in GCP. VPC peering is more efficient for VPC-to-VPC connectivity within Google Cloud.

- **C (Cloud Interconnect):** Cloud Interconnect is designed for hybrid connectivity scenarios, providing dedicated physical connections between on-premises networks and Google Cloud. It's not applicable for connecting two VPC networks that are both already in GCP. This would be massive over-engineering and extremely expensive for this use case.

- **D (Shared VPC):** Shared VPC cannot be used across different organizations. According to documentation, "participating host and service projects cannot belong to different organizations." Shared VPC only works within a single organization to share network resources across multiple projects.

### References

- [VPC Network Peering](https://docs.cloud.google.com/vpc/docs/vpc-peering)
- [Set up and manage VPC Network Peering](https://docs.cloud.google.com/vpc/docs/using-vpc-peering)
- [Shared VPC](https://docs.cloud.google.com/vpc/docs/shared-vpc)
