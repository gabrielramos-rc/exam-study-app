# Question 069

**Source:** https://www.examtopics.com/discussions/google/view/30227-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, Directory Sync, GCDS, user lifecycle, identity provider

---

## Question

An organization is evaluating the use of Google Cloud Platform (GCP) for certain IT workloads. A well-established directory service is used to manage user identities and lifecycle management. This directory service must continue for the organization to use as the `source of truth` directory for identities. Which solution meets the organization's requirements?
## Choices

- **A.** Google Cloud Directory Sync (GCDS) Most Voted
- **B.** Cloud Identity
- **C.** Security Assertion Markup Language (SAML)
- **D.** Pub/Sub

---

## Community

**Most Voted:** A


**Votes:** A: 100% (7 total)


**Top Comments:**

- (17 upvotes) Agreed

- (12 upvotes) The question inplies the company has a directory as the soruce of truth and want to maintain that in GCP... GCDS will make sure that occurs too Cloud Identity. It's not askling for a replacement of LD

- (8 upvotes) GCDS is a part of CI's feature that synchronizes the data in Google domain to match with AD/LDAP server. This includes users, groups contacts etc are synchronized/migrated to match. Hence, I would go 

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Google Cloud Directory Sync (GCDS) is specifically designed for this exact scenario where an organization wants to maintain their existing directory service (like Active Directory or LDAP) as the authoritative source of truth for user identities while using Google Cloud Platform.

GCDS is a free provisioning tool that synchronizes user and group information from on-premises LDAP directories to Cloud Identity or Google Workspace. Key characteristics that make it the correct answer:

- **One-way synchronization**: GCDS performs one-way sync from your directory service to Google Cloud, ensuring your existing directory remains the source of truth
- **Lifecycle management preservation**: All user lifecycle operations (creation, modification, suspension, deletion) continue to be managed in your existing directory and are automatically synchronized to Cloud Identity
- **Automated provisioning**: GCDS queries the LDAP directory, retrieves necessary information, and uses the Directory API to automatically add, modify, or delete users in your cloud account
- **Flexible deployment**: Can run on Windows or Linux, either on-premises or in Google Cloud, with support for scheduled automated synchronization

The official Google Cloud documentation explicitly states: "If you use Active Directory as the source of truth for identity management, then you can set up federation. You use Google Cloud Directory Sync (GCDS) to automatically provision users and groups from Active Directory for Cloud Identity or Google Workspace."

### Why Other Options Are Wrong

- **B. Cloud Identity**: While Cloud Identity is the Google identity service that stores the synchronized user accounts, it alone does not synchronize data from an existing directory service. Cloud Identity is the destination for GCDS synchronization, not the synchronization mechanism itself. The organization needs GCDS to connect their existing directory to Cloud Identity.

- **C. Security Assertion Markup Language (SAML)**: SAML is an authentication protocol used for single sign-on (SSO), allowing users to authenticate using their existing identity provider. While SAML is important for federated authentication, it does not provision or synchronize user accounts and lifecycle data from the existing directory to Google Cloud. SAML handles authentication after users are already provisioned.

- **D. Pub/Sub**: Google Cloud Pub/Sub is a messaging service for asynchronous event-driven systems. It has no relationship to identity management or directory synchronization. This option is completely unrelated to the requirement.

### References

- [Active Directory user account provisioning - Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/federating-gcp-with-active-directory-synchronizing-user-accounts)
- [Patterns for authenticating workforce users in a hybrid environment](https://docs.cloud.google.com/architecture/patterns-for-authenticating-corporate-users-in-a-hybrid-environment)
