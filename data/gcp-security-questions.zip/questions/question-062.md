# Question 062

**Source:** https://www.examtopics.com/discussions/google/view/30236-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Logging, log export, Cloud Storage, log retention, cost optimization

---

## Question

A manager wants to start retaining security event logs for 2 years while minimizing costs. You write a filter to select the appropriate log entries. Where should you export the logs?
## Choices

- **A.** BigQuery datasets
- **B.** Cloud Storage buckets Most Voted
- **C.** StackDriver logging
- **D.** Cloud Pub/Sub topics

---

## Community

**Most Voted:** B


**Votes:** B: 100% (8 total)


**Top Comments:**

- (4 upvotes) Ans: B

- (4 upvotes) Ans is B

- (2 upvotes) B- is the cheapest optaion

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud Storage buckets are the most cost-effective solution for long-term log retention (2 years) while minimizing costs. According to Google Cloud documentation, Cloud Storage is explicitly recommended for long-term storage of log data. The cost structure makes it ideal for archival purposes:

- **Cloud Storage for archival**: Log bucket storage fee is $0.01 per GiB per month. For logs that need to be retained for 2+ years, you can use Cloud Storage's Coldline or Archive storage classes for even lower costs.

- **Compared to BigQuery**: While BigQuery offers long-term storage pricing of $0.01/GB/month after 90 days of inactivity, it also incurs streaming ingestion costs ($0.05/GiB) and active storage costs ($0.02/GiB for the first 90 days). This makes it more expensive for pure archival use cases where the logs are rarely queried.

- **Compared to Cloud Logging**: While Cloud Logging's default retention (up to 30 days free) works well for short-term needs, extended retention beyond 30 days costs $0.01/GiB/month. For 2-year retention, exporting to Cloud Storage provides better cost optimization and archival features.

Log entries are stored in Cloud Storage as JSON files in hourly batches, organized by log type and date, making them suitable for compliance and long-term archival requirements.

### Why Other Options Are Wrong

- **A.** BigQuery datasets are better suited for analytics and querying log data alongside business data. While BigQuery offers long-term storage pricing, the streaming ingestion costs and active storage costs make it more expensive than Cloud Storage for pure archival scenarios where logs are rarely accessed.

- **C.** StackDriver logging (Cloud Logging) is the log collection service itself, not an export destination for long-term retention. Logs stored in Cloud Logging buckets beyond the default 30-day retention incur ongoing costs, and it's not designed as a long-term archival solution. For 2-year retention, exporting logs is the recommended approach.

- **D.** Cloud Pub/Sub topics are designed for real-time message streaming and integration with third-party tools (like Splunk or Datadog), not for log storage and retention. Pub/Sub is a messaging service that delivers messages to subscribers but doesn't persist logs for long-term archival purposes.

### References

- [Route logs to supported destinations | Cloud Logging](https://docs.cloud.google.com/logging/docs/export/configure_export_v2)
- [View logs routed to Cloud Storage | Cloud Logging](https://docs.cloud.google.com/logging/docs/export/storage)
- [Best practices for Cloud Audit Logs | Cloud Logging](https://docs.cloud.google.com/logging/docs/audit/best-practices)
