# Question 138

**Source:** https://www.examtopics.com/discussions/google/view/79827-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Audit Logs, Data Access logs, Cloud SQL, monitoring, API calls

---

## Question

A database administrator notices malicious activities within their Cloud SQL instance. The database administrator wants to monitor the API calls that read the configuration or metadata of resources. Which logs should the database administrator review?
## Choices

- **A.** Admin Activity
- **B.** System Event
- **C.** Access Transparency
- **D.** Data Access Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (18 total)


**Top Comments:**

- (10 upvotes) D. Data Access

- (4 upvotes) Should be D https://cloud.google.com/logging/docs/audit/#data-access

- (3 upvotes) D. https://cloud.google.com/logging/docs/audit/#data-access "Data Access audit logs contain API calls that read the configuration or metadata of resources, as well as user-driven API calls that create

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

**Data Access audit logs** are the correct logs to review for monitoring API calls that read the configuration or metadata of resources. According to Google Cloud's official documentation, Data Access audit logs are specifically designed to capture "API calls that read the configuration or metadata of resources" as well as user-driven API calls that create, modify, or read user-provided resource data.

For a Cloud SQL instance, Data Access logs would record operations such as:
- Reading Cloud SQL instance configuration (instance settings, flags, etc.)
- Reading database metadata
- Querying instance details
- Accessing backup configurations

These logs are disabled by default (except for BigQuery) and must be explicitly enabled. They are stored in the `_Default` bucket and require the appropriate IAM permissions to view (roles beyond the basic Logs Viewer role).

### Why Other Options Are Wrong

- **A (Admin Activity):** Admin Activity logs capture API calls that **modify** the configuration or metadata of resources, not read operations. These logs record when users create VM instances, change IAM permissions, or modify resource configurations. They focus on write operations (ADMIN_WRITE permissions), not the read operations the database administrator needs to monitor.

- **B (System Event):** System Event audit logs record actions performed by Google Cloud systems that modify resources without direct user action. These are automated system operations (like automatic VM migrations or system maintenance), not API calls made by users or applications to read configuration/metadata.

- **C (Access Transparency):** Access Transparency logs provide visibility into actions taken by Google Cloud staff when they access customer content for support purposes. These logs are only available to customers using Assured Workloads or Assured Support and are not related to monitoring general API calls that read resource configuration or metadata.

### References

- [Cloud Audit Logs overview](https://docs.cloud.google.com/logging/docs/audit)
- [Enable Data Access audit logs](https://docs.cloud.google.com/logging/docs/audit/configure-data-access)
