# Question 312

**Source:** https://www.examtopics.com/discussions/google/view/150184-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Logging, log sink, Pub/Sub, Dataflow, SIEM integration, log export

---

## Question

A team at your organization collects logs in an on-premises security information and event management system (SIEM). You must provide a subset of Google Cloud logs for the SIEM, and minimize the risk of data exposure in your cloud environment. What should you do?
## Choices

- **A.** Create a new BigQuery dataset. Stream all logs to this dataset. Provide the on-premises SIEM system access to the data in BigQuery by using workload identity federation and let the SIEM team filter for the relevant log data.
- **B.** Define a log view for the relevant logs. Provide access to the log view to a principal from your on-premises identity provider by using workforce identity federation.
- **C.** Create a log sink for the relevant logs. Send the logs to Pub/Sub. Retrieve the logs from Pub/Sub and push the logs to the SIEM by using Dataflow. Most Voted
- **D.** Filter for the relevant logs. Store the logs in a Cloud Storage bucket. Grant the service account access to the bucket. Provide the service account key to the SIEM team.

---

## Community

**Most Voted:** C


**Votes:** B: 33% | C: 67% (9 total)


**Top Comments:**

- (2 upvotes) Option C, does involve setting up multiple components (Pub/Sub, Dataflow, log sinks) and ensuring they are properly configured. This might add to the complexity of the setup. That being said, option B

- (2 upvotes) Answer C.

- (2 upvotes) Log views let you grant a user access to only a subset of the logs stored in a log bucket. https://cloud.google.com/logging/docs/logs-views

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is correct because it actually delivers logs to the on-premises SIEM system, which is the fundamental requirement. The architecture works as follows:

1. **Log sink with filter**: Creates a sink that exports only the relevant subset of logs (not all logs), minimizing data exposure at the source
2. **Pub/Sub**: Acts as a reliable, scalable buffer for log messages with built-in security controls
3. **Dataflow**: Retrieves logs from Pub/Sub and pushes them to the on-premises SIEM

This is the standard GCP pattern for SIEM integration because:

- **Actually delivers logs**: SIEMs need to ingest logs for correlation, alerting, and analysis - they can't just "view" logs in a cloud console
- **Filters at source**: Log sink filters ensure only the required subset leaves Cloud Logging
- **No service account keys**: Dataflow uses its service account with IAM roles, no key distribution needed
- **Secure transport**: Pub/Sub and Dataflow both support encryption in transit
- **Reliable delivery**: Pub/Sub provides durable message delivery with acknowledgment

### Why Other Options Are Wrong

- **A:** Streams ALL logs to BigQuery before filtering, which violates the "minimize data exposure" requirement. Also, workload identity federation would need the SIEM to pull data from BigQuery - it doesn't push logs to the SIEM. Exposing all logs first and filtering later is backwards from a security perspective.

- **B:** **Does not send logs to the SIEM.** Log views only provide filtered *viewing access* within Cloud Logging - they don't export or deliver data anywhere. Additionally, workforce identity federation is designed for human users accessing cloud consoles, not for workloads like SIEM systems that need to programmatically ingest data. The question explicitly says the team "collects logs in an on-premises SIEM" and you must "provide logs for the SIEM" - this requires actual data delivery, not just viewing access.

- **D:** Has a critical security flaw: distributing service account keys. Service account keys are long-lived credentials that pose significant risk if compromised. Google Cloud best practices strongly recommend avoiding key distribution. This approach also only stores logs in Cloud Storage without actually pushing them to the SIEM.

### References

- [Export logs to supported destinations](https://cloud.google.com/logging/docs/export)
- [Aggregated log sinks](https://cloud.google.com/logging/docs/export/aggregated_sinks)
- [Pub/Sub to Dataflow streaming](https://cloud.google.com/dataflow/docs/concepts/streaming-with-cloud-pubsub)
- [Security Command Center SIEM integration](https://cloud.google.com/security-command-center/docs/how-to-siem-integration)
