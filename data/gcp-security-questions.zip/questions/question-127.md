# Question 127

**Source:** https://www.examtopics.com/discussions/google/view/74835-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.3 - Configuring network security
**Tags:** Shared VPC, organization policy, project liens, host project protection

---

## Question

You want to prevent users from accidentally deleting a Shared VPC host project. Which organization-level policy constraint should you enable?
## Choices

- **A.** compute.restrictSharedVpcHostProjects
- **B.** compute.restrictXpnProjectLienRemoval Most Voted
- **C.** compute.restrictSharedVpcSubnetworks
- **D.** compute.sharedReservationsOwnerProjects

---

## Community

**Most Voted:** B


**Votes:** B: 100% (13 total)


**Top Comments:**

- (10 upvotes) B is the answer. https://cloud.google.com/resource-manager/docs/organization-policy/org-policy-constraints#constraints-for-specific-services - constraints/compute.restrictXpnProjectLienRemoval - Restr

- (9 upvotes) Agree with your explanation and Thank you for sharing the link

- (2 upvotes) To prevent users from accidentally deleting a Shared VPC host project, you should enable the compute.restrictXpnProjectLienRemoval organization-level policy constraint . This policy constraint limits 

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

The correct answer is **compute.restrictXpnProjectLienRemoval**. When a project is configured as a Shared VPC host project, Google Cloud automatically places a lien on the project to prevent accidental deletion. This is critical because deleting a host project would cause outages in all attached service projects.

By default, project owners can remove this lien, which creates a risk of accidental deletion. The organization policy constraint `constraints/compute.restrictXpnProjectLienRemoval` addresses this risk by limiting lien removal to only users with specific roles at the organization level (roles/owner or roles/resourcemanager.lienModifier).

This constraint ensures that only authorized organization administrators can remove the protective lien, preventing accidental deletion of Shared VPC host projects by project-level owners.

### Why Other Options Are Wrong

- **A (compute.restrictSharedVpcHostProjects):** This constraint controls which projects can be configured as Shared VPC host projects, not whether they can be deleted. It's used to limit where Shared VPC can be enabled, not to protect existing host projects from deletion.

- **C (compute.restrictSharedVpcSubnetworks):** This constraint controls which Shared VPC subnets can be used by service projects. It's about subnet-level access control, not project deletion protection.

- **D (compute.sharedReservationsOwnerProjects):** This constraint is related to Compute Engine shared reservations and owner projects, not Shared VPC host project protection. It has nothing to do with preventing project deletion.

### References

- [Deprovisioning Shared VPC - Project Liens](https://docs.cloud.google.com/vpc/docs/deprovisioning-shared-vpc)
- [Protecting Projects with Liens](https://docs.cloud.google.com/resource-manager/docs/project-liens)
- [Provision Shared VPC - Organizational Policies](https://docs.cloud.google.com/vpc/docs/provisioning-shared-vpc)
