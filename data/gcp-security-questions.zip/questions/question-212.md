# Question 212

**Source:** https://www.examtopics.com/discussions/google/view/117284-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, Google Cloud Directory Sync, GCDS, unmanaged users, user migration, transfer tool

---

## Question

Your company is moving to Google Cloud. You plan to sync your users first by using Google Cloud Directory Sync (GCDS). Some employees have already created Google Cloud accounts by using their company email addresses that were created outside of GCDS. You must create your users on Cloud Identity. What should you do?
## Choices

- **A.** Configure GCDS and use GCDS search rules to sync these users.
- **B.** Use the transfer tool to migrate unmanaged users. Most Voted
- **C.** Write a custom script to identify existing Google Cloud users and call the Admin SDK: Directory API to transfer their account.
- **D.** Configure GCDS and use GCDS exclusion rules to ensure users are not suspended.

---

## Community

**Most Voted:** B


**Votes:** B: 88% | C: 12% (8 total)


**Top Comments:**

- (3 upvotes) B https://support.google.com/a/answer/7177267?sjid=1548376628970849998-AP

- (2 upvotes) Using the Directory API, you can programmatically manage user accounts, which includes creating new ones. This would let you create users in Cloud Identity and handle ones that already have accounts.

- (2 upvotes) B is the correct - https://support.google.com/a/answer/6178640?hl=en&amp;ref_topic=7042002&amp;sjid=4882239396686183653-EU

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

The **transfer tool for unmanaged users** is the correct Google-recommended solution for this scenario. When employees create Google Cloud accounts (consumer accounts) using company email addresses before those domains are added to Cloud Identity, these become "unmanaged accounts."

When you verify your domain in Cloud Identity or Google Workspace, Google automatically searches for consumer accounts using that domain. Within approximately 12 hours, these accounts surface in the transfer tool (accessible at `admin.google.com/ac/unmanaged`). The tool allows administrators to:

1. **Identify** all unmanaged consumer accounts using your verified domain
2. **Invite** users to transfer their accounts by transitioning them from "Not yet invited" to "Invited" status
3. **Preserve** the user's identity (email address) and all associated data during the transfer
4. **Convert** the consumer account to a managed Cloud Identity account upon user acceptance

This is the official, supported method that maintains data integrity while bringing external accounts under organizational control. After the transfer completes, you can then use GCDS to manage these now-managed accounts going forward.

### Why Other Options Are Wrong

- **A:** GCDS search rules are designed to identify and sync users from your authoritative source (like Active Directory or LDAP), not to handle pre-existing consumer accounts. GCDS cannot sync unmanaged consumer accounts that exist outside your directory—it would create conflicting accounts instead.

- **C:** While the Admin SDK Directory API can manage Cloud Identity accounts, there is no supported API method to transfer ownership of consumer accounts to your organization. The transfer process requires user consent and must go through the official transfer tool. Writing a custom script for this is unnecessary and wouldn't achieve the required account transfer.

- **D:** GCDS exclusion rules prevent specific users from being suspended or deleted during sync operations, but they don't address the core problem of unmanaged consumer accounts. These accounts exist outside of GCDS's scope entirely—exclusion rules won't migrate them into Cloud Identity or resolve the conflict between managed and unmanaged accounts.

### References

- [Migrate consumer accounts | Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/migrating-consumer-accounts)
- [Identities for users | IAM Documentation](https://docs.cloud.google.com/iam/docs/user-identities)
