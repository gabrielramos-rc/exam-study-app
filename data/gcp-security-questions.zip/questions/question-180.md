# Question 180

**Source:** https://www.examtopics.com/discussions/google/view/117159-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Automating infrastructure and application security
**Tags:** software supply chain, SLSA, provenance, Cloud Build, attestation

---

## Question

Your organization develops software involved in many open source projects and is concerned about software supply chain threats. You need to deliver provenance for the build to demonstrate the software is untampered. What should you do?
## Choices

- **A.** 1. Hire an external auditor to review and provide provenance. 2. Define the scope and conditions. 3. Get support from the Security department or representative. 4. Publish the attestation to your public web page.
- **B.** 1. Review the software process. 2. Generate private and public key pairs and use Pretty Good Privacy (PGP) protocols to sign the output software artifacts together with a file containing the address of your enterprise and point of contact. 3. Publish the PGP signed attestation to your public web page.
- **C.** 1. Publish the software code on GitHub as open source. 2. Establish a bug bounty program, and encourage the open source community to review, report, and fix the vulnerabilities.
- **D.** 1. Generate Supply Chain Levels for Software Artifacts (SLSA) level 3 assurance by using Cloud Build. 2. View the build provenance in the Security insights side panel within the Google Cloud console. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (7 total)


**Top Comments:**

- (6 upvotes) The best option would be D. Generate Supply Chain Levels for Software Artifacts (SLSA) level 3 assurance by using Cloud Build and view the build provenance in the Security insights side panel within t

- (3 upvotes) D it is

- (2 upvotes) D is correct.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Cloud Build natively supports generating Supply Chain Levels for Software Artifacts (SLSA) level 3 provenance, which is the industry standard for software supply chain security. SLSA is a framework developed by the Open Source Security Foundation (OpenSSF) that provides graduated levels of assurance about the integrity of software artifacts.

When you configure Cloud Build with `requestedVerifyOption: VERIFIED` and store artifacts in Artifact Registry, Cloud Build automatically:
1. Generates authenticated and non-falsifiable build provenance metadata
2. Includes details such as digests of built images, input source locations, build toolchain, build steps, and build duration
3. Signs the provenance to ensure it cannot be tampered with
4. Makes the provenance available through the Security insights side panel in the Google Cloud console

This approach provides verifiable, cryptographically-signed evidence that the software build process was not compromised, which is exactly what's needed to demonstrate that software is untampered. The provenance can be validated using the SLSA verifier tool and meets SLSA level 3 requirements.

### Why Other Options Are Wrong

- **A:** Hiring an external auditor is expensive, slow, and does not provide automated, continuous provenance generation. It relies on manual processes rather than cryptographically verifiable technical controls. External audits provide assurance reports, not technical build provenance.

- **B:** While PGP signing provides some level of authenticity, it does not provide comprehensive provenance metadata about the build process itself. PGP only signs the final artifacts, but doesn't capture information about how they were built, what sources were used, or the build environment. This doesn't meet SLSA standards for supply chain security.

- **C:** Publishing code as open source and running a bug bounty program helps with vulnerability detection but does not provide build provenance. This approach addresses vulnerability management but not supply chain integrity. It doesn't demonstrate that the distributed binaries match the source code or that the build process wasn't compromised.

### References

- [Generate and validate build provenance | Cloud Build](https://docs.cloud.google.com/build/docs/securing-builds/generate-validate-build-provenance)
- [Software supply chain security | Google Cloud](https://docs.cloud.google.com/software-supply-chain-security/docs/overview)
- [Safeguard builds | Software supply chain security](https://docs.cloud.google.com/software-supply-chain-security/docs/safeguard-builds)
