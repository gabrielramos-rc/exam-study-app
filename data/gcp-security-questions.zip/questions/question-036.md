# Question 036

**Source:** https://www.examtopics.com/discussions/google/view/16459-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, Data Loss Prevention, PII detection, user-generated content

---

## Question

A retail customer allows users to upload comments and product reviews. The customer needs to make sure the text does not include sensitive data before the comments or reviews are published. Which Google Cloud Service should be used to achieve this?
## Choices

- **A.** Cloud Key Management Service
- **B.** Cloud Data Loss Prevention API Most Voted
- **C.** BigQuery
- **D.** Web Security Scanner

---

## Community

**Most Voted:** B


**Votes:** B: 100% (7 total)


**Top Comments:**

- (28 upvotes) B. Cloud Data Loss Prevention API

- (3 upvotes) Its B.

- (2 upvotes) B is correct answer here.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Cloud Data Loss Prevention API (DLP API), now part of Sensitive Data Protection, is the correct service for detecting sensitive data in user-generated text content like comments and product reviews. The documentation explicitly states that inspection is "especially useful if you have unstructured data—like user-provided comments—that might have intermittent instances of personally identifiable information."

The DLP API works by:
1. **Inspection**: Scanning text content using the `content.inspect` method to identify sensitive information
2. **InfoType Detection**: Matching against configurable patterns (infoTypes) representing various data categories like credit card numbers, phone numbers, email addresses, names, and other PII
3. **Synchronous or Asynchronous**: Offering immediate inspection results for real-time validation before publishing comments, or batch processing for large volumes

For the retail use case, the DLP API can scan each comment or review before publication, identify any sensitive data (SSN, credit card numbers, phone numbers, etc.), and either block the content, redact sensitive portions, or alert administrators—preventing PII from being publicly published.

### Why Other Options Are Wrong

- **A. Cloud Key Management Service**: KMS is for managing cryptographic keys used for encryption and decryption. It does not inspect or detect sensitive content in text—it only manages the keys that encrypt data.

- **C. BigQuery**: BigQuery is a data warehouse for analytics and querying large datasets. While DLP can inspect data stored in BigQuery, BigQuery itself does not provide sensitive data detection capabilities for text content validation.

- **D. Web Security Scanner**: This service identifies security vulnerabilities in App Engine, GKE, and Compute Engine web applications (XSS, Flash injection, outdated libraries, etc.). It does not scan user-generated text content for sensitive data—it scans application code and configurations for security flaws.

### References

- [Sensitive Data Protection overview](https://docs.cloud.google.com/sensitive-data-protection/docs/sensitive-data-protection-overview)
- [Inspect sensitive text by using the DLP API](https://docs.cloud.google.com/sensitive-data-protection/docs/inspect-sensitive-text-api)
- [Inspecting structured text for sensitive data](https://docs.cloud.google.com/sensitive-data-protection/docs/inspecting-structured-text)
