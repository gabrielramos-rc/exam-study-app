# Question 296

**Source:** https://www.examtopics.com/discussions/google/view/148651-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** IAM roles, least privilege, compliance, VM hardening, regulatory risk

---

## Question

Your organization operates in a highly regulated industry and uses multiple Google Cloud services. You need to identify potential risks to regulatory compliance. Which situation introduces the greatest risk?
## Choices

- **A.** The security team mandates the use of customer-managed encryption keys (CMEK) for all data classified as sensitive.
- **B.** Sensitive data is stored in a Cloud Storage bucket with the uniform bucket-level access setting enabled.
- **C.** The audit team needs access to Cloud Audit Logs related to managed services like BigQuery.
- **D.** Principals have broad IAM roles allowing the creation and management of Compute Engine VMs without a pre-defined hardening process.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D introduces the greatest compliance risk because it violates the fundamental principle of least privilege and creates multiple compliance vulnerabilities:

**Broad IAM roles are explicitly discouraged in production environments.** Google Cloud documentation states: "Basic roles include thousands of permissions across all Google Cloud services. In production environments, do not grant basic roles unless there is no alternative." Granting broad roles (like Editor or Owner) allows principals to access and modify almost all resources, which is potentially dangerous.

**Lack of pre-defined hardening process creates configuration drift and security gaps.** In highly regulated industries, compliance frameworks (PCI DSS, HIPAA, FedRAMP) require implementation of industry-accepted hardening standards (PCI DSS section 2.2). Without a hardening process, VMs may:
- Run unnecessary services and ports (violating attack surface reduction requirements)
- Lack proper security configurations (patch management, OS hardening)
- Fail to meet compliance baseline requirements
- Create inconsistent security posture across the infrastructure

**The combination of broad permissions + uncontrolled VM creation = compliance nightmare.** Principals can create VMs with arbitrary configurations, store regulated data without proper controls, bypass security policies, and establish non-compliant workloads—all outside the audit trail and governance structure required by regulatory frameworks.

### Why Other Options Are Wrong

- **A:** Using CMEK for sensitive data is a **security best practice**, not a risk. Many compliance frameworks (HIPAA, PCI DSS) require customer control over encryption keys. CMEK enhances compliance posture by providing additional control over data encryption and key lifecycle management.

- **B:** Uniform bucket-level access is a **security improvement**, not a risk. It disables legacy object ACLs and enforces IAM-only access control, which provides consistent, centralized access management. This simplifies compliance auditing and reduces the risk of misconfigured object-level permissions.

- **C:** Providing audit team access to Cloud Audit Logs is a **compliance requirement**, not a risk. Regulatory frameworks mandate audit logging and review. Cloud Audit Logs for managed services like BigQuery are essential for monitoring data access, detecting anomalies, and demonstrating compliance during audits.

### References

- [Use IAM securely | Identity and Access Management Documentation](https://docs.cloud.google.com/iam/docs/using-iam-securely)
- [Best practices for using service accounts securely | IAM Documentation](https://docs.cloud.google.com/iam/docs/best-practices-service-accounts)
- [PCI Data Security Standard compliance | Cloud Architecture Center](https://docs.cloud.google.com/architecture/pci-dss-compliance-in-gcp)
