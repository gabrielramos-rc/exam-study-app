# Question 025

**Source:** https://www.examtopics.com/discussions/google/view/27112-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** Shared VPC, network segmentation, centralized network control, VPN, on-premises connectivity

---

## Question

Your team needs to configure their Google Cloud Platform (GCP) environment so they can centralize the control over networking resources like firewall rules, subnets, and routes. They also have an on-premises environment where resources need access back to the GCP resources through a private VPN connection. The networking resources will need to be controlled by the network security team. Which type of networking design should your team use to meet these requirements?
## Choices

- **A.** Shared VPC Network with a host project and service projects Most Voted
- **B.** Grant Compute Admin role to the networking team for each engineering project
- **C.** VPC peering between all engineering projects using a hub and spoke model
- **D.** Cloud VPN Gateway between all engineering projects using a hub and spoke model

---

## Community

**Most Voted:** A


**Votes:** A: 100% (1 total)


**Top Comments:**

- (19 upvotes) WATCH: https://www.youtube.com/watch?v=WotV3D01tJA READ: https://cloud.google.com/docs/enterprise/best-practices-for-enterprise-organizations#centralize_network_control

- (5 upvotes) I believe the answer is D. How can shared VPC give access to your on premise environment ? A seems wrong to me.

- (5 upvotes) I also believe the same. i worked on interconnects and gateways to connect on prem resources.. only hub and spoke helps to connect onpremise network. ofcourse, we can centralize network controls using

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Shared VPC is the ideal solution for this scenario because it provides centralized control over networking resources while supporting on-premises connectivity requirements. Here's why option A is correct:

**Centralized Network Control**: Shared VPC enables organizations to maintain centralized control over network resources like subnets, routes, and firewall rules in a single host project. Network administrators can manage all networking infrastructure from this central location while delegating instance creation responsibilities to Service Project Admins. As the documentation states, Shared VPC lets administrators "delegate administrative responsibilities...while maintaining centralized control over network resources like subnets, routes, and firewalls."

**Host and Service Project Architecture**: The host project contains the shared VPC network and is managed by the network security team (Shared VPC Admins). Service projects attach to this host project and consume the shared network resources. This architecture implements the principle of least privilege - service teams can create and manage instances within approved subnets, but cannot modify network-level resources without proper authorization.

**On-Premises Connectivity**: The host project can centrally manage Cloud VPN gateways and other hybrid connectivity resources. All service projects automatically inherit this connectivity without needing individual VPN configurations. Google's documentation confirms that "using Shared VPC is preferable if you need to create many projects and would like to prevent individual project owners from managing their connectivity back to your on-premises network."

**Consistent Security Policies**: By centralizing firewall rules, routes, and VPN configurations in the host project, the network security team can enforce consistent access control policies across all service projects, ensuring uniform security posture.

### Why Other Options Are Wrong

- **B (Grant Compute Admin role to networking team):** This approach creates a decentralized management model where networking resources are spread across multiple projects. It violates the principle of centralized control and makes it difficult to enforce consistent network policies. The Compute Admin role also grants far more permissions than needed for network administration, violating least privilege. Additionally, this doesn't address the requirement for centralized VPN connectivity management.

- **C (VPC peering with hub and spoke):** VPC Network Peering has significant limitations compared to Shared VPC. Routes are not automatically shared across peered networks, requiring manual configuration. Peering doesn't provide centralized network administration - each VPC owner maintains independent control. Google explicitly states "Google recommends using Shared VPC over using VPC Network Peering because Shared VPC is easier to configure and scale." Peering also complicates on-premises connectivity because VPN gateways in one network don't automatically extend to peered networks without additional routing configuration.

- **D (Cloud VPN Gateway between projects):** This creates unnecessary complexity by establishing VPN tunnels between GCP projects rather than between GCP and on-premises. Cloud VPN is designed for hybrid connectivity (connecting GCP to external networks), not for inter-project communication within GCP. This architecture would require multiple VPN gateways and complex routing, making it difficult for the network security team to maintain centralized control. It's also inefficient and costly compared to Shared VPC's native connectivity model.

### References

- [Shared VPC | Virtual Private Cloud](https://docs.cloud.google.com/vpc/docs/shared-vpc)
- [Best practices and reference architectures for VPC design](https://docs.cloud.google.com/architecture/best-practices-vpc-design)
- [Cloud VPN overview](https://docs.cloud.google.com/network-connectivity/docs/vpn/concepts/overview)
