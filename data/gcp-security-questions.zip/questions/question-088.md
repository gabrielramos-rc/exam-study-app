# Question 088

**Source:** https://www.examtopics.com/discussions/google/view/31142-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** load balancer, network tier, Premium Tier, multi-region

---

## Question

Your company operates an application instance group that is currently deployed behind a Google Cloud load balancer in us-central-1 and is configured to use the Standard Tier network. The infrastructure team wants to expand to a second Google Cloud region, us-east-2. You need to set up a single external IP address to distribute new requests to the instance groups in both regions. What should you do?
## Choices

- **A.** Change the load balancer backend configuration to use network endpoint groups instead of instance groups.
- **B.** Change the load balancer frontend configuration to use the Premium Tier network, and add the new instance group. Most Voted
- **C.** Create a new load balancer in us-east-2 using the Standard Tier network, and assign a static external IP address.
- **D.** Create a Cloud VPN connection between the two regions, and enable Google Private Access.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (9 total)


**Top Comments:**

- (14 upvotes) B is right

- (8 upvotes) B is the correct answer.

- (3 upvotes) only Premium allows LB between regions

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

To distribute traffic to instance groups in multiple regions using a **single external IP address**, you must use **Premium Tier networking**. This is a fundamental architectural requirement in Google Cloud:

**Standard Tier limitations:**
- Only supports regional backends (single region deployment)
- Uses regional external IP addresses and regional forwarding rules
- To support multiple regions with Standard Tier, you would need separate load balancers in each region, each with its own IP address, then use DNS-based distribution

**Premium Tier capabilities:**
- Supports global load balancing with a single anycast IP address
- Can distribute traffic across backends in multiple regions
- Uses Google's premium backbone for low-latency global routing
- Automatically routes users to the closest available backend region

The solution is to change the load balancer frontend configuration from Standard Tier to Premium Tier, which will enable the global forwarding rule and allow you to add the new instance group in us-east-2 while maintaining a single external IP address.

### Why Other Options Are Wrong

- **A:** Changing to Network Endpoint Groups (NEGs) doesn't solve the fundamental network tier limitation. NEGs are a backend configuration option that can be used with either Standard or Premium Tier, but they don't enable multi-region distribution with a single IP if you're using Standard Tier.

- **C:** Creating a separate load balancer in us-east-2 with Standard Tier would give you a *second* IP address, not a single IP address as required. This defeats the purpose of having one unified entry point and would require DNS-based traffic distribution between two different IPs.

- **D:** Cloud VPN and Private Google Access are for private connectivity between on-premises networks or internal Google services. They have nothing to do with exposing a public load balancer to external users across multiple regions with a single IP.

### References

- [Network Service Tiers overview](https://docs.cloud.google.com/network-tiers/docs/overview)
- [Cloud Load Balancing overview](https://docs.cloud.google.com/load-balancing/docs/load-balancing-overview)
