# Question 333

**Source:** https://www.examtopics.com/discussions/google/view/311200-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** Access Context Manager, VPC Service Controls, Context-Aware Access, device policy, Chrome Enterprise Premium

---

## Question

Your organization is implementing a Zero Trust security model and using Chrome Enterprise Premium. The company is interested in governing access to sensitive data stored in Cloud Storage. You need to configure access controls that ensure only authorized users on managed devices can access this data, regardless of their network location. Access should be restricted based on the device's security posture. This requires up-to-date operating system patches and antivirus software. What should you do?
## Choices

- **A.** Grant access to specific users to the VPC Service Controls to create a perimeter to access the Cloud Storage buckets. Configure Identity-Aware Proxy (IAP) to authenticate users before they can access the data.
- **B.** Configure IAM conditions based on IP address ranges. Require users to connect through a VPN. Implement endpoint verification software on user devices to check for basic compliance.
- **C.** Create an access level in Access Context Manager that requires a device policy. Create a Context-Aware Access policy using this access level. Apply the policy to the VPC Service Controls perimeter that includes the Cloud Storage buckets. Most Voted
- **D.** Use Cloud Firewall rules to restrict access to the Cloud Storage buckets based on the source IP addresses. Require users to authenticate with a multi-factor authentication method.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (1 total)

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is the correct solution for implementing Zero Trust security with Chrome Enterprise Premium to protect Cloud Storage based on device security posture. This approach leverages the full Chrome Enterprise Premium stack:

1. **Endpoint Verification**: Deployed as part of Chrome Enterprise Premium, this Chrome extension collects device attributes including OS patches (hotfixes on Windows), antivirus status, disk encryption, firewall status, and screen lock configuration. These attributes are stored in an inventory accessible to Access Context Manager.

2. **Access Context Manager**: Creates access levels that define device policy requirements. You can specify conditions such as "require OS patches to be current," "require antivirus to be installed and enabled," along with other security attributes like disk encryption and screen lock. These access levels use device data from Endpoint Verification to make real-time access decisions.

3. **VPC Service Controls**: Protects Cloud Storage buckets within a service perimeter. The access level created in Access Context Manager is applied to this perimeter, ensuring that only requests from devices meeting the security posture requirements can access the protected resources.

4. **Zero Trust Implementation**: This solution enforces access regardless of network location (no VPN required), validates device security posture in real-time, and provides context-aware access based on both user identity and device state—the core principles of Zero Trust.

The integration between these components provides the exact scenario described: authorized users on managed devices with proper security posture (OS patches and antivirus) can access Cloud Storage data regardless of network location.

### Why Other Options Are Wrong

- **A:** IAP is primarily designed for web applications and VM instances (SSH/RDP access via IAP tunnel), not for Cloud Storage access. While IAP provides identity-based access control, it doesn't enforce device security posture requirements like OS patches and antivirus software. VPC Service Controls needs access levels from Access Context Manager, not just user permissions.

- **B:** IP-based IAM conditions and VPN requirements contradict Zero Trust principles by relying on network location rather than identity and device context. This approach doesn't provide the device security posture validation needed (OS patches, antivirus) and requires users to be on specific networks, which violates the "regardless of network location" requirement.

- **D:** Cloud Firewall rules apply to network traffic between VPC resources, not to Cloud Storage access. You cannot use firewall rules to restrict access to Cloud Storage buckets—they operate at different layers. Additionally, this approach relies solely on network controls (IP addresses) rather than device security posture, and doesn't provide the device policy validation required.

### References

- [Endpoint Verification Overview](https://docs.cloud.google.com/endpoint-verification/docs/overview)
- [Device Attributes Collected by Endpoint Verification](https://docs.cloud.google.com/endpoint-verification/docs/device-information)
- [Define Access Policies Using Access Levels](https://docs.cloud.google.com/chrome-enterprise-premium/docs/define-access-policies)
- [Create Access Levels in Access Context Manager](https://docs.cloud.google.com/access-context-manager/docs/create-access-level)
- [Service Perimeter Details and Configuration](https://cloud.google.com/vpc-service-controls/docs/service-perimeters)
