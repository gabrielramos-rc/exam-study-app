# Question 313

**Source:** https://www.examtopics.com/discussions/google/view/150185-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, Shared VPC, resource hierarchy, security controls

---

## Question

Your Google Cloud organization is subdivided into three folders: production, development, and networking, Networking resources for the organization are centrally managed in the networking folder. You discovered that projects in the production folder are attaching to Shared VPCs that are outside of the networking folder which could become a data exfiltration risk. You must resolve the production folder issue without impacting the development folder. You need to use the most efficient and least disruptive approach. What should you do?
## Choices

- **A.** Enable the Restrict Shared VPC Host Projects organization policy on the production folder. Create a custom rule and configure the policy type to Allow. In the Custom value section, enter under:folders/networking. Most Voted
- **B.** Enable the Restrict Shared VPC Host Projects organization policy on the networking folder only. Create a new custom rule and configure the policy type to Allow. In the Custom value section, enter under:organizations/123456739123.
- **C.** Enable the Restrict Shared VPC Host Projects organization policy at the project level for each of the production projects. Create a custom rule and configure the policy type to Allow. In the Custom value section, enter under:folders/networking.
- **D.** Enable the Restrict Shared VPC Host Projects organization policy at the organization level. Create a custom rule and configure the policy type to Allow. In the Custom value section, enter under:folders/networking.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (4 total)


**Top Comments:**

- (1 upvotes) Rest don't make sense tbh.

- (1 upvotes) Answer A

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is correct because it applies the `constraints/compute.restrictSharedVpcHostProjects` organization policy at the production folder level with an allow list containing `under:folders/networking`. This approach:

1. **Targets only production projects**: Folder-level policies affect exclusively that folder and its descendants without impacting sibling folders (development remains unaffected).

2. **Prevents data exfiltration risk**: The allow list restricts production service projects to attach only to Shared VPC host projects within the networking folder, blocking attachments to external host projects.

3. **Uses the correct syntax**: The `under:folders/networking` value in the allow list specifies that only host projects under the networking folder hierarchy are permitted.

4. **Most efficient and least disruptive**: Applying the policy at the folder level is more efficient than managing it at the project level (Option C) and more targeted than organization-wide application (Option D).

According to Google Cloud documentation, "A resource that has an organization policy set by default supersedes any policy set by its parent resources," meaning the production folder policy will govern production projects regardless of organization-level settings.

### Why Other Options Are Wrong

- **B:** Applying the policy on the networking folder is incorrect because the policy needs to be enforced on the service projects (in production folder), not on the host projects (in networking folder). The constraint controls which host projects a service project can attach to, so it must be applied where the service projects reside. Additionally, allowing the entire organization would defeat the purpose of restricting to the networking folder.

- **C:** Applying the policy at the project level for each production project would work but is inefficient and not scalable. It requires managing the policy separately for each project, which increases administrative overhead and is error-prone when new production projects are created. The folder-level approach (Option A) automatically applies to all current and future projects in the production folder.

- **D:** Applying the policy at the organization level would restrict all projects across the entire organization (including development folder) to only use host projects in the networking folder. This violates the requirement to "resolve the production folder issue without impacting the development folder." The development folder needs flexibility to use other Shared VPC configurations.

### References

- [Provision Shared VPC - Organization Policy Constraints](https://docs.cloud.google.com/vpc/docs/provisioning-shared-vpc)
- [Understanding Hierarchy Evaluation - Organization Policies](https://docs.cloud.google.com/resource-manager/docs/organization-policy/understanding-hierarchy)
- [Using Constraints - Organization Policy](https://docs.cloud.google.com/resource-manager/docs/organization-policy/using-constraints)
