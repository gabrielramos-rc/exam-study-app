# Question 264

**Source:** https://www.examtopics.com/discussions/google/view/147058-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Armor, logging, verbose logging, WAF, troubleshooting

---

## Question

Customers complain about error messages when they access your organization's website. You suspect that the web application firewall rules configured in Cloud Armor are too strict. You want to collect request logs to investigate what triggered the rules and blocked the traffic. What should you do?
## Choices

- **A.** Modify the Application Load Balancer backend and increase the tog sample rate to a higher number.
- **B.** Enable logging in the Application Load Balancer backend and set the log level to VERBOSE in the Cloud Armor policy. Most Voted
- **C.** Change the configuration of suspicious web application firewall rules in the Cloud Armor policy to preview mode.
- **D.** Create a log sink with a filter for togs containing redirected_by_security_policy and set a BigQuery dataset as destination.

---

## Community

**Most Voted:** B


**Votes:** B: 90% | C: 10% (10 total)


**Top Comments:**

- (4 upvotes) I think it's B.

- (1 upvotes) https://cloud.google.com/armor/docs/verbose-logging You can adjust the level of detail recorded in your logs. We recommend that you enable verbose logging only when you first create a policy, make cha

- (1 upvotes) Enabling verbose logging for your Cloud Armor policy provides the most detailed logs, including information about why specific requests triggered a WAF rule. This level of detail is critical for troub

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B is the correct approach for collecting request logs to investigate what triggered Cloud Armor rules and blocked traffic. This requires two essential steps:

1. **Enable logging on the Application Load Balancer backend**: Cloud Armor per-request logs are generated as part of Cloud Load Balancing logs. Logging for new backend services is disabled by default, so you must explicitly enable it to record Cloud Armor security policy information.

2. **Set the log level to VERBOSE in the Cloud Armor policy**: Verbose logging provides detailed information about what triggered preconfigured WAF rules. When enabled using `gcloud compute security-policies update [POLICY_NAME] --log-level=VERBOSE`, it adds critical fields to request logs including:
   - **matchedFieldType**: The request element type (e.g., "ARG_VALUES", "HEADER_VALUES", "BODY")
   - **matchedFieldName**: The parameter name if applicable
   - **matchedFieldValue**: Up to 16-byte prefix of the matching content
   - **matchedFieldLength**: Total field size
   - **matchedOffset/matchedLength**: Position and size of the match

Google specifically recommends enabling verbose logging when troubleshooting a policy to get the additional detail needed to analyze and debug rules. The logs will include `statusDetails: "denied_by_security_policy"` for blocked requests, along with the matched rule priority and configured action.

### Why Other Options Are Wrong

- **A:** Increasing the sample rate would actually reduce log coverage, not increase it. The sample rate determines what percentage of requests are logged - a higher sample rate means MORE requests are logged. However, this option mentions increasing the sample rate but also contains a typo ("tog" instead of "log"), and more importantly, it doesn't address the need for verbose logging to see what triggered the rules. Sample rate alone won't provide the detailed match information needed for investigation.

- **C:** Changing rules to preview mode would prevent them from blocking traffic, which defeats the purpose of having the WAF rules in place. Preview mode is useful for testing new rules before enforcement, but it doesn't help investigate why existing rules are blocking legitimate traffic. You need to keep the rules active while collecting detailed logs to understand the blocking behavior.

- **D:** Creating a log sink with a filter is a log export mechanism, not a log generation mechanism. The correct field name is `denied_by_security_policy` (not "redirected_by_security_policy" - this appears to be a typo). Even with the correct field name, you first need to enable logging on the backend service to generate the logs before you can export them. Additionally, this doesn't enable verbose logging, which provides the crucial detail about what triggered the rules.

### References

- [Use request logging | Cloud Armor](https://docs.cloud.google.com/armor/docs/request-logging)
- [Verbose logging | Cloud Armor](https://docs.cloud.google.com/armor/docs/verbose-logging)
- [Troubleshoot Cloud Armor issues](https://docs.cloud.google.com/armor/docs/troubleshooting)
