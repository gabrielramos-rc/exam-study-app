# Question 328

**Source:** https://www.examtopics.com/discussions/google/view/306217-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** service account keys, key rotation, secret management, access control

---

## Question

Your organization’s application is being integrated with a partner application that requires read access to customer data to process customer orders. The customer data is stored in one of your Cloud Storage buckets. You have evaluated different options and determined that this activity requires the use of service account keys. You must advise the partner on how to minimize the risk of a compromised service account key causing a loss of data. What should you advise the partner to do?
## Choices

- **A.** Scan the Cloud Storage bucket with Sensitive Data Protection when new data is added, and automatically mask all customer data.
- **B.** Define a VPC Service Controls perimeter, and restrict the Cloud Storage API. Add an ingress rule to the perimeter to allow access to the Cloud Storage API for the service account from outside of the perimeter.
- **C.** Ensure that all data for the application that is accessed through the relevant service accounts is encrypted at rest by using customer-managed encryption keys (CMEK).
- **D.** Implement a secret management service. Configure the service to frequently rotate the service account key. Configure proper access control to the key, and restrict who can create service account keys. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (3 total)


**Top Comments:**

- (2 upvotes) D is correct

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D provides the most comprehensive approach to minimizing the risk of compromised service account keys through multiple defense layers:

**Key Rotation**: Regular rotation of service account keys is a fundamental security best practice explicitly recommended by Google Cloud. If a key is leaked, frequent rotation increases the likelihood that the compromised key will be invalidated before it can be exploited. Google documentation states that "rotating service account keys can help reduce the risk posed by leaked or stolen keys" because "if you regularly rotate your service account keys, there's a higher chance that the leaked keys will be invalid by the time a bad actor gets them."

**Secret Management Service**: Google recommends using centralized secret management services (like HashiCorp Vault) that provide automatic secret rotation capabilities. These services securely store keys without exposing private key material in plaintext and provide auditable access to credentials.

**Access Control**: Implementing proper access controls to the keys and restricting who can create service account keys prevents unauthorized key creation and limits the attack surface. Google specifically recommends using organization policy constraints to "prevent creating new service account keys, and allow exceptions only for projects that have demonstrated that they cannot use a more secure alternative."

**Restricting Key Creation**: Limiting who can create service account keys prevents privilege escalation attacks where attackers with Editor roles might create new keys to maintain persistent access.

This multi-layered approach (rotation + secure storage + access control + creation restrictions) directly addresses the question's requirement to "minimize the risk of a compromised service account key."

### Why Other Options Are Wrong

- **A:** While Sensitive Data Protection (DLP) scanning and masking can protect data content, it does not address the fundamental security risk of the service account key itself being compromised. A compromised key could still be used to access the bucket and exfiltrate data, even if some data is masked. This protects data but not against key compromise.

- **B:** VPC Service Controls provides perimeter security and prevents data exfiltration from within the perimeter, but it doesn't minimize the risk of the key itself being compromised. Once the key is compromised and used from an allowed location (outside the perimeter via the ingress rule), the attacker has access. This controls where the key can be used but doesn't reduce key compromise risk.

- **C:** Customer-managed encryption keys (CMEK) protect data at rest by ensuring that data is encrypted with keys you control, but this doesn't prevent a compromised service account key from being used to access and decrypt the data. If the service account has the necessary permissions, it can still access CMEK-encrypted data. CMEK protects against Google-side compromise, not service account key compromise.

### References

- [Best practices for managing service account keys](https://docs.cloud.google.com/iam/docs/best-practices-for-managing-service-account-keys)
- [Service account key rotation](https://docs.cloud.google.com/iam/docs/key-rotation)
