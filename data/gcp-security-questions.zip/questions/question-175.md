# Question 175

**Source:** https://www.examtopics.com/discussions/google/view/79869-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** encryption, end-to-end encryption, encryption at rest, encryption in transit, encryption in use, Confidential Computing, client-side encryption

---

## Question

You are consulting with a client that requires end-to-end encryption of application data (including data in transit, data in use, and data at rest) within Google Cloud. Which options should you utilize to accomplish this? (Choose two.)
## Choices

- **A.** External Key Manager
- **B.** Customer-supplied encryption keys
- **C.** Hardware Security Module
- **D.** Confidential Computing and Istio Most Voted
- **E.** Client-side encryption Most Voted

---

## Community

**Most Voted:** DE


**Votes:** AE: 3% | BC: 6% | BD: 10% | BE: 3% | DE: 77% (31 total)


**Top Comments:**

- (14 upvotes) I feel this should be DE. Confidential Computing enables encryption for "data-in-use" Client Side encryption enables security for "data in transit" from Customer site to GCP Once data is at rest, use 

- (8 upvotes) Confidential Computing and Istio (Option D): Confidential Computing protects data in use by running workloads in secure enclaves, ensuring that data remains encrypted even during processing. Istio can

- (4 upvotes) D. Confidential Computing and Istio E. Client-side encryption

---

## Answer

**Correct:** D, E

**Confidence:** high

### Explanation

End-to-end encryption requires protecting data in all three states: **at rest**, **in transit**, and **in use**. This question specifically requires all three types of protection.

**D. Confidential Computing and Istio** provides the critical missing piece - **encryption in use**. Confidential Computing uses hardware-based Trusted Execution Environments (TEEs) with inline memory encryption to protect data while it is being actively processed. Confidential VMs encrypt data in memory using technologies like AMD SEV, Intel TDX, or Arm CCA. When combined with Istio's service mesh capabilities for securing data in transit (mTLS between services), this option addresses both encryption in use and encryption in transit within the application layer.

**E. Client-side encryption** ensures data is encrypted **before it ever leaves the client** and reaches Google Cloud. With client-side encryption, the customer encrypts data on their side using their own keys before transmission to GCP. This provides true end-to-end encryption because:
- Data is encrypted at rest (encrypted before storage)
- Data remains encrypted in transit (already encrypted when transmitted)
- The customer maintains complete control over encryption keys (Google never sees unencrypted data)

Together, these two options provide comprehensive coverage: Confidential Computing protects data during processing (in use), Istio secures service-to-service communication (in transit), and client-side encryption ensures data is protected from the source through storage (at rest and in transit).

### Why Other Options Are Wrong

- **A. External Key Manager (EKM):** EKM allows you to manage encryption keys outside of Google Cloud, but it only addresses **key management** for encryption at rest and does not provide encryption in use. EKM is about where keys are stored and managed, not about protecting data during active processing.

- **B. Customer-supplied encryption keys (CSEK):** CSEK allows you to provide your own encryption keys for data at rest in services like Cloud Storage and Compute Engine. However, it only addresses **encryption at rest** and does not protect data in use or provide comprehensive end-to-end encryption. The data is still decrypted during processing.

- **C. Hardware Security Module (HSM):** Cloud HSM provides FIPS 140-2 Level 3 certified hardware for storing and managing cryptographic keys. Like EKM and CSEK, this is a **key management solution** for encryption at rest, not a solution for protecting data in use. HSM ensures keys are protected in tamper-resistant hardware but doesn't encrypt data during processing.

### References

- [Confidential Computing overview](https://docs.cloud.google.com/confidential-computing/docs/confidential-computing-overview)
- [Encryption in transit for Google Cloud](https://docs.cloud.google.com/docs/security/encryption-in-transit)
- [Default encryption at rest](https://docs.cloud.google.com/docs/security/encryption/default-encryption)
