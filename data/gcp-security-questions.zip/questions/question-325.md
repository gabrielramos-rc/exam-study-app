# Question 325

**Source:** https://www.examtopics.com/discussions/google/view/305717-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Cloud Armor, DDoS, WAF, IAP, firewall rules

---

## Question

Your organization manages a critical web application that serves international customers on Google Cloud. An increase in malicious traffic targeting this application has strained resources and caused periods of downtime. You need to design security measures to increase the application's resilience against web attacks, enhance perimeter protection, and provide access control. What should you do?
## Choices

- **A.** Employ network load balancing for traffic distribution. Update Identity-Aware Proxy (IAP) policies to allow only administrative access. Implement custom firewall rules on all external IP addresses.
- **B.** Set up firewall rules on Compute Engine instances within the application's environment. Rely on load balancers for threat detection. Increase instance resources to cope with attack volume.
- **C.** Configure firewall rules to block traffic from known malicious IP ranges. Set up Google Cloud Armor and implement Identity-Aware Proxy (IAP) for granular access control. Most Voted
- **D.** Add firewall rules that restrict all internal IP ranges. Establish Cloud DNS security policies. Disable external IP addresses to reduce the attack surface. Create user groups for access control.

---

## Community

**Most Voted:** C


**Votes:** C: 67% | D: 33% (3 total)


**Top Comments:**

- (1 upvotes) C is correct

- (1 upvotes) Why C?. There is no known IP address

- (1 upvotes) C is correct. The list of know malicious IP addresses are part of the threat intelligence capabilities and can be added to Cloud Armor

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C provides the most comprehensive and appropriate solution for protecting a critical web application against malicious traffic, DDoS attacks, and web-based threats while maintaining proper access control.

**Google Cloud Armor** is specifically designed for this scenario. It provides always-on DDoS protection against network/protocol-based volumetric attacks and Layer 7 application attacks. Cloud Armor operates at the Google Cloud edge, filtering malicious traffic before it reaches your infrastructure or consumes resources. It includes preconfigured WAF rules based on OWASP Core Rule Set 3.3.2, protecting against OWASP Top 10 vulnerabilities including XSS and SQL injection. The custom rules engine allows you to define prioritized rules with configurable match conditions and actions tailored to your specific security requirements.

**Identity-Aware Proxy (IAP)** provides granular access control at the application level. It establishes a central authorization layer for HTTPS-accessed applications, allowing you to use application-level access control instead of relying solely on network-level firewalls. IAP ensures that only authenticated and authorized users with the correct IAM role (IAP-Secured Web App User) can access the application, without requiring VPN infrastructure.

**Firewall rules** blocking known malicious IP ranges add an additional layer of perimeter defense, preventing traffic from known threat sources from even reaching your application infrastructure.

This combination directly addresses all three requirements: resilience against web attacks (Cloud Armor's DDoS and WAF protection), enhanced perimeter protection (edge-based filtering and IP blocking), and access control (IAP's identity-based authorization).

### Why Other Options Are Wrong

- **A:** Network load balancing alone doesn't provide DDoS protection or WAF capabilities. Restricting IAP to "only administrative access" would block legitimate customer traffic to the application, which defeats the purpose of a customer-facing web application. This option misunderstands IAP's role in protecting user access.

- **B:** Instance-level firewall rules and increasing resources is a reactive approach that doesn't prevent attacks. Load balancers alone do not provide threat detection or DDoS mitigation capabilities. Simply scaling resources to "cope with attack volume" is cost-ineffective and doesn't actually stop the attacks from consuming resources and potentially causing downtime.

- **D:** Restricting internal IP ranges and disabling external IPs would make the web application inaccessible to internet customers, which contradicts the requirement to serve international customers. Cloud DNS security policies don't address web application attacks or DDoS. User groups alone don't provide the granular, identity-based access control that IAP provides.

### References

- [Google Cloud Armor Product Overview](https://docs.cloud.google.com/armor/docs/cloud-armor-overview)
- [Identity-Aware Proxy Overview](https://docs.cloud.google.com/iap/docs/concepts-overview)
- [Managing Access with IAP](https://docs.cloud.google.com/iap/docs/managing-access)
