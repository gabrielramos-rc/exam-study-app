# Question 133

**Source:** https://www.examtopics.com/discussions/google/view/75428-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** resource hierarchy, organization policy, Resource Location Restriction, data residency

---

## Question

Your company's Chief Information Security Officer (CISO) creates a requirement that business data must be stored in specific locations due to regulatory requirements that affect the company's global expansion plans. After working on the details to implement this requirement, you determine the following: ✑ The services in scope are included in the Google Cloud Data Residency Terms. ✑ The business data remains within specific locations under the same organization. ✑ The folder structure can contain multiple data residency locations. You plan to use the Resource Location Restriction organization policy constraint. At which level in the resource hierarchy should you set the constraint?
## Choices

- **A.** Folder
- **B.** Resource
- **C.** Project Most Voted
- **D.** Organization

---

## Community

**Most Voted:** C


**Votes:** A: 32% | B: 2% | C: 60% | D: 5% (40 total)


**Top Comments:**

- (24 upvotes) why not D?

- (6 upvotes) Reference: https://cloud.google.com/resource-manager/docs/organization-policy/defining-locations#overview A policy that includes this constraint will not be enforced on sub-resource creation for certa

- (4 upvotes) "C" Project Level These restrictions can be applied at Org level, Folder Level or Project Level, but not resource level. Also, these policies are inherited, which means they need to be applied at the 

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The correct answer is **Folder** because the question explicitly states that "the folder structure can contain multiple data residency locations." This is the key requirement that determines the appropriate hierarchy level.

When you have multiple folders requiring different data residency locations, you must set the Resource Location Restriction organization policy constraint at the **folder level**. This allows each folder to have its own specific location restrictions tailored to different regulatory requirements (e.g., one folder for EU data with `europe` locations, another folder for US data with `us` locations).

Organization policies follow inheritance patterns in the resource hierarchy. When you set a constraint at the folder level, you can:
- Configure different allowed locations for each folder
- Override parent policies when needed
- Ensure that all projects and resources within each folder comply with that folder's specific location requirements

Setting the constraint at a higher level (organization) would apply a single uniform policy across all folders, which wouldn't support the requirement for multiple different data residency locations. Setting it at lower levels (project or resource) would be administratively inefficient and wouldn't provide the proper grouping for data residency zones.

### Why Other Options Are Wrong

- **B (Resource):** Resource-level organization policies are not supported. Organization policies can be set at organization, folder, or project levels, but not at individual resource levels. Additionally, this would be too granular for managing data residency requirements.

- **C (Project):** While you can set organization policies at the project level, this approach would be inefficient when managing data residency at scale. Projects are meant for workload separation, not regulatory boundary management. Using folders allows you to group multiple projects under the same data residency requirements, providing better administrative organization and reducing policy management overhead.

- **D (Organization):** Setting the constraint at the organization level would apply a single set of allowed locations to all resources across the entire organization. This contradicts the requirement that "the folder structure can contain multiple data residency locations." An organization-level policy cannot accommodate different location restrictions for different folders simultaneously.

### References

- [Restricting Resource Locations](https://docs.cloud.google.com/resource-manager/docs/organization-policy/defining-locations)
- [Creating and managing organization policies](https://docs.cloud.google.com/resource-manager/docs/organization-policy/creating-managing-policies)
- [Introduction to the Organization Policy Service](https://cloud.google.com/resource-manager/docs/organization-policy/overview)
