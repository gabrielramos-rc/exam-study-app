# Question 189

**Source:** https://www.examtopics.com/discussions/google/view/117091-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring network security
**Tags:** Cloud Armor, rate limiting, throttle, DDoS protection

---

## Question

Your application is deployed as a highly available, cross-region solution behind a global external HTTP(S) load balancer. You notice significant spikes in traffic from multiple IP addresses, but it is unknown whether the IPs are malicious. You are concerned about your application's availability. You want to limit traffic from these clients over a specified time interval. What should you do?
## Choices

- **A.** Configure a throttle action by using Google Cloud Armor to limit the number of requests per client over a specified time interval. Most Voted
- **B.** Configure a rate_based_ban action by using Google Cloud Armor and set the ban_duration_sec parameter to the specified lime interval.
- **C.** Configure a firewall rule in your VPC to throttle traffic from the identified IP addresses.
- **D.** Configure a deny action by using Google Cloud Armor to deny the clients that issued too many requests over the specified time interval.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (8 total)


**Top Comments:**

- (4 upvotes) A https://cloud.google.com/blog/products/identity-security/announcing-new-cloud-armor-rate-limiting-adaptive-protection-and-bot-defense

- (2 upvotes) When dealing with potential DDoS attacks or unexpected spikes in traffic, it's essential to handle the situation carefully to maintain the availability of your application. Here are the options you ha

- (2 upvotes) A you want to limit, not ban traffic https://cloud.google.com/armor/docs/rate-limiting-overview#throttle-traffic

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

The **throttle action** in Google Cloud Armor is specifically designed for this scenario. When configured, it limits the rate of requests from each client to a defined maximum over a specified time interval. The throttle action works by:

1. **Allowing conforming traffic**: When a client's traffic rate is under or equal to the `rate_limit_threshold_count`, requests follow the `conform_action` (always allow), and traffic reaches its destination normally.

2. **Limiting exceeding traffic**: When a client's traffic exceeds the specified threshold, Cloud Armor applies the `exceed_action` (deny with status code or redirect) for requests over the limit for the rest of the threshold interval.

This approach is ideal when the IPs are **unknown whether malicious** because it maintains availability by allowing some traffic through while preventing complete overload. For example, if you set a threshold of 2,000 requests within 1,200 seconds (20 minutes), and a client sends 2,500 requests, approximately 20% of that client's traffic is throttled until the permitted request volume drops below the configured threshold.

The throttle action prioritizes **maintaining service availability** during traffic spikes, which directly addresses the concern stated in the question.

### Why Other Options Are Wrong

- **B.** `rate_based_ban` action blocks ALL traffic from the offending client for the entire ban duration period. This is too aggressive when you don't know if the IPs are malicious - it could block legitimate users experiencing traffic spikes. Additionally, the ban_duration_sec is an additional period beyond the threshold interval, not the same as the specified time interval mentioned in the question.

- **C.** VPC firewall rules operate at Layer 3/4 and cannot perform rate-based throttling. Firewall rules only allow or deny traffic based on IP addresses, protocols, and ports - they don't have the capability to count requests over time intervals or implement throttling logic. Additionally, for a global external HTTP(S) load balancer, Cloud Armor is the appropriate service for application-layer rate limiting.

- **D.** A simple deny action would completely block traffic from clients that exceed the threshold, rather than limiting/throttling it. This doesn't meet the requirement to "limit traffic over a specified time interval" - it would instead result in complete denial of service for those clients, potentially impacting legitimate users.

### References

- [Rate limiting overview | Google Cloud Armor](https://docs.cloud.google.com/armor/docs/rate-limiting-overview)
- [Configure rate limiting | Google Cloud Armor](https://docs.cloud.google.com/armor/docs/configure-rate-limiting)
