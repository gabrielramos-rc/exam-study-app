# Question 101

**Source:** https://www.examtopics.com/discussions/google/view/74595-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Configuring Cloud Data Loss Prevention (DLP)
**Tags:** Cloud DLP, de-identification, tokenization, deterministic encryption, referential integrity

---

## Question

Your company wants to determine what products they can build to help customers improve their credit scores depending on their age range. To achieve this, you need to join user information in the company's banking app with customers' credit score data received from a third party. While using this raw data will allow you to complete this task, it exposes sensitive data, which could be propagated into new systems. This risk needs to be addressed using de-identification and tokenization with Cloud Data Loss Prevention while maintaining the referential integrity across the database. Which cryptographic token format should you use to meet these requirements?
## Choices

- **A.** Deterministic encryption Most Voted
- **B.** Secure, key-based hashes
- **C.** Format-preserving encryption
- **D.** Cryptographic hashing

---

## Community

**Most Voted:** A


**Votes:** A: 66% | C: 19% | D: 16% (32 total)


**Top Comments:**

- (11 upvotes) A is right

- (4 upvotes) This question is taken from the exact scenario described in this link https://cloud.google.com/blog/products/identity-security/take-charge-of-your-data-how-tokenization-makes-data-usable-without-sacri

- (3 upvotes) Why C. Format-preserving encryption is correct: Format-preserving encryption (FPE) encrypts data while preserving its format (e.g., encrypting a credit card number would still result in a string with 

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Deterministic encryption using AES-SIV is the correct cryptographic token format for this use case because it specifically addresses the requirement to maintain referential integrity across databases while de-identifying sensitive data.

When you need to join user information from the banking app with credit score data from a third party, the same sensitive values (like user IDs or customer identifiers) must tokenize to the same encrypted values consistently. Deterministic encryption ensures that given the same cryptographic key and context tweak, an input value is always transformed to the same encrypted token. This preservation of referential integrity allows you to:

1. Join datasets across different systems without exposing raw sensitive data
2. Maintain relationships between records even after de-identification
3. Perform analytics on age ranges and credit scores without accessing the original PII

Cloud DLP's deterministic encryption replaces input values with tokens generated using AES in Synthetic Initialization Vector mode (AES-SIV), which are base64-encoded and can include surrogate annotations for re-identification when authorized. The method uses cryptographic keys (managed via Cloud KMS) to ensure security while maintaining consistency across transformations.

### Why Other Options Are Wrong

- **B (Secure, key-based hashes):** While this option sounds similar to cryptographic methods, it's not a standard Cloud DLP cryptographic token format. The actual format is "cryptographic hashing" using HMAC-SHA-256, which is listed as option D. This terminology makes the option technically incorrect.

- **C (Format-preserving encryption):** While FPE-FFX does maintain referential integrity and is a valid Cloud DLP method, it's primarily designed for scenarios where you need to preserve the original character set and length of data (e.g., maintaining credit card number format). For general database joins where format preservation isn't required, deterministic encryption is the more standard and commonly recommended approach.

- **D (Cryptographic hashing):** HMAC-SHA-256 creates one-way irreversible tokens with uniform length. While it maintains referential integrity, it's not reversible, meaning you cannot re-identify the original values when needed. The question mentions "tokenization with Cloud Data Loss Prevention," which typically implies the ability to decrypt/re-identify data when authorized, making deterministic encryption the better choice.

### References

- [Pseudonymization | Sensitive Data Protection | Google Cloud](https://docs.cloud.google.com/sensitive-data-protection/docs/pseudonymization)
- [Take charge of your data: How tokenization makes data usable without sacrificing privacy | Google Cloud Blog](https://cloud.google.com/blog/products/identity-security/take-charge-of-your-data-how-tokenization-makes-data-usable-without-sacrificing-privacy)
- [De-identification and re-identification of PII using Sensitive Data Protection | Cloud Architecture Center](https://cloud.google.com/architecture/de-identification-re-identification-pii-using-cloud-dlp)
