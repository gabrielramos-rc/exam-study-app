# Question 007

**Source:** https://www.examtopics.com/discussions/google/view/15921-exam-professional-cloud-security-engineer-topic-1-question-7/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Cloud VPN, Cloud Interconnect, hybrid connectivity, on-premises

---

## Question

A company is running workloads in a dedicated server room. They must only be accessed from within the private company network. You need to connect to these workloads from Compute Engine instances within a Google Cloud Platform project. Which two approaches can you take to meet the requirements? (Choose two.)
## Choices

- **A.** Configure the project with Cloud VPN. Most Voted
- **B.** Configure the project with Shared VPC.
- **C.** Configure the project with Cloud Interconnect. Most Voted
- **D.** Configure the project with VPC peering.
- **E.** Configure all Compute Engine instances with Private Access.

---

## Community

**Most Voted:** AC


**Votes:** AC: 100% (10 total)


**Top Comments:**

- (31 upvotes) Again you are correct

- (4 upvotes) A and C are correct answer here.

- (4 upvotes) Private Access won't help, AC is the answer

---

## Answer

**Correct:** A, C

**Confidence:** high

### Explanation

To connect from GCP Compute Engine instances to on-premises workloads in a dedicated server room, you need a hybrid connectivity solution that extends your on-premises network to your VPC network. The two primary solutions for this are:

**A. Cloud VPN** - Cloud VPN securely extends your on-premises network to your VPC network through an IPsec VPN connection. HA VPN provides a high-availability solution with an SLA of up to 99.99%, encrypting traffic between the networks. This is ideal for organizations with moderate bandwidth requirements or those starting their cloud migration journey. The VPN tunnels traverse the internet but provide industry-standard IPsec encryption for data protection.

**C. Cloud Interconnect** - Cloud Interconnect provides dedicated, high-bandwidth connectivity between your on-premises network and Google Cloud. It offers three options: Dedicated Interconnect (10-Gbps or 100-Gbps direct connections), Partner Interconnect (connectivity through service providers), and Cross-Cloud Interconnect (connections to other cloud providers). Cloud Interconnect supports VLAN attachments with flexible capacities from 50 Mbps to 50 Gbps, making it suitable for enterprise-grade connectivity with higher bandwidth requirements.

Both solutions enable private communication between GCP and on-premises infrastructure, allowing Compute Engine instances to access workloads in the dedicated server room over private IP addresses.

### Why Other Options Are Wrong

- **B. Shared VPC** - Shared VPC is an internal GCP feature that allows resources from multiple projects within the same organization to connect to a common VPC network. It does not provide connectivity to on-premises infrastructure. Shared VPC is for resource sharing within Google Cloud, not for hybrid connectivity.

- **D. VPC peering** - VPC peering connects two separate VPC networks within Google Cloud, allowing private RFC 1918 connectivity between them. It is strictly for connecting Google Cloud VPC networks to each other, not for connecting to on-premises networks. VPC peering cannot be used to extend connectivity to external networks or data centers.

- **E. Configure all Compute Engine instances with Private Access** - Private Google Access allows VM instances without external IP addresses to reach Google APIs and services using internal IP addresses. This enables access to Google Cloud services, not to on-premises workloads. Private Access is about reaching Google services from private instances, not about establishing hybrid connectivity to external networks.

### References

- [Cloud Interconnect overview](https://docs.cloud.google.com/network-connectivity/docs/interconnect/concepts/overview)
- [Cloud VPN overview](https://docs.cloud.google.com/network-connectivity/docs/vpn/concepts/overview)
- [Choosing a Network Connectivity product](https://docs.cloud.google.com/network-connectivity/docs/how-to/choose-product)
