# Question 013

**Source:** https://www.examtopics.com/discussions/google/view/16544-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, Google Workspace, domain conflict, SAML, existing account

---

## Question

A customer's data science group wants to use Google Cloud Platform (GCP) for their analytics workloads. Company policy dictates that all data must be company-owned and all user authentications must go through their own Security Assertion Markup Language (SAML) 2.0 Identity Provider (IdP). The Infrastructure Operations Systems Engineer was trying to set up Cloud Identity for the customer and realized that their domain was already being used by G Suite. How should you best advise the Systems Engineer to proceed with the least disruption?
## Choices

- **A.** Contact Google Support and initiate the Domain Contestation Process to use the domain name in your new Cloud Identity domain.
- **B.** Register a new domain name, and use that for the new Cloud Identity domain.
- **C.** Ask Google to provision the data science manager's account as a Super Administrator in the existing domain.
- **D.** Ask customer's management to discover any other uses of Google managed services, and work with the existing Super Administrator. Most Voted

---

## Community

**Most Voted:** D


**Votes:** A: 10% | D: 90% (10 total)


**Top Comments:**

- (20 upvotes) Least amount of disruption would mean working with the existing super admin

- (12 upvotes) The answer is A "This domain is already in use" If you receive this message when trying to sign up for a Google service, it might be because: You recently removed this domain from another managed Goog

- (9 upvotes) Answer is D - there is no evidence that the account is lost, or similar. In a large corp it is very possible that someone (the IT org) has registered with google, and the Data science Department simpl

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

When a domain is already being used by Google Workspace (formerly G Suite) or Cloud Identity, you cannot create a separate Cloud Identity account with that same domain. According to Google Cloud documentation, "the sign-up process might fail if the primary DNS domain that you selected is already in use by a different Cloud Identity or Google Workspace account."

The correct approach is **Option D**: Work with the existing Google Workspace account and its Super Administrator. This provides the least disruption because:

1. **The domain cannot be duplicated**: Each domain can only be associated with one Cloud Identity or Google Workspace account
2. **Existing infrastructure can be leveraged**: The Google Workspace account already has the domain verified and can support Cloud Identity functionality
3. **SAML SSO is already available**: Google Workspace supports SAML 2.0 for SSO integration with external identity providers
4. **User management consolidation**: Working with the existing Super Administrator allows proper coordination of user lifecycle management and avoids fragmentation

The existing Google Workspace account can be configured to:
- Add SAML SSO profiles to integrate with the customer's existing SAML 2.0 IdP
- Provision users for the data science group
- Grant appropriate access to Google Cloud Platform resources
- Maintain company ownership of all data (Google Workspace and Cloud Identity both support this requirement)

### Why Other Options Are Wrong

- **A.** Domain Contestation Process is for resolving disputes when someone else has fraudulently claimed your domain. It's not appropriate when your own organization legitimately has an existing Google Workspace account. This would be disruptive and unnecessary.

- **B.** Registering a new domain would create unnecessary complexity, split identity management across multiple domains, and increase administrative overhead. This violates the "least disruption" requirement and creates an artificial separation when the existing infrastructure can meet all requirements.

- **C.** Google does not provision Super Administrator accounts directly. Super Administrators are managed within the organization's Google Workspace or Cloud Identity account by existing administrators. This option demonstrates a misunderstanding of how Google Cloud identity management works.

### References

- [Quickstart: Set up Cloud Identity as a Google Cloud administrator](https://docs.cloud.google.com/identity/docs/how-to/set-up-cloud-identity-admin)
- [Prepare your Google Workspace or Cloud Identity account](https://docs.cloud.google.com/architecture/identity/preparing-your-g-suite-or-cloud-identity-account)
- [Best practices for planning accounts and organizations](https://docs.cloud.google.com/architecture/identity/best-practices-for-planning)
