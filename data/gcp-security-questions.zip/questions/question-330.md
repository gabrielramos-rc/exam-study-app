# Question 330

**Source:** https://www.examtopics.com/discussions/google/view/305135-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Secure Web Proxy, egress proxy, monitoring, logging, external web services

---

## Question

Your organization has Google Cloud applications that require access to external web services. You must monitor, control, and log access to these services. What should you do?
## Choices

- **A.** Set up a Secure Web Proxy that allows access to the specific external web services. Configure applications to use the proxy for the web service requests. Most Voted
- **B.** Set up a Cloud NAT instance to allow egress traffic from your VPC.
- **C.** Configure VPC firewall rules to allow the services to access the IP addresses of required external web services.
- **D.** Configure Google Cloud Armor to monitor and protect your applications by checking incoming traffic patterns for attack patterns.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (4 total)


**Top Comments:**

- (2 upvotes) To monitor, control, and log outbound access to external services, use Secure Web Proxy – the only option that satisfies all three requirements (monitoring, control, and logging).

- (1 upvotes) Secure Web Proxy is a Google-managed service that lets you: • Control which external destinations are accessible (by URL or domain). • Monitor traffic patterns. • Log access requests via Cloud Logging

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Secure Web Proxy is specifically designed to monitor, control, and log access to external web services from Google Cloud applications. It provides comprehensive capabilities that directly address all three requirements:

**Monitoring and Logging**: Secure Web Proxy integrates with Cloud Audit Logs and Google Cloud Observability to record administrative activities, access requests, metrics, and transaction logs for all requests handled by the proxy. The service logs detailed information about every transaction between applications and the internet, enabling organizations to monitor internet usage, discover threats, and respond to security events.

**Control**: The proxy enforces granular egress access policies based on source (secure tags, service accounts, IP addresses), destination (URLs and hostnames), and request characteristics (methods, headers). It uses a deny-all by default approach, requiring explicit authorization for web access, and supports modular policies using lists, wildcards, or patterns.

**Application Integration**: Applications are configured to route their web service requests through the proxy, providing a centralized control point for all external web access with end-to-end TLS support through HTTP/S CONNECT.

The service also offers autoscaling proxy capacity to maintain performance during demand spikes and supports TLS inspection for encrypted traffic analysis.

### Why Other Options Are Wrong

- **B:** Cloud NAT provides egress connectivity for instances without external IP addresses but does NOT provide monitoring, control, or logging capabilities for web service access. It only enables outbound traffic and performs network address translation without application-layer visibility or policy enforcement.

- **C:** VPC firewall rules operate at the network layer (Layer 3/4) and can allow/deny traffic based on IP addresses, but they do NOT provide application-layer monitoring, detailed logging of web service requests, or granular control based on URLs, hostnames, or request characteristics. Firewall rules also don't offer visibility into the specific external web services being accessed.

- **D:** Google Cloud Armor is a Web Application Firewall (WAF) designed to protect applications from INCOMING traffic threats (DDoS attacks, OWASP Top 10 vulnerabilities). It does NOT monitor, control, or log OUTBOUND/egress traffic to external web services, as it focuses on protecting applications from external attackers rather than controlling application access to external services.

### References

- [Secure Web Proxy overview | Google Cloud Documentation](https://docs.cloud.google.com/secure-web-proxy/docs/overview)
- [Understand and view logs | Secure Web Proxy | Google Cloud Documentation](https://docs.cloud.google.com/secure-web-proxy/docs/monitor-logs)
