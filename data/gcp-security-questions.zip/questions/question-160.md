# Question 160

**Source:** https://www.examtopics.com/discussions/google/view/83929-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** encryption, Cloud EKM, CSEK, key management, external key storage

---

## Question

You are working with a client that is concerned about control of their encryption keys for sensitive data. The client does not want to store encryption keys at rest in the same cloud service provider (CSP) as the data that the keys are encrypting. Which Google Cloud encryption solutions should you recommend to this client? (Choose two.)
## Choices

- **A.** Customer-supplied encryption keys. Most Voted
- **B.** Google default encryption
- **C.** Secret Manager
- **D.** Cloud External Key Manager Most Voted
- **E.** Customer-managed encryption keys

---

## Community

**Most Voted:** AD


**Votes:** AD: 100% (13 total)


**Top Comments:**

- (6 upvotes) A. Customer-supplied encryption keys. D. Cloud External Key Manager

- (6 upvotes) what about CMEK?

- (3 upvotes) I'm leaning towards D because CSEK is so limited.

---

## Answer

**Correct:** A, D

**Confidence:** high

### Explanation

The client's requirement is clear: encryption keys must NOT be stored at rest in Google Cloud. Two solutions meet this requirement:

**A. Customer-Supplied Encryption Keys (CSEK)** - With CSEK, you provide your own AES-256 encryption keys that Google uses to protect service-generated keys. Google does NOT permanently store your CSEK keys on its servers. The keys are held temporarily in memory only during encryption/decryption operations and are deleted once operations complete. You manage and store the keys externally, and Google cannot access your data without you providing the key for each operation.

**D. Cloud External Key Manager (EKM)** - Cloud EKM enables you to use encryption keys managed in an external key management system (partners like Fortanix, Futurex, or Thales). The critical feature is that "the external key material of a Cloud EKM key is cryptographic material created and stored in your EKM. This material does not leave your EKM and it is never shared with Google." External keys are never cached or stored within Google Cloud - Cloud EKM communicates directly with the external key manager for each cryptographic operation. This provides true key separation where the keys reside completely outside Google Cloud's infrastructure.

Both solutions ensure keys are not stored at rest in the same CSP as the encrypted data, meeting the client's control and separation requirements.

### Why Other Options Are Wrong

- **B. Google default encryption** - Keys are managed and stored entirely by Google within Google Cloud infrastructure. This violates the requirement of not storing keys in the same CSP as the data.

- **C. Secret Manager** - While Secret Manager can store encryption keys and credentials, it is a Google Cloud service that stores secrets within Google Cloud infrastructure. The keys would be stored at rest in the same CSP as the data, failing the separation requirement.

- **E. Customer-managed encryption keys (CMEK)** - CMEK keys are stored in Cloud Key Management Service (Cloud KMS), which is within Google Cloud infrastructure. Although you control key rotation and access policies, the keys themselves reside at rest in Google Cloud, not meeting the external storage requirement. (Note: Cloud EKM uses CMEK architecture but adds external key material storage.)

### References

- [Cloud External Key Manager](https://docs.cloud.google.com/kms/docs/ekm)
- [Customer-Supplied Encryption Keys Overview](https://docs.cloud.google.com/docs/security/encryption/customer-supplied-encryption-keys)
- [Cloud Storage Customer-Supplied Keys](https://cloud.google.com/storage/docs/encryption/customer-supplied-keys)
- [Compute Engine CSEK](https://cloud.google.com/compute/docs/disks/customer-supplied-encryption)
