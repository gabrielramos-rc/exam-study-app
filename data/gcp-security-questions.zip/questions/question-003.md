# Question 003

**Source:** https://www.examtopics.com/discussions/google/view/16230-exam-professional-cloud-security-engineer-topic-1-question-3/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Secret Manager, secrets storage, CMEK, encryption

---

## Question

A customer needs an alternative to storing their plain text secrets in their source-code management (SCM) system. How should the customer achieve this using Google Cloud Platform?
## Choices

- **A.** Use Cloud Source Repositories, and store secrets in Cloud SQL.
- **B.** Encrypt the secrets with a Customer-Managed Encryption Key (CMEK), and store them in Cloud Storage. Most Voted
- **C.** Run the Cloud Data Loss Prevention API to scan the secrets, and store them in Cloud SQL.
- **D.** Deploy the SCM to a Compute Engine VM with local SSDs, and enable preemptible VMs.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (6 total)


**Top Comments:**

- (20 upvotes) Gosh, clearly this is a very old question. Secret Manager is the answer. No matter what choices are there.

- (6 upvotes) B but now there is secret manager

- (2 upvotes) Secrets Manager is needed in answers

---

## Answer

**Correct:** B

**Confidence:** medium

### Explanation

While **Secret Manager** is the purpose-built GCP service for storing secrets and credentials (not offered as an option here), **option B** is the best available choice among the given answers. Encrypting secrets with Customer-Managed Encryption Keys (CMEK) and storing them in Cloud Storage provides:

1. **Encryption control**: CMEK gives you full control over encryption keys stored in Cloud Key Management Service, including key lifecycle, rotation schedule, access permissions, and audit logging
2. **Separation from source code**: Moves secrets out of the SCM system into a separate storage service
3. **Access control**: Cloud Storage supports IAM policies to control who can access the encrypted secrets
4. **Encryption at rest**: All data in Cloud Storage is encrypted by default; CMEK adds an extra layer by using customer-controlled keys

**Important limitation**: Cloud Storage documentation explicitly states "do not include sensitive information in your object and bucket metadata or names" because metadata remains readable even with CMEK encryption. This makes it less ideal than Secret Manager, which is specifically designed for credential storage.

The proper GCP best practice would be to use **Secret Manager**, which provides:
- Purpose-built secret storage with versioning
- Automatic encryption (AES-256) with optional CMEK support
- Fine-grained IAM access control
- Automatic rotation capabilities
- Integration with Cloud Code and CI/CD pipelines

### Why Other Options Are Wrong

- **A:** Cloud SQL is a relational database service, not designed for secret management. Storing secrets in a database adds unnecessary complexity, requires managing database credentials separately, and doesn't provide the specialized features of a secrets management service. Cloud Source Repositories is still a SCM system, which doesn't solve the problem of removing secrets from source code.

- **C:** Cloud Data Loss Prevention (DLP) API is designed to **detect and classify** sensitive data (PII, credentials, etc.), not to **store** it securely. DLP scans data to find sensitive information and can redact or mask it, but it's not a storage solution. Additionally, Cloud SQL has the same issues as option A - it's a database, not a secrets management service.

- **D:** Deploying the SCM to a Compute Engine VM with local SSDs is actually **less secure** than cloud-native solutions. Local SSDs provide temporary storage that is lost when the instance stops, making it unsuitable for persistent secret storage. Preemptible VMs are even worse as they can be terminated at any time, risking data loss. This approach also requires manual security hardening, patch management, and provides no built-in encryption key management.

### References

- [Secret Manager overview | Google Cloud Documentation](https://docs.cloud.google.com/secret-manager/docs/overview)
- [Secret Manager best practices | Google Cloud Documentation](https://docs.cloud.google.com/secret-manager/docs/best-practices)
- [Customer-managed encryption keys | Cloud Storage | Google Cloud Documentation](https://docs.cloud.google.com/storage/docs/encryption/customer-managed-keys)
- [Enable customer-managed encryption keys for Secret Manager | Google Cloud Documentation](https://docs.cloud.google.com/secret-manager/docs/cmek)
