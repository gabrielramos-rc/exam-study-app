# Question 153

**Source:** https://www.examtopics.com/discussions/google/view/79838-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** Cloud EKM, External Key Manager, CMEK, BigQuery encryption, encryption at rest

---

## Question

You need to use Cloud External Key Manager to create an encryption key to encrypt specific BigQuery data at rest in Google Cloud. Which steps should you do first?
## Choices

- **A.** 1. Create or use an existing key with a unique uniform resource identifier (URI) in your Google Cloud project. 2. Grant your Google Cloud project access to a supported external key management partner system.
- **B.** 1. Create or use an existing key with a unique uniform resource identifier (URI) in Cloud Key Management Service (Cloud KMS). 2. In Cloud KMS, grant your Google Cloud project access to use the key.
- **C.** 1. Create or use an existing key with a unique uniform resource identifier (URI) in a supported external key management partner system. 2. In the external key management partner system, grant access for this key to use your Google Cloud project. Most Voted
- **D.** 1. Create an external key with a unique uniform resource identifier (URI) in Cloud Key Management Service (Cloud KMS). 2. In Cloud KMS, grant your Google Cloud project access to use the key.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (19 total)


**Top Comments:**

- (12 upvotes) Thank you for detailed explanation, I agree with you

- (4 upvotes) C seems to be correct option. https://cloud.google.com/kms/docs/ekm#how_it_works

- (3 upvotes) C is the answer

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Cloud External Key Manager (Cloud EKM) allows you to use encryption keys that are created and stored outside of Google Cloud in a supported external key management partner system. The documentation clearly states that "the external cryptographic material is created in your external key management partner system, not in Google Cloud" and that "externally managed keys are never cached or stored within Google Cloud."

The first steps are:
1. **Create or use an existing key in the external key management partner system** - The key with a unique URI must reside in your external key manager (such as Thales CipherTrust Manager, Fortanix SDKMS, or other supported partners), not in Google Cloud or Cloud KMS
2. **Grant access in the external system** - You must configure permissions in the external key management partner system to allow your Google Cloud project to use that key for cryptographic operations

Google Cloud then references this external key through Cloud KMS but the actual cryptographic material never leaves the external system. When BigQuery needs to encrypt or decrypt data, Cloud KMS makes requests to your external key manager to perform the cryptographic operations.

### Why Other Options Are Wrong

- **A:** Incorrect because it suggests creating the key "in your Google Cloud project" first, which contradicts the fundamental principle of EKM. The key must be created in the external partner system, not in GCP. Also, the order is wrong - you grant access in the external system, not to it.

- **B:** Incorrect because it suggests creating the key in Cloud KMS itself. This describes the process for regular Cloud KMS keys (CMEK), not Cloud EKM. With EKM, the key material resides entirely outside Google Cloud in an external key management system.

- **D:** Incorrect because you cannot create an "external key" in Cloud KMS. While you do create a Cloud EKM key resource in Cloud KMS, this is just a reference that points to the actual key material in the external system. The actual external key material must be created in the external partner system first.

### References

- [Cloud External Key Manager | Cloud Key Management Service](https://docs.cloud.google.com/kms/docs/ekm)
- [Customer-managed Cloud KMS keys | BigQuery](https://docs.cloud.google.com/bigquery/docs/customer-managed-encryption)
