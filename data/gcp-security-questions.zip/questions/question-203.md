# Question 203

**Source:** https://www.examtopics.com/discussions/google/view/117305-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** Cloud Logging, log buckets, data residency, regional storage, compliance

---

## Question

Your organization must comply with the regulation to keep instance logging data within Europe. Your workloads will be hosted in the Netherlands in region europe-west4 in a new project. You must configure Cloud Logging to keep your data in the country. What should you do?
## Choices

- **A.** Configure the organization policy constraint gcp.resourceLocations to europe-west4.
- **B.** Configure log sink to export all logs into a Cloud Storage bucket in europe-west4.
- **C.** Create a new log bucket in europe-west4, and redirect the _Default bucket to the new bucket. Most Voted
- **D.** Set the logging storage region to europe-west4 by using the gcloud CLI logging settings update.

---

## Community

**Most Voted:** C


**Votes:** C: 59% | D: 41% (27 total)


**Top Comments:**

- (7 upvotes) The question ask for a NEW bucket. not change the existing.. C is correct

- (4 upvotes) you need to create new bucket in specific region

- (4 upvotes) D. Set the logging storage region to Europe-west4 using the gcloud CLI logging settings update. Here's how this option aligns with the requirement: By setting the logging storage region to Europe-west

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The correct approach is to use `gcloud logging settings update --storage-location=europe-west4` to set the default storage region for Cloud Logging. This command configures the default storage location at the project, folder, or organization level, ensuring that when new resources are created (like the new project mentioned), their system-generated `_Required` and `_Default` log buckets will automatically inherit the specified regional storage location.

For a new project, you would run:
```
gcloud logging settings update --project=PROJECT_ID --storage-location=europe-west4
```

This approach ensures all logs in the new project are stored in the europe-west4 region to comply with the European data residency requirement. The setting applies to newly created buckets, which is perfect for a new project scenario.

### Why Other Options Are Wrong

- **A:** The organization policy constraint `gcp.resourceLocations` restricts where resources can be created but doesn't automatically configure Cloud Logging's storage location. It's a constraint, not a configuration. You would still need to explicitly set the logging storage region.

- **B:** While exporting logs to a Cloud Storage bucket in europe-west4 would store copies in Europe, it doesn't address the primary log storage. Cloud Logging would still store the original logs in the default location (which could be outside Europe). This creates a copy but doesn't solve the data residency requirement for the primary logs.

- **C:** You cannot "redirect" the `_Default` bucket to another bucket. The `_Default` bucket is automatically created by Google Cloud. While you could create a custom log bucket in europe-west4 and configure sinks to route logs there, this is more complex than necessary and doesn't change where the `_Default` bucket stores data. Option D directly sets the storage location for the `_Default` bucket itself.

### References

- [Configure default resource settings - Cloud Logging](https://docs.cloud.google.com/logging/docs/default-settings)
- [Configure and manage log buckets - Cloud Logging](https://docs.cloud.google.com/logging/docs/buckets)
