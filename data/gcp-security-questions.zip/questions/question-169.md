# Question 169

**Source:** https://www.examtopics.com/discussions/google/view/84320-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Configuring network isolation and segregation
**Tags:** Shared VPC, firewall, network admin, separation of duties, VPC

---

## Question

You need to create a VPC that enables your security team to control network resources such as firewall rules. How should you configure the network to allow for separation of duties for network resources?
## Choices

- **A.** Set up multiple VPC networks, and set up multi-NIC virtual appliances to connect the networks.
- **B.** Set up VPC Network Peering, and allow developers to peer their network with a Shared VPC.
- **C.** Set up a VPC in a project. Assign the Compute Network Admin role to the security team, and assign the Compute Admin role to the developers.
- **D.** Set up a Shared VPC where the security team manages the firewall rules, and share the network with developers via service projects. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (8 total)


**Top Comments:**

- (7 upvotes) D. Shared VPC: This feature allows centralizing network management within a host project (managed by the security team). Service projects (managed by developers) can then be linked to the Shared VPC, 

- (4 upvotes) D is the answer.

- (3 upvotes) Answer is D

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Shared VPC is specifically designed to enable separation of duties for network resources by establishing a clear division of responsibilities between network/security teams and application developers. In this architecture:

- A **host project** contains the shared VPC network where the security team manages centralized network resources including firewall rules, subnets, and routes
- **Service projects** are attached to the host project, allowing developers to create and manage their application instances while consuming the shared network
- The **Security Admin** role in the host project grants the security team permissions to create and manage firewall rules and SSL certificates
- **Service Project Admins** can deploy instances and application resources but cannot modify network-level configurations or firewall rules

This architecture implements "least privilege for network administration" - developers receive necessary operational capabilities without the ability to make network-impacting changes, while the security team maintains centralized control over critical security resources like firewall rules. The documentation explicitly states that Shared VPC "allows a clear separation of responsibilities" where network administrators manage infrastructure resources in the host project and workload teams deploy application resources in service projects.

### Why Other Options Are Wrong

- **A:** Multiple VPC networks with multi-NIC virtual appliances is an overly complex solution that creates management overhead and doesn't provide the built-in separation of duties that Shared VPC offers. This approach requires manual configuration and maintenance of virtual appliances, which is not the recommended pattern for centralized network management.

- **B:** VPC Network Peering doesn't support the required separation of duties. Peering creates a symmetric relationship between VPCs where each network owner retains administrative control over their own resources. There's no mechanism to centralize firewall rule management or prevent developers from modifying network resources in their peered VPC.

- **C:** Using a single project with different IAM roles doesn't provide proper separation of duties. The Compute Network Admin role includes permissions beyond just network management, and the Compute Admin role would allow developers to potentially modify network configurations. This approach doesn't leverage the organizational boundary that Shared VPC provides between the host project (network team) and service projects (developers).

### References

- [Shared VPC Documentation](https://docs.cloud.google.com/vpc/docs/shared-vpc)
- [Best practices and reference architectures for VPC design](https://docs.cloud.google.com/architecture/best-practices-vpc-design)
- [IAM roles for Networking-related Job Functions](https://docs.cloud.google.com/iam/docs/job-functions/networking)
