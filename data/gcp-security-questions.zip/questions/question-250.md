# Question 250

**Source:** https://www.examtopics.com/discussions/google/view/146884-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.2 - Managing encryption at rest, in transit, and in use
**Tags:** Cloud Storage, lifecycle policy, object lifecycle, storage class, cost optimization

---

## Question

You are managing data in your organization's Cloud Storage buckets and are required to retain objects. To reduce storage costs, you must automatically downgrade the storage class of objects older than 365 days to Coldline storage. What should you do?
## Choices

- **A.** Use Cloud Asset Inventory to generate a report of the configuration of all storage buckets. Examine the Lifecycle management policy settings and ensure that they are set correctly.
- **B.** Set up a CloudRun Job with Cloud Scheduler to execute a script that searches for and removes flies older than 365 days from your Cloud Storage.
- **C.** Enable the Autoclass feature to manage all aspects of bucket storage classes.
- **D.** Define a lifecycle policy JSON with an action on SetStorageClass to COLDLINE with an age condition of 365 and matchStorageClass STANDARD. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (4 total)


**Top Comments:**

- (1 upvotes) Create a lifecycle policy JSON: Specify an action (SetStorageClass) to move objects to COLDLINE storage. Include a condition (age) to apply the policy to objects older than 365 days. Use the matchStor

- (1 upvotes) D. Define a lifecycle policy JSON with an action on SetStorageClass to COLDLINE with an age condition of 365 and matchStorageClass STANDARD.

- (1 upvotes) its D i think

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Option D is the correct and most direct solution. Cloud Storage Object Lifecycle Management allows you to define lifecycle policies that automatically change the storage class of objects based on specific conditions. The correct configuration requires:

1. **Action**: `SetStorageClass` to COLDLINE - This changes the storage class of matching objects
2. **Condition**: `age: 365` - Triggers when objects are older than 365 days
3. **Condition**: `matchesStorageClass: ["STANDARD"]` - Only applies to objects currently in Standard storage

The JSON configuration would look like:
```json
{
  "lifecycle": {
    "rule": [{
      "action": {
        "type": "SetStorageClass",
        "storageClass": "COLDLINE"
      },
      "condition": {
        "age": 365,
        "matchesStorageClass": ["STANDARD"]
      }
    }]
  }
}
```

This approach is automated, requires no custom scripting, and provides precise control over the transition timing and target storage class. The lifecycle management service runs daily and automatically applies the configured rules.

### Why Other Options Are Wrong

- **A:** Cloud Asset Inventory is a discovery and inventory tool used to audit and analyze existing configurations. While it can help you verify that lifecycle policies are configured correctly, it does not configure or implement the lifecycle policies themselves. This option only provides reporting, not automation of the storage class transition.

- **B:** This approach has multiple critical flaws. First, the question asks to "retain objects" and "downgrade the storage class," but this option proposes to "remove files" (delete them), which violates the retention requirement. Second, creating a custom Cloud Run Job with Cloud Scheduler is unnecessarily complex and requires ongoing maintenance. Third, this solution would incur additional compute costs and operational overhead compared to the native lifecycle management feature.

- **C:** While Autoclass does automatically manage storage classes, it follows its own predefined transition schedule that cannot be customized. Specifically, Autoclass transitions objects to Archive storage (not Coldline) after 365 days of no access. The transition timeline is: 30 days to Nearline, 90 days to Coldline, and 365 days to Archive. Additionally, Autoclass is mutually exclusive with SetStorageClass lifecycle rules - you cannot use both on the same bucket. Since the requirement specifically calls for Coldline storage at 365 days (not Archive), Autoclass does not meet the stated requirements.

### References

- [Object Lifecycle Management - Google Cloud](https://docs.cloud.google.com/storage/docs/lifecycle)
- [Autoclass - Google Cloud](https://docs.cloud.google.com/storage/docs/autoclass)
- [Configuration Examples for Object Lifecycle Management - Google Cloud](https://cloud.google.com/storage/docs/lifecycle-configurations)
