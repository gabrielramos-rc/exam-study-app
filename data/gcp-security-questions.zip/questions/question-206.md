# Question 206

**Source:** https://www.examtopics.com/discussions/google/view/117280-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** BigQuery, row-level security, column-level access control, data access, policy tags

---

## Question

You manage a BigQuery analytical data warehouse in your organization. You want to keep data for all your customers in a common table while you also restrict query access based on rows and columns permissions. Non-query operations should not be supported. What should you do? (Choose two.)
## Choices

- **A.** Create row-level access policies to restrict the result data when you run queries with the filter expression set to TRUE.
- **B.** Configure column-level encryption by using Authenticated Encryption with Associated Data (AEAD) functions with Cloud Key Management Service (KMS) to control access to columns at query runtime.
- **C.** Create row-level access policies to restrict the result data when you run queries with the filter expression set to FALSE. Most Voted
- **D.** Configure dynamic data masking rules to control access to columns at query runtime.
- **E.** Create column-level policy tags to control access to columns at query runtime. Most Voted

---

## Community

**Most Voted:** CE


**Votes:** AE: 8% | CE: 92% (13 total)


**Top Comments:**

- (6 upvotes) Therefore, for "restrict query access based on rows and columns permissions" and "Non-query operations should not be supported," the combination of C and E makes the most sense.

- (3 upvotes) CD is correct !

- (2 upvotes) CE is ok

---

## Answer

**Correct:** A, E

**Confidence:** high

### Explanation

This question requires implementing both row-level and column-level access controls in BigQuery for query-time restrictions while preventing non-query operations. The correct combination is:

**Option A** is correct because row-level access policies use filter expressions that work like WHERE clauses. When the filter expression evaluates to **TRUE**, those matching rows become visible to the specified users. The documentation explicitly states: "Like a WHERE clause, the filter_expression matches the data that you want to be visible to the members of the grantee_list." For example, `FILTER USING (region = 'APAC')` shows rows where this condition is TRUE.

**Option E** is correct because column-level access control using policy tags restricts access at query runtime through IAM permissions. You create taxonomies with policy tags in Data Catalog, apply them to BigQuery columns, and grant users the "Data Catalog Fine-Grained Reader" role on specific tags. At query time, BigQuery checks these permissions - if users lack the required role, the query fails with an access denied error. This provides granular column-level access control without modifying the underlying data.

Both mechanisms enforce access control at **query runtime** only, which satisfies the requirement that "non-query operations should not be supported." Row-level access policies and column-level policy tags are fully compatible and can be used together on the same table.

### Why Other Options Are Wrong

- **B:** AEAD encryption with Cloud KMS provides encryption-at-rest protection, not access control at query runtime. This is a cryptographic solution that protects data storage but doesn't restrict query access based on permissions. Users with decrypt permissions can access all data regardless of row or column sensitivity.

- **C:** Filter expression set to FALSE is incorrect. When a filter expression evaluates to FALSE, those rows are HIDDEN from users, not shown. This is the opposite of how row-level access policies work - you define what data users SHOULD see (TRUE), not what they shouldn't see (FALSE).

- **D:** While dynamic data masking does control access to columns at query runtime by substituting masked values based on user roles, it's not as precise as policy tags for pure access control. More importantly, the question asks to "restrict query access" which implies denying access entirely, not just masking values. Policy tags (Option E) provide cleaner access denial compared to masking's value substitution approach.

### References

- [Introduction to BigQuery row-level security](https://docs.cloud.google.com/bigquery/docs/row-level-security-intro)
- [Use row-level security - BigQuery](https://docs.cloud.google.com/bigquery/docs/managing-row-level-security)
- [Introduction to column-level access control](https://docs.cloud.google.com/bigquery/docs/column-level-security-intro)
- [Restrict access with column-level access control](https://docs.cloud.google.com/bigquery/docs/column-level-security)
