# Question 278

**Source:** https://www.examtopics.com/discussions/google/view/147072-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** shared responsibility model, cloud security controls, business deployment, regulatory compliance

---

## Question

Your organization is preparing to build business services in Google Cloud for the first time. You must determine where to apply appropriate controls or policies. You must also identify what aspects of your cloud deployment are managed by Google. What should you do?
## Choices

- **A.** Model your deployment on the Google Enterprise foundations blueprint. Follow the blueprint exactly and rely on the blueprint to maintain the posture necessary for your business.
- **B.** Use the Risk Manager tool in the Risk Protection Program to generate a report on your cloud security posture. Obtain cyber insurance coverage.
- **C.** Subscribe to the Google Cloud release notes to keep up on product updates and when new services are available. Evaluate new services for appropriate use before enabling their API.
- **D.** Study the shared responsibilities model. Depending on your business scenario, you might need to consider your responsibilities based on the location of your business offices, your customers, and your data. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (5 total)


**Top Comments:**

- (2 upvotes) I think it's D.

- (1 upvotes) They love to bang on about this

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The shared responsibility model is the fundamental framework for understanding where to apply controls and what aspects Google manages in Google Cloud. According to Google's documentation, this model describes how security tasks are divided between Google Cloud and customers. Organizations must understand this model to determine:

- **Google's responsibilities**: Underlying network and infrastructure, physical security, default encryption, and infrastructure controls
- **Customer responsibilities**: Access policies, data security, authentication, application-level configurations, and compliance verification

The responsibility split varies by service type (IaaS, PaaS, SaaS, serverless), and customers must consider their regulatory compliance obligations, internal security standards, and customer/vendor security requirements. As Google states, "You're the expert in knowing the security and regulatory requirements for your business," which means organizations must study the shared responsibility model to understand where their specific responsibilities lie based on their business scenario, including the location of offices, customers, and data.

This approach directly answers the question's requirement to "determine where to apply appropriate controls or policies" and "identify what aspects of your cloud deployment are managed by Google."

### Why Other Options Are Wrong

- **A:** While the Enterprise foundations blueprint is a valuable reference architecture, blindly following it "exactly" and "relying on the blueprint" to maintain security posture is inappropriate. Organizations have unique business requirements, regulatory obligations, and security needs that require customized approaches rather than exact replication.

- **B:** The "Risk Manager tool in the Risk Protection Program" is not a standard Google Cloud offering for determining responsibility boundaries. While cyber insurance is a valid risk mitigation strategy, it doesn't help organizations understand where to apply controls or what Google manages versus what the customer manages.

- **C:** Subscribing to release notes is good operational practice for staying informed about new features, but it doesn't help determine the fundamental division of security responsibilities between Google and the customer. Release notes are tactical updates, not strategic guidance on responsibility boundaries.

### References

- [Shared responsibilities and shared fate on Google Cloud](https://docs.cloud.google.com/architecture/framework/security/shared-responsibility-shared-fate)
- [Shared responsibility in Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/shared-responsibility)
