# Question 150

**Source:** https://www.examtopics.com/discussions/google/view/80506-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.1 - Designing and configuring perimeter security
**Tags:** Shared VPC, load balancer, Cloud NAT, perimeter security, external access

---

## Question

Your organization's Google Cloud VMs are deployed via an instance template that configures them with a public IP address in order to host web services for external users. The VMs reside in a service project that is attached to a host (VPC) project containing one custom Shared VPC for the VMs. You have been asked to reduce the exposure of the VMs to the internet while continuing to service external users. You have already recreated the instance template without a public IP address configuration to launch the managed instance group (MIG). What should you do?
## Choices

- **A.** Deploy a Cloud NAT Gateway in the service project for the MIG.
- **B.** Deploy a Cloud NAT Gateway in the host (VPC) project for the MIG.
- **C.** Deploy an external HTTP(S) load balancer in the service project with the MIG as a backend. Most Voted
- **D.** Deploy an external HTTP(S) load balancer in the host (VPC) project with the MIG as a backend.

---

## Community

**Most Voted:** C


**Votes:** B: 6% | C: 71% | D: 23% (48 total)


**Top Comments:**

- (14 upvotes) No doubt the answer is C, this is the Two-tier web service model , below the example from google cloud documentation https://cloud.google.com/vpc/docs/shared-vpc#two-tier_web_service

- (7 upvotes) Based on the network architecture and best practices for managing resources in a Shared VPC environment. Answer is D

- (5 upvotes) NAT is for outbound while the requirement is to serve external customers who will consume web service. Hence the choice is a LB not NAT

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

The correct answer is to deploy an external HTTP(S) load balancer in the service project with the MIG as a backend. This solution addresses both requirements: reducing VM exposure to the internet while continuing to serve external users.

Since the VMs no longer have public IP addresses (as specified in the recreated instance template), they need a way to receive inbound traffic from external users. An external HTTP(S) load balancer provides this by:

1. Exposing a single public IP address (on the load balancer's frontend) instead of multiple VM public IPs
2. Keeping the backend VMs private (no public IPs) while still allowing them to serve web traffic
3. Providing additional security features like Cloud Armor for DDoS protection and WAF capabilities
4. Significantly reducing the attack surface by eliminating direct internet exposure of individual VMs

In a Shared VPC architecture, load balancer components should be deployed in the service project where the backend resources (MIG) reside. According to Google Cloud documentation, the standard deployment model has "all load balancer components and backends created in one service project." The load balancer uses IP addresses and subnets from the host project's Shared VPC network, but the load balancer resources themselves (forwarding rule, target proxy, URL map, backend service) are created in the service project.

This configuration properly separates network administration (host project manages the Shared VPC) from service development (service project manages the application and its load balancer).

### Why Other Options Are Wrong

- **A:** Cloud NAT gateways cannot be deployed in service projects when using Shared VPC. Additionally, Cloud NAT only provides outbound connectivity for VMs without public IPs, not inbound access for external users trying to reach web services.

- **B:** While Cloud NAT gateways must be created in the host project when using Shared VPC, Cloud NAT is fundamentally the wrong solution for this scenario. Cloud NAT enables private VMs to make outbound connections to the internet (for updates, API calls, etc.) but does not allow inbound traffic from external users. Since the requirement is to serve external users with web services, Cloud NAT cannot fulfill this need.

- **D:** Deploying the load balancer in the host project violates Shared VPC best practices and the separation of duties model. The host project should only contain network infrastructure (VPC, subnets, firewall rules), while service projects contain application resources including load balancers. Google Cloud documentation explicitly states that load balancer components are created in service projects, not the host project.

### References

- [Set up a global external Application Load Balancer with Shared VPC](https://docs.cloud.google.com/load-balancing/docs/https/set-up-global-ext-https-shared-vpc)
- [Shared VPC Overview](https://docs.cloud.google.com/vpc/docs/shared-vpc)
- [Cloud NAT product interactions](https://docs.cloud.google.com/nat/docs/nat-product-interactions)
