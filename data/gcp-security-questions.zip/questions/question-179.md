# Question 179

**Source:** https://www.examtopics.com/discussions/google/view/117160-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.3 - Establishing private connectivity
**Tags:** Cloud Interconnect, restricted.googleapis.com, VPC Service Controls, private connectivity, on-premises

---

## Question

You need to set up a Cloud Interconnect connection between your company’s on-premises data center and VPC host network. You want to make sure that on-premises applications can only access Google APIs over the Cloud Interconnect and not through the public internet. You are required to only use APIs that are supported by VPC Service Controls to mitigate against exfiltration risk to non-supported APIs. How should you configure the network?
## Choices

- **A.** Enable Private Google Access on the regional subnets and global dynamic routing mode.
- **B.** Create a CNAME to map *.googleapis.com to restricted.googleapis.com, and create A records for restricted.googleapis.com mapped to 199.36.153.8/30.
- **C.** Use private.googleapis.com to access Google APIs using a set of IP addresses only routable from within Google Cloud, which are advertised as routes over the connection.
- **D.** Use restricted googleapis.com to access Google APIs using a set of IP addresses only routable from within Google Cloud, which are advertised as routes over the Cloud Interconnect connection. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (5 total)


**Top Comments:**

- (4 upvotes) D, use restricted google.apis.com. https://cloud.google.com/vpc/docs/configure-private-google-access-hybrid

- (4 upvotes) D, restricted

- (1 upvotes) This is a repeated question

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

Using **restricted.googleapis.com** is the correct solution for this scenario because it specifically addresses both requirements: private access over Cloud Interconnect and VPC Service Controls integration to prevent data exfiltration.

When you configure restricted.googleapis.com for on-premises access via Cloud Interconnect:

1. **VPC Service Controls Integration**: The restricted.googleapis.com domain only allows access to Google APIs that are supported by VPC Service Controls. This directly mitigates the exfiltration risk mentioned in the question by denying access to non-supported APIs.

2. **IP Address Ranges**: The restricted VIP uses the IP range 199.36.153.4/30 (IPv4) or 2600:2d00:0002:1000::/64 (IPv6), which are only routable from within Google Cloud.

3. **Cloud Interconnect Advertisement**: Your Cloud Router advertises these restricted VIP address ranges over the Cloud Interconnect connection, ensuring on-premises applications can reach Google APIs through the private connection.

4. **DNS Configuration**: You configure DNS (using Cloud DNS or on-premises BIND) to create a CNAME mapping *.googleapis.com to restricted.googleapis.com, and A records for restricted.googleapis.com to the restricted VIP addresses.

5. **Route Configuration**: A custom static route in your VPC directs traffic to 199.36.153.4/30 to the default-internet-gateway as the next hop, while Cloud Router advertises this range to on-premises.

The documentation explicitly states: "It's recommended to use restricted.googleapis.com, which integrates with VPC Service Controls and mitigates data exfiltration risks."

### Why Other Options Are Wrong

- **A:** Private Google Access only applies to VMs within VPC subnets accessing Google APIs. It doesn't extend to on-premises applications over Cloud Interconnect, nor does it provide VPC Service Controls integration to restrict access to only supported APIs.

- **B:** The IP range is incorrect. The restricted.googleapis.com IP range is 199.36.153.4/30, not 199.36.153.8/30. While the CNAME approach is correct, using the wrong IP addresses would cause connectivity failures.

- **C:** private.googleapis.com provides access to all Google APIs and services, including those NOT supported by VPC Service Controls. This violates the requirement to "only use APIs that are supported by VPC Service Controls to mitigate against exfiltration risk to non-supported APIs." The documentation specifically warns that the private VIP can allow access to services with potential data exfiltration risks.

### References

- [Set up private connectivity to Google APIs and services | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/set-up-private-connectivity)
- [Overview of VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/overview)
- [Private Google Access with VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/private-connectivity)
