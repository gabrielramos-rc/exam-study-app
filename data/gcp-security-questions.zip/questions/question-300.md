# Question 300

**Source:** https://www.examtopics.com/discussions/google/view/148655-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC, IAP, network segmentation, least privilege, Identity-Aware Proxy

---

## Question

You work for an ecommerce company that stores sensitive customer data across multiple Google Cloud regions. The development team has built a new 3-tier application to process orders and must integrate the application into the production environment. You must design the network architecture to ensure strong security boundaries and isolation for the new application, facilitate secure remote maintenance by authorized third-party vendors, and follow the principle of least privilege. What should you do?
## Choices

- **A.** Create separate VPC networks for each tier. Use VPC peering between application tiers and other required VPCs. Provide vendors with SSH keys and root access only to the instances within the VPC for maintenance purposes.
- **B.** Create a single VPC network and create different subnets for each tier. Create a new Google project specifically for the third-party vendors and grant the network admin role to the vendors. Deploy a VPN appliance and rely on the vendors' configurations to secure third-party access.
- **C.** Create separate VPC networks for each tier. Use VPC peering between application tiers and other required VPCs. Enable Identity-Aware Proxy (IAP) for remote access to management resources, limiting access to authorized vendors. Most Voted
- **D.** Create a single VPC network and create different subnets for each tier. Create a new Google project specifically for the third-party vendors. Grant the vendors ownership of that project and the ability to modify the Shared VPC configuration.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (4 total)


**Top Comments:**

- (2 upvotes) This approach ensures that each tier of the application is isolated within its own VPC, enhancing security. VPC peering allows necessary communication between tiers while maintaining isolation. Using 

- (1 upvotes) It's C.

- (1 upvotes) C - Separate VPCs: Creating separate VPC networks for each tier provides a strong isolation boundary, reducing the risk of unauthorized access or lateral movement. VPC Peering: Using VPC peering betwe

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C is the correct answer, though it's not ideal because Google Cloud recommends using a single VPC with subnets for multi-tier applications rather than separate VPCs. However, among the given choices, Option C is the best because:

1. **Security boundaries and isolation**: While separate VPCs per tier provides strong isolation, it's more operationally complex than needed. Google recommends using a single VPC with subnets and firewall rules based on service accounts or network tags for tier isolation.

2. **IAP for vendor access**: This is the critical differentiator. IAP TCP forwarding provides secure remote access following least privilege principles by:
   - Establishing encrypted tunnels without requiring external IPs or VPN infrastructure
   - Enforcing fine-grained IAM controls (roles/iap.tunnelResourceAccessor) per-VM or per-port
   - Eliminating the need to distribute SSH keys or grant broad network access
   - Providing centralized authorization at the proxy layer before traffic reaches VMs

3. **Least privilege**: IAP allows granular access control with IAM conditions, limiting vendors to specific VMs, ports, and time windows, unlike options A, B, or D which grant excessive permissions.

The ideal answer would be "single VPC with subnets + IAP," but that option isn't provided. Option C uses IAP correctly despite the non-optimal separate VPC architecture.

### Why Other Options Are Wrong

- **A:** Violates least privilege by providing SSH keys and root access directly. This creates a security risk with long-lived credentials, no centralized access control, and excessive permissions for vendors.

- **B:** Grants network admin role (excessive privilege) to vendors and relies on vendor-managed VPN configurations (security anti-pattern). You should never delegate security configuration responsibility to third parties. Also creates a separate project unnecessarily.

- **D:** Grants project ownership and Shared VPC modification rights to vendors - a catastrophic violation of least privilege that could allow vendors to reconfigure production network architecture.

### References

- [IAP TCP Forwarding Documentation](https://docs.cloud.google.com/iap/docs/using-tcp-forwarding)
- [Identity-Aware Proxy Overview](https://docs.cloud.google.com/iap/docs/concepts-overview)
- [Best Practices for VPC Design](https://docs.cloud.google.com/architecture/best-practices-vpc-design)
