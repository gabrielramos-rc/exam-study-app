# Question 270

**Source:** https://www.examtopics.com/discussions/google/view/147064-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** Assured Workloads, Access Approval, Access Transparency, data residency, healthcare compliance, HIPAA, audit logging

---

## Question

You work for a healthcare provider that is expanding into the cloud to store and process sensitive patient data. You must ensure the chosen Google Cloud configuration meets these strict regulatory requirements:
- Data must reside within specific geographic regions.
- Certain administrative actions on patient data require explicit approval from designated compliance officers.
- Access to patient data must be auditable.

What should you do?

## Choices

- **A.** Select a standard Google Cloud region. Restrict access to patient data based on user location and job function by using Access Context Manager. Enable both Cloud Audit Logging and Access Transparency.
- **B.** Deploy an Assured Workloads environment in an approved region. Configure Access Approval for sensitive operations on patient data. Enable both Cloud Audit Logs and Access Transparency. Most Voted
- **C.** Deploy an Assured Workloads environment in multiple regions for redundancy. Utilize custom IAM roles with granular permissions. Isolate network-level data by using VPC Service Controls.
- **D.** Select multiple standard Google Cloud regions for high availability. Implement Access Control Lists (ACLs) on individual storage objects containing patient data. Enable Cloud Audit Logs.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (6 total)


**Top Comments:**

- (3 upvotes) I think it's B.

- (1 upvotes) Option B fulfils the given strict regulatory requirements below: • Data must reside within specific geographic regions. • Certain administrative actions on patient data require explicit approval from 

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B correctly addresses all three strict regulatory requirements for healthcare data:

1. **Data residency in specific geographic regions**: Assured Workloads provides regional data boundary control packages specifically designed for healthcare compliance (Healthcare and Life Sciences Controls with HIPAA/HITRUST support). These control packages restrict the geographic location where resources and patient data can be stored, ensuring data residency requirements are met.

2. **Explicit approval for administrative actions**: Access Approval enables designated compliance officers to approve or deny Google personnel access requests before they can access patient data. You can grant the Access Approval Approver role (roles/accessapproval.approver) to specific compliance officers, ensuring that sensitive operations on patient data require explicit authorization from these designated individuals.

3. **Auditable access to patient data**: The combination of Cloud Audit Logs and Access Transparency provides comprehensive auditability. Cloud Audit Logs record all actions taken on resources, while Access Transparency specifically logs actions related to Google support requests, documenting when and why Google personnel access customer data.

Assured Workloads is purpose-built for organizations with strict regulatory requirements (financial services, healthcare, government) and provides the sovereignty controls, data residency enforcement, and personnel access controls necessary for healthcare compliance.

### Why Other Options Are Wrong

- **A:** Standard Google Cloud regions do not provide the regulatory compliance controls, data residency guarantees, or personnel access restrictions that healthcare providers require. Access Context Manager controls user access based on context (location, device, IP) but doesn't address Google personnel access approval or enforce regional data boundaries for compliance. Access Transparency is only available with Assured Workloads, not standard regions.

- **C:** While Assured Workloads is correctly identified, this option misses the critical Access Approval requirement for explicit approval of administrative actions. Custom IAM roles and VPC Service Controls are useful security measures but don't fulfill the specific requirement for compliance officer approval of sensitive operations. Additionally, deploying across multiple regions may conflict with data residency requirements that often mandate data stay within a single jurisdiction.

- **D:** Standard Google Cloud regions lack the compliance control packages required for healthcare. ACLs on storage objects provide basic access control but don't address data residency requirements, don't provide mechanisms for compliance officer approval of administrative actions, and don't include Access Transparency logging. This approach doesn't meet healthcare regulatory standards like HIPAA.

### References

- [Overview of Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/overview)
- [Assured Workloads Control Packages](https://docs.cloud.google.com/assured-workloads/docs/control-packages)
- [Data Residency in Assured Workloads](https://docs.cloud.google.com/assured-workloads/docs/data-residency)
- [Overview of Access Approval](https://docs.cloud.google.com/assured-workloads/access-approval/docs/overview)
- [Access Control with IAM for Access Approval](https://docs.cloud.google.com/assured-workloads/access-approval/docs/access-control)
- [Overview of Access Transparency](https://docs.cloud.google.com/assured-workloads/access-transparency/docs/overview)
