# Question 172

**Source:** https://www.examtopics.com/discussions/google/view/79864-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** IAM, least privilege, incident response, custom IAM role, Privileged Access Manager

---

## Question

You're developing the incident response plan for your company. You need to define the access strategy that your DevOps team will use when reviewing and investigating a deployment issue in your Google Cloud environment. There are two main requirements: ✑ Least-privilege access must be enforced at all times. ✑ The DevOps team must be able to access the required resources only during the deployment issue. How should you grant access while following Google-recommended best practices?
## Choices

- **A.** Assign the Project Viewer Identity and Access Management (IAM) role to the DevOps team.
- **B.** Create a custom IAM role with limited list/view permissions, and assign it to the DevOps team. Most Voted
- **C.** Create a service account, and grant it the Project Owner IAM role. Give the Service Account User Role on this service account to the DevOps team.
- **D.** Create a service account, and grant it limited list/view permissions. Give the Service Account User Role on this service account to the DevOps team.

---

## Community

**Most Voted:** B


**Votes:** B: 54% | D: 46% (41 total)


**Top Comments:**

- (18 upvotes) You can create "Just in time" permissions with IAM conditions.

- (7 upvotes) It follows best practices and has traceability

- (3 upvotes) I go with D, While B seems to allows defining specific permissions, it adds complexity to the access control strategy and might still grant more access than necessary.

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Option B correctly implements the least privilege principle by creating a custom IAM role with only the specific list/view permissions needed for incident investigation. Custom roles allow you to grant exactly the permissions required without including unnecessary permissions that come with predefined roles.

For the temporal requirement ("only during the deployment issue"), Google recommends using Privileged Access Manager (PAM) or Just-in-Time Access to grant these custom role bindings temporarily. The question asks about the permission model (what to grant), and the correct answer is to assign a custom role with limited permissions directly to the DevOps team. The temporal aspect would be handled by PAM or IAM Conditions, which can grant time-bound access to these roles only when needed.

According to Google's temporary elevated access documentation, you should combine least privilege permanent roles with just-in-time temporary access mechanisms. Creating a custom role with limited permissions satisfies the least privilege requirement, while tools like PAM enable the temporal access pattern required for incident response.

### Why Other Options Are Wrong

- **A:** Project Viewer is a basic role that grants broad read-only access across the entire project. This violates the principle of least privilege because it includes far more permissions than needed for investigating specific deployment issues. Google recommends avoiding basic roles unless absolutely necessary.

- **C:** Granting Project Owner to a service account is extremely dangerous and violates least privilege. Project Owner includes full administrative access, including the ability to delete resources, modify IAM policies, and access all data. Using service account impersonation adds unnecessary complexity when direct user access is simpler and more appropriate.

- **D:** While this option provides limited permissions through a service account, it adds unnecessary complexity. Service account impersonation is recommended when you need to delegate specific actions to systems or when you need to separate the identity performing actions from the user initiating them. For human incident responders, Google recommends assigning permissions directly to users rather than through service account impersonation unless there's a specific architectural reason to do so.

### References

- [Temporary elevated access overview](https://docs.cloud.google.com/iam/docs/temporary-elevated-access)
- [Privileged Access Manager overview](https://docs.cloud.google.com/iam/docs/pam-overview)
- [Create and manage custom roles](https://docs.cloud.google.com/iam/docs/creating-custom-roles)
- [Operations best practices - Security foundations](https://docs.cloud.google.com/architecture/blueprints/security-foundations/operation-best-practices)
