# Question 234

**Source:** https://www.examtopics.com/discussions/google/view/126773-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** IAM roles, BigQuery, least privilege, data access logs, need to know

---

## Question

Your organization uses BigQuery to process highly sensitive, structured datasets. Following the “need to know” principle, you need to create the Identity and Access Management (IAM) design to meet the needs of these users:
- Business user: must access curated reports.
- Data engineer: must administrate the data lifecycle in the platform.
- Security operator: must review user activity on the data platform.

What should you do?

## Choices

- **A.** Configure data access log for BigQuery services, and grant Project Viewer role to security operator.
- **B.** Set row-based access control based on the "region" column, and filter the record from the United States for data engineers.
- **C.** Create curated tables in a separate dataset and assign the role roles/bigquery.dataViewer. Most Voted
- **D.** Generate a CSV data file based on the business user's needs, and send the data to their email addresses.

---

## Community

**Most Voted:** C


**Votes:** A: 29% | C: 71% (14 total)


**Top Comments:**

- (7 upvotes) The answers do not fit all the requirements. But the one that addresses is C. A is not right, as even if Data Access logs are enabled, they cannot be viewed by the Security Operator role with `viewer`

- (1 upvotes) C. Create curated tables in a separate dataset and assign the role roles/bigquery.dataViewer.

- (1 upvotes) Answer C: Data Access audit logs—except for BigQuery Data Access audit logs—are disabled by default because audit logs can be quite large.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C correctly implements the "need to know" principle by creating curated tables in a separate dataset and granting the `roles/bigquery.dataViewer` role to business users. This approach provides:

1. **Separation of concerns**: Curated tables contain only the data business users need to access, following the principle of least privilege
2. **Read-only access**: The `roles/bigquery.dataViewer` role grants permission to query and view table data without modification capabilities
3. **Granular control**: By placing curated reports in a separate dataset, you can apply IAM policies at the dataset level, restricting access to only authorized business users
4. **Best practice alignment**: This follows Google Cloud's recommended pattern for implementing need-to-know access - grant specific BigQuery roles at the dataset or table level rather than project-wide permissions

For the data engineer role, they would receive `roles/bigquery.dataEditor` or `roles/bigquery.admin` on the source datasets to manage the data lifecycle. For the security operator, they would receive `roles/logging.privateLogViewer` to review user activity through audit logs (not Project Viewer as suggested in option A).

### Why Other Options Are Wrong

- **A:** Project Viewer role (`roles/viewer`) does NOT provide access to data access logs. According to Google Cloud documentation, the Project Viewer role "lets a principal access all log data stored in the _Required and _Default log buckets, except for data access logs." To view data access logs (which are needed to review user activity), the security operator requires the `roles/logging.privateLogViewer` role specifically. Additionally, this option doesn't address the business user or data engineer requirements.

- **B:** Row-based access control filtering records by region is not relevant to the user personas described. The question states users need different functional access (curated reports, data administration, security review), not geographic data filtering. This doesn't implement proper role separation for business users, data engineers, and security operators. Also, filtering "records from the United States for data engineers" doesn't make sense as data engineers need to administrate the entire data lifecycle, not just regional subsets.

- **D:** Sending CSV files via email violates multiple security best practices: it creates uncontrolled data copies outside the managed platform, bypasses audit logging of data access, makes data lifecycle management impossible, increases data loss risk, and doesn't scale as business needs change. This approach completely abandons the controlled access framework that BigQuery IAM provides and fails to implement proper need-to-know principles.

### References

- [BigQuery IAM roles and permissions](https://docs.cloud.google.com/bigquery/docs/access-control)
- [Access control with IAM - Cloud Logging](https://docs.cloud.google.com/logging/docs/access-control)
- [BigQuery audit logs overview](https://docs.cloud.google.com/bigquery/docs/reference/auditlogs)
