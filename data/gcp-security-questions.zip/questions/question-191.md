# Question 191

**Source:** https://www.examtopics.com/discussions/google/view/117092-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** BeyondCorp Enterprise, access policy, device certificate, access binding, Context-Aware Access

---

## Question

Employees at your company use their personal computers to access your organization's Google Cloud console. You need to ensure that users can only access the Google Cloud console from their corporate-issued devices and verify that they have a valid enterprise certificate. What should you do?
## Choices

- **A.** Implement an Access Policy in BeyondCorp Enterprise to verify the device certificate. Create an access binding with the access policy just created. Most Voted
- **B.** Implement a VPC firewall policy. Activate packet inspection and create an allow rule to validate and verify the device certificate.
- **C.** Implement an organization policy to verify the certificate from the access context.
- **D.** Implement an Identity and Access Management (IAM) conditional policy to verify the device certificate.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (6 total)


**Top Comments:**

- (3 upvotes) Only option A speaks about device here remaining all false

- (2 upvotes) must be A

- (2 upvotes) A https://cloud.google.com/beyondcorp?hl=pt-br

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

BeyondCorp Enterprise (now part of Chrome Enterprise Premium) is specifically designed to enforce Context-Aware Access controls based on device trust, including enterprise certificate verification. The correct implementation requires two components:

1. **Access Policy with Certificate Verification**: Create an access level in BeyondCorp Enterprise using advanced mode with the expression `certificateBindingState(origin, device) == CertificateBindingState.CERT_MATCHES_EXISTING_DEVICE`. This verifies that the device presents a valid X.509 certificate matching an existing registered device.

2. **Access Binding**: After creating the access policy, you must apply it using an access binding to specific user groups or resources (like Google Cloud console access) for the policy to be enforced.

This solution leverages Endpoint Verification (deployed as a Chrome extension with helper app) to collect device certificate information and enforce that only corporate-issued devices with valid enterprise certificates can access the Google Cloud console, regardless of the user's credentials.

### Why Other Options Are Wrong

- **B:** VPC firewall policies operate at the network layer (L3/L4) and control traffic to/from VPC resources based on IP addresses, protocols, and ports. They cannot inspect TLS/SSL certificates or enforce device-based authentication for console access. Packet inspection in VPC firewalls doesn't extend to validating client device certificates for application-level access control.

- **C:** Organization policies are administrative controls that restrict how resources can be configured within your GCP organization (e.g., restricting VM external IPs, enforcing domain restrictions). They do not provide runtime access control or device certificate verification. Access Context Manager is used for access policies, not organization policies.

- **D:** IAM conditional policies can enforce conditions based on attributes like time, IP address, or resource tags, but they cannot directly verify device certificates. IAM conditions lack the ability to integrate with endpoint verification systems or validate client-side X.509 certificates. Certificate verification requires the specialized capabilities of BeyondCorp Enterprise/Access Context Manager.

### References

- [Define access policies using access levels - Chrome Enterprise Premium](https://docs.cloud.google.com/chrome-enterprise-premium/docs/define-access-policies)
- [Chrome Enterprise Premium access protection overview](https://docs.cloud.google.com/chrome-enterprise-premium/docs/access-protection)
- [Access Context Manager Overview](https://docs.cloud.google.com/access-context-manager/docs/overview)
