# Question 017

**Source:** https://www.examtopics.com/discussions/google/view/17819-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, de-identification, pseudonymization, format-preserving encryption, CryptoReplaceFfxFpeConfig

---

## Question

An employer wants to track how bonus compensations have changed over time to identify employee outliers and correct earning disparities. This task must be performed without exposing the sensitive compensation data for any individual and must be reversible to identify the outlier. Which Cloud Data Loss Prevention API technique should you use to accomplish this?
## Choices

- **A.** Generalization
- **B.** Redaction
- **C.** CryptoHashConfig
- **D.** CryptoReplaceFfxFpeConfig Most Voted

---

## Community

**Most Voted:** D


**Votes:** A: 19% | C: 6% | D: 75% (16 total)


**Top Comments:**

- (17 upvotes) Also the same usecase in the url that you post. D is right.

- (7 upvotes) it is reversible for D

- (6 upvotes) Completely wrong The answer is D for sure. The example was even in google docs but replaced for some reasons. http://price2meet.com/gcp/docs/dlp_docs_pseudonymization.pdf

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

CryptoReplaceFfxFpeConfig is the correct technique because it satisfies all three requirements specified in the question:

1. **Track changes over time**: CryptoReplaceFfxFpeConfig uses format-preserving encryption (FPE) with FFX mode, which is deterministic - it generates identical tokens for each instance of an identical input value. This means the same compensation amount will always produce the same encrypted token, allowing you to track how an individual's compensation changes over time while maintaining referential integrity across datasets.

2. **Does not expose sensitive data**: The encryption replaces the original compensation values with cryptographically secure tokens that protect the actual amounts from unauthorized access.

3. **Reversible to identify outliers**: This is the critical requirement that eliminates other options. CryptoReplaceFfxFpeConfig is reversible when used with the ReidentifyContent API method - you can decrypt the token back to the original value using the same cryptographic key. This enables you to identify which specific employee is the outlier once the analysis is complete.

The technique preserves both the format and length of the original data, making it suitable for numerical compensation data that needs to be analyzed statistically while maintaining privacy.

### Why Other Options Are Wrong

- **A (Generalization):** While generalization can protect sensitive data by replacing it with ranges (e.g., salary bands like "$50K-$75K"), it is not reversible. You cannot determine the exact original compensation value from a generalized range, making it impossible to identify the specific individual outlier. Additionally, generalization loses precision needed for accurate temporal tracking.

- **B (Redaction):** Redaction simply deletes or removes all or part of the sensitive value, making it completely non-reversible. Once data is redacted, the original values are permanently lost and cannot be recovered to identify outliers. This technique is unsuitable for any analysis that requires tracking changes or recovering original values.

- **C (CryptoHashConfig):** While cryptographic hashing with HMAC-SHA-256 produces deterministic outputs (same input always produces the same hash), it is explicitly non-reversible. As stated in the documentation: "this transformation can't be reversed. That is, given the hashed output value of the transformation and the original cryptographic key, there is no way to restore the original value." This makes it impossible to identify the actual outlier employee, failing the reversibility requirement.

### References

- [Pseudonymization | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/pseudonymization)
- [De-identification Transformations Reference | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/transformations-reference)
- [Format-preserving encryption (FPE) | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/samples/dlp-deidentify-fpe)
