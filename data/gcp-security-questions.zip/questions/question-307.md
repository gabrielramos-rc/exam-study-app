# Question 307

**Source:** https://www.examtopics.com/discussions/google/view/148662-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.3 - Securing AI workloads
**Tags:** AI security, ML security, Cloud DLP, Sensitive Data Protection, de-identification, BigQuery, IAM, model training, PII

---

## Question

Your organization is developing a sophisticated machine learning (ML) model to predict customer behavior for targeted marketing campaigns. The BigQuery dataset used for training includes sensitive personal information. You must design the security controls around the AI/ML pipeline. Data privacy must be maintained throughout the model’s lifecycle and you must ensure that personal data is not used in the training process. Additionally, you must restrict access to the dataset to an authorized subset of people only. What should you do?
## Choices

- **A.** De-identify sensitive data before model training by using Cloud Data Loss Prevention (DLP)APIs. and implement strict Identity and Access Management (IAM) policies to control access to BigQuery. Most Voted
- **B.** Implement Identity-Aware Proxy to enforce context-aware access to BigQuery and models based on user identity and device.
- **C.** Implement at-rest encryption by using customer-managed encryption keys (CMEK) for the pipeline. Implement strict Identity and Access Management (IAM) policies to control access to BigQuery.
- **D.** Deploy the model on Confidential VMs for enhanced protection of data and code while in use. Implement strict Identity and Access Management (IAM) policies to control access to BigQuery.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (4 total)


**Top Comments:**

- (2 upvotes) It's A Well explained below.

- (1 upvotes) Ans is A We want data privacy through out lifecycle. C is at rest D is in use B says nothing about data privacy

- (1 upvotes) A - Data De-identification: De-identifying sensitive data using Cloud DLP APIs ensures that the data used for model training does not contain personally identifiable information (PII). This protects d

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A correctly addresses both critical requirements for securing the ML pipeline with sensitive personal data:

**De-identification with Cloud DLP/Sensitive Data Protection**: The question explicitly states "you must ensure that personal data is not used in the training process." Cloud DLP (now Sensitive Data Protection) provides comprehensive de-identification techniques specifically designed for this use case:
- **Masking**: Partially or fully replacing characters with symbols while preserving data structure
- **Tokenization**: Replacing sensitive values with surrogate values using Format-Preserving Encryption (FPE) or cryptographic hashing
- **Redaction**: Complete removal of sensitive information
- **Bucketing/Generalization**: Grouping numerical values into ranges to reduce precision while maintaining analytical utility
- **Date Shifting**: Pseudorandomly shifting dates while preserving temporal relationships

Cloud DLP integrates directly with BigQuery through multiple methods:
- De-identify data at query time using BigQuery remote functions
- Use Dataflow templates for data masking/tokenization pipelines from Cloud Storage to BigQuery
- Apply transformations before extracting training datasets

**IAM Policies for Access Control**: The requirement to "restrict access to the dataset to an authorized subset of people only" is met through strict IAM policies on BigQuery datasets and tables. This provides role-based access control (RBAC) to ensure only authorized personnel can access the raw sensitive data.

Together, these controls ensure that:
1. Sensitive PII is de-identified before being used in model training (data privacy maintained)
2. The original sensitive dataset is protected through access controls
3. The ML pipeline uses privacy-preserving data throughout the model lifecycle

### Why Other Options Are Wrong

- **B:** Identity-Aware Proxy (IAP) provides context-aware access control for applications and VMs, but it doesn't address the core requirement of de-identifying personal data before model training. IAP controls access but does nothing to prevent sensitive PII from being used in the training process itself. The question explicitly requires that "personal data is not used in the training process," which IAP alone cannot achieve.

- **C:** CMEK (Customer-Managed Encryption Keys) provides encryption-at-rest for data stored in BigQuery, protecting data from unauthorized access at the storage layer. However, encryption doesn't prevent personal data from being used in model training—when the data is decrypted for use (which happens automatically during queries and processing), the sensitive PII is still present and would be fed into the ML model. CMEK addresses data security during storage but not data privacy during use.

- **D:** Confidential VMs provide runtime memory encryption (encryption-in-use) to protect data and code while actively being processed. While this is valuable for protecting the model and data during training from infrastructure-level attacks, it doesn't de-identify the personal data. The sensitive PII would still be used in its original form during training, just in an encrypted memory environment. This fails to meet the requirement that "personal data is not used in the training process."

### References

- [De-identifying sensitive data - Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/deidentify-sensitive-data)
- [Using Sensitive Data Protection with BigQuery](https://docs.cloud.google.com/sensitive-data-protection/docs/dlp-bigquery)
- [De-identify BigQuery data at query time](https://docs.cloud.google.com/sensitive-data-protection/docs/deidentify-bq-tutorial)
- [Data Masking/Tokenization from Cloud Storage to BigQuery template](https://docs.cloud.google.com/dataflow/docs/guides/templates/provided/dlp-text-to-bigquery)
