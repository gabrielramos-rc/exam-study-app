# Question 105

**Source:** https://www.examtopics.com/discussions/google/view/75742-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Cloud Identity, SAML SSO, gcloud authentication, Workforce Identity Federation

---

## Question

You want to use the gcloud command-line tool to authenticate using a third-party single sign-on (SSO) SAML identity provider. Which options are necessary to ensure that authentication is supported by the third-party identity provider (IdP)? (Choose two.)
## Choices

- **A.** SSO SAML as a third-party IdP Most Voted
- **B.** Identity Platform
- **C.** OpenID Connect
- **D.** Identity-Aware Proxy
- **E.** Cloud Identity Most Voted

---

## Community

**Most Voted:** AE


**Votes:** AC: 41% | AE: 56% | CE: 3% (75 total)


**Top Comments:**

- (23 upvotes) A, E is right

- (16 upvotes) A. SSO SAML as a third-party IdP This option confirms that you are using SSO with SAML for authentication via the third-party identity provider, which is essential for enabling SSO capabilities throug

- (5 upvotes) I think the correct answer is A and C. The questions asks about what is required with third-party IdP to authenticate the gcloud commands. So the gcloud command requests goes to GCP. Since GCP is inte

---

## Answer

**Correct:** A, E

**Confidence:** high

### Explanation

To authenticate with gcloud CLI using a third-party SAML SSO identity provider, two components are necessary:

**A. SSO SAML as a third-party IdP** - This is the fundamental requirement. The external identity provider must support SAML 2.0 protocol to enable single sign-on. Google Cloud implements SAML 2.0 HTTP POST binding as the authentication protocol. The third-party IdP (such as Okta, Azure AD, or AD FS) must be SAML 2.0-compliant and configured to exchange authentication assertions with Google Cloud.

**E. Cloud Identity** - This is required to manage user accounts that are federated with the external IdP. As stated in the documentation: "To use SSO, a user must have a user account in Cloud Identity or Google Workspace and a corresponding identity in the external IdP." Cloud Identity (or Google Workspace) serves as the service provider in the SAML relationship, while your organization's IdP is the SAML identity provider. Cloud Identity supports SAML profiles for each IdP you want to integrate.

Together, these components enable the authentication flow: when a user runs `gcloud auth login`, they are redirected to the external SAML IdP for authentication, which then returns a SAML assertion to Google Cloud (via Cloud Identity), establishing a session with temporary access tokens.

### Why Other Options Are Wrong

- **B. Identity Platform:** While Identity Platform does support SAML authentication for web and mobile applications, it is not required for gcloud CLI authentication with third-party SSO. Identity Platform is designed for customer identity and access management (CIAM) scenarios, not for organizational user authentication via gcloud.

- **C. OpenID Connect:** This is an alternative federation protocol, not a requirement for SAML authentication. While Workforce Identity Federation supports both SAML 2.0 and OIDC, the question specifically asks about SAML SSO authentication. OIDC and SAML are different protocols that serve similar purposes but are not used together.

- **D. Identity-Aware Proxy:** IAP is a perimeter security service for controlling access to applications and VMs via identity and context. It is not involved in gcloud CLI authentication with SAML providers. IAP is used for application-level access control, not for CLI authentication.

### References

- [Single sign-on | Cloud Architecture Center](https://docs.cloud.google.com/architecture/identity/single-sign-on)
- [Authorize the gcloud CLI](https://docs.cloud.google.com/sdk/docs/authorizing)
- [Configure Workforce Identity Federation with Microsoft Entra ID](https://docs.cloud.google.com/iam/docs/workforce-sign-in-microsoft-entra-id)
