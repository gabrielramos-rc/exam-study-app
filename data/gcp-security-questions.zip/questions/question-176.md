# Question 176

**Source:** https://www.examtopics.com/discussions/google/view/80453-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, Cloud Storage, public access prevention, security policy, bucket security

---

## Question

You need to enforce a security policy in your Google Cloud organization that prevents users from exposing objects in their buckets externally. There are currently no buckets in your organization. Which solution should you implement proactively to achieve this goal with the least operational overhead?
## Choices

- **A.** Create an hourly cron job to run a Cloud Function that finds public buckets and makes them private.
- **B.** Enable the constraints/storage.publicAccessPrevention constraint at the organization level. Most Voted
- **C.** Enable the constraints/storage.uniformBucketLevelAccess constraint at the organization level.
- **D.** Create a VPC Service Controls perimeter that protects the storage.googleapis.com service in your projects that contains buckets. Add any new project that contains a bucket to the perimeter.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (14 total)


**Top Comments:**

- (4 upvotes) Exam Question Dec 2022

- (4 upvotes) B. https://cloud.google.com/storage/docs/org-policy-constraints "When you apply the publicAccessPrevention constraint on a resource, public access is restricted for all buckets and objects, both new a

- (3 upvotes) B is right

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

The **constraints/storage.publicAccessPrevention** organization policy constraint is specifically designed to prevent public access to Cloud Storage buckets and objects. When enforced at the organization level, it:

- **Proactively blocks public access**: Prevents anyone from granting access to `allUsers` or `allAuthenticatedUsers` through IAM policies or ACLs
- **Applies hierarchically**: Automatically applies to all existing and future buckets across all projects, folders, and resources in the organization
- **Requires zero operational overhead**: Once enabled, it's enforced automatically without any manual intervention or monitoring
- **Fails requests immediately**: Any attempt to make data public fails with HTTP 401 or 403 status codes

This is a preventative control that enforces the policy before any public access can be granted, making it the ideal solution for proactively securing the organization. Since there are currently no buckets, enabling this constraint now ensures that all future buckets will be protected from the moment they are created.

### Why Other Options Are Wrong

- **A:** Creating an hourly cron job is a reactive (detective) control, not a proactive (preventative) one. It requires ongoing operational overhead to maintain the Cloud Function, and there's a gap of up to one hour where buckets could remain public. This violates the requirement for "least operational overhead" and doesn't prevent the issue—it only remediates it after the fact.

- **C:** The `constraints/storage.uniformBucketLevelAccess` constraint enforces that new buckets use IAM-only access control (disabling ACLs), but it doesn't prevent buckets from being made public. Even with uniform bucket-level access enabled, you can still grant `allUsers` permissions through IAM policies, making buckets publicly accessible. This constraint is about access control methodology, not public access prevention.

- **D:** VPC Service Controls creates a security perimeter that protects against data exfiltration and unauthorized access from outside the perimeter, but it doesn't prevent buckets from being made publicly accessible to the internet. Additionally, this solution has high operational overhead because you must manually add each new project containing a bucket to the perimeter, and it doesn't specifically address the requirement to prevent public bucket exposure.

### References

- [Public access prevention | Cloud Storage](https://docs.cloud.google.com/storage/docs/public-access-prevention)
- [Organization policy constraints for Cloud Storage](https://docs.cloud.google.com/storage/docs/org-policy-constraints)
- [Use public access prevention](https://docs.cloud.google.com/storage/docs/using-public-access-prevention)
- [Uniform bucket-level access](https://docs.cloud.google.com/storage/docs/uniform-bucket-level-access)
