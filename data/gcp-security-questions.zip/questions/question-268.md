# Question 268

**Source:** https://www.examtopics.com/discussions/google/view/147062-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.4 - Managing and implementing authorization controls
**Tags:** IAM, authorization, BigQuery, Cloud Storage, granular access control

---

## Question

Your organization has sensitive data stored in BigQuery and Cloud Storage. You need to design a solution that provides granular and flexible control authorization to read data. What should you do?
## Choices

- **A.** Deidentify sensitive fields within the dataset by using data leakage protection within the Sensitive Data Protection services.
- **B.** Use Cloud External Key Manager (Cloud EKM) to encrypt the data in BigQuery and Cloud Storage.
- **C.** Grant identity and access management (IAM) roles and permissions to principals. Most Voted
- **D.** Enable server-side encryption on the data in BigQuery and Cloud Storage.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (3 total)


**Top Comments:**

- (1 upvotes) Why Option C: Granular Control: IAM roles and permissions allow you to specify exactly who can access which resources, down to the level of individual datasets or tables. Flexibility: You can create c

- (1 upvotes) I think it's C.

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

IAM (Identity and Access Management) is the primary and most appropriate mechanism for providing granular and flexible control authorization to read data in BigQuery and Cloud Storage. According to Google Cloud documentation, "IAM lets you grant granular access to specific BigQuery resources and helps prevent access to other resources."

IAM provides multiple levels of granularity:
- **Organization/folder/project level**: Broad access across all resources
- **Dataset level**: Specific dataset access in BigQuery without granting access to other project resources
- **Individual resource level**: Tables, views, routines, or specific Cloud Storage buckets/objects
- **Column-level security**: Control access to specific columns within BigQuery tables
- **Row-level security**: Dynamic filtering of rows based on user context

IAM roles can be predefined (managed by Google Cloud for common use cases) or custom (user-specified permissions), providing the flexibility required. The documentation emphasizes that "permissions are not assigned directly to users, groups, or service accounts. Instead, users, groups, or service accounts are granted one or more predefined or custom roles that grant them permissions to perform actions on resources."

This aligns with the principle of least privilege, ensuring principals receive only the necessary access to read data.

### Why Other Options Are Wrong

- **A:** Sensitive Data Protection (formerly DLP) is designed for data discovery, classification, and de-identification of sensitive data. While it can redact or mask sensitive fields, it does not provide authorization controls for who can read the data. It's a data protection technique, not an access control mechanism.

- **B:** Cloud External Key Manager (Cloud EKM) is an encryption key management solution that allows you to use encryption keys stored in external key management systems. While encryption is important for data protection, it does not provide granular authorization controls for read access. Encryption controls who can decrypt data with keys, but IAM controls who can access resources in the first place.

- **D:** Server-side encryption is enabled by default on all data in BigQuery and Cloud Storage using Google-managed encryption keys. While this protects data at rest, it does not provide any authorization or access control capabilities. Encryption and authorization are separate security controls that serve different purposes.

### References

- [Introduction to security and access controls in BigQuery](https://docs.cloud.google.com/bigquery/docs/access-control-intro)
- [Control access to resources with IAM - BigQuery](https://docs.cloud.google.com/bigquery/docs/control-access-to-resources-iam)
- [Overview of access control - Cloud Storage](https://docs.cloud.google.com/storage/docs/access-control)
