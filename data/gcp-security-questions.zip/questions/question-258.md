# Question 258

**Source:** https://www.examtopics.com/discussions/google/view/147052-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 2.2 - Configuring boundary segmentation
**Tags:** VPC Service Controls, Access Context Manager, access level, service perimeter, IP subnetworks

---

## Question

Your organization is adopting Google Cloud and wants to ensure sensitive resources are only accessible from devices within the internal on-premises corporate network. You must configure Access Context Manager to enforce this requirement. These considerations apply:
- The internal network uses IP ranges 10.100.0.0/16 and 192.168.0.0/16.
- Some employees work remotely but connect securely through a company-managed virtual private network (VPN). The VPN dynamically allocates IP addresses from the pool 172.16.0.0/20.
- Access should be restricted to a specific Google Cloud project that is contained within an existing service perimeter.

What should you do?

## Choices

- **A.** Create an access level named "Authorized Devices." Utilize the Device Policy attribute to require corporate-managed devices. Apply the access level to the Google Cloud project and instruct all employees to enroll their devices in the organization's management system.
- **B.** Create an access level titled "Internal Network Only." Add a condition with these attributes: • IP Subnetworks: 10.100.0.0/16, 192.168.0.0/16 • Device Policy: Require OS as Windows or macOS. Apply this access level to the sensitive Google Cloud project.
- **C.** Create an access level titled "Corporate Access." Add a condition with the IP Subnetworks attribute, including the ranges: 10.100.0.0/16, 192.168.0.0/16, 172.16.0.0/20. Assign this access level to a service perimeter encompassing the sensitive project. Most Voted
- **D.** Create a new IAM role called "InternalAccess. Add the IP ranges 10.100.0.0/16, 192.16.0.0/16, and 172.16.0.0/20 to the role as an IAM condition. Assign this role to IAM groups corresponding to on-premises and VPN users. Grant this role the necessary permissions on the resource within this sensitive Google Cloud project.

---

## Community

**Most Voted:** C


**Votes:** C: 100% (6 total)


**Top Comments:**

- (2 upvotes) The recommended approach is to configure Access Context Manager to create access levels incorporating the specified IP ranges (10.100.0.0/16, 192.168.0.0/16, and 172.16.0.0/20) and apply this access l

- (2 upvotes) I think it's C.

- (1 upvotes) https://cloud.google.com/access-context-manager/docs/overview#ip-address

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Option C correctly implements Access Context Manager with VPC Service Controls to restrict access based on IP addresses. The solution creates an access level with all three required IP ranges (on-premises networks 10.100.0.0/16 and 192.168.0.0/16, plus VPN pool 172.16.0.0/20) and assigns it to the service perimeter that already contains the sensitive project.

Access Context Manager access levels define conditions that requests must meet, including IP subnetworks in CIDR format. When an access level is assigned to a VPC Service Controls service perimeter, it controls access to protected resources from outside the perimeter. As the documentation states: "Access levels only allow requests from outside a perimeter for the resources of a protected service inside a perimeter."

The IP Subnetworks attribute accepts public IP addresses formatted as CIDR blocks. In this scenario, requests originating from any of the three specified IP ranges will satisfy the access level condition, allowing users from both on-premises locations and the VPN to access the protected resources. Multiple IP ranges can be specified in a single access level, and you can include up to 200 CIDR ranges per access level attribute.

### Why Other Options Are Wrong

- **A:** While device policy enforcement is valid in Access Context Manager, this option ignores the specific requirement to restrict access based on the internal network IP ranges. It focuses solely on device management without implementing the IP-based restrictions specified in the requirements. Additionally, requiring all employees to enroll devices is operationally complex and doesn't address the immediate need to restrict by network location.

- **B:** This option makes two critical errors. First, it's missing the VPN IP range (172.16.0.0/20), which means remote employees connecting via VPN would be blocked. Second, adding an OS requirement (Windows or macOS) is not specified in the requirements and creates unnecessary restrictions that could block legitimate access from other corporate-approved operating systems. Also, it incorrectly states applying the access level "to the sensitive Google Cloud project" rather than to the service perimeter.

- **D:** This fundamentally misunderstands the architecture. IAM roles and IAM conditions cannot restrict access based on source IP addresses to resources within a VPC Service Controls perimeter. IP-based restrictions for VPC Service Controls must be implemented through Access Context Manager access levels, not through IAM policies. Additionally, there's a typo in one of the IP ranges (192.16.0.0/16 instead of 192.168.0.0/16). IAM conditions support some context attributes, but source IP restrictions for perimeter security require Access Context Manager.

### References

- [Creating a basic access level | Access Context Manager](https://docs.cloud.google.com/access-context-manager/docs/create-basic-access-level)
- [Allow access to protected resources from outside a perimeter | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/use-access-levels)
- [Manage service perimeters | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/manage-service-perimeters)
- [Design access levels | VPC Service Controls](https://docs.cloud.google.com/vpc-service-controls/docs/access-level-design)
