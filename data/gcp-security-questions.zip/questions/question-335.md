# Question 335

**Source:** https://www.examtopics.com/discussions/google/view/311198-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, organization restrictions, access control, Cloud Storage

---

## Question

You are responsible for configuring Identity and Access Management in your organization's Google Cloud environment. You need to restrict your organization's users from accessing Cloud Storage buckets in other Google Cloud organizations. What should you do?
## Choices

- **A.** Set a principal access boundary policy with the appropriate enforcement version. Bind the policy to the principals of your organization. Most Voted
- **B.** Configure organization restriction headers for your environment. Only include the organization ID of your organization in the list of allowed resources.
- **C.** Create an IAM deny policy on the organization level that prevents access to Cloud Storage buckets outside the organization.
- **D.** Enforce domain restricted sharing in your organization. Configure a managed constraint, and only include the principals in your organization.

---

## Community

**Most Voted:** A


**Votes:** A: 57% | B: 14% | C: 14% | D: 14% (7 total)


**Top Comments:**

- (2 upvotes) The egress proxy inspects all outbound traffic to Google Cloud API's and injects a custom HTTP header, X-Goog-Allowed-Resources, into the request.

- (1 upvotes) If a user in your organization tries to access a Cloud Storage bucket in an external organization (even if that external organization has granted them IAM roles), the PAB policy will block the access 

- (1 upvotes) An IAM deny policy is the most precise and effective tool for this task. Unlike "allow" policies, which grant permissions, deny policies explicitly prevent a principal from performing a specific actio

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

Organization restrictions headers are specifically designed to prevent users from accessing resources in other Google Cloud organizations, making option B the correct solution. This security feature works by configuring egress proxies to add the `X-Goog-Allowed-Resources` header to requests from managed devices. The header contains a base64-encoded JSON structure with a list of authorized organization IDs in the "resources" field.

When configured correctly, Google Cloud inspects all incoming requests for this header and allows access only if the target resource belongs to an organization ID listed in the allowed resources. This creates an organizational boundary layer that prevents data exfiltration through phishing or insider attacks by ensuring users can only access Cloud Storage buckets (and other resources) within authorized organizations.

The implementation involves:
1. Creating a JSON structure with your organization ID in the resources array
2. Encoding it using web-safe base64 encoding (RFC 4648 Section 5)
3. Configuring the egress proxy to insert the header into requests targeting Google Cloud domains
4. Using "strict" mode to enforce restrictions for all Google Cloud services, or "cloudStorageReadAllowed" if read access to public buckets is needed

### Why Other Options Are Wrong

- **A.** Principal access boundary policies are used to limit the maximum permissions that a principal can be granted within IAM, not to restrict access to resources outside your organization. They don't prevent users from accessing external organization resources.

- **C.** IAM deny policies operate on resources within your own organization and cannot deny access to resources in other organizations. You cannot create a deny policy that applies to Cloud Storage buckets you don't control in other organizations.

- **D.** Domain restricted sharing (enforced via the `iam.allowedPolicyMemberDomains` organization policy constraint) restricts who can be granted IAM roles on your own organization's resources. It prevents sharing your resources with external domains, but it doesn't prevent your users from accessing resources in other organizations if those resources have granted them access.

### References

- [Introduction to organization restrictions](https://docs.cloud.google.com/resource-manager/docs/organization-restrictions/overview)
- [Configure organization restrictions](https://docs.cloud.google.com/resource-manager/docs/organization-restrictions/configure-organization-restrictions)
