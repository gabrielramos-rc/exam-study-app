# Question 024

**Source:** https://www.examtopics.com/discussions/google/view/29020-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.2 - Managing service accounts
**Tags:** service account, service account key, key rotation, key management

---

## Question

A company's application is deployed with a user-managed Service Account key. You want to use Google-recommended practices to rotate the key. What should you do?
## Choices

- **A.** Open Cloud Shell and run gcloud iam service-accounts enable-auto-rotate --iam-account=IAM_ACCOUNT.
- **B.** Open Cloud Shell and run gcloud iam service-accounts keys rotate --iam-account=IAM_ACCOUNT --key=NEW_KEY.
- **C.** Create a new key, and use the new key in the application. Delete the old key from the Service Account. Most Voted
- **D.** Create a new key, and use the new key in the application. Store the old key on the system as a backup key.

---

## Community

**Most Voted:** C


**Votes:** C: 57% | D: 43% (7 total)


**Top Comments:**

- (11 upvotes) B is correct. for C creating a new key and deleting the old one from the Service Account, is not recommended. Deleting the old key without replacing it could prevent your application from authenticati

- (4 upvotes) Correct Answer: C

- (3 upvotes) C it is the ans

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Google-recommended practices for rotating user-managed service account keys follow a manual five-step process: (1) identify keys needing rotation, (2) create new keys for the same service accounts, (3) replace the existing keys with the new keys across all applications, (4) disable the replaced keys and monitor the applications to confirm they work as expected, and (5) delete the service account keys that were replaced.

Option C correctly implements this best practice by creating a new key, deploying it to the application, and then deleting the old key. This is the manual rotation process recommended by Google Cloud documentation, which emphasizes rotating keys at least every 90 days to reduce the risk posed by leaked keys. The documentation explicitly states that Google Cloud does not provide automatic rotation commands for user-managed service account keys.

### Why Other Options Are Wrong

- **A.** The command `gcloud iam service-accounts enable-auto-rotate` does not exist. Google Cloud does not provide automatic rotation for user-managed service account keys. Automatic rotation is only available for customer-managed encryption keys (CMEK) in Cloud KMS, not for service account keys.

- **B.** The command `gcloud iam service-accounts keys rotate` does not exist. There is no built-in gcloud command to automatically rotate service account keys. The rotation process must be performed manually by creating new keys and replacing old ones.

- **D.** Storing the old key as a backup violates security best practices. Google recommends deleting old keys after confirming the new keys work properly. Keeping old keys increases the number of valid credentials in circulation, which expands the attack surface and increases risk if keys are leaked or stolen. The documentation emphasizes minimizing the number of valid service account keys in circulation.

### References

- [Service account key rotation | IAM Documentation](https://docs.cloud.google.com/iam/docs/key-rotation)
- [Best practices for managing service account keys | IAM Documentation](https://docs.cloud.google.com/iam/docs/best-practices-for-managing-service-account-keys)
