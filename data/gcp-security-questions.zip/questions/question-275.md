# Question 275

**Source:** https://www.examtopics.com/discussions/google/view/147069-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** Workforce Identity Federation, external identity, partner organizations, IdP

---

## Question

Your organization is migrating business critical applications to Google Cloud across multiple projects. You only have the required IAM permission at the Google Cloud organization level. You want to grant project access to support engineers from two partner organizations using their existing identity provider (IdP) credentials. What should you do?
## Choices

- **A.** Create two single sign-on (SSO) profiles for the internal and partner IdPs by using SSO for Cloud Identity.
- **B.** Create users manually by using the Google Cloud console. Assign the users to groups.
- **C.** Create two workforce identity pools for the partner IdPs. Most Voted
- **D.** Sync user identities from their existing IdPs to Cloud Identity by using Google Cloud Directory Sync (GCDS).

---

## Community

**Most Voted:** C


**Votes:** C: 78% | D: 22% (9 total)


**Top Comments:**

- (3 upvotes) I think it's D.

- (2 upvotes) Classic workforce identity use-case because the question references outside identity providers. You wouldn't use GCDS in this scenario.

- (2 upvotes) I meant Workforce Identity Federation :)

---

## Answer

**Correct:** C

**Confidence:** high

### Explanation

Workforce Identity Federation is the correct solution for granting external partner organizations access to Google Cloud resources using their existing IdP credentials. The documentation explicitly describes this scenario: "Enterprise Example Organization can create a separate workforce pool for partner company employees, then grant that pool's administrator permissions to configure access through their own IdP."

Key advantages of workforce identity pools for this use case:

1. **Syncless Architecture**: No need to synchronize user accounts from partner IdPs to Cloud Identity - users authenticate directly with their existing credentials
2. **Multi-Organization Support**: Creating two separate workforce identity pools (one per partner organization) provides clear organizational separation and independent management
3. **Organization-Level Configuration**: Workforce identity pools are configured at the Google Cloud organization level, which aligns with the requirement that you only have IAM permissions at the org level
4. **Partner Control**: Each partner organization can manage their own users and authentication policies through their existing IdP
5. **IAM Integration**: Once configured, you can grant IAM permissions to the workforce identity pools to access projects across your organization

The workforce identity pool acts as a container that groups external identities and allows you to apply IAM policies to those federated identities without creating Google Cloud user accounts.

### Why Other Options Are Wrong

- **A:** SSO for Cloud Identity is designed for internal workforce federation and requires Cloud Identity user accounts. It's not the appropriate solution for external partner organizations that should remain completely independent with their own IdPs. Additionally, SSO profiles don't provide the same level of organizational separation and access control needed for external partners.

- **B:** Manually creating users is inefficient, doesn't scale, and defeats the purpose of using existing IdP credentials. This approach would require ongoing manual maintenance as partner engineers join/leave and doesn't leverage the partners' existing identity management systems.

- **D:** Google Cloud Directory Sync (GCDS) is designed to synchronize identities from an on-premises directory (like Active Directory) to Cloud Identity. It's not appropriate for external partner organizations who should maintain their own separate identity systems. GCDS would require partner organizations to grant you access to their identity infrastructure, which is a security and governance concern.

### References

- [Workforce Identity Federation](https://docs.cloud.google.com/iam/docs/workforce-identity-federation)
- [Configure Workforce Identity Federation](https://docs.cloud.google.com/iam/docs/configuring-workforce-identity-federation)
