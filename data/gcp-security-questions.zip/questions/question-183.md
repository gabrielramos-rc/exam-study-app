# Question 183

**Source:** https://www.examtopics.com/discussions/google/view/117158-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 3.1 - Protecting sensitive data and preventing data loss
**Tags:** Sensitive Data Protection, DLP, date shifting, de-identification, BigQuery

---

## Question

Your company conducts clinical trials and needs to analyze the results of a recent study that are stored in BigQuery. The interval when the medicine was taken contains start and stop dates. The interval data is critical to the analysis, but specific dates may identify a particular batch and introduce bias. You need to obfuscate the start and end dates for each row and preserve the interval data. What should you do?
## Choices

- **A.** Use date shifting with the context set to the unique ID of the test subject. Most Voted
- **B.** Extract the date using TimePartConfig from each date field and append a random month and year.
- **C.** Use bucketing to shift values to a predetermined date based on the initial value.
- **D.** Use the FFX mode of format preserving encryption (FPE) and maintain data consistency.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (11 total)


**Top Comments:**

- (4 upvotes) Option A is good

- (3 upvotes) A- date shifting.

- (2 upvotes) Option A and D works, but the focus here is to preserve the interval data. So option A is more suited in this case. "Date shifting techniques randomly shift a set of dates but preserve the sequence an

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Date shifting with context is the ideal technique for this clinical trial scenario. By setting the context to the unique ID of the test subject (using the `entity_field_id` parameter in Cloud DLP), all dates belonging to a single test subject are shifted by the same random amount of time. This approach provides exactly what's needed:

**Preserves interval data:** The time duration between start and stop dates remains identical for each subject. If a subject took medicine for 14 days in the original data, the shifted dates will still show a 14-day interval.

**Obfuscates specific dates:** Each subject's dates are shifted by a different random amount (within configured bounds), preventing identification of particular batches while eliminating bias.

**Maintains analytical integrity:** The chronological sequence and temporal relationships are preserved per subject, allowing meaningful analysis of the study results.

**Consistent transformation:** Using a cryptographic key ensures reproducible shifts across multiple de-identification operations on the same dataset.

The Cloud DLP date shifting transformation is specifically designed for scenarios like clinical trials where temporal relationships must be preserved while protecting identifiable information.

### Why Other Options Are Wrong

- **B:** TimePartConfig extraction with random month/year appending would destroy the interval data completely. You would lose the actual duration between start and stop dates, making it impossible to analyze how long subjects took the medicine. This breaks the core requirement of preserving interval data.

- **C:** Bucketing shifts values to predetermined dates, which does not preserve the precise interval duration between start and stop dates for each subject. Bucketing groups dates into ranges (e.g., all dates in Q1 2023 become "2023-01-01"), which loses the granular day-level intervals needed for clinical trial analysis.

- **D:** FFX format-preserving encryption (FPE) maintains the format (dates remain dates) and consistency (same input produces same output), but it doesn't preserve the temporal relationships or intervals between dates. FPE encrypts each date independently, so the duration between encrypted start and stop dates would be meaningless for analysis.

### References

- [Date shifting | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/concepts-date-shifting)
- [De-identifying sensitive data | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/deidentify-sensitive-data)
- [Transformation reference | Sensitive Data Protection](https://docs.cloud.google.com/sensitive-data-protection/docs/transformations-reference)
