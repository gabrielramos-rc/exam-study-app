# Question 229

**Source:** https://www.examtopics.com/discussions/google/view/117243-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 5.1 - Adhering to regulatory and industry standards requirements
**Tags:** GDPR, organization policy, resource location restriction, data residency, compliance

---

## Question

Your organization wants to be General Data Protection Regulation (GDPR) compliant. You want to ensure that your DevOps teams can only create Google Cloud resources in the Europe regions. What should you do?
## Choices

- **A.** Use Identity-Aware Proxy (IAP) with Access Context Manager to restrict the location of Google Cloud resources.
- **B.** Use the org policy constraint 'Google Cloud Platform – Resource Location Restriction' on your Google Cloud organization node. Most Voted
- **C.** Use the org policy constraint 'Restrict Resource Service Usage' on your Google Cloud organization node.
- **D.** Use Identity and Access Management (IAM) custom roles to ensure that your DevOps team can only create resources in the Europe regions.

---

## Community

**Most Voted:** B


**Votes:** B: 100% (5 total)


**Top Comments:**

- (3 upvotes) Wouldn't that affect everyone under the organization? The location restriction is supposed to be applied only to the devops team and I imagine there are other teams/groups within the organization as w

- (2 upvotes) Correct answer is B https://cloud.google.com/resource-manager/docs/organization-policy/defining-locations

- (2 upvotes) I think While custom IAM roles can control permissions within projects, they do not inherently enforce geographic location restrictions on resource creation. Your thoughts ?

---

## Answer

**Correct:** B

**Confidence:** high

### Explanation

The organization policy constraint **"Google Cloud Platform - Resource Location Restriction"** (constraint ID: `gcp.resourceLocations`) is specifically designed to restrict where Google Cloud resources can be created based on geographic location. When applied at the organization node, this policy constraint:

1. **Enforces geographic restrictions** - Prevents creation of new resources outside specified regions (e.g., Europe)
2. **Applies organization-wide** - When set at the organization level, it cascades down to all folders and projects, ensuring DevOps teams cannot bypass the restriction
3. **Supports region groups** - You can use value groups like `in:europe-locations` which automatically includes all European regions (Belgium, Germany, Poland, Finland, etc.)
4. **GDPR compliance** - Directly addresses data residency requirements by ensuring resources stay within the EU, which is critical for GDPR compliance

The configuration is straightforward:
```yaml
name: organizations/ORG_ID/policies/gcp.resourceLocations
spec:
  rules:
  - values:
      allowedValues:
      - in:europe-locations
```

This is the recommended approach for organizations that need to enforce geographic constraints for compliance reasons, as it provides a centralized, enforceable control that cannot be overridden by individual teams without proper organization-level permissions.

### Why Other Options Are Wrong

- **A:** Identity-Aware Proxy (IAP) is used for context-aware access control to applications and VMs, not for restricting resource creation locations. Access Context Manager defines access levels based on attributes like device status, IP address, and user identity - but neither IAP nor Access Context Manager can enforce geographic resource placement constraints.

- **C:** The "Restrict Resource Service Usage" constraint is used to limit which Google Cloud services can be used within a project or organization, not where resources can be created geographically. This constraint helps you control service usage (e.g., allowing only specific APIs), but it does not enforce location restrictions.

- **D:** IAM custom roles control what actions users can perform (permissions), not where resources can be created. While you could theoretically create complex custom roles with location-specific permissions, IAM is fundamentally about authorization (who can do what), not about enforcing geographic placement. This would be extremely difficult to implement and maintain, and would not provide reliable location enforcement.

### References

- [Restricting Resource Locations | Resource Manager | Google Cloud](https://docs.cloud.google.com/resource-manager/docs/organization-policy/defining-locations)
- [Organization Policy Constraints | Resource Manager | Google Cloud](https://docs.cloud.google.com/resource-manager/docs/organization-policy/org-policy-constraints)
- [Resource Locations Supported Services | Google Cloud](https://docs.cloud.google.com/resource-manager/docs/organization-policy/defining-locations-supported-services)
