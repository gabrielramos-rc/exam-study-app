# Question 242

**Source:** https://www.examtopics.com/discussions/google/view/126782-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.5 - Defining the resource hierarchy
**Tags:** organization policy, constraints/iam.allowedPolicyMemberDomains, inheritFromParent, resource hierarchy, domain restriction

---

## Question

Your Google Cloud environment has one organization node, one folder named “Apps”, and several projects within that folder. The organizational node enforces the constraints/iam.allowedPolicyMemberDomains organization policy, which allows members from the terramearth.com organization. The “Apps” folder enforces the constraints/iam.allowedPolicyMemberDomains organization policy, which allows members from the flowlogistic.com organization. It also has the inheritFromParent: false property. You attempt to grant access to a project in the “Apps” folder to the user testuser@terramearth.com. What is the result of your action and why?
## Choices

- **A.** The action succeeds because members from both organizations, terramearth.com or flowlogistic.com, are allowed on projects in the "Apps" folder.
- **B.** The action succeeds and the new member is successfully added to the project's Identity and Access Management (IAM) policy because all policies are inherited by underlying folders and projects.
- **C.** The action fails because a constraints/iam.allowedPolicyMemberDomains organization policy must be defined on the current project to deactivate the constraint temporarily.
- **D.** The action fails because a constraints/iam.allowedPolicyMemberDomains organization policy is in place and only members from the flowlogistic.com organization are allowed. Most Voted

---

## Community

**Most Voted:** D


**Votes:** D: 100% (9 total)


**Top Comments:**

- (5 upvotes) The action fails because a constraints/iam.allowedPolicyMemberDomains organization policy is in place and only members from the flowlogistic.com organization are allowed

- (1 upvotes) The correct answer is D. The action fails because a constraints/iam.allowedPolicyMemberDomains organization policy is in place and only members from the flowlogistic.com organization are allowed. The 

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

The action fails because when the "Apps" folder sets `inheritFromParent: false`, it **completely disregards the parent organization node's policy**. According to Google Cloud documentation, "If a resource has a policy that includes `inheritFromParent = false`, it doesn't inherit the organization policy from its parent."

In this scenario:
- The **organization node** allows members from `terramearth.com`
- The **"Apps" folder** sets `inheritFromParent: false` AND allows only `flowlogistic.com`
- Projects within the "Apps" folder inherit the folder's policy (not the organization's)

Since `inheritFromParent: false` breaks the inheritance chain, projects in the "Apps" folder are governed solely by the folder's policy, which allows only `flowlogistic.com` members. Attempting to grant access to `testuser@terramearth.com` violates this constraint and the action fails.

### Why Other Options Are Wrong

- **A:** Incorrect. The `inheritFromParent: false` setting means the parent's `terramearth.com` allowance is NOT inherited. Only `flowlogistic.com` members are allowed, not both organizations.

- **B:** Incorrect. This fundamentally misunderstands the `inheritFromParent: false` property. When set to false, policies are NOT inherited from parent resources. The "Apps" folder explicitly blocks inheritance from the organization node.

- **C:** Incorrect. There is no requirement to define the policy at the project level to "deactivate the constraint temporarily." The constraint is already active at the folder level with `inheritFromParent: false`, which is sufficient to enforce the restriction. Projects automatically inherit their parent folder's policy.

### References

- [Understanding hierarchy evaluation | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/organization-policy/understanding-hierarchy)
- [Restricting identities by domain | Resource Manager](https://docs.cloud.google.com/resource-manager/docs/organization-policy/restricting-domains)
