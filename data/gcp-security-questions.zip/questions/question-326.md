# Question 326

**Source:** https://www.examtopics.com/discussions/google/view/306214-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.1 - Building and deploying infrastructure and application assets
**Tags:** GKE, node auto-upgrades, patch management, maintenance windows, operational security

---

## Question

Your organization deploys a large number of containerized applications on Google Kubernetes Engine (GKE). Node updates are currently applied manually. Audit findings show that a critical patch has not been installed due to a missed notification. You need to design a more reliable, cloud-first, and scalable process for node updates. What should you do?
## Choices

- **A.** Configure node auto-upgrades for node pools in the maintenance windows. Most Voted
- **B.** Develop a custom script to continuously check for patch availability, download patches, and apply the patches across all components of the cluster.
- **C.** Migrate the cluster infrastructure to a self-managed Kubernetes environment for greater control over the patching process.
- **D.** Schedule a daily reboot for all nodes to automatically upgrade.

---

## Community

**Most Voted:** A


**Votes:** A: 100% (2 total)


**Top Comments:**

- (1 upvotes) A is correct

---

## Answer

**Correct:** A

**Confidence:** high

### Explanation

Option A is the correct cloud-native approach for ensuring GKE nodes remain patched and secure. Node auto-upgrades is a built-in GKE feature that automatically applies security patches and updates when they become available, addressing the exact problem described - missed notifications and manual processes that led to critical patches not being installed.

Key benefits of this approach:

1. **Automated Security Updates**: GKE automatically ensures security updates are applied and kept up to date, eliminating the risk of missed notifications that caused the audit finding.

2. **Maintenance Windows**: Configuring maintenance windows allows you to control when automatic upgrades occur, preventing disruptions during critical business periods while still ensuring timely patching.

3. **Default Recommended Practice**: Node auto-upgrade is enabled by default on new GKE clusters because it's the Google-recommended approach for keeping nodes current.

4. **Reduced Management Burden**: Eliminates manual tracking and updating of nodes, making it scalable across large numbers of containerized applications.

5. **Cloud-First Design**: This is a fully managed GKE feature that leverages Google's automation and security expertise, rather than requiring custom scripts or self-managed infrastructure.

The combination of node auto-upgrades with maintenance windows provides both automation (reliability) and control (scheduling), perfectly addressing the requirement for a "more reliable, cloud-first, and scalable process."

### Why Other Options Are Wrong

- **B:** Developing custom scripts is the opposite of cloud-first. It creates maintenance overhead, requires continuous development and testing, and reintroduces manual processes that can fail. This approach doesn't scale well and contradicts GCP best practices of using managed services.

- **C:** Migrating to self-managed Kubernetes increases operational complexity and management burden significantly. This is the opposite of cloud-first and would make patching more difficult, not easier. Self-managed infrastructure requires more manual intervention, not less.

- **D:** Daily reboots do not automatically upgrade nodes. Rebooting nodes simply restarts them at their current version - it doesn't install patches or upgrades. This would cause daily disruptions without solving the patching problem.

### References

- [Auto-upgrading nodes | Google Kubernetes Engine (GKE)](https://docs.cloud.google.com/kubernetes-engine/docs/how-to/node-auto-upgrades)
- [Maintenance windows and exclusions | Google Kubernetes Engine (GKE)](https://docs.cloud.google.com/kubernetes-engine/docs/concepts/maintenance-windows-and-exclusions)
- [Standard cluster upgrades | Google Kubernetes Engine (GKE)](https://docs.cloud.google.com/kubernetes-engine/docs/concepts/cluster-upgrades)
