# Question 157

**Source:** https://www.examtopics.com/discussions/google/view/79841-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 1.1 - Managing Cloud Identity
**Tags:** super administrator, super admin, MFA, multi-factor authentication, admin account, least privilege

---

## Question

You are in charge of creating a new Google Cloud organization for your company. Which two actions should you take when creating the super administrator accounts? (Choose two.)
## Choices

- **A.** Create an access level in the Google Admin console to prevent super admin from logging in to Google Cloud.
- **B.** Disable any Identity and Access Management (IAM) roles for super admin at the organization level in the Google Cloud Console.
- **C.** Use a physical token to secure the super admin credentials with multi-factor authentication (MFA). Most Voted
- **D.** Use a private connection to create the super admin accounts to avoid sending your credentials over the Internet.
- **E.** Provide non-privileged identities to the super admin users for their day-to-day activities. Most Voted

---

## Community

**Most Voted:** CE


**Votes:** CE: 100% (8 total)


**Top Comments:**

- (9 upvotes) CE are right answer.

- (4 upvotes) CE is the answer. https://cloud.google.com/resource-manager/docs/super-admin-best-practices#discourage_super_admin_account_usage - Use a security key or other physical authentication device to enforce

- (2 upvotes) CE is good

---

## Answer

**Correct:** C, E

**Confidence:** high

### Explanation

**C. Use a physical token to secure the super admin credentials with multi-factor authentication (MFA)** and **E. Provide non-privileged identities to the super admin users for their day-to-day activities** are the correct best practices according to Google Cloud's official super administrator security guidance.

**Option C** is critical because Google explicitly recommends using physical security keys for super admin accounts: "Use a security key or other physical authentication device to enforce two-step verification. For the initial super admin account, ensure that the security key is kept in a safe place, preferably at your physical location." Physical tokens (hardware security keys) provide strong phishing-resistant authentication and are the gold standard for protecting highly privileged accounts.

**Option E** follows the principle of least privilege and separation of duties. Google's documentation states: "Give super admins a separate account that requires a separate login. For example, user alice@example.com could have a super admin account alice-admin@example.com." The guidance also explicitly warns: "We recommend against using Google Workspace or Cloud Identity super admin accounts for day-to-day management of your organization resource." This separation ensures that super admin credentials are rarely used, reducing the attack surface and limiting the risk of credential exposure through phishing, keylogging, or other attacks during routine operations.

### Why Other Options Are Wrong

- **A:** Creating an access level to prevent super admin from logging in to Google Cloud defeats the purpose of having a super admin account. Super admins need the ability to access Google Cloud for emergency recovery and critical administrative tasks. The goal is to restrict casual use, not eliminate access entirely.

- **B:** Disabling IAM roles at the organization level for super admin is incorrect because super admins have inherent permissions through their Google Workspace/Cloud Identity role that cannot and should not be disabled. The super admin role in Cloud Identity/Google Workspace automatically grants the ability to assign themselves any IAM role in the organization, including Organization Administrator. The best practice is to keep super admin separate and use Organization Administrator roles for day-to-day operations instead.

- **D:** Using a private connection to create super admin accounts is unnecessary and impractical. Google Cloud uses encrypted HTTPS connections for all authentication traffic, which provides sufficient protection. Account creation itself doesn't require special network connectivity. The security focus should be on MFA and proper account management, not network-level restrictions during account creation.

### References

- [Super administrator account best practices](https://docs.cloud.google.com/resource-manager/docs/super-admin-best-practices)
- [Prepare your Google Workspace or Cloud Identity account](https://docs.cloud.google.com/architecture/identity/preparing-your-g-suite-or-cloud-identity-account)
