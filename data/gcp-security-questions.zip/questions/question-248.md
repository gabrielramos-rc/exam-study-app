# Question 248

**Source:** https://www.examtopics.com/discussions/google/view/147000-exam-professional-cloud-security-engineer-topic-1-question/
**Section:** 4.2 - Configuring logging, monitoring, and detection
**Tags:** security incidents, incident response, service account impersonation, Security Command Center, Cloud Audit Logs, Event Threat Detection

---

## Question

During a routine security review, your team discovered a suspicious login attempt to impersonate a highly privileged but regularly used service account by an unknown IP address. You need to effectively investigate in order to respond to this potential security incident. What should you do?
## Choices

- **A.** Enable Cloud Audit Logs for the resources that the service account interacts with. Review the logs for further evidence of unauthorized activity.
- **B.** Review Cloud Audit Logs for activity related to the service account. Focus on the time period of the suspicious login attempt.
- **C.** Run a vulnerability scan to identify potentially exploitable weaknesses in systems that use the service account.
- **D.** Check Event Threat Detection in Security Command Center for any related alerts. Cross-reference your findings with Cloud Audit Logs. Most Voted

---

## Community

**Most Voted:** D


**Votes:** B: 33% | D: 67% (9 total)


**Top Comments:**

- (3 upvotes) " need to effectively investigate in order to respond to this potential security incident"

- (2 upvotes) Selected Answer: D

- (2 upvotes) I think it's D.

---

## Answer

**Correct:** D

**Confidence:** high

### Explanation

When investigating a suspicious service account impersonation attempt, the most effective approach is to start with Event Threat Detection in Security Command Center and cross-reference findings with Cloud Audit Logs. Here's why:

**Event Threat Detection** is specifically designed to automatically detect anomalous service account behavior, including suspicious impersonation attempts. It examines Admin Activity Audit Logs and generates findings when it identifies patterns such as:
- Anomalous service account impersonation from unusual IP addresses
- Privilege escalation through service account delegation chains
- Service account access from suspicious user agents

By checking Security Command Center first, you immediately access:
1. **Automated threat detection findings** that have already correlated and analyzed the anomalous activity
2. **Enriched context** including delegation chains, principal information, and anomaly scores
3. **Related findings** that might indicate a broader compromise pattern
4. **Actionable investigation guidance** for the specific threat type

Cross-referencing with Cloud Audit Logs provides the detailed raw event data to:
- Verify the finding details
- Examine the complete timeline of service account activity
- Identify the full scope of potentially compromised actions
- Gather evidence for incident response

This combination provides both high-level threat intelligence (from Security Command Center) and detailed forensic data (from Cloud Audit Logs), enabling a comprehensive investigation.

### Why Other Options Are Wrong

- **A:** Enabling Cloud Audit Logs during an incident investigation is too late. Admin Activity Audit Logs are already enabled by default for all Google Cloud services and cannot be disabled. Attempting to "enable" logs during an active incident wastes critical investigation time and demonstrates a misunderstanding of Google Cloud's audit logging architecture.

- **B:** While reviewing Cloud Audit Logs is an important part of the investigation, starting with raw logs alone is inefficient. You would need to manually search through potentially thousands of log entries to identify the anomalous pattern. Event Threat Detection has already performed this analysis automatically and can immediately highlight the suspicious activity, saving valuable time during incident response.

- **C:** Running a vulnerability scan addresses a different security concern (identifying software vulnerabilities) and does not help investigate the immediate incident of suspicious service account impersonation. Vulnerability scanning is a preventive measure for system hardening, not an incident investigation technique. It would not reveal who accessed the service account, from where, or what actions were performed.

### References

- [Privilege Escalation: Anomalous Impersonation of Service Account for Admin Activity](https://docs.cloud.google.com/security-command-center/docs/findings/threats/anomalous-sa-delegation-impersonation-of-sa-admin-activity)
- [Handle compromised Google Cloud credentials](https://docs.cloud.google.com/docs/security/compromised-credentials)
- [Cloud Audit Logs overview](https://docs.cloud.google.com/logging/docs/audit)
- [Security log analytics in Google Cloud](https://docs.cloud.google.com/architecture/security-log-analytics)
